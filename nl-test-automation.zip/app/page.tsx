"use client"

import  from "../src/main/resources/static/js/chat"

export default function SyntheticV0PageForDeployment() {
  return < />
}