#!/bin/bash

# Setup script for Natural Language Test Automation
# This script helps configure the environment variables and dependencies

echo "=== Natural Language Test Automation Setup ==="
echo ""

# Check if Java is installed
if command -v java &> /dev/null; then
    JAVA_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2)
    echo "✓ Java found: $JAVA_VERSION"
else
    echo "✗ Java not found. Please install Java 17 or higher."
    exit 1
fi

# Check if Maven is installed
if command -v mvn &> /dev/null; then
    MVN_VERSION=$(mvn -version | head -n 1 | cut -d' ' -f3)
    echo "✓ Maven found: $MVN_VERSION"
else
    echo "✗ Maven not found. Please install Maven 3.6 or higher."
    exit 1
fi

echo ""
echo "=== Environment Configuration ==="

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "Creating .env file..."
    cat > .env << EOF
# OpenAI API Configuration
OPENAI_API_KEY=your-openai-api-key-here
OPENAI_API_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-3.5-turbo
OPENAI_MAX_TOKENS=1000
OPENAI_TEMPERATURE=0.1

# Alternative API Configurations (uncomment to use)
# For Anthropic Claude
#OPENAI_API_BASE_URL=https://api.anthropic.com/v1
#OPENAI_MODEL=claude-3-sonnet-20240229

# For Local LLM (like Ollama)
#OPENAI_API_BASE_URL=http://localhost:11434/v1
#OPENAI_MODEL=llama2

# For Azure OpenAI
#OPENAI_API_BASE_URL=https://your-resource.openai.azure.com/openai/deployments/your-deployment
#OPENAI_MODEL=gpt-35-turbo

# Selenium Configuration
SELENIUM_BROWSER=chrome
SELENIUM_HEADLESS=false
SELENIUM_IMPLICIT_WAIT=10
SELENIUM_PAGE_LOAD_TIMEOUT=30
SELENIUM_SCRIPT_TIMEOUT=30
SELENIUM_SCREENSHOT_PATH=screenshots/

# Spring Profile
SPRING_PROFILES_ACTIVE=dev
EOF
    echo "✓ Created .env file with default configuration"
else
    echo "✓ .env file already exists"
fi

# Create directories
echo ""
echo "Creating required directories..."
mkdir -p screenshots
mkdir -p logs
echo "✓ Created screenshots and logs directories"

# Check for Chrome/Chromium
echo ""
echo "=== Browser Check ==="
if command -v google-chrome &> /dev/null || command -v chromium-browser &> /dev/null || command -v chromium &> /dev/null; then
    echo "✓ Chrome/Chromium found"
else
    echo "⚠ Chrome/Chromium not found. Please install Chrome or Chromium for Selenium automation."
fi

# Check for Firefox
if command -v firefox &> /dev/null; then
    echo "✓ Firefox found"
else
    echo "⚠ Firefox not found. Install Firefox if you want to use it for automation."
fi

echo ""
echo "=== Setup Complete ==="
echo ""
echo "Next steps:"
echo "1. Edit the .env file and add your OpenAI API key"
echo "2. Run 'source .env' to load environment variables"
echo "3. Run 'mvn spring-boot:run' to start the application"
echo "4. Open http://localhost:8080 in your browser"
echo ""
echo "For production deployment:"
echo "1. Set environment variables in your deployment platform"
echo "2. Use 'mvn clean package' to build the JAR file"
echo "3. Run with 'java -jar target/nl-test-automation-0.0.1-SNAPSHOT.jar'"
echo ""
