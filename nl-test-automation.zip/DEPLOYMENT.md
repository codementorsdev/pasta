# Deployment Guide

This guide covers various deployment scenarios for the Natural Language Test Automation application.

## 📋 Prerequisites

- Docker and Docker Compose (for containerized deployments)
- Java 17+ and Maven 3.6+ (for local deployments)
- OpenAI API key or compatible LLM API access
- Chrome/Firefox browser (for local development)

## 🏠 Local Development

### Quick Start
\`\`\`bash
# Clone and setup
git clone <repository-url>
cd nl-test-automation
./scripts/setup-environment.sh

# Configure API key
echo "OPENAI_API_KEY=your-key-here" > .env
source .env

# Run application
mvn spring-boot:run
\`\`\`

### Development with Hot Reload
\`\`\`bash
# Enable Spring Boot DevTools
export SPRING_PROFILES_ACTIVE=dev
mvn spring-boot:run

# Application will automatically restart on code changes
\`\`\`

## 🐳 Docker Deployment

### Single Container
\`\`\`bash
# Build image
docker build -t nl-test-automation .

# Run container
docker run -d \
  --name nl-automation \
  -p 8080:8080 \
  -e OPENAI_API_KEY=your-key-here \
  -e SELENIUM_HEADLESS=true \
  -v $(pwd)/screenshots:/app/screenshots \
  -v $(pwd)/logs:/app/logs \
  nl-test-automation
\`\`\`

### Docker Compose (Recommended)
\`\`\`yaml
# docker-compose.yml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "8080:8080"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - SELENIUM_HEADLESS=true
      - SPRING_PROFILES_ACTIVE=prod
    volumes:
      - ./screenshots:/app/screenshots
      - ./logs:/app/logs
    restart: unless-stopped
\`\`\`

\`\`\`bash
# Deploy
echo "OPENAI_API_KEY=your-key-here" > .env
docker-compose up -d
\`\`\`

## ☁️ Cloud Deployments

### Heroku

1. **Prepare application**:
\`\`\`bash
# Create Procfile
echo "web: java -jar target/nl-test-automation-*.jar" > Procfile

# Create system.properties
echo "java.runtime.version=17" > system.properties
\`\`\`

2. **Deploy**:
\`\`\`bash
# Install Heroku CLI and login
heroku create your-app-name

# Add buildpacks
heroku buildpacks:add heroku/java
heroku buildpacks:add https://github.com/heroku/heroku-buildpack-google-chrome

# Set environment variables
heroku config:set OPENAI_API_KEY=your-key
heroku config:set SPRING_PROFILES_ACTIVE=prod
heroku config:set SELENIUM_HEADLESS=true
heroku config:set SELENIUM_BROWSER=chrome

# Deploy
git push heroku main
\`\`\`

### AWS ECS with Fargate

1. **Create ECR repository**:
\`\`\`bash
aws ecr create-repository --repository-name nl-test-automation
\`\`\`

2. **Build and push image**:
\`\`\`bash
# Get login token
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 123456789012.dkr.ecr.us-east-1.amazonaws.com

# Build and tag
docker build -t nl-test-automation .
docker tag nl-test-automation:latest 123456789012.dkr.ecr.us-east-1.amazonaws.com/nl-test-automation:latest

# Push
docker push 123456789012.dkr.ecr.us-east-1.amazonaws.com/nl-test-automation:latest
\`\`\`

3. **Create ECS task definition**:
\`\`\`json
{
  "family": "nl-test-automation",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "2048",
  "executionRoleArn": "arn:aws:iam::123456789012:role/ecsTaskExecutionRole",
  "containerDefinitions": [
    {
      "name": "nl-test-automation",
      "image": "123456789012.dkr.ecr.us-east-1.amazonaws.com/nl-test-automation:latest",
      "portMappings": [
        {
          "containerPort": 8080,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "SPRING_PROFILES_ACTIVE",
          "value": "prod"
        },
        {
          "name": "SELENIUM_HEADLESS",
          "value": "true"
        }
      ],
      "secrets": [
        {
          "name": "OPENAI_API_KEY",
          "valueFrom": "arn:aws:secretsmanager:us-east-1:123456789012:secret:openai-api-key"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/nl-test-automation",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
\`\`\`

### Google Cloud Run

1. **Build and deploy**:
\`\`\`bash
# Set project
gcloud config set project your-project-id

# Build image
gcloud builds submit --tag gcr.io/your-project-id/nl-test-automation

# Deploy to Cloud Run
gcloud run deploy nl-test-automation \
  --image gcr.io/your-project-id/nl-test-automation \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars SPRING_PROFILES_ACTIVE=prod,SELENIUM_HEADLESS=true \
  --set-secrets OPENAI_API_KEY=openai-key:latest \
  --memory 2Gi \
  --cpu 1 \
  --timeout 300
\`\`\`

### Azure Container Instances

\`\`\`bash
# Create resource group
az group create --name nl-automation-rg --location eastus

# Create container instance
az container create \
  --resource-group nl-automation-rg \
  --name nl-test-automation \
  --image your-registry/nl-test-automation:latest \
  --cpu 1 \
  --memory 2 \
  --ports 8080 \
  --environment-variables \
    SPRING_PROFILES_ACTIVE=prod \
    SELENIUM_HEADLESS=true \
  --secure-environment-variables \
    OPENAI_API_KEY=your-key-here \
  --restart-policy Always
\`\`\`

## ⚙️ Kubernetes Deployment

### Basic Deployment

1. **Create namespace**:
\`\`\`bash
kubectl create namespace nl-automation
\`\`\`

2. **Create secret for API key**:
\`\`\`bash
kubectl create secret generic api-secrets \
  --from-literal=openai-key=your-api-key-here \
  -n nl-automation
\`\`\`

3. **Apply deployment**:
\`\`\`yaml
# k8s-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nl-test-automation
  namespace: nl-automation
spec:
  replicas: 2
  selector:
    matchLabels:
      app: nl-test-automation
  template:
    metadata:
      labels:
        app: nl-test-automation
    spec:
      containers:
      - name: app
        image: nl-test-automation:latest
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: "prod"
        - name: SELENIUM_HEADLESS
          value: "true"
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: api-secrets
              key: openai-key
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /api/config/health
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /api/config/health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
---
apiVersion: v1
kind: Service
metadata:
  name: nl-test-automation-service
  namespace: nl-automation
spec:
  selector:
    app: nl-test-automation
  ports:
  - port: 80
    targetPort: 8080
  type: LoadBalancer
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: nl-test-automation-ingress
  namespace: nl-automation
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
spec:
  tls:
  - hosts:
    - your-domain.com
    secretName: nl-automation-tls
  rules:
  - host: your-domain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: nl-test-automation-service
            port:
              number: 80
\`\`\`

\`\`\`bash
kubectl apply -f k8s-deployment.yaml
\`\`\`

### Helm Chart Deployment

1. **Create Helm chart**:
\`\`\`bash
helm create nl-test-automation-chart
\`\`\`

2. **Configure values.yaml**:
\`\`\`yaml
# values.yaml
replicaCount: 2

image:
  repository: nl-test-automation
  tag: latest
  pullPolicy: IfNotPresent

service:
  type: LoadBalancer
  port: 80
  targetPort: 8080

ingress:
  enabled: true
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
  hosts:
    - host: your-domain.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: nl-automation-tls
      hosts:
        - your-domain.com

resources:
  requests:
    memory: "1Gi"
    cpu: "500m"
  limits:
    memory: "2Gi"
    cpu: "1000m"

env:
  SPRING_PROFILES_ACTIVE: "prod"
  SELENIUM_HEADLESS: "true"

secrets:
  OPENAI_API_KEY: "your-api-key-here"
\`\`\`

3. **Deploy with Helm**:
\`\`\`bash
helm install nl-test-automation ./nl-test-automation-chart
\`\`\`

## 🔒 Security Considerations

### Environment Variables
- Never commit API keys to version control
- Use secrets management systems in production
- Rotate API keys regularly

### Network Security
\`\`\`bash
# Use HTTPS in production
# Configure firewall rules
# Implement rate limiting
\`\`\`

### Container Security
\`\`\`dockerfile
# Use non-root user
RUN groupadd -r appuser && useradd -r -g appuser appuser
USER appuser

# Scan images for vulnerabilities
docker scan nl-test-automation:latest
\`\`\`

## 📊 Monitoring and Logging

### Application Metrics
\`\`\`yaml
# Add to application.yml
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
  metrics:
    export:
      prometheus:
        enabled: true
\`\`\`

### Log Aggregation
\`\`\`bash
# Use centralized logging
# ELK Stack, Fluentd, or cloud logging services
\`\`\`

### Health Checks
\`\`\`bash
# Application health endpoint
curl http://your-app/api/config/health

# Kubernetes health checks are configured in deployment
\`\`\`

## 🚀 Performance Optimization

### JVM Tuning
\`\`\`bash
# Set JVM options
export JAVA_OPTS="-Xmx2g -Xms1g -XX:+UseG1GC -XX:MaxGCPauseMillis=200"
\`\`\`

### Resource Limits
\`\`\`yaml
# Kubernetes resource limits
resources:
  requests:
    memory: "1Gi"
    cpu: "500m"
  limits:
    memory: "2Gi"
    cpu: "1000m"
\`\`\`

### Scaling
\`\`\`bash
# Horizontal Pod Autoscaler
kubectl autoscale deployment nl-test-automation --cpu-percent=70 --min=2 --max=10
\`\`\`

## 🔄 CI/CD Pipeline

### GitHub Actions Example
\`\`\`yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up JDK 17
      uses: actions/setup-java@v2
      with:
        java-version: '17'
        distribution: 'temurin'
    
    - name: Build with Maven
      run: mvn clean package -DskipTests
    
    - name: Build Docker image
      run: docker build -t nl-test-automation:${{ github.sha }} .
    
    - name: Deploy to production
      run: |
        # Add your deployment commands here
        echo "Deploying to production..."
\`\`\`

## 🆘 Troubleshooting Deployments

### Common Issues

1. **Out of Memory Errors**:
\`\`\`bash
# Increase memory limits
docker run -m 2g nl-test-automation
# Or in Kubernetes
resources:
  limits:
    memory: "2Gi"
\`\`\`

2. **Chrome/Selenium Issues in Containers**:
\`\`\`dockerfile
# Add to Dockerfile
RUN apt-get update && apt-get install -y \
    --no-install-recommends \
    ca-certificates \
    fonts-liberation \
    libasound2 \
    libatk-bridge2.0-0 \
    libdrm2 \
    libgtk-3-0 \
    libnspr4 \
    libnss3 \
    libx11-xcb1 \
    libxcomposite1 \
    libxdamage1 \
    libxrandr2 \
    xdg-utils
\`\`\`

3. **WebSocket Connection Issues**:
\`\`\`bash
# Check proxy/load balancer configuration
# Ensure WebSocket upgrade headers are passed through
\`\`\`

4. **API Rate Limits**:
\`\`\`bash
# Implement exponential backoff
# Monitor API usage
# Consider caching responses
\`\`\`

This deployment guide covers the most common scenarios. Choose the deployment method that best fits your infrastructure and requirements.
