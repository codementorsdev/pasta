# API Documentation

Complete API reference for the Natural Language Test Automation system.

## 📋 Overview

The application provides both REST API endpoints and WebSocket communication for real-time automation. All endpoints return JSON responses and support CORS for cross-origin requests.

## 🔗 Base URL

- **Local Development**: `http://localhost:8080`
- **Production**: `https://your-domain.com`

## 🔐 Authentication

Currently, the API does not require authentication. In production environments, consider implementing:
- API key authentication
- JWT tokens
- OAuth 2.0

## 📡 REST API Endpoints

### Chat Operations

#### Process Natural Language Message

**Endpoint**: `POST /api/chat/message`

**Description**: Processes a natural language instruction and executes corresponding automation actions.

**Request Headers**:
\`\`\`
Content-Type: application/json
\`\`\`

**Request Body**:
\`\`\`json
{
  "message": "Open google.com and search for selenium automation",
  "sessionId": "optional-session-identifier"
}
\`\`\`

**Parameters**:
- `message` (string, required): Natural language instruction
- `sessionId` (string, optional): Browser session identifier. If not provided, a new session will be created.

**Response**:
\`\`\`json
{
  "sessionId": "550e8400-e29b-41d4-a716-446655440000",
  "message": "Processed: Open google.com and search for selenium automation",
  "executionResults": [
    "Browser session started successfully",
    "Successfully navigated to: https://www.google.com (Page title: Google)",
    "Successfully typed text into element: input[name='q']",
    "Successfully pressed key: ENTER",
    "Screenshot saved: screenshots/search_results_20240115_103045.png"
  ],
  "status": "success",
  "timestamp": "2024-01-15T10:30:45.123",
  "screenshotBase64": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="
}
\`\`\`

**Status Codes**:
- `200 OK`: Request processed successfully
- `400 Bad Request`: Invalid request format or missing required fields
- `500 Internal Server Error`: Server error during processing

**Example cURL**:
\`\`\`bash
curl -X POST http://localhost:8080/api/chat/message \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Navigate to github.com and click the sign in button",
    "sessionId": "my-test-session"
  }'
\`\`\`

#### Get Session Status

**Endpoint**: `GET /api/chat/session/{sessionId}/status`

**Description**: Retrieves the current status of a browser session.

**Path Parameters**:
- `sessionId` (string, required): Browser session identifier

**Response**:
\`\`\`json
{
  "sessionId": "550e8400-e29b-41d4-a716-446655440000",
  "message": "Session is active",
  "status": "active",
  "executionResults": [
    "Browser session is active and responsive",
    "Current URL: https://github.com",
    "Page title: GitHub: Let's build from here"
  ],
  "timestamp": "2024-01-15T10:35:22.456",
  "screenshotBase64": "current-page-screenshot-data"
}
\`\`\`

**Status Values**:
- `active`: Browser session is running and responsive
- `inactive`: No browser session found
- `error`: Session exists but has errors

**Example cURL**:
\`\`\`bash
curl http://localhost:8080/api/chat/session/my-test-session/status
\`\`\`

#### Close Session

**Endpoint**: `DELETE /api/chat/session/{sessionId}`

**Description**: Closes a browser session and cleans up resources.

**Path Parameters**:
- `sessionId` (string, required): Browser session identifier

**Response**:
\`\`\`json
{
  "sessionId": "550e8400-e29b-41d4-a716-446655440000",
  "message": "Session closed",
  "executionResults": [
    "Browser session closed successfully",
    "Resources cleaned up"
  ],
  "status": "success",
  "timestamp": "2024-01-15T10:40:15.789"
}
\`\`\`

**Example cURL**:
\`\`\`bash
curl -X DELETE http://localhost:8080/api/chat/session/my-test-session
\`\`\`

### Configuration Operations

#### Get Configuration Information

**Endpoint**: `GET /api/config/info`

**Description**: Returns current application configuration (excluding sensitive information).

**Response**:
\`\`\`json
{
  "openai": {
    "baseUrl": "https://api.openai.com/v1",
    "model": "gpt-3.5-turbo",
    "maxTokens": 1000,
    "temperature": 0.1,
    "apiKeyConfigured": true
  },
  "selenium": {
    "browser": "chrome",
    "headless": false,
    "implicitWait": 10,
    "pageLoadTimeout": 30,
    "scriptTimeout": 30,
    "screenshotPath": "screenshots/"
  },
  "version": "1.0.0",
  "javaVersion": "17.0.2"
}
\`\`\`

**Example cURL**:
\`\`\`bash
curl http://localhost:8080/api/config/info
\`\`\`

#### Health Check

**Endpoint**: `GET /api/config/health`

**Description**: Returns application health status and configuration validation.

**Response**:
\`\`\`json
{
  "status": "UP",
  "timestamp": 1705312345678,
  "openaiConfigured": true,
  "seleniumConfigured": true,
  "checks": {
    "diskSpace": "OK",
    "memory": "OK",
    "webDriver": "OK"
  }
}
\`\`\`

**Example cURL**:
\`\`\`bash
curl http://localhost:8080/api/config/health
\`\`\`

## 🔌 WebSocket API

### Connection

**Endpoint**: `/ws`

**Protocol**: SockJS + STOMP

**Description**: Establishes a WebSocket connection for real-time communication.

### JavaScript Client Example

\`\`\`javascript
// Connect to WebSocket
const socket = new SockJS('/ws');
const stompClient = new StompJs.Client({
  webSocketFactory: () => socket,
  debug: (str) => console.log('STOMP: ' + str),
  reconnectDelay: 5000,
});

stompClient.onConnect = (frame) => {
  console.log('Connected: ' + frame);
  
  // Subscribe to responses
  stompClient.subscribe('/topic/chat', (message) => {
    const response = JSON.parse(message.body);
    handleChatResponse(response);
  });
};

stompClient.activate();

// Send message
function sendMessage(text, sessionId) {
  stompClient.publish({
    destination: '/app/chat',
    body: JSON.stringify({
      message: text,
      sessionId: sessionId
    })
  });
}
\`\`\`

### Message Format

**Send Message** (to `/app/chat`):
\`\`\`json
{
  "message": "Open amazon.com and search for laptops",
  "sessionId": "optional-session-id"
}
\`\`\`

**Receive Response** (from `/topic/chat`):
\`\`\`json
{
  "sessionId": "550e8400-e29b-41d4-a716-446655440000",
  "message": "Processed: Open amazon.com and search for laptops",
  "executionResults": [
    "Successfully navigated to: https://www.amazon.com",
    "Successfully typed text into element: #twotabsearchtextbox",
    "Successfully pressed key: ENTER"
  ],
  "status": "success",
  "timestamp": "2024-01-15T10:45:30.123",
  "screenshotBase64": "base64-screenshot-data"
}
\`\`\`

## 🎯 Automation Commands

### Supported Natural Language Patterns

#### Navigation
\`\`\`
"Open google.com"
"Navigate to https://github.com"
"Go to amazon.com"
"Visit the login page"
\`\`\`

#### Element Interaction
\`\`\`
"Click the submit button"
"Click on the link with text 'Sign In'"
"Type 'hello world' in the search box"
"Enter 'user@example.com' in the email field"
"Clear the password field"
"Select 'United States' from the country dropdown"
\`\`\`

#### Assertions and Verification
\`\`\`
"Verify the page title contains 'Welcome'"
"Check that the heading says 'Dashboard'"
"Assert the login button is visible"
"Confirm the URL contains 'success'"
\`\`\`

#### Advanced Operations
\`\`\`
"Hover over the menu item"
"Press the Enter key"
"Press Tab to move to next field"
"Wait for the loading spinner to disappear"
"Take a screenshot named 'final-result'"
"Scroll down to the footer"
\`\`\`

### Element Selectors

The system automatically determines the best selector strategy:

- **ID**: `#login-button`, `input#email`
- **Class**: `.btn-primary`, `button.submit`
- **CSS Selector**: `input[name='username']`, `.container > .header`
- **XPath**: `//button[text()='Submit']`, `//input[@placeholder='Email']`
- **Text Content**: Elements containing specific text

### Response Status Codes

| Status | Description |
|--------|-------------|
| `success` | Command executed successfully |
| `error` | Error occurred during execution |
| `validation_error` | Invalid request format |
| `timeout` | Operation timed out |
| `element_not_found` | Target element not found |
| `session_not_found` | Browser session not found |

## 📊 Error Handling

### Error Response Format

\`\`\`json
{
  "sessionId": "session-id-if-available",
  "message": "Error processing request",
  "executionResults": [
    "Error: Element not found: #non-existent-button",
    "Suggestion: Try using a more specific selector or wait for the element to load"
  ],
  "status": "error",
  "timestamp": "2024-01-15T10:50:00.000",
  "errorCode": "ELEMENT_NOT_FOUND",
  "errorDetails": {
    "selector": "#non-existent-button",
    "timeout": 10,
    "suggestions": [
      "Check if the element exists on the page",
      "Try using a different selector",
      "Increase wait time if element loads dynamically"
    ]
  }
}
\`\`\`

### Common Error Codes

| Code | Description | Solution |
|------|-------------|----------|
| `ELEMENT_NOT_FOUND` | Target element not found | Use more specific selector or increase wait time |
| `TIMEOUT` | Operation timed out | Increase timeout or check page loading |
| `INVALID_SELECTOR` | Malformed selector | Use valid CSS selector or XPath |
| `SESSION_NOT_FOUND` | Browser session not found | Start a new browser session |
| `API_ERROR` | LLM API error | Check API key and connectivity |
| `BROWSER_ERROR` | WebDriver error | Check browser installation and configuration |

## 🔧 Rate Limiting

### Current Limits

- **REST API**: No rate limiting (consider implementing in production)
- **WebSocket**: No rate limiting
- **LLM API**: Subject to provider's rate limits

### Recommended Production Limits

\`\`\`yaml
# Example rate limiting configuration
rate_limiting:
  requests_per_minute: 60
  requests_per_hour: 1000
  concurrent_sessions: 10
\`\`\`

## 📈 Monitoring and Analytics

### Metrics Endpoints

**Endpoint**: `GET /actuator/metrics`

**Available Metrics**:
- `http.server.requests`: HTTP request metrics
- `jvm.memory.used`: JVM memory usage
- `selenium.sessions.active`: Active browser sessions
- `automation.commands.executed`: Total automation commands
- `automation.commands.failed`: Failed automation commands

**Example**:
\`\`\`bash
curl http://localhost:8080/actuator/metrics/selenium.sessions.active
\`\`\`

### Custom Metrics

The application exposes custom metrics for monitoring:

\`\`\`json
{
  "name": "automation.commands.executed",
  "measurements": [
    {
      "statistic": "COUNT",
      "value": 1250
    }
  ],
  "availableTags": [
    {
      "tag": "command_type",
      "values": ["click", "type", "navigate", "assert"]
    },
    {
      "tag": "status",
      "values": ["success", "error"]
    }
  ]
}
\`\`\`

## 🧪 Testing the API

### Postman Collection

Import this collection to test all endpoints:

\`\`\`json
{
  "info": {
    "name": "NL Test Automation API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Process Message",
      "request": {
        "method": "POST",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"message\": \"Open google.com and search for selenium\",\n  \"sessionId\": \"test-session\"\n}"
        },
        "url": {
          "raw": "{{baseUrl}}/api/chat/message",
          "host": ["{{baseUrl}}"],
          "path": ["api", "chat", "message"]
        }
      }
    }
  ],
  "variable": [
    {
      "key": "baseUrl",
      "value": "http://localhost:8080"
    }
  ]
}
\`\`\`

### Integration Tests

\`\`\`bash
# Run integration tests
mvn test -Dtest=*IntegrationTest

# Test specific endpoint
mvn test -Dtest=ChatControllerIntegrationTest
\`\`\`

This API documentation provides comprehensive information for integrating with the Natural Language Test Automation system. For additional support, refer to the main README or open an issue in the repository.
