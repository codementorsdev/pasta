// Natural Language Test Automation Chat Interface JavaScript

// Import necessary libraries
const SockJS = window.SockJS
const StompJs = window.Stomp
const bootstrap = window.bootstrap

class ChatInterface {
  constructor() {
    this.sessionId = null
    this.stompClient = null
    this.isConnected = false

    this.initializeWebSocket()
    this.bindEvents()
    this.updateSessionDisplay()
  }

  initializeWebSocket() {
    try {
      const socket = new SockJS("/ws")
      this.stompClient = new StompJs.Client({
        webSocketFactory: () => socket,
        debug: (str) => console.log("STOMP: " + str),
        reconnectDelay: 5000,
        heartbeatIncoming: 4000,
        heartbeatOutgoing: 4000,
      })

      this.stompClient.onConnect = (frame) => {
        console.log("Connected: " + frame)
        this.isConnected = true

        this.stompClient.subscribe("/topic/chat", (message) => {
          const response = JSON.parse(message.body)
          this.handleChatResponse(response)
        })
      }

      this.stompClient.onStompError = (frame) => {
        console.error("Broker reported error: " + frame.headers["message"])
        console.error("Additional details: " + frame.body)
        this.isConnected = false
      }

      this.stompClient.activate()
    } catch (error) {
      console.error("WebSocket initialization failed:", error)
      this.isConnected = false
    }
  }

  bindEvents() {
    const messageInput = document.getElementById("messageInput")
    messageInput.addEventListener("keypress", (e) => this.handleKeyPress(e))

    // Auto-resize input
    messageInput.addEventListener("input", function () {
      this.style.height = "auto"
      this.style.height = this.scrollHeight + "px"
    })
  }

  handleKeyPress(event) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault()
      this.sendMessage()
    }
  }

  sendMessage() {
    const messageInput = document.getElementById("messageInput")
    const message = messageInput.value.trim()

    if (!message) {
      return
    }

    // Display user message immediately
    this.addUserMessage(message)

    // Clear input
    messageInput.value = ""
    messageInput.style.height = "auto"

    // Show loading indicator
    this.showLoading(true)

    // Send message via WebSocket or HTTP
    if (this.isConnected && this.stompClient) {
      this.sendViaWebSocket(message)
    } else {
      this.sendViaHTTP(message)
    }
  }

  sendViaWebSocket(message) {
    const chatRequest = {
      message: message,
      sessionId: this.sessionId,
    }

    this.stompClient.publish({
      destination: "/app/chat",
      body: JSON.stringify(chatRequest),
    })
  }

  async sendViaHTTP(message) {
    try {
      const response = await fetch("/api/chat/message", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: message,
          sessionId: this.sessionId,
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const chatResponse = await response.json()
      this.handleChatResponse(chatResponse)
    } catch (error) {
      console.error("Error sending message:", error)
      this.addBotMessage("Sorry, there was an error processing your request. Please try again.")
    } finally {
      this.showLoading(false)
    }
  }

  handleChatResponse(response) {
    this.showLoading(false)

    // Update session ID if provided
    if (response.sessionId && response.sessionId !== this.sessionId) {
      this.sessionId = response.sessionId
      this.updateSessionDisplay()
    }

    // Add bot response message
    this.addBotMessage(response.message, response.executionResults, response.screenshotBase64)

    // Update session status
    this.updateSessionStatus(response.status)
  }

  addUserMessage(message) {
    const chatMessages = document.getElementById("chatMessages")
    const messageElement = this.createMessageElement("user", message)
    chatMessages.appendChild(messageElement)
    this.scrollToBottom()
  }

  addBotMessage(message, executionResults = null, screenshotBase64 = null) {
    const chatMessages = document.getElementById("chatMessages")
    const messageElement = this.createMessageElement("bot", message, executionResults, screenshotBase64)
    chatMessages.appendChild(messageElement)
    this.scrollToBottom()
  }

  createMessageElement(type, message, executionResults = null, screenshotBase64 = null) {
    const messageDiv = document.createElement("div")
    messageDiv.className = `message ${type}-message`

    const avatarDiv = document.createElement("div")
    avatarDiv.className = "message-avatar"
    avatarDiv.innerHTML = type === "user" ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>'

    const contentDiv = document.createElement("div")
    contentDiv.className = "message-content"

    const textDiv = document.createElement("div")
    textDiv.className = "message-text"
    textDiv.textContent = message

    const timeDiv = document.createElement("div")
    timeDiv.className = "message-time"
    timeDiv.textContent = new Date().toLocaleTimeString()

    contentDiv.appendChild(textDiv)
    contentDiv.appendChild(timeDiv)

    // Add execution results if provided
    if (executionResults && executionResults.length > 0) {
      const resultsDiv = document.createElement("div")
      resultsDiv.className = "execution-results"

      const resultsTitle = document.createElement("h6")
      resultsTitle.textContent = "Execution Results:"
      resultsDiv.appendChild(resultsTitle)

      const resultsList = document.createElement("ul")
      executionResults.forEach((result) => {
        const listItem = document.createElement("li")
        listItem.textContent = result

        // Add styling based on result content
        if (result.toLowerCase().includes("success") || result.toLowerCase().includes("passed")) {
          listItem.className = "success"
        } else if (result.toLowerCase().includes("error") || result.toLowerCase().includes("failed")) {
          listItem.className = "error"
        }

        resultsList.appendChild(listItem)
      })

      resultsDiv.appendChild(resultsList)
      contentDiv.appendChild(resultsDiv)
    }

    // Add screenshot if provided
    if (screenshotBase64 && !screenshotBase64.startsWith("Error")) {
      const screenshotDiv = document.createElement("div")
      screenshotDiv.className = "screenshot-container"

      const screenshotImg = document.createElement("img")
      screenshotImg.src = `data:image/png;base64,${screenshotBase64}`
      screenshotImg.className = "screenshot-thumbnail"
      screenshotImg.alt = "Screenshot"
      screenshotImg.onclick = () => this.showScreenshotModal(screenshotBase64)

      screenshotDiv.appendChild(screenshotImg)
      contentDiv.appendChild(screenshotDiv)
    }

    messageDiv.appendChild(avatarDiv)
    messageDiv.appendChild(contentDiv)

    return messageDiv
  }

  showScreenshotModal(screenshotBase64) {
    const modal = new bootstrap.Modal(document.getElementById("screenshotModal"))
    const img = document.getElementById("screenshotImage")
    img.src = `data:image/png;base64,${screenshotBase64}`
    modal.show()
  }

  scrollToBottom() {
    const chatMessages = document.getElementById("chatMessages")
    chatMessages.scrollTop = chatMessages.scrollHeight
  }

  showLoading(show) {
    const loadingIndicator = document.getElementById("loadingIndicator")
    loadingIndicator.style.display = show ? "block" : "none"
  }

  updateSessionDisplay() {
    const sessionIdElement = document.getElementById("sessionId")
    sessionIdElement.textContent = this.sessionId || "Not started"

    if (this.sessionId) {
      sessionIdElement.title = this.sessionId
    }
  }

  updateSessionStatus(status) {
    const statusElement = document.getElementById("sessionStatus")
    statusElement.className = "badge"

    switch (status) {
      case "success":
      case "active":
        statusElement.classList.add("bg-success")
        statusElement.textContent = "Active"
        break
      case "error":
        statusElement.classList.add("bg-danger")
        statusElement.textContent = "Error"
        break
      case "inactive":
        statusElement.classList.add("bg-secondary")
        statusElement.textContent = "Inactive"
        break
      default:
        statusElement.classList.add("bg-secondary")
        statusElement.textContent = "Unknown"
    }
  }

  async closeSession() {
    if (!this.sessionId) {
      this.addBotMessage("No active session to close.")
      return
    }

    try {
      const response = await fetch(`/api/chat/session/${this.sessionId}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()
      this.addBotMessage(result.message, result.executionResults)

      // Reset session
      this.sessionId = null
      this.updateSessionDisplay()
      this.updateSessionStatus("inactive")
    } catch (error) {
      console.error("Error closing session:", error)
      this.addBotMessage("Error closing session. Please try again.")
    }
  }
}

// Global functions for HTML onclick handlers
let chatInterface

function sendQuickMessage(message) {
  const messageInput = document.getElementById("messageInput")
  messageInput.value = message
  chatInterface.sendMessage()
}

function closeSession() {
  chatInterface.closeSession()
}

function handleKeyPress(event) {
  chatInterface.handleKeyPress(event)
}

function sendMessage() {
  chatInterface.sendMessage()
}

// Initialize chat interface when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  chatInterface = new ChatInterface()
})
