package com.automation.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Map;

/**
 * Represents an automation action to be executed
 */
public class AutomationAction {
    
    @JsonProperty("action")
    private String action;
    
    @JsonProperty("parameters")
    private Map<String, Object> parameters;
    
    @JsonProperty("description")
    private String description;
    
    public AutomationAction() {}
    
    public AutomationAction(String action, Map<String, Object> parameters, String description) {
        this.action = action;
        this.parameters = parameters;
        this.description = description;
    }
    
    public String getAction() {
        return action;
    }
    
    public void setAction(String action) {
        this.action = action;
    }
    
    public Map<String, Object> getParameters() {
        return parameters;
    }
    
    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
}
