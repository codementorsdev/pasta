package com.automation.model;

import jakarta.validation.constraints.NotBlank;

/**
 * Request model for chat messages
 */
public class ChatRequest {
    
    @NotBlank(message = "Message cannot be empty")
    private String message;
    
    private String sessionId;
    
    public ChatRequest() {}
    
    public ChatRequest(String message, String sessionId) {
        this.message = message;
        this.sessionId = sessionId;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getSessionId() {
        return sessionId;
    }
    
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
}
