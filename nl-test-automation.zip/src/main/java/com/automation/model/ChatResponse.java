package com.automation.model;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Response model for chat messages
 */
public class ChatResponse {
    
    private String sessionId;
    private String message;
    private List<String> executionResults;
    private String status;
    private LocalDateTime timestamp;
    private String screenshotBase64;
    
    public ChatResponse() {
        this.timestamp = LocalDateTime.now();
    }
    
    public ChatResponse(String sessionId, String message, List<String> executionResults, String status) {
        this.sessionId = sessionId;
        this.message = message;
        this.executionResults = executionResults;
        this.status = status;
        this.timestamp = LocalDateTime.now();
    }
    
    public String getSessionId() {
        return sessionId;
    }
    
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public List<String> getExecutionResults() {
        return executionResults;
    }
    
    public void setExecutionResults(List<String> executionResults) {
        this.executionResults = executionResults;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
    
    public String getScreenshotBase64() {
        return screenshotBase64;
    }
    
    public void setScreenshotBase64(String screenshotBase64) {
        this.screenshotBase64 = screenshotBase64;
    }
}
