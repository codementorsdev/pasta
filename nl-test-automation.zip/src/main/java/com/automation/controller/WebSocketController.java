package com.automation.controller;

import com.automation.model.AutomationAction;
import com.automation.model.ChatRequest;
import com.automation.model.ChatResponse;
import com.automation.service.AutomationOrchestrator;
import com.automation.service.LLMService;
import com.automation.selenium.ScreenshotService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.UUID;

/**
 * WebSocket Controller for real-time chat communication
 */
@Controller
public class WebSocketController {
    
    private static final Logger logger = LoggerFactory.getLogger(WebSocketController.class);
    
    @Autowired
    private LLMService llmService;
    
    @Autowired
    private AutomationOrchestrator automationOrchestrator;
    
    @Autowired
    private ScreenshotService screenshotService;
    
    /**
     * Handles WebSocket chat messages
     * 
     * @param chatRequest The chat request from the client
     * @return ChatResponse to be broadcast to subscribers
     */
    @MessageMapping("/chat")
    @SendTo("/topic/chat")
    public ChatResponse handleChatMessage(ChatRequest chatRequest) {
        try {
            // Generate session ID if not provided
            String sessionId = chatRequest.getSessionId();
            if (sessionId == null || sessionId.trim().isEmpty()) {
                sessionId = UUID.randomUUID().toString();
            }
            
            logger.info("Processing WebSocket chat message for session {}: {}", sessionId, chatRequest.getMessage());
            
            // Process the natural language instruction with LLM
            List<AutomationAction> actions = llmService.processInstruction(sessionId, chatRequest.getMessage());
            
            // Execute the automation actions
            List<String> executionResults = automationOrchestrator.executeActions(sessionId, actions);
            
            // Create response
            ChatResponse response = new ChatResponse(
                sessionId,
                "Processed: " + chatRequest.getMessage(),
                executionResults,
                "success"
            );
            
            // Optionally capture screenshot if browser session exists
            try {
                String screenshot = screenshotService.captureScreenshotAsBase64(sessionId);
                if (screenshot != null && !screenshot.startsWith("Error")) {
                    response.setScreenshotBase64(screenshot);
                }
            } catch (Exception e) {
                logger.debug("Could not capture screenshot for session {}: {}", sessionId, e.getMessage());
            }
            
            logger.info("Successfully processed WebSocket message for session {}", sessionId);
            return response;
            
        } catch (Exception e) {
            logger.error("Error processing WebSocket chat message: {}", chatRequest.getMessage(), e);
            
            return new ChatResponse(
                chatRequest.getSessionId(),
                "Error processing message",
                List.of("Error: " + e.getMessage()),
                "error"
            );
        }
    }
}
