package com.automation.controller;

import com.automation.model.AutomationAction;
import com.automation.model.ChatRequest;
import com.automation.model.ChatResponse;
import com.automation.service.AutomationOrchestrator;
import com.automation.service.LLMService;
import com.automation.selenium.ScreenshotService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

/**
 * REST Controller for handling chat-based automation requests
 */
@RestController
@RequestMapping("/api/chat")
@CrossOrigin(origins = "*")
public class ChatController {
    
    private static final Logger logger = LoggerFactory.getLogger(ChatController.class);
    
    @Autowired
    private LLMService llmService;
    
    @Autowired
    private AutomationOrchestrator automationOrchestrator;
    
    @Autowired
    private ScreenshotService screenshotService;
    
    /**
     * Processes a chat message and executes automation commands
     * 
     * @param chatRequest The chat request containing the user's message
     * @return ChatResponse with execution results
     */
    @PostMapping("/message")
    public ResponseEntity<ChatResponse> processMessage(@Valid @RequestBody ChatRequest chatRequest) {
        try {
            // Generate session ID if not provided
            String sessionId = chatRequest.getSessionId();
            if (sessionId == null || sessionId.trim().isEmpty()) {
                sessionId = UUID.randomUUID().toString();
            }
            
            logger.info("Processing chat message for session {}: {}", sessionId, chatRequest.getMessage());
            
            // Process the natural language instruction with LLM
            List<AutomationAction> actions = llmService.processInstruction(sessionId, chatRequest.getMessage());
            
            // Execute the automation actions
            List<String> executionResults = automationOrchestrator.executeActions(sessionId, actions);
            
            // Create response
            ChatResponse response = new ChatResponse(
                sessionId,
                "Processed: " + chatRequest.getMessage(),
                executionResults,
                "success"
            );
            
            // Optionally capture screenshot if browser session exists
            try {
                String screenshot = screenshotService.captureScreenshotAsBase64(sessionId);
                if (screenshot != null && !screenshot.startsWith("Error")) {
                    response.setScreenshotBase64(screenshot);
                }
            } catch (Exception e) {
                logger.debug("Could not capture screenshot for session {}: {}", sessionId, e.getMessage());
            }
            
            logger.info("Successfully processed message for session {}", sessionId);
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error processing chat message: {}", chatRequest.getMessage(), e);
            
            ChatResponse errorResponse = new ChatResponse(
                chatRequest.getSessionId(),
                "Error processing message",
                List.of("Error: " + e.getMessage()),
                "error"
            );
            
            return ResponseEntity.ok(errorResponse);
        }
    }
    
    /**
     * Gets the current status of a browser session
     * 
     * @param sessionId Browser session identifier
     * @return Session status information
     */
    @GetMapping("/session/{sessionId}/status")
    public ResponseEntity<ChatResponse> getSessionStatus(@PathVariable String sessionId) {
        try {
            logger.info("Getting status for session: {}", sessionId);
            
            // Try to capture a screenshot to verify session is active
            String screenshot = screenshotService.captureScreenshotAsBase64(sessionId);
            
            ChatResponse response = new ChatResponse();
            response.setSessionId(sessionId);
            
            if (screenshot != null && !screenshot.startsWith("Error")) {
                response.setMessage("Session is active");
                response.setStatus("active");
                response.setScreenshotBase64(screenshot);
                response.setExecutionResults(List.of("Browser session is active and responsive"));
            } else {
                response.setMessage("Session not found or inactive");
                response.setStatus("inactive");
                response.setExecutionResults(List.of("No active browser session found"));
            }
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error getting session status for: {}", sessionId, e);
            
            ChatResponse errorResponse = new ChatResponse();
            errorResponse.setSessionId(sessionId);
            errorResponse.setMessage("Error checking session status");
            errorResponse.setStatus("error");
            errorResponse.setExecutionResults(List.of("Error: " + e.getMessage()));
            
            return ResponseEntity.ok(errorResponse);
        }
    }
    
    /**
     * Closes a browser session
     * 
     * @param sessionId Browser session identifier
     * @return Closure confirmation
     */
    @DeleteMapping("/session/{sessionId}")
    public ResponseEntity<ChatResponse> closeSession(@PathVariable String sessionId) {
        try {
            logger.info("Closing session: {}", sessionId);
            
            // Execute close browser action
            List<AutomationAction> closeAction = List.of(
                new AutomationAction("closeBrowser", null, "Close browser session")
            );
            
            List<String> results = automationOrchestrator.executeActions(sessionId, closeAction);
            
            ChatResponse response = new ChatResponse(
                sessionId,
                "Session closed",
                results,
                "success"
            );
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error closing session: {}", sessionId, e);
            
            ChatResponse errorResponse = new ChatResponse(
                sessionId,
                "Error closing session",
                List.of("Error: " + e.getMessage()),
                "error"
            );
            
            return ResponseEntity.ok(errorResponse);
        }
    }
}
