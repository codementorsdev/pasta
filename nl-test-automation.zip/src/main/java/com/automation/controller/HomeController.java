package com.automation.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for serving the main chat UI
 */
@Controller
public class HomeController {
    
    /**
     * Serves the main chat interface
     * 
     * @param model Spring MVC model
     * @return Template name for the chat interface
     */
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("title", "Natural Language Test Automation");
        model.addAttribute("description", "Chat-based web automation using AI and Selenium");
        return "chat";
    }
    
    /**
     * Serves the chat interface (alternative route)
     * 
     * @param model Spring MVC model
     * @return Template name for the chat interface
     */
    @GetMapping("/chat")
    public String chat(Model model) {
        model.addAttribute("title", "Natural Language Test Automation");
        model.addAttribute("description", "Chat-based web automation using AI and Selenium");
        return "chat";
    }
}
