package com.automation.selenium;

import com.automation.config.SeleniumConfig;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Service for managing WebDriver instances
 * 
 * This service handles the creation, configuration, and lifecycle management
 * of WebDriver instances for different browsers.
 */
@Service
public class BrowserService {
    
    private static final Logger logger = LoggerFactory.getLogger(BrowserService.class);
    private final ConcurrentMap<String, WebDriver> driverInstances = new ConcurrentHashMap<>();
    
    @Autowired
    private SeleniumConfig seleniumConfig;
    
    /**
     * Creates and configures a new WebDriver instance
     * 
     * @param sessionId Unique identifier for this browser session
     * @return Configured WebDriver instance
     */
    public WebDriver createDriver(String sessionId) {
        logger.info("Creating new WebDriver instance for session: {}", sessionId);
        
        WebDriver driver;
        String browser = seleniumConfig.getBrowser().toLowerCase();
        
        switch (browser) {
            case "chrome":
                driver = createChromeDriver();
                break;
            case "firefox":
                driver = createFirefoxDriver();
                break;
            default:
                logger.warn("Unsupported browser: {}. Defaulting to Chrome.", browser);
                driver = createChromeDriver();
        }
        
        // Configure timeouts
        driver.manage().timeouts()
                .implicitlyWait(Duration.ofSeconds(seleniumConfig.getImplicitWait()))
                .pageLoadTimeout(Duration.ofSeconds(seleniumConfig.getPageLoadTimeout()))
                .scriptTimeout(Duration.ofSeconds(seleniumConfig.getScriptTimeout()));
        
        // Maximize window if not headless
        if (!seleniumConfig.isHeadless()) {
            driver.manage().window().maximize();
        }
        
        driverInstances.put(sessionId, driver);
        logger.info("WebDriver instance created successfully for session: {}", sessionId);
        
        return driver;
    }
    
    /**
     * Creates a Chrome WebDriver instance with appropriate options
     */
    private WebDriver createChromeDriver() {
        WebDriverManager.chromedriver().setup();
        
        ChromeOptions options = new ChromeOptions();
        if (seleniumConfig.isHeadless()) {
            options.addArguments("--headless");
        }
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-gpu");
        options.addArguments("--window-size=1920,1080");
        
        return new ChromeDriver(options);
    }
    
    /**
     * Creates a Firefox WebDriver instance with appropriate options
     */
    private WebDriver createFirefoxDriver() {
        WebDriverManager.firefoxdriver().setup();
        
        FirefoxOptions options = new FirefoxOptions();
        if (seleniumConfig.isHeadless()) {
            options.addArguments("--headless");
        }
        options.addArguments("--width=1920");
        options.addArguments("--height=1080");
        
        return new FirefoxDriver(options);
    }
    
    /**
     * Retrieves an existing WebDriver instance for a session
     * 
     * @param sessionId Session identifier
     * @return WebDriver instance or null if not found
     */
    public WebDriver getDriver(String sessionId) {
        return driverInstances.get(sessionId);
    }
    
    /**
     * Closes and removes a WebDriver instance
     * 
     * @param sessionId Session identifier
     */
    public void closeDriver(String sessionId) {
        WebDriver driver = driverInstances.remove(sessionId);
        if (driver != null) {
            try {
                driver.quit();
                logger.info("WebDriver instance closed for session: {}", sessionId);
            } catch (Exception e) {
                logger.error("Error closing WebDriver for session: {}", sessionId, e);
            }
        }
    }
    
    /**
     * Closes all active WebDriver instances
     */
    public void closeAllDrivers() {
        logger.info("Closing all WebDriver instances");
        driverInstances.forEach((sessionId, driver) -> {
            try {
                driver.quit();
            } catch (Exception e) {
                logger.error("Error closing WebDriver for session: {}", sessionId, e);
            }
        });
        driverInstances.clear();
    }
}
