package com.automation.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;

/**
 * Service for handling explicit waits in Selenium
 */
@Service
public class WaitService {
    
    private static final Logger logger = LoggerFactory.getLogger(WaitService.class);
    
    @Autowired
    private BrowserService browserService;
    
    /**
     * Waits for an element to be visible
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @param timeoutSeconds Maximum time to wait in seconds
     * @return WebElement if found, null otherwise
     */
    public WebElement waitForElementToBeVisible(String sessionId, String selector, int timeoutSeconds) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                logger.error("No browser session found for: {}", sessionId);
                return null;
            }
            
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
            By locator = parseSelector(selector);
            
            logger.debug("Waiting for element to be visible: {} (timeout: {}s)", selector, timeoutSeconds);
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            
        } catch (Exception e) {
            logger.error("Element not visible within timeout: {} for session: {}", selector, sessionId, e);
            return null;
        }
    }
    
    /**
     * Waits for an element to be clickable
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @param timeoutSeconds Maximum time to wait in seconds
     * @return WebElement if found and clickable, null otherwise
     */
    public WebElement waitForElementToBeClickable(String sessionId, String selector, int timeoutSeconds) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                logger.error("No browser session found for: {}", sessionId);
                return null;
            }
            
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
            By locator = parseSelector(selector);
            
            logger.debug("Waiting for element to be clickable: {} (timeout: {}s)", selector, timeoutSeconds);
            return wait.until(ExpectedConditions.elementToBeClickable(locator));
            
        } catch (Exception e) {
            logger.error("Element not clickable within timeout: {} for session: {}", selector, sessionId, e);
            return null;
        }
    }
    
    /**
     * Waits for an element to be present in DOM
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @param timeoutSeconds Maximum time to wait in seconds
     * @return WebElement if found, null otherwise
     */
    public WebElement waitForElementToBePresent(String sessionId, String selector, int timeoutSeconds) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                logger.error("No browser session found for: {}", sessionId);
                return null;
            }
            
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
            By locator = parseSelector(selector);
            
            logger.debug("Waiting for element to be present: {} (timeout: {}s)", selector, timeoutSeconds);
            return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            
        } catch (Exception e) {
            logger.error("Element not present within timeout: {} for session: {}", selector, sessionId, e);
            return null;
        }
    }
    
    /**
     * Waits for text to be present in an element
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @param text Text to wait for
     * @param timeoutSeconds Maximum time to wait in seconds
     * @return true if text is present, false otherwise
     */
    public boolean waitForTextToBePresent(String sessionId, String selector, String text, int timeoutSeconds) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                logger.error("No browser session found for: {}", sessionId);
                return false;
            }
            
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
            By locator = parseSelector(selector);
            
            logger.debug("Waiting for text '{}' to be present in element: {} (timeout: {}s)", text, selector, timeoutSeconds);
            return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
            
        } catch (Exception e) {
            logger.error("Text '{}' not present in element {} within timeout for session: {}", text, selector, sessionId, e);
            return false;
        }
    }
    
    /**
     * Converts selector string to By object
     * 
     * @param selector Selector string (supports CSS, XPath, ID, etc.)
     * @return By object for element location
     */
    private By parseSelector(String selector) {
        if (selector.startsWith("//") || selector.startsWith("(")) {
            return By.xpath(selector);
        } else if (selector.startsWith("#")) {
            return By.id(selector.substring(1));
        } else if (selector.startsWith(".")) {
            return By.className(selector.substring(1));
        } else {
            return By.cssSelector(selector);
        }
    }
}
