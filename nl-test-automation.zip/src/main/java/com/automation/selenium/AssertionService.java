package com.automation.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service for performing assertions and validations on web elements
 */
@Service
public class AssertionService {
    
    private static final Logger logger = LoggerFactory.getLogger(AssertionService.class);
    
    @Autowired
    private BrowserService browserService;
    
    @Autowired
    private WaitService waitService;
    
    /**
     * Asserts that an element contains the expected text
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @param expectedText Expected text content
     * @return Assertion result message
     */
    public String assertTextPresent(String sessionId, String selector, String expectedText) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Asserting text '{}' is present in element: {} for session: {}", expectedText, selector, sessionId);
            
            WebElement element = waitService.waitForElementToBeVisible(sessionId, selector, 10);
            if (element == null) {
                return "Assertion failed: Element not found: " + selector;
            }
            
            String actualText = element.getText();
            if (actualText.contains(expectedText)) {
                logger.info("Assertion passed: Text '{}' found in element: {}", expectedText, selector);
                return "Assertion passed: Text '" + expectedText + "' found in element: " + selector;
            } else {
                logger.warn("Assertion failed: Expected '{}', but found '{}' in element: {}", expectedText, actualText, selector);
                return "Assertion failed: Expected '" + expectedText + "', but found '" + actualText + "' in element: " + selector;
            }
            
        } catch (Exception e) {
            logger.error("Error during text assertion for element: {} for session: {}", selector, sessionId, e);
            return "Error during assertion: " + e.getMessage();
        }
    }
    
    /**
     * Asserts that an element is visible on the page
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @return Assertion result message
     */
    public String assertElementVisible(String sessionId, String selector) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Asserting element is visible: {} for session: {}", selector, sessionId);
            
            WebElement element = waitService.waitForElementToBeVisible(sessionId, selector, 10);
            if (element != null && element.isDisplayed()) {
                logger.info("Assertion passed: Element is visible: {}", selector);
                return "Assertion passed: Element is visible: " + selector;
            } else {
                logger.warn("Assertion failed: Element is not visible: {}", selector);
                return "Assertion failed: Element is not visible: " + selector;
            }
            
        } catch (Exception e) {
            logger.error("Error during visibility assertion for element: {} for session: {}", selector, sessionId, e);
            return "Error during assertion: " + e.getMessage();
        }
    }
    
    /**
     * Asserts that the current page title matches the expected title
     * 
     * @param sessionId Browser session identifier
     * @param expectedTitle Expected page title
     * @return Assertion result message
     */
    public String assertPageTitle(String sessionId, String expectedTitle) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Asserting page title is: {} for session: {}", expectedTitle, sessionId);
            
            String actualTitle = driver.getTitle();
            if (actualTitle.equals(expectedTitle)) {
                logger.info("Assertion passed: Page title matches: {}", expectedTitle);
                return "Assertion passed: Page title matches: " + expectedTitle;
            } else {
                logger.warn("Assertion failed: Expected title '{}', but found '{}'", expectedTitle, actualTitle);
                return "Assertion failed: Expected title '" + expectedTitle + "', but found '" + actualTitle + "'";
            }
            
        } catch (Exception e) {
            logger.error("Error during title assertion for session: {}", sessionId, e);
            return "Error during assertion: " + e.getMessage();
        }
    }
    
    /**
     * Asserts that the current URL contains the expected text
     * 
     * @param sessionId Browser session identifier
     * @param expectedUrlPart Expected URL part
     * @return Assertion result message
     */
    public String assertUrlContains(String sessionId, String expectedUrlPart) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Asserting URL contains: {} for session: {}", expectedUrlPart, sessionId);
            
            String currentUrl = driver.getCurrentUrl();
            if (currentUrl.contains(expectedUrlPart)) {
                logger.info("Assertion passed: URL contains: {}", expectedUrlPart);
                return "Assertion passed: URL contains: " + expectedUrlPart;
            } else {
                logger.warn("Assertion failed: URL '{}' does not contain '{}'", currentUrl, expectedUrlPart);
                return "Assertion failed: URL '" + currentUrl + "' does not contain '" + expectedUrlPart + "'";
            }
            
        } catch (Exception e) {
            logger.error("Error during URL assertion for session: {}", sessionId, e);
            return "Error during assertion: " + e.getMessage();
        }
    }
}
