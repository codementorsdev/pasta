package com.automation.selenium;

import com.automation.config.SeleniumConfig;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

/**
 * Service for capturing and managing screenshots
 */
@Service
public class ScreenshotService {
    
    private static final Logger logger = LoggerFactory.getLogger(ScreenshotService.class);
    
    @Autowired
    private BrowserService browserService;
    
    @Autowired
    private SeleniumConfig seleniumConfig;
    
    /**
     * Captures a screenshot and saves it to the configured directory
     * 
     * @param sessionId Browser session identifier
     * @param name Optional name for the screenshot (timestamp will be added)
     * @return Path to the saved screenshot or error message
     */
    public String captureScreenshot(String sessionId, String name) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            if (!(driver instanceof TakesScreenshot)) {
                return "Error: WebDriver does not support screenshots.";
            }
            
            // Create screenshots directory if it doesn't exist
            Path screenshotDir = Paths.get(seleniumConfig.getScreenshotPath());
            if (!Files.exists(screenshotDir)) {
                Files.createDirectories(screenshotDir);
            }
            
            // Generate filename with timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String filename = (name != null && !name.trim().isEmpty()) 
                ? name + "_" + timestamp + ".png"
                : "screenshot_" + timestamp + ".png";
            
            Path screenshotPath = screenshotDir.resolve(filename);
            
            // Capture screenshot
            TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
            File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
            
            // Save screenshot
            Files.copy(sourceFile.toPath(), screenshotPath);
            
            logger.info("Screenshot captured and saved: {} for session: {}", screenshotPath, sessionId);
            return "Screenshot saved: " + screenshotPath.toString();
            
        } catch (IOException e) {
            logger.error("Error saving screenshot for session: {}", sessionId, e);
            return "Error saving screenshot: " + e.getMessage();
        } catch (Exception e) {
            logger.error("Error capturing screenshot for session: {}", sessionId, e);
            return "Error capturing screenshot: " + e.getMessage();
        }
    }
    
    /**
     * Captures a screenshot and returns it as a base64 encoded string
     * 
     * @param sessionId Browser session identifier
     * @return Base64 encoded screenshot or error message
     */
    public String captureScreenshotAsBase64(String sessionId) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            if (!(driver instanceof TakesScreenshot)) {
                return "Error: WebDriver does not support screenshots.";
            }
            
            TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
            byte[] screenshotBytes = takesScreenshot.getScreenshotAs(OutputType.BYTES);
            
            String base64Screenshot = Base64.getEncoder().encodeToString(screenshotBytes);
            logger.info("Screenshot captured as base64 for session: {}", sessionId);
            
            return base64Screenshot;
            
        } catch (Exception e) {
            logger.error("Error capturing screenshot as base64 for session: {}", sessionId, e);
            return "Error capturing screenshot: " + e.getMessage();
        }
    }
}
