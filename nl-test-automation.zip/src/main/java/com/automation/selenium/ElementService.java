package com.automation.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service for interacting with web elements
 */
@Service
public class ElementService {
    
    private static final Logger logger = LoggerFactory.getLogger(ElementService.class);
    
    @Autowired
    private BrowserService browserService;
    
    @Autowired
    private WaitService waitService;
    
    /**
     * Clicks on an element identified by the given selector
     * 
     * @param sessionId Browser session identifier
     * @param selector CSS selector, XPath, or other locator strategy
     * @return Success message or error description
     */
    public String clickElement(String sessionId, String selector) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Clicking element with selector: {} for session: {}", selector, sessionId);
            
            WebElement element = waitService.waitForElementToBeClickable(sessionId, selector, 10);
            if (element == null) {
                return "Error: Element not found or not clickable: " + selector;
            }
            
            element.click();
            logger.info("Successfully clicked element: {}", selector);
            
            return "Successfully clicked element: " + selector;
            
        } catch (Exception e) {
            logger.error("Error clicking element: {} for session: {}", selector, sessionId, e);
            return "Error clicking element: " + e.getMessage();
        }
    }
    
    /**
     * Types text into an input element
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @param text Text to type
     * @return Success message or error description
     */
    public String typeText(String sessionId, String selector, String text) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Typing text into element: {} for session: {}", selector, sessionId);
            
            WebElement element = waitService.waitForElementToBeVisible(sessionId, selector, 10);
            if (element == null) {
                return "Error: Element not found: " + selector;
            }
            
            element.clear();
            element.sendKeys(text);
            logger.info("Successfully typed text into element: {}", selector);
            
            return "Successfully typed text into element: " + selector;
            
        } catch (Exception e) {
            logger.error("Error typing text into element: {} for session: {}", selector, sessionId, e);
            return "Error typing text: " + e.getMessage();
        }
    }
    
    /**
     * Clears text from an input element
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @return Success message or error description
     */
    public String clearText(String sessionId, String selector) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Clearing text from element: {} for session: {}", selector, sessionId);
            
            WebElement element = waitService.waitForElementToBeVisible(sessionId, selector, 10);
            if (element == null) {
                return "Error: Element not found: " + selector;
            }
            
            element.clear();
            logger.info("Successfully cleared text from element: {}", selector);
            
            return "Successfully cleared text from element: " + selector;
            
        } catch (Exception e) {
            logger.error("Error clearing text from element: {} for session: {}", selector, sessionId, e);
            return "Error clearing text: " + e.getMessage();
        }
    }
    
    /**
     * Hovers over an element
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @return Success message or error description
     */
    public String hoverElement(String sessionId, String selector) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Hovering over element: {} for session: {}", selector, sessionId);
            
            WebElement element = waitService.waitForElementToBeVisible(sessionId, selector, 10);
            if (element == null) {
                return "Error: Element not found: " + selector;
            }
            
            Actions actions = new Actions(driver);
            actions.moveToElement(element).perform();
            logger.info("Successfully hovered over element: {}", selector);
            
            return "Successfully hovered over element: " + selector;
            
        } catch (Exception e) {
            logger.error("Error hovering over element: {} for session: {}", selector, sessionId, e);
            return "Error hovering over element: " + e.getMessage();
        }
    }
    
    /**
     * Selects an option from a dropdown by visible text
     * 
     * @param sessionId Browser session identifier
     * @param selector Dropdown selector
     * @param optionText Visible text of the option to select
     * @return Success message or error description
     */
    public String selectByText(String sessionId, String selector, String optionText) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Selecting option '{}' from dropdown: {} for session: {}", optionText, selector, sessionId);
            
            WebElement element = waitService.waitForElementToBeVisible(sessionId, selector, 10);
            if (element == null) {
                return "Error: Dropdown not found: " + selector;
            }
            
            Select select = new Select(element);
            select.selectByVisibleText(optionText);
            logger.info("Successfully selected option '{}' from dropdown: {}", optionText, selector);
            
            return "Successfully selected option '" + optionText + "' from dropdown: " + selector;
            
        } catch (Exception e) {
            logger.error("Error selecting option from dropdown: {} for session: {}", selector, sessionId, e);
            return "Error selecting option: " + e.getMessage();
        }
    }
    
    /**
     * Presses a key (like Enter, Tab, etc.)
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector (optional, can be null to send to active element)
     * @param keyName Name of the key to press (ENTER, TAB, ESCAPE, etc.)
     * @return Success message or error description
     */
    public String pressKey(String sessionId, String selector, String keyName) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            Keys key;
            try {
                key = Keys.valueOf(keyName.toUpperCase());
            } catch (IllegalArgumentException e) {
                return "Error: Invalid key name: " + keyName;
            }
            
            if (selector != null && !selector.trim().isEmpty()) {
                WebElement element = waitService.waitForElementToBeVisible(sessionId, selector, 10);
                if (element == null) {
                    return "Error: Element not found: " + selector;
                }
                element.sendKeys(key);
                logger.info("Successfully pressed key '{}' on element: {}", keyName, selector);
            } else {
                Actions actions = new Actions(driver);
                actions.sendKeys(key).perform();
                logger.info("Successfully pressed key '{}' on active element", keyName);
            }
            
            return "Successfully pressed key: " + keyName;
            
        } catch (Exception e) {
            logger.error("Error pressing key: {} for session: {}", keyName, sessionId, e);
            return "Error pressing key: " + e.getMessage();
        }
    }
    
    /**
     * Gets text content from an element
     * 
     * @param sessionId Browser session identifier
     * @param selector Element selector
     * @return Element text or error message
     */
    public String getText(String sessionId, String selector) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            WebElement element = waitService.waitForElementToBeVisible(sessionId, selector, 10);
            if (element == null) {
                return "Error: Element not found: " + selector;
            }
            
            String text = element.getText();
            logger.info("Retrieved text from element {}: {}", selector, text);
            
            return text;
            
        } catch (Exception e) {
            logger.error("Error getting text from element: {} for session: {}", selector, sessionId, e);
            return "Error getting text: " + e.getMessage();
        }
    }
    
    /**
     * Converts selector string to By object
     * 
     * @param selector Selector string (supports CSS, XPath, ID, etc.)
     * @return By object for element location
     */
    private By parseSelector(String selector) {
        if (selector.startsWith("//") || selector.startsWith("(")) {
            return By.xpath(selector);
        } else if (selector.startsWith("#")) {
            return By.id(selector.substring(1));
        } else if (selector.startsWith(".")) {
            return By.className(selector.substring(1));
        } else {
            return By.cssSelector(selector);
        }
    }
}
