package com.automation.selenium;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service for handling browser navigation operations
 */
@Service
public class NavigationService {
    
    private static final Logger logger = LoggerFactory.getLogger(NavigationService.class);
    
    @Autowired
    private BrowserService browserService;
    
    /**
     * Navigates to the specified URL
     * 
     * @param sessionId Browser session identifier
     * @param url Target URL to navigate to
     * @return Success message or error description
     */
    public String navigateTo(String sessionId, String url) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found. Please start a browser session first.";
            }
            
            logger.info("Navigating to URL: {} for session: {}", url, sessionId);
            driver.get(url);
            
            String currentUrl = driver.getCurrentUrl();
            String title = driver.getTitle();
            
            logger.info("Successfully navigated to: {} (Title: {})", currentUrl, title);
            return String.format("Successfully navigated to: %s (Page title: %s)", currentUrl, title);
            
        } catch (Exception e) {
            logger.error("Error navigating to URL: {} for session: {}", url, sessionId, e);
            return "Error navigating to URL: " + e.getMessage();
        }
    }
    
    /**
     * Refreshes the current page
     * 
     * @param sessionId Browser session identifier
     * @return Success message or error description
     */
    public String refresh(String sessionId) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Refreshing page for session: {}", sessionId);
            driver.navigate().refresh();
            
            return "Page refreshed successfully";
            
        } catch (Exception e) {
            logger.error("Error refreshing page for session: {}", sessionId, e);
            return "Error refreshing page: " + e.getMessage();
        }
    }
    
    /**
     * Navigates back in browser history
     * 
     * @param sessionId Browser session identifier
     * @return Success message or error description
     */
    public String goBack(String sessionId) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Navigating back for session: {}", sessionId);
            driver.navigate().back();
            
            return "Navigated back successfully";
            
        } catch (Exception e) {
            logger.error("Error navigating back for session: {}", sessionId, e);
            return "Error navigating back: " + e.getMessage();
        }
    }
    
    /**
     * Navigates forward in browser history
     * 
     * @param sessionId Browser session identifier
     * @return Success message or error description
     */
    public String goForward(String sessionId) {
        try {
            WebDriver driver = browserService.getDriver(sessionId);
            if (driver == null) {
                return "Error: No browser session found.";
            }
            
            logger.info("Navigating forward for session: {}", sessionId);
            driver.navigate().forward();
            
            return "Navigated forward successfully";
            
        } catch (Exception e) {
            logger.error("Error navigating forward for session: {}", sessionId, e);
            return "Error navigating forward: " + e.getMessage();
        }
    }
}
