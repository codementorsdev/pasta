package com.automation.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration properties for OpenAI-compatible API settings
 * 
 * This class allows the application to be configured with any OpenAI-compatible
 * API provider by simply changing the base URL and model name in application.properties
 */
@Configuration
@ConfigurationProperties(prefix = "openai.api")
public class OpenAIConfig {
    
    private String baseUrl = "https://api.openai.com/v1";
    private String key;
    private String model = "gpt-3.5-turbo";
    private int maxTokens = 1000;
    private double temperature = 0.1;
    
    // Getters and Setters
    public String getBaseUrl() {
        return baseUrl;
    }
    
    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }
    
    public String getKey() {
        return key;
    }
    
    public void setKey(String key) {
        this.key = key;
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this.model = model;
    }
    
    public int getMaxTokens() {
        return maxTokens;
    }
    
    public void setMaxTokens(int maxTokens) {
        this.maxTokens = maxTokens;
    }
    
    public double getTemperature() {
        return temperature;
    }
    
    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }
}
