package com.automation.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Main application configuration class
 */
@Configuration
@EnableConfigurationProperties({OpenAIConfig.class, SeleniumConfig.class})
public class ApplicationConfig {
    
    /**
     * WebClient bean for HTTP requests
     */
    @Bean
    public WebClient webClient() {
        return WebClient.builder()
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(10 * 1024 * 1024)) // 10MB
                .build();
    }
    
    /**
     * Initialize required directories on startup
     */
    @Bean
    public String initializeDirectories(SeleniumConfig seleniumConfig) {
        try {
            // Create screenshots directory
            Path screenshotPath = Paths.get(seleniumConfig.getScreenshotPath());
            if (!Files.exists(screenshotPath)) {
                Files.createDirectories(screenshotPath);
            }
            
            // Create logs directory
            Path logsPath = Paths.get("logs");
            if (!Files.exists(logsPath)) {
                Files.createDirectories(logsPath);
            }
            
            return "Directories initialized successfully";
            
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize directories", e);
        }
    }
}
