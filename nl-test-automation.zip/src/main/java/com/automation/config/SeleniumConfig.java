package com.automation.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration properties for Selenium WebDriver settings
 */
@Configuration
@ConfigurationProperties(prefix = "selenium")
public class SeleniumConfig {
    
    private String browser = "chrome";
    private boolean headless = false;
    private int implicitWait = 10;
    private int pageLoadTimeout = 30;
    private int scriptTimeout = 30;
    private String screenshotPath = "screenshots/";
    
    // Getters and Setters
    public String getBrowser() {
        return browser;
    }
    
    public void setBrowser(String browser) {
        this.browser = browser;
    }
    
    public boolean isHeadless() {
        return headless;
    }
    
    public void setHeadless(boolean headless) {
        this.headless = headless;
    }
    
    public int getImplicitWait() {
        return implicitWait;
    }
    
    public void setImplicitWait(int implicitWait) {
        this.implicitWait = implicitWait;
    }
    
    public int getPageLoadTimeout() {
        return pageLoadTimeout;
    }
    
    public void setPageLoadTimeout(int pageLoadTimeout) {
        this.pageLoadTimeout = pageLoadTimeout;
    }
    
    public int getScriptTimeout() {
        return scriptTimeout;
    }
    
    public void setScriptTimeout(int scriptTimeout) {
        this.scriptTimeout = scriptTimeout;
    }
    
    public String getScreenshotPath() {
        return screenshotPath;
    }
    
    public void setScreenshotPath(String screenshotPath) {
        this.screenshotPath = screenshotPath;
    }
}
