package com.automation.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Validates application configuration on startup
 */
@Component
public class ConfigurationValidator implements CommandLineRunner {
    
    private static final Logger logger = LoggerFactory.getLogger(ConfigurationValidator.class);
    
    @Autowired
    private OpenAIConfig openAIConfig;
    
    @Autowired
    private SeleniumConfig seleniumConfig;
    
    @Override
    public void run(String... args) throws Exception {
        logger.info("Validating application configuration...");
        
        validateOpenAIConfig();
        validateSeleniumConfig();
        
        logger.info("Configuration validation completed successfully");
    }
    
    private void validateOpenAIConfig() {
        logger.info("OpenAI Configuration:");
        logger.info("  Base URL: {}", openAIConfig.getBaseUrl());
        logger.info("  Model: {}", openAIConfig.getModel());
        logger.info("  Max Tokens: {}", openAIConfig.getMaxTokens());
        logger.info("  Temperature: {}", openAIConfig.getTemperature());
        
        if (openAIConfig.getKey() == null || openAIConfig.getKey().trim().isEmpty() || 
            openAIConfig.getKey().equals("your-api-key-here") || 
            openAIConfig.getKey().equals("your-openai-api-key-here")) {
            logger.warn("WARNING: OpenAI API key is not properly configured!");
            logger.warn("Please set the OPENAI_API_KEY environment variable or update application.properties");
        } else {
            logger.info("  API Key: Configured (length: {})", openAIConfig.getKey().length());
        }
        
        if (openAIConfig.getBaseUrl() == null || openAIConfig.getBaseUrl().trim().isEmpty()) {
            throw new IllegalStateException("OpenAI base URL must be configured");
        }
        
        if (openAIConfig.getModel() == null || openAIConfig.getModel().trim().isEmpty()) {
            throw new IllegalStateException("OpenAI model must be configured");
        }
    }
    
    private void validateSeleniumConfig() {
        logger.info("Selenium Configuration:");
        logger.info("  Browser: {}", seleniumConfig.getBrowser());
        logger.info("  Headless: {}", seleniumConfig.isHeadless());
        logger.info("  Implicit Wait: {} seconds", seleniumConfig.getImplicitWait());
        logger.info("  Page Load Timeout: {} seconds", seleniumConfig.getPageLoadTimeout());
        logger.info("  Script Timeout: {} seconds", seleniumConfig.getScriptTimeout());
        logger.info("  Screenshot Path: {}", seleniumConfig.getScreenshotPath());
        
        String browser = seleniumConfig.getBrowser().toLowerCase();
        if (!browser.equals("chrome") && !browser.equals("firefox")) {
            logger.warn("WARNING: Unsupported browser '{}'. Supported browsers: chrome, firefox", browser);
        }
        
        if (seleniumConfig.getImplicitWait() <= 0) {
            throw new IllegalStateException("Implicit wait must be greater than 0");
        }
        
        if (seleniumConfig.getPageLoadTimeout() <= 0) {
            throw new IllegalStateException("Page load timeout must be greater than 0");
        }
    }
}
