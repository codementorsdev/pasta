package com.automation.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * REST Controller for exposing configuration information
 */
@RestController
@RequestMapping("/api/config")
public class EnvironmentInfoController {
    
    @Autowired
    private OpenAIConfig openAIConfig;
    
    @Autowired
    private SeleniumConfig seleniumConfig;
    
    /**
     * Returns current configuration information (excluding sensitive data)
     */
    @GetMapping("/info")
    public Map<String, Object> getConfigInfo() {
        Map<String, Object> config = new HashMap<>();
        
        // OpenAI Configuration (excluding API key)
        Map<String, Object> openaiConfig = new HashMap<>();
        openaiConfig.put("baseUrl", openAIConfig.getBaseUrl());
        openaiConfig.put("model", openAIConfig.getModel());
        openaiConfig.put("maxTokens", openAIConfig.getMaxTokens());
        openaiConfig.put("temperature", openAIConfig.getTemperature());
        openaiConfig.put("apiKeyConfigured", 
            openAIConfig.getKey() != null && 
            !openAIConfig.getKey().trim().isEmpty() && 
            !openAIConfig.getKey().equals("your-api-key-here") &&
            !openAIConfig.getKey().equals("your-openai-api-key-here"));
        
        // Selenium Configuration
        Map<String, Object> seleniumConfigMap = new HashMap<>();
        seleniumConfigMap.put("browser", seleniumConfig.getBrowser());
        seleniumConfigMap.put("headless", seleniumConfig.isHeadless());
        seleniumConfigMap.put("implicitWait", seleniumConfig.getImplicitWait());
        seleniumConfigMap.put("pageLoadTimeout", seleniumConfig.getPageLoadTimeout());
        seleniumConfigMap.put("scriptTimeout", seleniumConfig.getScriptTimeout());
        seleniumConfigMap.put("screenshotPath", seleniumConfig.getScreenshotPath());
        
        config.put("openai", openaiConfig);
        config.put("selenium", seleniumConfigMap);
        config.put("version", "1.0.0");
        config.put("javaVersion", System.getProperty("java.version"));
        
        return config;
    }
    
    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public Map<String, Object> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("timestamp", System.currentTimeMillis());
        
        // Check if critical configurations are present
        boolean openaiConfigured = openAIConfig.getKey() != null && 
            !openAIConfig.getKey().trim().isEmpty() && 
            !openAIConfig.getKey().equals("your-api-key-here") &&
            !openAIConfig.getKey().equals("your-openai-api-key-here");
        
        health.put("openaiConfigured", openaiConfigured);
        health.put("seleniumConfigured", true); // Selenium config is always present
        
        return health;
    }
}
