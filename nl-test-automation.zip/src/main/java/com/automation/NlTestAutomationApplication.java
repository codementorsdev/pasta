package com.automation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot Application for Natural Language Test Automation
 * 
 * This application provides a chat-based interface where users can enter
 * natural language instructions that are converted to Selenium automation
 * commands using configurable OpenAI-compatible LLM APIs.
 */
@SpringBootApplication
public class NlTestAutomationApplication {

    public static void main(String[] args) {
        SpringApplication.run(NlTestAutomationApplication.class, args);
    }
}
