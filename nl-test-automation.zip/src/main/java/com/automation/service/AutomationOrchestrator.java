package com.automation.service;

import com.automation.model.AutomationAction;
import com.automation.selenium.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Orchestrates the execution of automation actions
 * 
 * This service takes automation actions from the LLM and executes them
 * using the appropriate Selenium utility services.
 */
@Service
public class AutomationOrchestrator {
    
    private static final Logger logger = LoggerFactory.getLogger(AutomationOrchestrator.class);
    
    @Autowired
    private BrowserService browserService;
    
    @Autowired
    private NavigationService navigationService;
    
    @Autowired
    private ElementService elementService;
    
    @Autowired
    private WaitService waitService;
    
    @Autowired
    private AssertionService assertionService;
    
    @Autowired
    private ScreenshotService screenshotService;
    
    /**
     * Executes a list of automation actions for a given session
     * 
     * @param sessionId Browser session identifier
     * @param actions List of automation actions to execute
     * @return List of execution results
     */
    public List<String> executeActions(String sessionId, List<AutomationAction> actions) {
        List<String> results = new ArrayList<>();
        
        logger.info("Executing {} actions for session: {}", actions.size(), sessionId);
        
        for (AutomationAction action : actions) {
            try {
                String result = executeAction(sessionId, action);
                results.add(result);
                logger.info("Action '{}' executed with result: {}", action.getAction(), result);
                
                // Add a small delay between actions to ensure stability
                Thread.sleep(500);
                
            } catch (Exception e) {
                String errorResult = "Error executing action '" + action.getAction() + "': " + e.getMessage();
                results.add(errorResult);
                logger.error("Error executing action: {}", action.getAction(), e);
            }
        }
        
        return results;
    }
    
    /**
     * Executes a single automation action
     * 
     * @param sessionId Browser session identifier
     * @param action Automation action to execute
     * @return Execution result message
     */
    private String executeAction(String sessionId, AutomationAction action) {
        String actionName = action.getAction();
        Map<String, Object> parameters = action.getParameters();
        
        logger.debug("Executing action: {} with parameters: {}", actionName, parameters);
        
        switch (actionName.toLowerCase()) {
            case "startbrowser":
                return startBrowser(sessionId);
                
            case "navigateto":
                String url = getStringParameter(parameters, "url");
                return navigationService.navigateTo(sessionId, url);
                
            case "clickelement":
                String clickSelector = getStringParameter(parameters, "selector");
                return elementService.clickElement(sessionId, clickSelector);
                
            case "typetext":
                String typeSelector = getStringParameter(parameters, "selector");
                String text = getStringParameter(parameters, "text");
                return elementService.typeText(sessionId, typeSelector, text);
                
            case "cleartext":
                String clearSelector = getStringParameter(parameters, "selector");
                return elementService.clearText(sessionId, clearSelector);
                
            case "hoverelement":
                String hoverSelector = getStringParameter(parameters, "selector");
                return elementService.hoverElement(sessionId, hoverSelector);
                
            case "selectbytext":
                String selectSelector = getStringParameter(parameters, "selector");
                String optionText = getStringParameter(parameters, "optionText");
                return elementService.selectByText(sessionId, selectSelector, optionText);
                
            case "presskey":
                String keySelector = getStringParameter(parameters, "selector");
                String keyName = getStringParameter(parameters, "keyName");
                return elementService.pressKey(sessionId, keySelector, keyName);
                
            case "gettext":
                String getTextSelector = getStringParameter(parameters, "selector");
                return elementService.getText(sessionId, getTextSelector);
                
            case "asserttextpresent":
                String assertSelector = getStringParameter(parameters, "selector");
                String expectedText = getStringParameter(parameters, "expectedText");
                return assertionService.assertTextPresent(sessionId, assertSelector, expectedText);
                
            case "assertelementvisible":
                String visibleSelector = getStringParameter(parameters, "selector");
                return assertionService.assertElementVisible(sessionId, visibleSelector);
                
            case "assertpagetitle":
                String expectedTitle = getStringParameter(parameters, "expectedTitle");
                return assertionService.assertPageTitle(sessionId, expectedTitle);
                
            case "asserturlcontains":
                String expectedUrlPart = getStringParameter(parameters, "expectedUrlPart");
                return assertionService.assertUrlContains(sessionId, expectedUrlPart);
                
            case "waitforelement":
                String waitSelector = getStringParameter(parameters, "selector");
                Integer timeoutSeconds = getIntegerParameter(parameters, "timeoutSeconds");
                return waitForElement(sessionId, waitSelector, timeoutSeconds);
                
            case "capturescreenshot":
                String screenshotName = getStringParameter(parameters, "name");
                return screenshotService.captureScreenshot(sessionId, screenshotName);
                
            case "closebrowser":
                return closeBrowser(sessionId);
                
            case "message":
                String content = getStringParameter(parameters, "content");
                return "LLM Response: " + content;
                
            case "error":
                String errorMessage = getStringParameter(parameters, "message");
                return "Error: " + errorMessage;
                
            default:
                return "Unknown action: " + actionName;
        }
    }
    
    /**
     * Starts a new browser session
     */
    private String startBrowser(String sessionId) {
        try {
            browserService.createDriver(sessionId);
            return "Browser session started successfully";
        } catch (Exception e) {
            return "Error starting browser: " + e.getMessage();
        }
    }
    
    /**
     * Waits for an element to be visible
     */
    private String waitForElement(String sessionId, String selector, Integer timeoutSeconds) {
        if (timeoutSeconds == null) {
            timeoutSeconds = 10;
        }
        
        if (waitService.waitForElementToBeVisible(sessionId, selector, timeoutSeconds) != null) {
            return "Element became visible: " + selector;
        } else {
            return "Element did not become visible within timeout: " + selector;
        }
    }
    
    /**
     * Closes the browser session
     */
    private String closeBrowser(String sessionId) {
        try {
            browserService.closeDriver(sessionId);
            return "Browser session closed successfully";
        } catch (Exception e) {
            return "Error closing browser: " + e.getMessage();
        }
    }
    
    /**
     * Helper method to get string parameter from action parameters
     */
    private String getStringParameter(Map<String, Object> parameters, String key) {
        Object value = parameters.get(key);
        return value != null ? value.toString() : null;
    }
    
    /**
     * Helper method to get integer parameter from action parameters
     */
    private Integer getIntegerParameter(Map<String, Object> parameters, String key) {
        Object value = parameters.get(key);
        if (value instanceof Integer) {
            return (Integer) value;
        } else if (value instanceof String) {
            try {
                return Integer.parseInt((String) value);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
}
