package com.automation.service;

import com.automation.config.OpenAIConfig;
import com.automation.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.*;

/**
 * Service for integrating with OpenAI-compatible LLM APIs
 * 
 * This service is designed to work with any OpenAI-compatible API by configuring
 * the base URL and model in application.properties. It handles the conversion
 * of natural language instructions into structured automation commands.
 */
@Service
public class LLMService {
    
    private static final Logger logger = LoggerFactory.getLogger(LLMService.class);
    
    @Autowired
    private OpenAIConfig openAIConfig;
    
    private final WebClient webClient;
    private final ObjectMapper objectMapper;
    
    public LLMService() {
        this.webClient = WebClient.builder().build();
        this.objectMapper = new ObjectMapper();
    }
    
    /**
     * Processes a natural language instruction and returns automation actions
     * 
     * @param sessionId Browser session identifier
     * @param instruction Natural language instruction from user
     * @return List of automation actions to execute
     */
    public List<AutomationAction> processInstruction(String sessionId, String instruction) {
        try {
            logger.info("Processing instruction for session {}: {}", sessionId, instruction);
            
            // Create system prompt that defines available tools and their usage
            String systemPrompt = createSystemPrompt();
            
            // Create messages for the conversation
            List<ChatMessage> messages = Arrays.asList(
                new ChatMessage("system", systemPrompt),
                new ChatMessage("user", instruction)
            );
            
            // Create request with tools
            OpenAIRequest request = new OpenAIRequest(
                openAIConfig.getModel(),
                messages,
                openAIConfig.getMaxTokens(),
                openAIConfig.getTemperature()
            );
            
            request.setTools(createAvailableTools());
            request.setToolChoice("auto");
            
            // Call LLM API
            OpenAIResponse response = callLLMAPI(request);
            
            // Parse response and extract automation actions
            return parseAutomationActions(response);
            
        } catch (Exception e) {
            logger.error("Error processing instruction for session {}: {}", sessionId, instruction, e);
            return Collections.singletonList(
                new AutomationAction("error", 
                    Map.of("message", "Error processing instruction: " + e.getMessage()),
                    "Error occurred while processing the instruction")
            );
        }
    }
    
    /**
     * Creates the system prompt that defines available automation tools
     */
    private String createSystemPrompt() {
        return """
            You are an AI assistant that converts natural language instructions into web automation commands using Selenium WebDriver.
            
            You have access to the following automation tools:
            
            1. startBrowser() - Start a new browser session
            2. navigateTo(url) - Navigate to a specific URL
            3. clickElement(selector) - Click on an element (use CSS selectors, XPath, or #id)
            4. typeText(selector, text) - Type text into an input field
            5. clearText(selector) - Clear text from an input field
            6. hoverElement(selector) - Hover over an element
            7. selectByText(selector, optionText) - Select option from dropdown by visible text
            8. pressKey(selector, keyName) - Press a key (ENTER, TAB, ESCAPE, etc.)
            9. getText(selector) - Get text content from an element
            10. assertTextPresent(selector, expectedText) - Assert that element contains expected text
            11. assertElementVisible(selector) - Assert that element is visible
            12. assertPageTitle(expectedTitle) - Assert page title matches expected value
            13. assertUrlContains(expectedUrlPart) - Assert URL contains expected text
            14. waitForElement(selector, timeoutSeconds) - Wait for element to be visible
            15. captureScreenshot(name) - Take a screenshot
            16. closeBrowser() - Close the browser session
            
            IMPORTANT RULES:
            1. Always start with startBrowser() if no browser session exists
            2. Use specific, reliable selectors (prefer IDs over complex CSS selectors)
            3. Add appropriate waits before interacting with elements
            4. Break complex tasks into smaller, sequential steps
            5. Use assertions to verify expected outcomes
            6. Take screenshots after important actions for verification
            7. Handle errors gracefully and provide clear feedback
            
            Convert the user's natural language instruction into a sequence of these automation commands.
            Respond with function calls using the available tools.
            """;
    }
    
    /**
     * Creates the list of available tools for the LLM
     */
    private List<Tool> createAvailableTools() {
        List<Tool> tools = new ArrayList<>();
        
        // Start Browser Tool
        tools.add(new Tool(new Tool.Function(
            "startBrowser",
            "Start a new browser session",
            Map.of(
                "type", "object",
                "properties", Map.of(),
                "required", List.of()
            )
        )));
        
        // Navigate To Tool
        tools.add(new Tool(new Tool.Function(
            "navigateTo",
            "Navigate to a specific URL",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "url", Map.of("type", "string", "description", "The URL to navigate to")
                ),
                "required", List.of("url")
            )
        )));
        
        // Click Element Tool
        tools.add(new Tool(new Tool.Function(
            "clickElement",
            "Click on a web element",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector, XPath, or element identifier")
                ),
                "required", List.of("selector")
            )
        )));
        
        // Type Text Tool
        tools.add(new Tool(new Tool.Function(
            "typeText",
            "Type text into an input field",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the input field"),
                    "text", Map.of("type", "string", "description", "Text to type")
                ),
                "required", List.of("selector", "text")
            )
        )));
        
        // Clear Text Tool
        tools.add(new Tool(new Tool.Function(
            "clearText",
            "Clear text from an input field",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the input field")
                ),
                "required", List.of("selector")
            )
        )));
        
        // Hover Element Tool
        tools.add(new Tool(new Tool.Function(
            "hoverElement",
            "Hover over a web element",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the element")
                ),
                "required", List.of("selector")
            )
        )));
        
        // Select By Text Tool
        tools.add(new Tool(new Tool.Function(
            "selectByText",
            "Select an option from a dropdown by visible text",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the dropdown"),
                    "optionText", Map.of("type", "string", "description", "Visible text of the option to select")
                ),
                "required", List.of("selector", "optionText")
            )
        )));
        
        // Press Key Tool
        tools.add(new Tool(new Tool.Function(
            "pressKey",
            "Press a keyboard key",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the element (optional)"),
                    "keyName", Map.of("type", "string", "description", "Name of the key to press (ENTER, TAB, ESCAPE, etc.)")
                ),
                "required", List.of("keyName")
            )
        )));
        
        // Get Text Tool
        tools.add(new Tool(new Tool.Function(
            "getText",
            "Get text content from an element",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the element")
                ),
                "required", List.of("selector")
            )
        )));
        
        // Assert Text Present Tool
        tools.add(new Tool(new Tool.Function(
            "assertTextPresent",
            "Assert that an element contains expected text",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the element"),
                    "expectedText", Map.of("type", "string", "description", "Expected text content")
                ),
                "required", List.of("selector", "expectedText")
            )
        )));
        
        // Assert Element Visible Tool
        tools.add(new Tool(new Tool.Function(
            "assertElementVisible",
            "Assert that an element is visible on the page",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the element")
                ),
                "required", List.of("selector")
            )
        )));
        
        // Assert Page Title Tool
        tools.add(new Tool(new Tool.Function(
            "assertPageTitle",
            "Assert that the page title matches expected value",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "expectedTitle", Map.of("type", "string", "description", "Expected page title")
                ),
                "required", List.of("expectedTitle")
            )
        )));
        
        // Assert URL Contains Tool
        tools.add(new Tool(new Tool.Function(
            "assertUrlContains",
            "Assert that the current URL contains expected text",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "expectedUrlPart", Map.of("type", "string", "description", "Expected URL part")
                ),
                "required", List.of("expectedUrlPart")
            )
        )));
        
        // Wait For Element Tool
        tools.add(new Tool(new Tool.Function(
            "waitForElement",
            "Wait for an element to be visible",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "selector", Map.of("type", "string", "description", "CSS selector for the element"),
                    "timeoutSeconds", Map.of("type", "integer", "description", "Maximum time to wait in seconds")
                ),
                "required", List.of("selector", "timeoutSeconds")
            )
        )));
        
        // Capture Screenshot Tool
        tools.add(new Tool(new Tool.Function(
            "captureScreenshot",
            "Take a screenshot of the current page",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "name", Map.of("type", "string", "description", "Optional name for the screenshot")
                ),
                "required", List.of()
            )
        )));
        
        // Close Browser Tool
        tools.add(new Tool(new Tool.Function(
            "closeBrowser",
            "Close the browser session",
            Map.of(
                "type", "object",
                "properties", Map.of(),
                "required", List.of()
            )
        )));
        
        return tools;
    }
    
    /**
     * Calls the configured OpenAI-compatible API
     */
    private OpenAIResponse callLLMAPI(OpenAIRequest request) {
        try {
            String requestBody = objectMapper.writeValueAsString(request);
            logger.debug("Calling LLM API: {} with request: {}", openAIConfig.getBaseUrl(), requestBody);
            
            Mono<OpenAIResponse> responseMono = webClient.post()
                .uri(openAIConfig.getBaseUrl() + "/chat/completions")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + openAIConfig.getKey())
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(OpenAIResponse.class);
            
            OpenAIResponse response = responseMono.block();
            logger.debug("Received LLM API response: {}", objectMapper.writeValueAsString(response));
            
            return response;
            
        } catch (JsonProcessingException e) {
            logger.error("Error serializing request", e);
            throw new RuntimeException("Error calling LLM API", e);
        } catch (Exception e) {
            logger.error("Error calling LLM API", e);
            throw new RuntimeException("Error calling LLM API", e);
        }
    }
    
    /**
     * Parses the LLM response and extracts automation actions
     */
    private List<AutomationAction> parseAutomationActions(OpenAIResponse response) {
        List<AutomationAction> actions = new ArrayList<>();
        
        if (response.getChoices() == null || response.getChoices().isEmpty()) {
            logger.warn("No choices in LLM response");
            return actions;
        }
        
        ChatMessage message = response.getChoices().get(0).getMessage();
        if (message == null) {
            logger.warn("No message in LLM response choice");
            return actions;
        }
        
        // For now, parse the content as a simple text response
        // In a full implementation, you would parse tool calls from the response
        String content = message.getContent();
        if (content != null && !content.trim().isEmpty()) {
            actions.add(new AutomationAction(
                "message",
                Map.of("content", content),
                "LLM response message"
            ));
        }
        
        return actions;
    }
}
