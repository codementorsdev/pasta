# Natural Language Test Automation

A powerful Spring Boot application that enables web automation through natural language commands. Simply describe what you want to test in plain English, and the system will convert your instructions into Selenium WebDriver automation using configurable OpenAI-compatible LLM APIs.

## 🚀 Features

- **Natural Language Processing**: Describe automation tasks in plain English
- **OpenAI-Compatible API Support**: Works with OpenAI, Anthropic Claude, local LLMs (Ollama), Azure OpenAI, and more
- **Real-time Chat Interface**: Interactive web UI with WebSocket support
- **Comprehensive Selenium Integration**: Full browser automation capabilities
- **Screenshot Capture**: Automatic screenshot capture for verification
- **Multi-browser Support**: Chrome and Firefox support
- **Configurable Environment**: Easy configuration for different deployment scenarios
- **Production Ready**: Docker support, health checks, and monitoring endpoints

## 📋 Table of Contents

- [Quick Start](#quick-start)
- [Architecture](#architecture)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage Examples](#usage-examples)
- [API Documentation](#api-documentation)
- [Deployment](#deployment)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)

## 🏃 Quick Start

### Prerequisites

- Java 17 or higher
- Maven 3.6 or higher
- Chrome or Firefox browser
- OpenAI API key (or compatible API)

### 1. Clone and Setup

\`\`\`bash
git clone <repository-url>
cd nl-test-automation
chmod +x scripts/setup-environment.sh
./scripts/setup-environment.sh
\`\`\`

### 2. Configure API Key

Edit the `.env` file created by the setup script:

\`\`\`bash
# Set your OpenAI API key
OPENAI_API_KEY=your-actual-api-key-here

# Or configure for other providers:
# For Anthropic Claude:
# OPENAI_API_BASE_URL=https://api.anthropic.com/v1
# OPENAI_MODEL=claude-3-sonnet-20240229

# For local Ollama:
# OPENAI_API_BASE_URL=http://localhost:11434/v1
# OPENAI_MODEL=llama2
\`\`\`

### 3. Run the Application

\`\`\`bash
source .env
mvn spring-boot:run
\`\`\`

### 4. Open the Chat Interface

Navigate to `http://localhost:8080` in your browser and start automating!

## 🏗️ Architecture

### System Overview

\`\`\`
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Chat UI       │    │   Spring Boot    │    │   LLM API       │
│   (Frontend)    │◄──►│   Backend        │◄──►│   (OpenAI       │
│                 │    │                  │    │   Compatible)   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │   Selenium      │
                       │   WebDriver     │
                       │                 │
                       └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │   Web Browser   │
                       │   (Chrome/      │
                       │   Firefox)      │
                       └─────────────────┘
\`\`\`

### Component Breakdown

#### 1. Frontend Layer (`src/main/resources/templates/` & `src/main/resources/static/`)
- **Chat Interface**: Modern, responsive web UI built with Bootstrap
- **Real-time Communication**: WebSocket integration for live updates
- **Screenshot Display**: Modal dialogs for viewing automation screenshots
- **Session Management**: Track and manage browser sessions

#### 2. API Layer (`src/main/java/com/automation/controller/`)
- **ChatController**: REST endpoints for chat messages and session management
- **WebSocketController**: Real-time WebSocket message handling
- **HomeController**: Serves the main chat interface
- **EnvironmentInfoController**: Configuration and health check endpoints

#### 3. Service Layer (`src/main/java/com/automation/service/`)
- **LLMService**: Integrates with OpenAI-compatible APIs
- **AutomationOrchestrator**: Coordinates execution of automation actions

#### 4. Selenium Utilities (`src/main/java/com/automation/selenium/`)
- **BrowserService**: WebDriver lifecycle management
- **NavigationService**: URL navigation and browser history
- **ElementService**: Element interaction (click, type, hover, etc.)
- **WaitService**: Explicit waits and element visibility
- **AssertionService**: Validation and verification operations
- **ScreenshotService**: Screenshot capture and management

#### 5. Configuration (`src/main/java/com/automation/config/`)
- **OpenAIConfig**: LLM API configuration
- **SeleniumConfig**: WebDriver settings
- **WebSocketConfig**: Real-time communication setup
- **ApplicationConfig**: General application configuration

## 💻 Installation

### Method 1: Local Development

1. **Install Prerequisites**:
   \`\`\`bash
   # Install Java 17
   sudo apt update
   sudo apt install openjdk-17-jdk
   
   # Install Maven
   sudo apt install maven
   
   # Install Chrome
   wget -q -O - https://dl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
   echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" | sudo tee /etc/apt/sources.list.d/google-chrome.list
   sudo apt update
   sudo apt install google-chrome-stable
   \`\`\`

2. **Clone and Build**:
   \`\`\`bash
   git clone <repository-url>
   cd nl-test-automation
   mvn clean install
   \`\`\`

3. **Configure Environment**:
   \`\`\`bash
   cp .env.example .env
   # Edit .env with your API keys and preferences
   \`\`\`

4. **Run**:
   \`\`\`bash
   mvn spring-boot:run
   \`\`\`

### Method 2: Docker

1. **Using Docker Compose** (Recommended):
   \`\`\`bash
   # Create .env file with your configuration
   echo "OPENAI_API_KEY=your-key-here" > .env
   
   # Start the application
   docker-compose up -d
   \`\`\`

2. **Using Docker directly**:
   \`\`\`bash
   # Build the image
   docker build -t nl-test-automation .
   
   # Run the container
   docker run -d \
     -p 8080:8080 \
     -e OPENAI_API_KEY=your-key-here \
     -e SELENIUM_HEADLESS=true \
     -v $(pwd)/screenshots:/app/screenshots \
     nl-test-automation
   \`\`\`

## ⚙️ Configuration

### Environment Variables

| Variable | Description | Default | Example |
|----------|-------------|---------|---------|
| `OPENAI_API_KEY` | API key for LLM service | - | `sk-...` |
| `OPENAI_API_BASE_URL` | Base URL for API | `https://api.openai.com/v1` | `http://localhost:11434/v1` |
| `OPENAI_MODEL` | Model to use | `gpt-3.5-turbo` | `claude-3-sonnet-20240229` |
| `OPENAI_MAX_TOKENS` | Maximum response tokens | `1000` | `1500` |
| `OPENAI_TEMPERATURE` | Response creativity | `0.1` | `0.3` |
| `SELENIUM_BROWSER` | Browser to use | `chrome` | `firefox` |
| `SELENIUM_HEADLESS` | Run browser headless | `false` | `true` |
| `SELENIUM_IMPLICIT_WAIT` | Default wait time (seconds) | `10` | `15` |
| `SELENIUM_SCREENSHOT_PATH` | Screenshot directory | `screenshots/` | `/tmp/screenshots/` |
| `SPRING_PROFILES_ACTIVE` | Spring profile | `dev` | `prod` |

### Provider-Specific Configuration

#### OpenAI
\`\`\`bash
OPENAI_API_BASE_URL=https://api.openai.com/v1
OPENAI_API_KEY=sk-your-openai-key
OPENAI_MODEL=gpt-3.5-turbo
\`\`\`

#### Anthropic Claude
\`\`\`bash
OPENAI_API_BASE_URL=https://api.anthropic.com/v1
OPENAI_API_KEY=your-anthropic-key
OPENAI_MODEL=claude-3-sonnet-20240229
\`\`\`

#### Local Ollama
\`\`\`bash
OPENAI_API_BASE_URL=http://localhost:11434/v1
OPENAI_API_KEY=not-required
OPENAI_MODEL=llama2
\`\`\`

#### Azure OpenAI
\`\`\`bash
OPENAI_API_BASE_URL=https://your-resource.openai.azure.com/openai/deployments/your-deployment
OPENAI_API_KEY=your-azure-key
OPENAI_MODEL=gpt-35-turbo
\`\`\`

## 📖 Usage Examples

### Basic Navigation
\`\`\`
"Open google.com"
"Navigate to github.com"
"Go to https://example.com"
\`\`\`

### Search Operations
\`\`\`
"Open google.com and search for selenium automation"
"Go to amazon.com and search for laptops"
"Navigate to youtube.com and search for spring boot tutorials"
\`\`\`

### Form Interactions
\`\`\`
"Go to github.com, click the sign in button, and enter username 'testuser'"
"Open the contact form on example.com and fill in the name field with 'John Doe'"
"Navigate to the login page and enter email 'test@example.com' and password 'secret123'"
\`\`\`

### Assertions and Verification
\`\`\`
"Open google.com and verify the page title contains 'Google'"
"Go to example.com and check that the heading says 'Example Domain'"
"Navigate to github.com and assert that the sign in button is visible"
\`\`\`

### Complex Workflows
\`\`\`
"Open amazon.com, search for 'wireless headphones', click on the first result, and take a screenshot"
"Go to github.com, click sign in, enter credentials, and verify successful login"
"Navigate to a shopping site, add items to cart, proceed to checkout, and capture the total price"
\`\`\`

### Screenshot and Documentation
\`\`\`
"Take a screenshot of the current page"
"Navigate to the dashboard and capture a screenshot named 'dashboard-view'"
"Open the reports page and take a screenshot for documentation"
\`\`\`

## 🔌 API Documentation

### REST Endpoints

#### POST `/api/chat/message`
Process a natural language automation command.

**Request Body**:
\`\`\`json
{
  "message": "Open google.com and search for selenium",
  "sessionId": "optional-session-id"
}
\`\`\`

**Response**:
\`\`\`json
{
  "sessionId": "generated-or-provided-session-id",
  "message": "Processed: Open google.com and search for selenium",
  "executionResults": [
    "Browser session started successfully",
    "Successfully navigated to: https://www.google.com",
    "Successfully typed text into element: input[name='q']",
    "Successfully pressed key: ENTER"
  ],
  "status": "success",
  "timestamp": "2024-01-15T10:30:00",
  "screenshotBase64": "base64-encoded-screenshot-data"
}
\`\`\`

#### GET `/api/chat/session/{sessionId}/status`
Get the current status of a browser session.

**Response**:
\`\`\`json
{
  "sessionId": "session-id",
  "message": "Session is active",
  "status": "active",
  "executionResults": ["Browser session is active and responsive"],
  "screenshotBase64": "current-page-screenshot"
}
\`\`\`

#### DELETE `/api/chat/session/{sessionId}`
Close a browser session.

**Response**:
\`\`\`json
{
  "sessionId": "session-id",
  "message": "Session closed",
  "executionResults": ["Browser session closed successfully"],
  "status": "success"
}
\`\`\`

#### GET `/api/config/info`
Get current configuration information (excluding sensitive data).

**Response**:
\`\`\`json
{
  "openai": {
    "baseUrl": "https://api.openai.com/v1",
    "model": "gpt-3.5-turbo",
    "maxTokens": 1000,
    "temperature": 0.1,
    "apiKeyConfigured": true
  },
  "selenium": {
    "browser": "chrome",
    "headless": false,
    "implicitWait": 10,
    "pageLoadTimeout": 30,
    "screenshotPath": "screenshots/"
  },
  "version": "1.0.0",
  "javaVersion": "17.0.2"
}
\`\`\`

### WebSocket Communication

Connect to `/ws` endpoint for real-time communication.

**Send Message**:
\`\`\`javascript
stompClient.send("/app/chat", {}, JSON.stringify({
  message: "Open google.com",
  sessionId: "optional-session-id"
}));
\`\`\`

**Receive Response**:
\`\`\`javascript
stompClient.subscribe('/topic/chat', function(message) {
  const response = JSON.parse(message.body);
  // Handle response
});
\`\`\`

## 🚀 Deployment

### Production Deployment with Docker

1. **Create production configuration**:
   \`\`\`bash
   # Create .env.prod file
   cat > .env.prod << EOF
   OPENAI_API_KEY=your-production-api-key
   SPRING_PROFILES_ACTIVE=prod
   SELENIUM_HEADLESS=true
   SELENIUM_BROWSER=chrome
   EOF
   \`\`\`

2. **Deploy with Docker Compose**:
   \`\`\`bash
   docker-compose --env-file .env.prod up -d
   \`\`\`

### Cloud Deployment

#### Heroku
\`\`\`bash
# Install Heroku CLI and login
heroku create your-app-name

# Set environment variables
heroku config:set OPENAI_API_KEY=your-key
heroku config:set SPRING_PROFILES_ACTIVE=prod
heroku config:set SELENIUM_HEADLESS=true

# Deploy
git push heroku main
\`\`\`

#### AWS ECS/Fargate
\`\`\`bash
# Build and push to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin your-account.dkr.ecr.us-east-1.amazonaws.com
docker build -t nl-test-automation .
docker tag nl-test-automation:latest your-account.dkr.ecr.us-east-1.amazonaws.com/nl-test-automation:latest
docker push your-account.dkr.ecr.us-east-1.amazonaws.com/nl-test-automation:latest

# Create ECS task definition and service
# (Use AWS Console or CLI to create ECS resources)
\`\`\`

#### Google Cloud Run
\`\`\`bash
# Build and deploy
gcloud builds submit --tag gcr.io/your-project/nl-test-automation
gcloud run deploy --image gcr.io/your-project/nl-test-automation --platform managed --set-env-vars OPENAI_API_KEY=your-key,SELENIUM_HEADLESS=true
\`\`\`

### Kubernetes Deployment

\`\`\`yaml
# k8s-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nl-test-automation
spec:
  replicas: 2
  selector:
    matchLabels:
      app: nl-test-automation
  template:
    metadata:
      labels:
        app: nl-test-automation
    spec:
      containers:
      - name: app
        image: nl-test-automation:latest
        ports:
        - containerPort: 8080
        env:
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: api-secrets
              key: openai-key
        - name: SELENIUM_HEADLESS
          value: "true"
        - name: SPRING_PROFILES_ACTIVE
          value: "prod"
---
apiVersion: v1
kind: Service
metadata:
  name: nl-test-automation-service
spec:
  selector:
    app: nl-test-automation
  ports:
  - port: 80
    targetPort: 8080
  type: LoadBalancer
\`\`\`

## 🔧 Troubleshooting

### Common Issues

#### 1. "OpenAI API key is not properly configured"
**Solution**: Ensure your API key is set correctly:
\`\`\`bash
export OPENAI_API_KEY=your-actual-api-key
# Or edit .env file
echo "OPENAI_API_KEY=your-actual-api-key" >> .env
\`\`\`

#### 2. "WebDriver not found" or Browser issues
**Solution**: Install Chrome/Firefox and verify WebDriverManager can download drivers:
\`\`\`bash
# For Ubuntu/Debian
sudo apt update
sudo apt install google-chrome-stable

# For CentOS/RHEL
sudo yum install google-chrome-stable

# Verify installation
google-chrome --version
\`\`\`

#### 3. "Element not found" errors
**Solution**: Increase wait times or use more specific selectors:
\`\`\`bash
# Increase implicit wait
SELENIUM_IMPLICIT_WAIT=15

# Use more specific natural language
# Instead of: "click the button"
# Try: "click the submit button" or "click the button with text 'Submit'"
\`\`\`

#### 4. Screenshots not saving
**Solution**: Check directory permissions:
\`\`\`bash
# Create screenshots directory with proper permissions
mkdir -p screenshots
chmod 755 screenshots

# Or set custom path
export SELENIUM_SCREENSHOT_PATH=/tmp/screenshots/
\`\`\`

#### 5. WebSocket connection issues
**Solution**: Check firewall and proxy settings:
\`\`\`bash
# Test WebSocket connection
curl -i -N -H "Connection: Upgrade" -H "Upgrade: websocket" -H "Sec-WebSocket-Key: test" -H "Sec-WebSocket-Version: 13" http://localhost:8080/ws
\`\`\`

#### 6. High memory usage
**Solution**: Configure JVM memory settings:
\`\`\`bash
# Set JVM options
export JAVA_OPTS="-Xmx1g -Xms512m"

# Or in Docker
docker run -e JAVA_OPTS="-Xmx1g" nl-test-automation
\`\`\`

### Debug Mode

Enable debug logging for troubleshooting:

\`\`\`bash
# Set debug profile
export SPRING_PROFILES_ACTIVE=dev

# Or add to application.properties
logging.level.com.automation=DEBUG
logging.level.org.selenium=DEBUG
\`\`\`

### Health Checks

Monitor application health:

\`\`\`bash
# Check application health
curl http://localhost:8080/api/config/health

# Check configuration
curl http://localhost:8080/api/config/info

# Check Spring Boot actuator endpoints
curl http://localhost:8080/actuator/health
\`\`\`

## 🤝 Contributing

We welcome contributions! Please follow these guidelines:

### Development Setup

1. **Fork and clone the repository**
2. **Create a feature branch**:
   \`\`\`bash
   git checkout -b feature/your-feature-name
   \`\`\`
3. **Set up development environment**:
   \`\`\`bash
   ./scripts/setup-environment.sh
   mvn clean install
   \`\`\`

### Code Style

- Follow Java naming conventions
- Use meaningful variable and method names
- Add Javadoc comments for public methods
- Write unit tests for new functionality
- Ensure code passes all existing tests

### Testing

\`\`\`bash
# Run all tests
mvn test

# Run specific test class
mvn test -Dtest=LLMServiceTest

# Run integration tests
mvn verify
\`\`\`

### Submitting Changes

1. **Ensure all tests pass**
2. **Update documentation** if needed
3. **Create a pull request** with:
   - Clear description of changes
   - Screenshots for UI changes
   - Test results
   - Updated documentation

### Feature Requests

Open an issue with:
- Clear description of the feature
- Use cases and benefits
- Proposed implementation approach
- Any relevant examples or mockups

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Spring Boot** - Application framework
- **Selenium WebDriver** - Browser automation
- **OpenAI** - Natural language processing
- **Bootstrap** - UI framework
- **WebDriverManager** - Automatic driver management
- **SockJS/STOMP** - WebSocket communication

## 📞 Support

- **Documentation**: Check this README and inline code comments
- **Issues**: Open a GitHub issue for bugs or feature requests
- **Discussions**: Use GitHub Discussions for questions and community support
- **Email**: Contact the maintainers for security issues

---

**Happy Automating!** 🚀

Transform your testing workflow with the power of natural language and AI.
