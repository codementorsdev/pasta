# Playwright LLM Automation Framework

A Java-based Playwright test automation framework with LLM capabilities for natural language test automation.

## Features

- **Natural Language Testing**: Use plain English to describe test steps
- **Record and Playback**: Record test scripts and play them back
- **Network Interception**: Monitor and modify network requests/responses
- **Full Page Screenshots**: Capture screenshots of the entire page
- **Element Highlighting**: Highlight elements before interactions
- **Allure Reporting**: Comprehensive test reporting with Allure
- **Data-Driven Testing**: Use multiple data sources (CSV, JSON, Excel)
- **Video Recording**: Record test execution videos
- **AI Integration**: Leverage OpenAI's GPT models for test automation

## Requirements

- Java 11 or higher
- Maven
- Playwright browsers (installed automatically)
- OpenAI API key (for LLM features)

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/playwright-llm-automation.git
cd playwright-llm-automation
