package com.playwright.framework.tests;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.options.AriaRole;
import com.playwright.framework.core.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Basic test demonstrating the framework capabilities
 */
public class BasicTest extends BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(BasicTest.class);

    @Test
    @Feature("UI Testing")
    @Story("Basic Navigation")
    @Severity(SeverityLevel.NORMAL)
    @Description("Test basic navigation to Example.com")
    public void testBasicNavigation() {
        logger.info("Starting basic navigation test");
        
        // Navigate to Example.com
        navigateTo("https://www.example.com");
        logger.info("Navigated to Example.com");
        
        // Take screenshot of the page
        takeScreenshot("example-home");
        
        // Verify title
        String title = page.title();
        logger.info("Page title: {}", title);
        Assert.assertEquals(title, "Example Domain", "Page title should be 'Example Domain'");
        
        // Verify heading
        Locator heading = page.locator("h1");
        String headingText = heading.textContent();
        logger.info("Heading text: {}", headingText);
        Assert.assertEquals(headingText, "Example Domain", "Heading should be 'Example Domain'");
        
        // Take element screenshot
        takeElementScreenshot("h1", "example-heading");
        
        logger.info("Test completed successfully");
    }
}