package com.playwright.framework.tests;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import com.playwright.framework.core.BaseTest;
import com.playwright.framework.llm.LlmClient;
import com.playwright.framework.llm.OpenAIClient;
import com.playwright.framework.llm.TestStepParser;
import io.qameta.allure.Description;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Sample test demonstrating the framework capabilities
 */
public class SampleTest extends BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(SampleTest.class);

    @Test
    @Feature("UI Testing")
    @Story("Basic Navigation")
    @Severity(SeverityLevel.NORMAL)
    @Description("Test basic navigation to Google and search functionality")
    public void testGoogleSearch() {
        logger.info("Starting Google search test");
        
        // Navigate to Google
        navigateTo("https://www.google.com");
        logger.info("Navigated to Google");
        
        // Take screenshot of the page
        takeScreenshot("google-home");
        
        // Accept cookies if present
        try {
            Locator acceptButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Accept all"));
            if (acceptButton.isVisible()) {
                acceptButton.click();
                logger.info("Accepted cookies");
            }
        } catch (Exception e) {
            logger.info("No cookie banner found or unable to accept cookies");
        }
        
        // Enable network logging to capture requests and responses
        enableNetworkLogging();
        
        // Search for "Playwright automation"
        Locator searchBox = page.getByRole(AriaRole.COMBOBOX, new Page.GetByRoleOptions().setName("Search"));
        searchBox.fill("Playwright automation");
        logger.info("Entered search term");
        
        // Take screenshot of the search query
        takeScreenshot("search-query");
        
        // Submit the search
        searchBox.press("Enter");
        logger.info("Submitted search");
        
        // Wait for the search results
        page.waitForSelector("h3:has-text('Playwright')");
        logger.info("Search results loaded");
        
        // Take screenshot of the search results
        takeScreenshot("search-results");
        
        // Verify that the search results contain Playwright
        Locator results = page.locator("h3:has-text('Playwright')");
        int count = results.count();
        logger.info("Found {} search results containing 'Playwright'", count);
        
        if (count > 0) {
            results.first().scrollIntoViewIfNeeded();
            takeElementScreenshot("h3:has-text('Playwright')", "playwright-result");
        }
        
        // Create a network traffic report
        String report = networkInterceptor.createNetworkTrafficReport("Google Search Network Traffic");
        allureManager.attachText("Network Traffic Report", report);
        
        logger.info("Test completed successfully");
    }
    
    @Test
    @Feature("Natural Language Testing")
    @Story("LLM-Powered Test Steps")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Test execution of natural language test steps")
    public void testNaturalLanguageSteps() {
        logger.info("Starting natural language test");
        
        // Initialize LLM client
        LlmClient llmClient = new OpenAIClient();
        llmClient.initialize();
        
        if (!llmClient.isInitialized()) {
            logger.warn("LLM client initialization failed, skipping test");
            return;
        }
        
        // Create a test step parser
        TestStepParser stepParser = new TestStepParser(page, llmClient);
        
        // Define test steps in natural language
        List<String> testSteps = Arrays.asList(
            "Navigate to https://www.example.com",
            "Wait for the page to load",
            "Verify that the page title contains 'Example'",
            "Check if the heading says 'Example Domain'",
            "Verify that the page contains text about the domain being for use in illustrative examples"
        );
        
        // Execute the test steps
        Map<String, String> results = stepParser.executeSteps(testSteps);
        
        // Log and report the results
        logger.info("Test step execution results:");
        for (Map.Entry<String, String> entry : results.entrySet()) {
            String step = entry.getKey();
            String result = entry.getValue();
            
            logger.info("Step: {} - Result: {}", step, result);
            allureManager.attachText("Step: " + step, result);
        }
        
        // Take a final screenshot
        takeScreenshot("final-state");
        
        logger.info("Natural language test completed");
    }
    
    @Test(dataProvider = "searchTerms")
    @Feature("Data-Driven Testing")
    @Story("Search Functionality")
    @Severity(SeverityLevel.NORMAL)
    @Description("Test search functionality with different search terms")
    public void testDataDrivenSearch(String searchTerm, String expectedResult) {
        logger.info("Starting data-driven search test with term: {}", searchTerm);
        
        // Navigate to Google
        navigateTo("https://www.google.com");
        
        // Accept cookies if present
        try {
            Locator acceptButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Accept all"));
            if (acceptButton.isVisible()) {
                acceptButton.click();
            }
        } catch (Exception e) {
            logger.info("No cookie banner found or unable to accept cookies");
        }
        
        // Search for the provided term
        Locator searchBox = page.getByRole(AriaRole.COMBOBOX, new Page.GetByRoleOptions().setName("Search"));
        searchBox.fill(searchTerm);
        
        // Take screenshot with the search term
        takeScreenshot("search-" + searchTerm.replaceAll("\\s+", "-"));
        
        // Submit the search
        searchBox.press("Enter");
        
        // Wait for the search results
        page.waitForLoadState();
        
        // Verify that the search results contain the expected result
        boolean resultFound = page.content().contains(expectedResult);
        logger.info("Search for '{}' - Expected result '{}' found: {}", 
                searchTerm, expectedResult, resultFound);
        
        // Take screenshot of the search results
        takeScreenshot("results-" + searchTerm.replaceAll("\\s+", "-"));
        
        logger.info("Data-driven test completed for term: {}", searchTerm);
    }
    
    @DataProvider(name = "searchTerms")
    public Object[][] getSearchTerms() {
        return new Object[][] {
            {"Playwright automation", "Microsoft"},
            {"Selenium WebDriver", "Selenium"},
            {"TestNG framework", "TestNG"}
        };
    }
}
