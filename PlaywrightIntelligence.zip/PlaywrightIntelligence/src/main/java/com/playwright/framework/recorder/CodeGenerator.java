package com.playwright.framework.recorder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Generates executable test code from recorded user actions.
 * Supports generating code in Java for Playwright.
 */
public class CodeGenerator {
    private static final Logger logger = LoggerFactory.getLogger(CodeGenerator.class);
    
    /**
     * Generate Java code from recorded actions
     * @param actions List of recorded actions as code snippets
     * @return Complete Java test class as string
     */
    public String generateJavaCode(List<String> actions) {
        if (actions == null || actions.isEmpty()) {
            logger.warn("No actions to generate code from");
            return "";
        }
        
        logger.info("Generating Java code from {} recorded actions", actions.size());
        
        StringBuilder codeBuilder = new StringBuilder();
        
        // Add package and imports
        codeBuilder.append("package com.playwright.framework.tests;\n\n");
        codeBuilder.append("import com.microsoft.playwright.*;\n");
        codeBuilder.append("import com.playwright.framework.core.BaseTest;\n");
        codeBuilder.append("import io.qameta.allure.Description;\n");
        codeBuilder.append("import io.qameta.allure.Severity;\n");
        codeBuilder.append("import io.qameta.allure.SeverityLevel;\n");
        codeBuilder.append("import org.testng.annotations.Test;\n\n");
        
        // Add class definition
        codeBuilder.append("/**\n");
        codeBuilder.append(" * Auto-generated test from recording\n");
        codeBuilder.append(" * Created on: ").append(java.time.LocalDateTime.now()).append("\n");
        codeBuilder.append(" */\n");
        codeBuilder.append("public class RecordedTest extends BaseTest {\n\n");
        
        // Add test method
        codeBuilder.append("    @Test\n");
        codeBuilder.append("    @Description(\"Auto-generated test from recording\")\n");
        codeBuilder.append("    @Severity(SeverityLevel.NORMAL)\n");
        codeBuilder.append("    public void recordedTest() {\n");
        
        // Extract base URL from navigate actions
        String baseUrl = extractBaseUrl(actions);
        if (baseUrl != null && !baseUrl.isEmpty()) {
            codeBuilder.append("        // Base URL: ").append(baseUrl).append("\n");
        }
        
        // Add actions
        for (String action : actions) {
            // Clean up the action and add proper indentation
            String cleanAction = cleanupAction(action);
            codeBuilder.append("        ").append(cleanAction).append("\n");
        }
        
        // Add assertions placeholder
        codeBuilder.append("\n        // TODO: Add assertions here\n");
        
        // Close method and class
        codeBuilder.append("    }\n");
        codeBuilder.append("}\n");
        
        return codeBuilder.toString();
    }
    
    /**
     * Generate Python code from recorded actions
     * @param actions List of recorded actions as code snippets
     * @return Complete Python test script as string
     */
    public String generatePythonCode(List<String> actions) {
        if (actions == null || actions.isEmpty()) {
            logger.warn("No actions to generate Python code from");
            return "";
        }
        
        logger.info("Generating Python code from {} recorded actions", actions.size());
        
        StringBuilder codeBuilder = new StringBuilder();
        
        // Add imports
        codeBuilder.append("from playwright.sync_api import Playwright, sync_playwright, expect\n");
        codeBuilder.append("import pytest\n\n");
        
        // Add test function
        codeBuilder.append("def test_recorded():\n");
        codeBuilder.append("    with sync_playwright() as playwright:\n");
        codeBuilder.append("        browser = playwright.chromium.launch(headless=False)\n");
        codeBuilder.append("        context = browser.new_context()\n");
        codeBuilder.append("        page = context.new_page()\n\n");
        
        // Convert Java actions to Python
        for (String action : actions) {
            String pythonAction = convertJavaToPython(action);
            if (!pythonAction.isEmpty()) {
                codeBuilder.append("        ").append(pythonAction).append("\n");
            }
        }
        
        // Add assertions placeholder
        codeBuilder.append("\n        # TODO: Add assertions here\n\n");
        
        // Cleanup
        codeBuilder.append("        # Teardown\n");
        codeBuilder.append("        context.close()\n");
        codeBuilder.append("        browser.close()\n\n");
        
        // Add main block to run the test
        codeBuilder.append("if __name__ == \"__main__\":\n");
        codeBuilder.append("    test_recorded()\n");
        
        return codeBuilder.toString();
    }
    
    /**
     * Extract base URL from navigate actions
     * @param actions List of recorded actions
     * @return Base URL or empty string if not found
     */
    private String extractBaseUrl(List<String> actions) {
        for (String action : actions) {
            if (action.contains("navigate(")) {
                Pattern pattern = Pattern.compile("navigate\\(\"(https?://[^/]+)");
                Matcher matcher = pattern.matcher(action);
                if (matcher.find()) {
                    return matcher.group(1);
                }
            }
        }
        return "";
    }
    
    /**
     * Clean up action code for better readability
     * @param action Action code snippet
     * @return Cleaned up action
     */
    private String cleanupAction(String action) {
        // Remove any leading/trailing whitespace
        String cleaned = action.trim();
        
        // Ensure each action ends with semicolon
        if (!cleaned.endsWith(";") && !cleaned.startsWith("//")) {
            cleaned += ";";
        }
        
        return cleaned;
    }
    
    /**
     * Convert Java Playwright code to Python Playwright code
     * @param javaAction Java code snippet
     * @return Equivalent Python code
     */
    private String convertJavaToPython(String javaAction) {
        String action = javaAction.trim();
        
        // Skip comments
        if (action.startsWith("//")) {
            return "# " + action.substring(2).trim();
        }
        
        // Convert navigate
        if (action.contains("navigate(")) {
            Pattern pattern = Pattern.compile("navigate\\(\"([^\"]+)\"\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                return "page.goto(\"" + matcher.group(1) + "\")";
            }
        }
        
        // Convert click
        if (action.contains(".click()")) {
            Pattern pattern = Pattern.compile("locator\\(\"([^\"]+)\"\\)\\.click\\(\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                return "page.locator(\"" + matcher.group(1) + "\").click()";
            }
        }
        
        // Convert fill
        if (action.contains(".fill(")) {
            Pattern pattern = Pattern.compile("locator\\(\"([^\"]+)\"\\)\\.fill\\(\"([^\"]+)\"\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                return "page.locator(\"" + matcher.group(1) + "\").fill(\"" + matcher.group(2) + "\")";
            }
        }
        
        // If we couldn't convert, return a comment
        if (!action.isEmpty() && !action.equals(";")) {
            return "# TODO: Convert Java action: " + action;
        }
        
        return "";
    }
    
    /**
     * Generate natural language description from recorded actions
     * @param actions List of recorded actions
     * @return Human-readable test description
     */
    public String generateNaturalLanguageDescription(List<String> actions) {
        if (actions == null || actions.isEmpty()) {
            return "No actions recorded.";
        }
        
        StringBuilder description = new StringBuilder("Test steps:\n");
        int stepNumber = 1;
        
        for (String action : actions) {
            String step = convertActionToNaturalLanguage(action);
            if (!step.isEmpty()) {
                description.append(stepNumber++).append(". ").append(step).append("\n");
            }
        }
        
        return description.toString();
    }
    
    /**
     * Convert a Playwright action to natural language
     * @param action Playwright action code
     * @return Human-readable description
     */
    private String convertActionToNaturalLanguage(String action) {
        // Skip empty actions or just semicolons
        if (action == null || action.trim().isEmpty() || action.trim().equals(";")) {
            return "";
        }
        
        // Handle comments
        if (action.trim().startsWith("//")) {
            return action.trim().substring(2).trim();
        }
        
        // Handle navigation
        if (action.contains("navigate(")) {
            Pattern pattern = Pattern.compile("navigate\\(\"([^\"]+)\"\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                return "Navigate to " + matcher.group(1);
            }
        }
        
        // Handle clicks
        if (action.contains(".click()")) {
            Pattern pattern = Pattern.compile("locator\\(\"([^\"]+)\"\\)\\.click\\(\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                String selector = matcher.group(1);
                return "Click on " + formatSelectorForHumans(selector);
            }
        }
        
        // Handle text input
        if (action.contains(".fill(")) {
            Pattern pattern = Pattern.compile("locator\\(\"([^\"]+)\"\\)\\.fill\\(\"([^\"]+)\"\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                String selector = matcher.group(1);
                String text = matcher.group(2);
                return "Enter \"" + text + "\" into " + formatSelectorForHumans(selector);
            }
        }
        
        // Handle selectOption
        if (action.contains(".selectOption(")) {
            Pattern pattern = Pattern.compile("locator\\(\"([^\"]+)\"\\)\\.selectOption\\(\"([^\"]+)\"\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                String selector = matcher.group(1);
                String option = matcher.group(2);
                return "Select \"" + option + "\" from " + formatSelectorForHumans(selector) + " dropdown";
            }
        }
        
        // Handle check/uncheck
        if (action.contains(".check()")) {
            Pattern pattern = Pattern.compile("locator\\(\"([^\"]+)\"\\)\\.check\\(\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                String selector = matcher.group(1);
                return "Check " + formatSelectorForHumans(selector);
            }
        }
        
        if (action.contains(".uncheck()")) {
            Pattern pattern = Pattern.compile("locator\\(\"([^\"]+)\"\\)\\.uncheck\\(\\)");
            Matcher matcher = pattern.matcher(action);
            if (matcher.find()) {
                String selector = matcher.group(1);
                return "Uncheck " + formatSelectorForHumans(selector);
            }
        }
        
        // If we couldn't convert, return the raw action
        return "Perform action: " + action.trim();
    }
    
    /**
     * Format a selector into a more human-readable form
     * @param selector CSS or XPath selector
     * @return Human-readable description
     */
    private String formatSelectorForHumans(String selector) {
        // Handle common selector types
        if (selector.startsWith("#")) {
            return "element with ID \"" + selector.substring(1) + "\"";
        }
        
        if (selector.startsWith(".")) {
            return "element with class \"" + selector.substring(1) + "\"";
        }
        
        if (selector.startsWith("[name=")) {
            Pattern pattern = Pattern.compile("\\[name=\"([^\"]+)\"\\]");
            Matcher matcher = pattern.matcher(selector);
            if (matcher.find()) {
                return "element with name \"" + matcher.group(1) + "\"";
            }
        }
        
        if (selector.startsWith("[data-testid=")) {
            Pattern pattern = Pattern.compile("\\[data-testid=\"([^\"]+)\"\\]");
            Matcher matcher = pattern.matcher(selector);
            if (matcher.find()) {
                return "element with test ID \"" + matcher.group(1) + "\"";
            }
        }
        
        if (selector.startsWith("text=")) {
            return "element with text \"" + selector.substring(5) + "\"";
        }
        
        if (selector.startsWith("//")) {
            return "element identified by XPath";
        }
        
        // For other selectors, just use the raw selector
        return "element \"" + selector + "\"";
    }
}
