package com.playwright.framework.dataprovider;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.DataProvider;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

/**
 * Data provider for JSON data sources.
 * Supports reading test data from JSON files.
 */
public class JsonDataProvider {
    private static final Logger logger = LoggerFactory.getLogger(JsonDataProvider.class);
    private final String filePath;
    private final ObjectMapper objectMapper;
    
    /**
     * Constructor for JsonDataProvider
     * @param filePath Path to the JSON file
     */
    public JsonDataProvider(String filePath) {
        this.filePath = filePath;
        this.objectMapper = new ObjectMapper();
        logger.info("Initialized JsonDataProvider with file: {}", filePath);
    }
    
    /**
     * Get the JSON data as a JsonNode
     * @return JsonNode representing the JSON data
     * @throws IOException If the file cannot be read or parsed
     */
    public JsonNode getJsonData() throws IOException {
        logger.debug("Reading JSON data from file: {}", filePath);
        return objectMapper.readTree(new File(filePath));
    }
    
    /**
     * Get a specific JSON node by path
     * @param path Path to the node (e.g., "users.0.name")
     * @return JsonNode at the specified path
     * @throws IOException If the file cannot be read or parsed
     */
    public JsonNode getJsonNode(String path) throws IOException {
        JsonNode rootNode = getJsonData();
        
        if (path == null || path.isEmpty()) {
            return rootNode;
        }
        
        String[] pathSegments = path.split("\\.");
        JsonNode currentNode = rootNode;
        
        for (String segment : pathSegments) {
            if (currentNode.isArray()) {
                try {
                    int index = Integer.parseInt(segment);
                    currentNode = currentNode.get(index);
                } catch (NumberFormatException e) {
                    logger.warn("Invalid array index: {}", segment);
                    return null;
                }
            } else {
                currentNode = currentNode.get(segment);
            }
            
            if (currentNode == null) {
                logger.warn("Path not found in JSON: {}", path);
                return null;
            }
        }
        
        return currentNode;
    }
    
    /**
     * Get a value from the JSON by path
     * @param path Path to the value (e.g., "users.0.name")
     * @return String value at the specified path
     * @throws IOException If the file cannot be read or parsed
     */
    public String getValue(String path) throws IOException {
        JsonNode node = getJsonNode(path);
        
        if (node != null) {
            if (node.isTextual()) {
                return node.asText();
            } else {
                return node.toString();
            }
        }
        
        return null;
    }
    
    /**
     * Parse JSON array into a list of maps for data-driven testing
     * @param arrayPath Path to the JSON array
     * @return List of maps, each representing a row of test data
     * @throws IOException If the file cannot be read or parsed
     */
    public List<Map<String, String>> getDataAsList(String arrayPath) throws IOException {
        JsonNode arrayNode = getJsonNode(arrayPath);
        List<Map<String, String>> dataList = new ArrayList<>();
        
        if (arrayNode != null && arrayNode.isArray()) {
            for (JsonNode element : arrayNode) {
                Map<String, String> row = new HashMap<>();
                Iterator<Map.Entry<String, JsonNode>> fields = element.fields();
                
                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> field = fields.next();
                    row.put(field.getKey(), field.getValue().asText());
                }
                
                dataList.add(row);
            }
        } else {
            logger.warn("Path does not point to an array or not found: {}", arrayPath);
        }
        
        return dataList;
    }
    
    /**
     * TestNG DataProvider method to provide test data from JSON
     * @param arrayPath Path to the JSON array containing test data
     * @return Object array for TestNG data-driven testing
     */
    @DataProvider(name = "jsonData")
    public Object[][] provideData(String arrayPath) {
        try {
            List<Map<String, String>> dataList = getDataAsList(arrayPath);
            Object[][] data = new Object[dataList.size()][1];
            
            for (int i = 0; i < dataList.size(); i++) {
                data[i][0] = dataList.get(i);
            }
            
            logger.info("Provided {} rows of test data from JSON", dataList.size());
            return data;
        } catch (IOException e) {
            logger.error("Failed to read JSON data from file: {}", filePath, e);
            return new Object[0][0];
        }
    }
    
    /**
     * Update a value in the JSON file
     * @param path Path to the value to update
     * @param newValue New value to set
     * @return true if update was successful, false otherwise
     */
    public boolean updateValue(String path, String newValue) {
        try {
            JsonNode rootNode = getJsonData();
            
            // Parse the path
            String[] pathSegments = path.split("\\.");
            JsonNode currentNode = rootNode;
            String lastSegment = pathSegments[pathSegments.length - 1];
            
            // Navigate to the parent node
            for (int i = 0; i < pathSegments.length - 1; i++) {
                String segment = pathSegments[i];
                
                if (currentNode.isArray()) {
                    currentNode = currentNode.get(Integer.parseInt(segment));
                } else {
                    currentNode = currentNode.get(segment);
                }
                
                if (currentNode == null) {
                    logger.warn("Path not found in JSON: {}", path);
                    return false;
                }
            }
            
            // Using reflection to modify the JsonNode (not ideal, but Jackson doesn't directly support updates)
            // In a real implementation, we would use a more robust approach
            // For now, we'll recreate the JSON with the modified value
            
            // Convert to editable map
            Map<String, Object> data = objectMapper.convertValue(rootNode, Map.class);
            
            // Update the value in the map
            Map<String, Object> currentMap = data;
            for (int i = 0; i < pathSegments.length - 1; i++) {
                String segment = pathSegments[i];
                
                Object nextObj = currentMap.get(segment);
                if (nextObj instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> nextMap = (Map<String, Object>) nextObj;
                    currentMap = nextMap;
                } else if (nextObj instanceof List) {
                    @SuppressWarnings("unchecked")
                    List<Object> list = (List<Object>) nextObj;
                    int index = Integer.parseInt(pathSegments[++i]);
                    if (index < list.size()) {
                        Object item = list.get(index);
                        if (item instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> mapItem = (Map<String, Object>) item;
                            currentMap = mapItem;
                        } else {
                            logger.warn("Cannot update non-map item in array");
                            return false;
                        }
                    } else {
                        logger.warn("Array index out of bounds");
                        return false;
                    }
                }
            }
            
            // Update the final value
            currentMap.put(lastSegment, newValue);
            
            // Write the updated JSON back to the file
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(filePath), data);
            
            logger.info("Updated JSON value at path: {}", path);
            return true;
        } catch (Exception e) {
            logger.error("Failed to update JSON value", e);
            return false;
        }
    }
    
    /**
     * Convert a generic Object to a Map (useful for JSON data)
     * @param obj Object to convert
     * @return Map representation of the object
     */
    public Map<String, Object> objectToMap(Object obj) {
        return objectMapper.convertValue(obj, Map.class);
    }
}
