package com.playwright.framework.dataprovider;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.DataProvider;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Data provider for Excel data sources.
 * Supports reading test data from Excel files.
 */
public class ExcelDataProvider {
    private static final Logger logger = LoggerFactory.getLogger(ExcelDataProvider.class);
    private final String filePath;
    
    /**
     * Constructor for ExcelDataProvider
     * @param filePath Path to the Excel file
     */
    public ExcelDataProvider(String filePath) {
        this.filePath = filePath;
        logger.info("Initialized ExcelDataProvider with file: {}", filePath);
    }
    
    /**
     * Parse the Excel file and return the data from the first sheet as a list of maps
     * @return List of maps, each representing a row of data
     * @throws IOException If the file cannot be read or parsed
     */
    public List<Map<String, String>> getData() throws IOException {
        return getData(0);
    }
    
    /**
     * Parse the Excel file and return the data from a specific sheet as a list of maps
     * @param sheetIndex Index of the sheet (0-based)
     * @return List of maps, each representing a row of data
     * @throws IOException If the file cannot be read or parsed
     */
    public List<Map<String, String>> getData(int sheetIndex) throws IOException {
        logger.debug("Reading Excel data from file: {} (sheet index: {})", filePath, sheetIndex);
        List<Map<String, String>> dataList = new ArrayList<>();
        
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = WorkbookFactory.create(fis)) {
            
            if (sheetIndex >= workbook.getNumberOfSheets()) {
                logger.warn("Sheet index out of bounds: {}", sheetIndex);
                return dataList;
            }
            
            Sheet sheet = workbook.getSheetAt(sheetIndex);
            Row headerRow = sheet.getRow(0);
            
            if (headerRow == null) {
                logger.warn("No header row found in sheet");
                return dataList;
            }
            
            // Get the header names
            List<String> headers = new ArrayList<>();
            for (Cell cell : headerRow) {
                headers.add(getCellValueAsString(cell));
            }
            
            // Process each data row
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row != null) {
                    Map<String, String> rowData = new HashMap<>();
                    
                    for (int j = 0; j < headers.size(); j++) {
                        Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                        rowData.put(headers.get(j), getCellValueAsString(cell));
                    }
                    
                    dataList.add(rowData);
                }
            }
            
            logger.debug("Read {} rows from Excel file", dataList.size());
            return dataList;
        }
    }
    
    /**
     * Parse the Excel file and return the data from a specific sheet as a list of maps
     * @param sheetName Name of the sheet
     * @return List of maps, each representing a row of data
     * @throws IOException If the file cannot be read or parsed
     */
    public List<Map<String, String>> getData(String sheetName) throws IOException {
        logger.debug("Reading Excel data from file: {} (sheet: {})", filePath, sheetName);
        List<Map<String, String>> dataList = new ArrayList<>();
        
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = WorkbookFactory.create(fis)) {
            
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                logger.warn("Sheet not found: {}", sheetName);
                return dataList;
            }
            
            Row headerRow = sheet.getRow(0);
            
            if (headerRow == null) {
                logger.warn("No header row found in sheet");
                return dataList;
            }
            
            // Get the header names
            List<String> headers = new ArrayList<>();
            for (Cell cell : headerRow) {
                headers.add(getCellValueAsString(cell));
            }
            
            // Process each data row
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row != null) {
                    Map<String, String> rowData = new HashMap<>();
                    
                    for (int j = 0; j < headers.size(); j++) {
                        Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                        rowData.put(headers.get(j), getCellValueAsString(cell));
                    }
                    
                    dataList.add(rowData);
                }
            }
            
            logger.debug("Read {} rows from Excel file", dataList.size());
            return dataList;
        }
    }
    
    /**
     * Get a specific cell value from the Excel file
     * @param sheetName Name of the sheet
     * @param rowIndex Index of the row (0-based)
     * @param columnIndex Index of the column (0-based)
     * @return Value of the cell as a string
     * @throws IOException If the file cannot be read or parsed
     */
    public String getCellValue(String sheetName, int rowIndex, int columnIndex) throws IOException {
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = WorkbookFactory.create(fis)) {
            
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                logger.warn("Sheet not found: {}", sheetName);
                return "";
            }
            
            Row row = sheet.getRow(rowIndex);
            if (row == null) {
                logger.warn("Row not found at index: {}", rowIndex);
                return "";
            }
            
            Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            return getCellValueAsString(cell);
        }
    }
    
    /**
     * Get a specific cell value from the Excel file
     * @param sheetName Name of the sheet
     * @param rowIndex Index of the row (0-based)
     * @param columnName Name of the column (header)
     * @return Value of the cell as a string
     * @throws IOException If the file cannot be read or parsed
     */
    public String getCellValue(String sheetName, int rowIndex, String columnName) throws IOException {
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = WorkbookFactory.create(fis)) {
            
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                logger.warn("Sheet not found: {}", sheetName);
                return "";
            }
            
            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                logger.warn("Header row not found");
                return "";
            }
            
            // Find the column index for the given column name
            int columnIndex = -1;
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                Cell cell = headerRow.getCell(i);
                if (cell != null && columnName.equals(getCellValueAsString(cell))) {
                    columnIndex = i;
                    break;
                }
            }
            
            if (columnIndex == -1) {
                logger.warn("Column not found: {}", columnName);
                return "";
            }
            
            Row row = sheet.getRow(rowIndex);
            if (row == null) {
                logger.warn("Row not found at index: {}", rowIndex);
                return "";
            }
            
            Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            return getCellValueAsString(cell);
        }
    }
    
    /**
     * Get the names of all sheets in the Excel file
     * @return List of sheet names
     * @throws IOException If the file cannot be read or parsed
     */
    public List<String> getSheetNames() throws IOException {
        List<String> sheetNames = new ArrayList<>();
        
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = WorkbookFactory.create(fis)) {
            
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                sheetNames.add(workbook.getSheetName(i));
            }
        }
        
        return sheetNames;
    }
    
    /**
     * Get the value of a cell as a string, regardless of cell type
     * @param cell Excel cell
     * @return String value of the cell
     */
    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    // Convert numeric to string without scientific notation
                    double value = cell.getNumericCellValue();
                    if (value == Math.floor(value)) {
                        return String.format("%.0f", value);
                    } else {
                        return String.valueOf(value);
                    }
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                try {
                    return String.valueOf(cell.getNumericCellValue());
                } catch (Exception e) {
                    try {
                        return cell.getStringCellValue();
                    } catch (Exception ex) {
                        return cell.getCellFormula();
                    }
                }
            default:
                return "";
        }
    }
    
    /**
     * TestNG DataProvider method to provide test data from Excel
     * @param sheetName Name of the sheet to read data from
     * @return Object array for TestNG data-driven testing
     */
    @DataProvider(name = "excelData")
    public Object[][] provideData(String sheetName) {
        try {
            List<Map<String, String>> dataList = getData(sheetName);
            Object[][] data = new Object[dataList.size()][1];
            
            for (int i = 0; i < dataList.size(); i++) {
                data[i][0] = dataList.get(i);
            }
            
            logger.info("Provided {} rows of test data from Excel sheet: {}", dataList.size(), sheetName);
            return data;
        } catch (IOException e) {
            logger.error("Failed to read Excel data from file: {}", filePath, e);
            return new Object[0][0];
        }
    }
}
