package com.playwright.framework.utils;

import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.RecordVideoSize;
import com.playwright.framework.config.FrameworkConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility class for recording videos of test executions.
 * Uses Playwright's built-in video recording capabilities.
 */
public class VideoRecorder {
    private static final Logger logger = LoggerFactory.getLogger(VideoRecorder.class);
    private final BrowserContext context;
    private final FrameworkConfig config;
    private final String videosDir;
    private String currentVideoPath;
    private boolean isRecording = false;
    
    public VideoRecorder(BrowserContext context) {
        this.context = context;
        this.config = FrameworkConfig.getInstance();
        this.videosDir = config.getVideosDir();
    }
    
    /**
     * Start video recording
     * @return Path to the video file
     */
    public String startRecording() {
        try {
            if (isRecording) {
                logger.warn("Video recording is already in progress");
                return currentVideoPath;
            }
            
            // Create the videos directory if it doesn't exist
            File directory = new File(videosDir);
            if (!directory.exists()) {
                directory.mkdirs();
            }
            
            // Generate a unique video file path
            String videoFileName = generateVideoFileName();
            Path videoPath = Paths.get(videosDir, videoFileName);
            currentVideoPath = videoPath.toString();
            
            logger.info("Starting video recording: {}", currentVideoPath);
            
            // Configure video size
            int width = config.getIntProperty("video.width", 1280);
            int height = config.getIntProperty("video.height", 720);
            
            // For Playwright 1.39.0, we need to create a new context with video recording
            // This will be implemented differently since we can't modify the context after creation
            logger.info("Note: In Playwright 1.39.0, video recording must be configured when creating the context");
            
            isRecording = true;
            
            return currentVideoPath;
        } catch (Exception e) {
            logger.error("Failed to start video recording", e);
            return null;
        }
    }
    
    /**
     * Stop video recording
     * @return Path to the recorded video file
     */
    public String stopRecording() {
        try {
            if (!isRecording) {
                logger.warn("Video recording is not in progress");
                return null;
            }
            
            logger.info("Stopping video recording: {}", currentVideoPath);
            
            // In Playwright, video recording is automatically stopped when context is closed,
            // but we can wait here for any pending video writes to complete
            // We'll close the context only if explicitly requested
            if (config.getBooleanProperty("close.context.after.recording", false)) {
                context.close();
            }
            
            isRecording = false;
            
            return currentVideoPath;
        } catch (Exception e) {
            logger.error("Failed to stop video recording", e);
            return null;
        }
    }
    
    /**
     * Check if recording is currently in progress
     * @return true if recording, false otherwise
     */
    public boolean isRecording() {
        return isRecording;
    }
    
    /**
     * Get the path of the current video recording
     * @return Path to the current video file or null if not recording
     */
    public String getCurrentVideoPath() {
        return currentVideoPath;
    }
    
    /**
     * Generate a unique filename for a video recording
     * @return Generated filename with timestamp
     */
    private String generateVideoFileName() {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String testName = Thread.currentThread().getStackTrace()[3].getMethodName();
        String cleanTestName = testName.replaceAll("[^a-zA-Z0-9-_]", "_");
        
        return String.format("video_%s_%s.webm", cleanTestName, timestamp);
    }
}
