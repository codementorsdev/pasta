package com.playwright.framework.reporting;

import com.playwright.framework.config.FrameworkConfig;
import io.qameta.allure.Allure;
import io.qameta.allure.Attachment;
import io.qameta.allure.model.Status;
import io.qameta.allure.model.StepResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

/**
 * Manager class for Allure reporting functionality.
 * Provides methods for attaching screenshots, videos, and other artifacts to the report.
 */
public class AllureManager {
    private static final Logger logger = LoggerFactory.getLogger(AllureManager.class);
    private final FrameworkConfig config;
    
    public AllureManager() {
        this.config = FrameworkConfig.getInstance();
        logger.info("Initialized AllureManager");
    }
    
    /**
     * Set the test start time in Allure report
     * @param result TestNG test result
     */
    public void setTestStartTime(ITestResult result) {
        logger.debug("Setting test start time for: {}", result.getName());
        Allure.getLifecycle().updateTestCase(uuid -> {
            // No action needed, just update timestamp
        });
    }
    
    /**
     * Start a step in the Allure report
     * @param stepName Name of the step
     * @return UUID of the created step
     */
    public String startStep(String stepName) {
        logger.debug("Starting Allure step: {}", stepName);
        
        String uuid = UUID.randomUUID().toString();
        StepResult result = new StepResult()
                .setName(stepName)
                .setStatus(Status.PASSED);
        
        Allure.getLifecycle().startStep(uuid, result);
        return uuid;
    }
    
    /**
     * Stop a step in the Allure report
     * @param uuid UUID of the step to stop
     * @param status Status of the step (passed, failed, skipped)
     */
    public void stopStep(String uuid, Status status) {
        logger.debug("Stopping Allure step with status: {}", status);
        
        Allure.getLifecycle().updateStep(uuid, step -> step.setStatus(status));
        Allure.getLifecycle().stopStep(uuid);
    }
    
    /**
     * Create a step in the Allure report with automatic start and stop
     * @param stepName Name of the step
     * @param runnable Code to execute within the step
     */
    public void step(String stepName, Runnable runnable) {
        logger.debug("Creating Allure step: {}", stepName);
        
        String uuid = startStep(stepName);
        try {
            runnable.run();
            stopStep(uuid, Status.PASSED);
        } catch (Throwable e) {
            stopStep(uuid, Status.FAILED);
            throw e;
        }
    }
    
    /**
     * Attach a screenshot to the Allure report
     * @param name Name of the screenshot
     * @param screenshotPath Path to the screenshot file
     */
    public void attachScreenshot(String name, String screenshotPath) {
        if (screenshotPath == null || screenshotPath.isEmpty()) {
            logger.warn("Cannot attach screenshot - path is null or empty");
            return;
        }
        
        logger.debug("Attaching screenshot to Allure report: {}", name);
        
        try {
            Path path = Paths.get(screenshotPath);
            byte[] content = Files.readAllBytes(path);
            
            // Determine the content type based on the file extension
            String extension = getFileExtension(screenshotPath).toLowerCase();
            String contentType;
            
            switch (extension) {
                case "png":
                    contentType = "image/png";
                    break;
                case "jpg":
                case "jpeg":
                    contentType = "image/jpeg";
                    break;
                case "gif":
                    contentType = "image/gif";
                    break;
                case "bmp":
                    contentType = "image/bmp";
                    break;
                default:
                    contentType = "image/png"; // Default to PNG
            }
            
            Allure.getLifecycle().addAttachment(name, contentType, extension, content);
            logger.debug("Screenshot attached successfully");
        } catch (IOException e) {
            logger.error("Failed to attach screenshot", e);
        }
    }
    
    /**
     * Attach a video to the Allure report
     * @param name Name of the video
     * @param videoPath Path to the video file
     */
    public void attachVideo(String name, String videoPath) {
        if (videoPath == null || videoPath.isEmpty()) {
            logger.warn("Cannot attach video - path is null or empty");
            return;
        }
        
        logger.debug("Attaching video to Allure report: {}", name);
        
        try {
            Path path = Paths.get(videoPath);
            byte[] content = Files.readAllBytes(path);
            
            // Determine the content type based on the file extension
            String extension = getFileExtension(videoPath).toLowerCase();
            String contentType;
            
            switch (extension) {
                case "mp4":
                    contentType = "video/mp4";
                    break;
                case "webm":
                    contentType = "video/webm";
                    break;
                case "ogg":
                    contentType = "video/ogg";
                    break;
                case "avi":
                    contentType = "video/x-msvideo";
                    break;
                default:
                    contentType = "video/webm"; // Default to WebM (Playwright's format)
            }
            
            Allure.getLifecycle().addAttachment(name, contentType, extension, content);
            logger.debug("Video attached successfully");
        } catch (IOException e) {
            logger.error("Failed to attach video", e);
        }
    }
    
    /**
     * Attach text content to the Allure report
     * @param name Name of the attachment
     * @param content Text content
     */
    public void attachText(String name, String content) {
        logger.debug("Attaching text to Allure report: {}", name);
        Allure.addAttachment(name, "text/plain", content);
    }
    
    /**
     * Attach HTML content to the Allure report
     * @param name Name of the attachment
     * @param content HTML content
     */
    public void attachHtml(String name, String content) {
        logger.debug("Attaching HTML to Allure report: {}", name);
        Allure.addAttachment(name, "text/html", content);
    }
    
    /**
     * Attach JSON content to the Allure report
     * @param name Name of the attachment
     * @param content JSON content
     */
    public void attachJson(String name, String content) {
        logger.debug("Attaching JSON to Allure report: {}", name);
        Allure.addAttachment(name, "application/json", content);
    }
    
    /**
     * Attach an arbitrary file to the Allure report
     * @param name Name of the attachment
     * @param filePath Path to the file
     */
    public void attachFile(String name, String filePath) {
        if (filePath == null || filePath.isEmpty()) {
            logger.warn("Cannot attach file - path is null or empty");
            return;
        }
        
        logger.debug("Attaching file to Allure report: {}", name);
        
        try {
            Path path = Paths.get(filePath);
            String extension = getFileExtension(filePath);
            
            try (InputStream is = Files.newInputStream(path)) {
                Allure.addAttachment(name, "application/octet-stream", is, extension);
            }
        } catch (IOException e) {
            logger.error("Failed to attach file", e);
        }
    }
    
    /**
     * Set a parameter in the Allure report
     * @param name Parameter name
     * @param value Parameter value
     */
    public void setParameter(String name, String value) {
        logger.debug("Setting Allure parameter: {} = {}", name, value);
        Allure.parameter(name, value);
    }
    
    /**
     * Add a label to the current test in the Allure report
     * @param name Label name
     * @param value Label value
     */
    public void addLabel(String name, String value) {
        logger.debug("Adding Allure label: {} = {}", name, value);
        Allure.label(name, value);
    }
    
    /**
     * Add a link to the current test in the Allure report
     * @param name Link name
     * @param url Link URL
     */
    public void addLink(String name, String url) {
        logger.debug("Adding Allure link: {} -> {}", name, url);
        Allure.link(name, url);
    }
    
    /**
     * Set a description for the current test in the Allure report
     * @param description Test description
     */
    public void setDescription(String description) {
        logger.debug("Setting Allure description");
        Allure.description(description);
    }
    
    /**
     * Get the file extension from a path
     * @param path File path
     * @return File extension
     */
    private String getFileExtension(String path) {
        int dotIndex = path.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < path.length() - 1) {
            return path.substring(dotIndex + 1);
        }
        return "";
    }
    
    /**
     * Generate the Allure report
     * @param outputDir Directory to output the report
     */
    public void generateReport(String outputDir) {
        logger.info("Generating Allure report to directory: {}", outputDir);
        
        // Create the output directory if it doesn't exist
        File directory = new File(outputDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        
        // In a real implementation, this would use the Allure command line tool
        // to generate the report, but here we'll just log the instruction
        logger.info("To generate the Allure report, run: allure generate {} -o {}", 
                config.getAllureResultsDir(), outputDir);
    }
}
