package com.playwright.framework.config;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * This class provides browser configuration settings for Playwright.
 * It includes methods to get browser launch options and browser context options.
 */
public class BrowserConfig {
    private static final Logger logger = LoggerFactory.getLogger(BrowserConfig.class);
    private final FrameworkConfig config;
    
    public BrowserConfig() {
        this.config = FrameworkConfig.getInstance();
    }
    
    /**
     * Get browser launch options based on configuration
     * @return Browser launch options as a map
     */
    public BrowserType.LaunchOptions getLaunchOptions() {
        BrowserType.LaunchOptions options = new BrowserType.LaunchOptions()
                .setHeadless(config.isHeadless())
                .setSlowMo(config.getIntProperty("browser.slowmo", 0));
        
        // Set chromium-specific launch arguments if using chromium
        if ("chromium".equalsIgnoreCase(config.getBrowserType())) {
            options.setArgs(Arrays.asList(getChromiumArgs()));
        }
        
        // Set the timeout for browser launch
        options.setTimeout(config.getIntProperty("browser.launch.timeout", 30000));
        
        logger.debug("Browser launch options: {}", options);
        return options;
    }
    
    /**
     * Get browser context options based on configuration
     * @return Browser context options
     */
    public Browser.NewContextOptions getContextOptions() {
        Browser.NewContextOptions options = new Browser.NewContextOptions()
                .setViewportSize(
                        config.getIntProperty("browser.width", 1920),
                        config.getIntProperty("browser.height", 1080)
                )
                .setIgnoreHTTPSErrors(config.getBooleanProperty("browser.ignore.https.errors", false))
                .setJavaScriptEnabled(config.getBooleanProperty("browser.javascript.enabled", true))
                .setDeviceScaleFactor(config.getIntProperty("browser.device.scale.factor", 1))
                .setHasTouch(config.getBooleanProperty("browser.has.touch", false))
                .setIsMobile(config.getBooleanProperty("browser.is.mobile", false));
        
        // Set geolocation if enabled
        if (config.getBooleanProperty("browser.geolocation.enabled", false)) {
            options.setGeolocation(
                    config.getIntProperty("browser.geolocation.latitude", 0),
                    config.getIntProperty("browser.geolocation.longitude", 0)
            );
        }
        
        // Set permissions if specified
        String permissions = config.getProperty("browser.permissions", "");
        if (!permissions.isEmpty()) {
            options.setPermissions(Arrays.asList(permissions.split(",")));
        }
        
        // Set locale and timezone
        options.setLocale(config.getProperty("browser.locale", "en-US"));
        options.setTimezoneId(config.getProperty("browser.timezone", "UTC"));
        
        // Set HTTP credentials if provided
        String username = config.getProperty("browser.http.credentials.username", "");
        String password = config.getProperty("browser.http.credentials.password", "");
        if (!username.isEmpty() && !password.isEmpty()) {
            options.setHttpCredentials(username, password);
        }
        
        // Set record video options if enabled
        if (config.getBooleanProperty("record.video", false)) {
            options.setRecordVideoDir(Paths.get(config.getVideosDir()));
        }
        
        logger.debug("Browser context options: {}", options);
        return options;
    }
    
    /**
     * Get Chromium-specific launch arguments
     * @return Array of Chromium launch arguments
     */
    private String[] getChromiumArgs() {
        return new String[] {
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-accelerated-2d-canvas",
                "--no-first-run",
                "--no-zygote",
                "--disable-gpu",
                "--disable-web-security",
                "--disable-features=IsolateOrigins,site-per-process"
        };
    }
    
    /**
     * Get extra HTTP headers to be sent with every request
     * @return Map of HTTP headers
     */
    public Map<String, String> getExtraHTTPHeaders() {
        Map<String, String> headers = new HashMap<>();
        
        // Add user-agent if specified
        String userAgent = config.getProperty("browser.user.agent", "");
        if (!userAgent.isEmpty()) {
            headers.put("User-Agent", userAgent);
        }
        
        // Add any other custom headers specified in the configuration
        String customHeaders = config.getProperty("browser.custom.headers", "");
        if (!customHeaders.isEmpty()) {
            String[] headerPairs = customHeaders.split(";");
            for (String pair : headerPairs) {
                String[] keyValue = pair.split(":");
                if (keyValue.length == 2) {
                    headers.put(keyValue[0].trim(), keyValue[1].trim());
                }
            }
        }
        
        return headers;
    }
}
