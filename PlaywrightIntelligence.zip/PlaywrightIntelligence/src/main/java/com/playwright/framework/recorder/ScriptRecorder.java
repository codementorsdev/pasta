package com.playwright.framework.recorder;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;
import com.playwright.framework.config.FrameworkConfig;
import com.playwright.framework.core.PlaywrightFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * Records user interactions with the browser and generates automation scripts.
 * Utilizes Playwright's event listeners to capture user actions.
 */
public class ScriptRecorder {
    private static final Logger logger = LoggerFactory.getLogger(ScriptRecorder.class);
    private final FrameworkConfig config;
    private final PlaywrightFactory playwrightFactory;
    private final CodeGenerator codeGenerator;
    private final List<String> recordedActions = new ArrayList<>();
    private final AtomicBoolean isRecording = new AtomicBoolean(false);
    
    private Page page;
    private BrowserContext context;
    
    public ScriptRecorder() {
        this.config = FrameworkConfig.getInstance();
        this.playwrightFactory = PlaywrightFactory.getInstance();
        this.codeGenerator = new CodeGenerator();
    }
    
    /**
     * Start recording user interactions
     * @param url Initial URL to navigate to
     * @return The Page instance being used for recording
     */
    public Page startRecording(String url) {
        try {
            if (isRecording.get()) {
                logger.warn("Recording is already in progress");
                return page;
            }
            
            logger.info("Starting script recording session");
            
            // Initialize Playwright if needed
            if (playwrightFactory.getPage() == null) {
                page = playwrightFactory.initializeBrowser();
            } else {
                page = playwrightFactory.getPage();
            }
            
            context = playwrightFactory.getBrowserContext();
            
            // Clear previous recorded actions
            recordedActions.clear();
            
            // Set up event listeners
            setupEventListeners();
            
            // Navigate to the initial URL
            if (url != null && !url.isEmpty()) {
                page.navigate(url);
                recordedActions.add(String.format("page.navigate(\"%s\");", url));
            }
            
            isRecording.set(true);
            logger.info("Recording started. Navigate and interact with the browser...");
            
            return page;
        } catch (Exception e) {
            logger.error("Failed to start recording", e);
            throw new RuntimeException("Failed to start recording: " + e.getMessage(), e);
        }
    }
    
    /**
     * Stop recording and generate code
     * @param outputPath Path to save the generated code
     * @return Path to the generated code file
     */
    public String stopRecording(String outputPath) {
        if (!isRecording.get()) {
            logger.warn("No recording in progress");
            return null;
        }
        
        logger.info("Stopping script recording session");
        isRecording.set(false);
        
        // Generate code based on recorded actions
        String generatedCode = codeGenerator.generateJavaCode(recordedActions);
        
        // Save code to file if output path provided
        if (outputPath != null) {
            try {
                Path filePath = saveGeneratedCode(generatedCode, outputPath);
                logger.info("Generated code saved to: {}", filePath);
                return filePath.toString();
            } catch (IOException e) {
                logger.error("Failed to save generated code", e);
            }
        }
        
        return generatedCode;
    }
    
    /**
     * Check if recording is in progress
     * @return true if recording, false otherwise
     */
    public boolean isRecording() {
        return isRecording.get();
    }
    
    /**
     * Get the list of recorded actions
     * @return List of recorded actions as code snippets
     */
    public List<String> getRecordedActions() {
        return new ArrayList<>(recordedActions);
    }
    
    /**
     * Set up event listeners to capture user interactions
     */
    private void setupEventListeners() {
        // In Playwright 1.39.0, we need to use a different approach for handling events
        page.onFrameNavigated(frame -> {
            if (!isRecording.get() || !frame.equals(page.mainFrame())) return;
            
            String url = frame.url();
            logger.debug("Navigation to: {}", url);
            recordedActions.add(String.format("page.navigate(\"%s\");", url));
        });
        
        // In Playwright 1.39.0, we need to use a custom method for clicks
        // We'll use page console messages as a workaround to track clicks
        page.onConsoleMessage(message -> {
            if (!isRecording.get()) return;
            
            // Check if this is a click-related message we injected
            String text = message.text();
            if (text.startsWith("RECORDER_CLICK:")) {
                try {
                    String clickInfo = text.substring("RECORDER_CLICK:".length());
                    logger.debug("Click detected: {}", clickInfo);
                    recordedActions.add(String.format("// Click detected: %s", clickInfo));
                } catch (Exception e) {
                    logger.warn("Failed to record click event", e);
                }
            }
        });
        
        // Inject click tracking script
        page.evaluate("() => {" +
            "  document.addEventListener('click', event => {" +
            "    const target = event.target;" +
            "    const tagName = target.tagName;" +
            "    const id = target.id;" +
            "    const className = target.className;" +
            "    console.log('RECORDER_CLICK:' + tagName + (id ? '#' + id : '') + " +
            "      (className ? '.' + className.replace(/\\s+/g, '.') : ''));" +
            "  });" +
            "}");
        
        // Listen for input events
        page.onDialog(dialog -> {
            if (!isRecording.get()) return;
            
            String message = dialog.message();
            String type = dialog.type().toString().toLowerCase();
            
            logger.debug("Dialog: {} - {}", type, message);
            recordedActions.add(String.format("// Dialog appeared: %s - %s", type, message));
            
            if (config.getBooleanProperty("auto.handle.dialogs", true)) {
                dialog.accept();
                recordedActions.add("page.onDialog(dialog -> dialog.accept());");
            }
        });
        
        // Custom event listener for form inputs
        page.evaluate("() => {" +
            "  document.addEventListener('input', event => {" +
            "    const target = event.target;" +
            "    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {" +
            "      const value = target.value;" +
            "      const id = target.id;" +
            "      const name = target.name;" +
            "      const selector = id ? '#' + id : name ? '[name=\"' + name + '\"]' : '';" +
            "      if (selector) {" +
            "        window.__recordedInput = { selector, value };" +
            "      }" +
            "    }" +
            "  }, true);" +
            "}");
        
        // Poll for recorded input events
        if (config.getBooleanProperty("record.input.events", true)) {
            Thread inputPollThread = new Thread(() -> {
                while (isRecording.get()) {
                    try {
                        Object result = page.evaluate("() => {" +
                            "  const data = window.__recordedInput;" +
                            "  window.__recordedInput = null;" +
                            "  return data;" +
                            "}");
                        
                        if (result != null) {
                            // We need to cast the result to access properties
                            @SuppressWarnings("unchecked")
                            java.util.Map<String, String> inputData = (java.util.Map<String, String>) result;
                            
                            String selector = inputData.get("selector");
                            String value = inputData.get("value");
                            
                            if (selector != null && value != null) {
                                logger.debug("Input: {} -> {}", selector, value);
                                recordedActions.add(String.format("page.locator(\"%s\").fill(\"%s\");", selector, value));
                            }
                        }
                        
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    } catch (Exception e) {
                        // Ignore evaluation errors during polling
                    }
                }
            });
            
            inputPollThread.setDaemon(true);
            inputPollThread.start();
        }
    }
    
    /**
     * Generate a selector for an element
     * @param element Playwright ElementHandle
     * @return CSS or XPath selector
     */
    private String generateSelector(ElementHandle element) {
        // Try different selector strategies
        
        // First try ID
        String id = element.getAttribute("id");
        if (id != null && !id.isEmpty()) {
            return "#" + id;
        }
        
        // Then try name
        String name = element.getAttribute("name");
        if (name != null && !name.isEmpty()) {
            return String.format("[name=\"%s\"]", name);
        }
        
        // Try data-testid or other common test attributes
        String testId = element.getAttribute("data-testid");
        if (testId != null && !testId.isEmpty()) {
            return String.format("[data-testid=\"%s\"]", testId);
        }
        
        // Try by button or link text
        String text = element.textContent();
        if (text != null && !text.trim().isEmpty()) {
            String tagName = element.evaluate("el => el.tagName").toString().toLowerCase();
            
            if ("button".equals(tagName)) {
                return String.format("text=\"%s\"", text.trim());
            }
            
            if ("a".equals(tagName)) {
                return String.format("a:has-text(\"%s\")", text.trim());
            }
        }
        
        // As a last resort, use a role selector if applicable
        String role = element.getAttribute("role");
        if (role != null && !role.isEmpty()) {
            return String.format("[role=\"%s\"]", role);
        }
        
        // If all else fails, use XPath with position
        return element.evaluate("el => {\n" +
                "  function getXPath(element) {\n" +
                "    if (element.id !== '') return `//*[@id=\"${element.id}\"]`;\n" +
                "    if (element === document.body) return '/html/body';\n" +
                "\n" +
                "    let ix = 0;\n" +
                "    const siblings = element.parentNode.childNodes;\n" +
                "    for (let i = 0; i < siblings.length; i++) {\n" +
                "      const sibling = siblings[i];\n" +
                "      if (sibling === element) return `${getXPath(element.parentNode)}/${element.tagName.toLowerCase()}[${ix+1}]`;\n" +
                "      if (sibling.nodeType === 1 && sibling.tagName === element.tagName) ix++;\n" +
                "    }\n" +
                "  }\n" +
                "  return getXPath(el);\n" +
                "}").toString();
    }
    
    /**
     * Save generated code to a file
     * @param code Generated code
     * @param outputPath Path to save the file
     * @return Path to the saved file
     * @throws IOException If file cannot be saved
     */
    private Path saveGeneratedCode(String code, String outputPath) throws IOException {
        // Create directory if it doesn't exist
        File directory = new File(outputPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        
        // Generate filename with timestamp
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String filename = String.format("recorded_test_%s.java", timestamp);
        Path filePath = Paths.get(outputPath, filename);
        
        // Write code to file
        Files.writeString(filePath, code);
        
        return filePath;
    }
}
