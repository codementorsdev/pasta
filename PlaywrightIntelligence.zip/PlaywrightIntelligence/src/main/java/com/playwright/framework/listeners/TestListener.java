package com.playwright.framework.listeners;

import com.playwright.framework.config.FrameworkConfig;
import com.playwright.framework.core.PlaywrightFactory;
import com.playwright.framework.reporting.AllureManager;
import com.playwright.framework.utils.ScreenshotUtil;
import io.qameta.allure.Attachment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;

/**
 * TestNG listener to handle test execution events.
 * Manages screenshots, videos, and reporting.
 */
public class TestListener implements ITestListener {
    private static final Logger logger = LoggerFactory.getLogger(TestListener.class);
    private final AllureManager allureManager = new AllureManager();
    private final FrameworkConfig config = FrameworkConfig.getInstance();
    
    @Override
    public void onTestStart(ITestResult result) {
        logger.info("Starting test: {}.{}", result.getTestClass().getName(), result.getName());
        
        // Set test start time in Allure report
        allureManager.setTestStartTime(result);
        
        // Log test information
        String description = result.getMethod().getDescription();
        if (description != null && !description.isEmpty()) {
            logger.info("Test description: {}", description);
        }
        
        // Log test parameters if any
        Object[] params = result.getParameters();
        if (params != null && params.length > 0) {
            logger.info("Test parameters: {}", Arrays.toString(params));
        }
    }
    
    @Override
    public void onTestSuccess(ITestResult result) {
        logger.info("Test passed: {}.{}", result.getTestClass().getName(), result.getName());
        
        // Take screenshot on success if configured
        if (config.getBooleanProperty("take.screenshot.on.success", false)) {
            captureScreenshot(result, "SUCCESS");
        }
    }
    
    @Override
    public void onTestFailure(ITestResult result) {
        logger.error("Test failed: {}.{}", result.getTestClass().getName(), result.getName());
        
        // Log the failure details
        Throwable throwable = result.getThrowable();
        if (throwable != null) {
            logger.error("Failure reason: {}", throwable.getMessage());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            throwable.printStackTrace(new PrintStream(out));
            logger.error("Stack trace: {}", out);
            
            // Attach exception details to Allure report
            allureManager.attachText("Exception", throwable.toString());
        }
        
        // Take screenshot on failure
        captureScreenshot(result, "FAILURE");
    }
    
    @Override
    public void onTestSkipped(ITestResult result) {
        logger.info("Test skipped: {}.{}", result.getTestClass().getName(), result.getName());
        
        // Log skip reason if available
        Throwable throwable = result.getThrowable();
        if (throwable != null) {
            logger.info("Skip reason: {}", throwable.getMessage());
        }
    }
    
    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        logger.info("Test failed within success percentage: {}.{}", result.getTestClass().getName(), result.getName());
    }
    
    @Override
    public void onStart(ITestContext context) {
        logger.info("Starting test context: {}", context.getName());
        logger.info("Included groups: {}", Arrays.toString(context.getIncludedGroups()));
        logger.info("Excluded groups: {}", Arrays.toString(context.getExcludedGroups()));
    }
    
    @Override
    public void onFinish(ITestContext context) {
        logger.info("Finished test context: {}", context.getName());
        logger.info("Passed tests: {}", context.getPassedTests().size());
        logger.info("Failed tests: {}", context.getFailedTests().size());
        logger.info("Skipped tests: {}", context.getSkippedTests().size());
    }
    
    /**
     * Capture a screenshot and attach it to the Allure report
     * @param result TestNG test result
     * @param status Test status (SUCCESS, FAILURE, etc.)
     */
    private void captureScreenshot(ITestResult result, String status) {
        try {
            // Get the current page from PlaywrightFactory
            PlaywrightFactory factory = PlaywrightFactory.getInstance();
            if (factory != null && factory.getPage() != null) {
                ScreenshotUtil screenshotUtil = new ScreenshotUtil(factory.getPage());
                
                // Take screenshot
                String testName = result.getName();
                String screenshotName = String.format("%s_%s", testName, status);
                String path = screenshotUtil.takeFullPageScreenshot(screenshotName);
                
                // Attach to Allure report
                allureManager.attachScreenshot(screenshotName, path);
                
                logger.info("Screenshot captured for test: {}", testName);
            } else {
                logger.warn("Cannot capture screenshot - Page instance is null");
            }
        } catch (Exception e) {
            logger.error("Failed to capture screenshot", e);
        }
    }
    
    /**
     * Attach the test logs as text to the Allure report
     * @param logs Log content
     * @return The same log content for method chaining
     */
    @Attachment(value = "Test Logs", type = "text/plain")
    private String attachLogs(String logs) {
        return logs;
    }
}
