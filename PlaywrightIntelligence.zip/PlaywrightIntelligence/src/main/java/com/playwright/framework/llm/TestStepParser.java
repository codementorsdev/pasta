package com.playwright.framework.llm;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.playwright.framework.config.FrameworkConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses natural language test steps and executes them using Playwright.
 * Supports both pattern-based parsing and LLM-based parsing.
 */
public class TestStepParser {
    private static final Logger logger = LoggerFactory.getLogger(TestStepParser.class);
    private final Page page;
    private final LlmClient llmClient;
    private final FrameworkConfig config;
    
    // Patterns for common test steps
    private static final Map<String, Pattern> STEP_PATTERNS = new HashMap<>();
    
    static {
        // Navigation patterns
        STEP_PATTERNS.put("navigate", Pattern.compile("(?i)(?:navigate|go|open)\\s+(?:to)?\\s+(?:the\\s+)?(?:url\\s+)?([^\\s]+)"));
        
        // Click patterns
        STEP_PATTERNS.put("click", Pattern.compile("(?i)click\\s+(?:on\\s+)?(?:the\\s+)?([\\w\\s]+)(?:\\s+button|link|element|checkbox|radio|tab)?"));
        
        // Type patterns
        STEP_PATTERNS.put("type", Pattern.compile("(?i)(?:type|enter|input)\\s+(?:the\\s+)?(?:text\\s+)?[\"']?([^\"']+)[\"']?\\s+(?:in|into|on)\\s+(?:the\\s+)?([\\w\\s]+)"));
        
        // Select patterns
        STEP_PATTERNS.put("select", Pattern.compile("(?i)select\\s+(?:the\\s+)?(?:option\\s+)?[\"']?([^\"']+)[\"']?\\s+(?:from|in)\\s+(?:the\\s+)?([\\w\\s]+)"));
        
        // Wait patterns
        STEP_PATTERNS.put("wait", Pattern.compile("(?i)wait\\s+(?:for\\s+)?(?:(\\d+)\\s+(?:second|seconds)|(?:the\\s+)?([\\w\\s]+)(?:\\s+to\\s+(?:appear|be\\s+visible|exist)))"));
        
        // Assertion patterns
        STEP_PATTERNS.put("verify", Pattern.compile("(?i)(?:verify|assert|check)\\s+(?:that\\s+)?(?:the\\s+)?([\\w\\s]+)\\s+(?:is|contains|has|should\\s+be)\\s+(?:equal\\s+to\\s+)?[\"']?([^\"']+)[\"']?"));
    }
    
    /**
     * Constructor for TestStepParser
     * @param page Playwright Page object
     * @param llmClient LLM client for natural language processing
     */
    public TestStepParser(Page page, LlmClient llmClient) {
        this.page = page;
        this.llmClient = llmClient;
        this.config = FrameworkConfig.getInstance();
        logger.info("Initialized TestStepParser");
    }
    
    /**
     * Parse and execute a test step
     * @param step Natural language test step
     * @return Result of the step execution
     */
    public String executeStep(String step) {
        logger.info("Executing test step: {}", step);
        
        try {
            // Try to use LLM for parsing if available and enabled
            if (llmClient != null && llmClient.isInitialized() && 
                    config.getBooleanProperty("use.llm.for.steps", true)) {
                return executeStepWithLlm(step);
            } else {
                // Fallback to pattern matching
                logger.debug("Using pattern matching for step parsing");
                return executeStepWithPatterns(step);
            }
        } catch (Exception e) {
            logger.error("Error executing test step: {}", step, e);
            return "FAIL: " + e.getMessage();
        }
    }
    
    /**
     * Execute a test step using LLM
     * @param step Natural language test step
     * @return Result of the step execution
     */
    private String executeStepWithLlm(String step) {
        logger.debug("Executing step with LLM: {}", step);
        
        try {
            // Provide context about the current page
            Map<String, Object> context = new HashMap<>();
            context.put("url", page.url());
            context.put("title", page.title());
            
            // Get code from LLM
            String code = llmClient.generateStepCode(step, context);
            
            if (code == null || code.isEmpty()) {
                logger.warn("LLM returned empty code for step: {}", step);
                return "FAIL: Could not generate code for step";
            }
            
            logger.debug("Generated code: {}", code);
            
            // Clean up the code if necessary
            code = cleanupGeneratedCode(code);
            
            // Execute the code
            // In a real implementation, we'd use a proper code execution mechanism
            // Here we'll use a simplified approach for demonstration
            
            if (code.contains("page.navigate(") || code.contains("page.goto(")) {
                // Extract URL from navigate command
                Pattern pattern = Pattern.compile("page\\.(?:navigate|goto)\\([\"']([^\"']+)[\"']\\)");
                Matcher matcher = pattern.matcher(code);
                if (matcher.find()) {
                    String url = matcher.group(1);
                    page.navigate(url);
                    return "PASS: Navigated to " + url;
                }
            } else if (code.contains(".click()")) {
                // Extract selector from click command
                Pattern pattern = Pattern.compile("page\\.locator\\([\"']([^\"']+)[\"']\\)\\.click\\(\\)");
                Matcher matcher = pattern.matcher(code);
                if (matcher.find()) {
                    String selector = matcher.group(1);
                    page.locator(selector).click();
                    return "PASS: Clicked on element with selector: " + selector;
                }
            } else if (code.contains(".fill(")) {
                // Extract selector and text from fill command
                Pattern pattern = Pattern.compile("page\\.locator\\([\"']([^\"']+)[\"']\\)\\.fill\\([\"']([^\"']+)[\"']\\)");
                Matcher matcher = pattern.matcher(code);
                if (matcher.find()) {
                    String selector = matcher.group(1);
                    String text = matcher.group(2);
                    page.locator(selector).fill(text);
                    return "PASS: Typed '" + text + "' into element with selector: " + selector;
                }
            } else if (code.contains(".selectOption(")) {
                // Extract selector and option from select command
                Pattern pattern = Pattern.compile("page\\.locator\\([\"']([^\"']+)[\"']\\)\\.selectOption\\([\"']([^\"']+)[\"']\\)");
                Matcher matcher = pattern.matcher(code);
                if (matcher.find()) {
                    String selector = matcher.group(1);
                    String option = matcher.group(2);
                    page.locator(selector).selectOption(option);
                    return "PASS: Selected option '" + option + "' in element with selector: " + selector;
                }
            } else if (code.contains(".check()")) {
                // Extract selector from check command
                Pattern pattern = Pattern.compile("page\\.locator\\([\"']([^\"']+)[\"']\\)\\.check\\(\\)");
                Matcher matcher = pattern.matcher(code);
                if (matcher.find()) {
                    String selector = matcher.group(1);
                    page.locator(selector).check();
                    return "PASS: Checked element with selector: " + selector;
                }
            } else if (code.contains(".waitFor")) {
                // Extract selector from wait command
                Pattern pattern = Pattern.compile("page\\.locator\\([\"']([^\"']+)[\"']\\)\\.waitFor\\(\\)");
                Matcher matcher = pattern.matcher(code);
                if (matcher.find()) {
                    String selector = matcher.group(1);
                    page.locator(selector).waitFor();
                    return "PASS: Waited for element with selector: " + selector;
                }
            } else if (code.contains("expect(") || code.contains("assert")) {
                // For assertions, execute the step with patterns as fallback
                // since assertions are more complex to parse
                return executeStepWithPatterns(step);
            }
            
            // If we couldn't parse the generated code, fallback to pattern matching
            logger.warn("Could not parse generated code, falling back to pattern matching");
            return executeStepWithPatterns(step);
            
        } catch (Exception e) {
            logger.error("Error executing step with LLM", e);
            return "FAIL: " + e.getMessage();
        }
    }
    
    /**
     * Execute a test step using pattern matching
     * @param step Natural language test step
     * @return Result of the step execution
     */
    private String executeStepWithPatterns(String step) {
        logger.debug("Executing step with patterns: {}", step);
        
        // Try each pattern type
        for (Map.Entry<String, Pattern> entry : STEP_PATTERNS.entrySet()) {
            String type = entry.getKey();
            Pattern pattern = entry.getValue();
            Matcher matcher = pattern.matcher(step);
            
            if (matcher.find()) {
                switch (type) {
                    case "navigate":
                        return executeNavigate(matcher.group(1));
                    case "click":
                        return executeClick(matcher.group(1));
                    case "type":
                        return executeType(matcher.group(1), matcher.group(2));
                    case "select":
                        return executeSelect(matcher.group(1), matcher.group(2));
                    case "wait":
                        String seconds = matcher.group(1);
                        String element = matcher.group(2);
                        return executeWait(seconds, element);
                    case "verify":
                        return executeVerify(matcher.group(1), matcher.group(2));
                }
            }
        }
        
        // If no pattern matches, use LLM as fallback if available
        if (llmClient != null && llmClient.isInitialized() && 
                !config.getBooleanProperty("use.llm.for.steps", true)) {
            logger.debug("No pattern match, trying LLM as fallback");
            return executeStepWithLlm(step);
        }
        
        logger.warn("Could not parse step: {}", step);
        return "FAIL: Could not understand step";
    }
    
    /**
     * Execute a navigate step
     * @param url URL to navigate to
     * @return Result of the step execution
     */
    private String executeNavigate(String url) {
        logger.info("Navigating to URL: {}", url);
        
        try {
            // Add http:// prefix if not present
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://" + url;
            }
            
            page.navigate(url);
            return "PASS: Navigated to " + url;
        } catch (Exception e) {
            logger.error("Error navigating to URL: {}", url, e);
            return "FAIL: " + e.getMessage();
        }
    }
    
    /**
     * Execute a click step
     * @param elementDescription Description of the element to click
     * @return Result of the step execution
     */
    private String executeClick(String elementDescription) {
        logger.info("Clicking on element: {}", elementDescription);
        
        try {
            Locator element = findElement(elementDescription);
            if (element != null) {
                element.click();
                return "PASS: Clicked on " + elementDescription;
            } else {
                return "FAIL: Could not find element: " + elementDescription;
            }
        } catch (Exception e) {
            logger.error("Error clicking on element: {}", elementDescription, e);
            return "FAIL: " + e.getMessage();
        }
    }
    
    /**
     * Execute a type step
     * @param text Text to type
     * @param elementDescription Description of the element to type into
     * @return Result of the step execution
     */
    private String executeType(String text, String elementDescription) {
        logger.info("Typing '{}' into element: {}", text, elementDescription);
        
        try {
            Locator element = findElement(elementDescription);
            if (element != null) {
                element.fill(text);
                return "PASS: Typed '" + text + "' into " + elementDescription;
            } else {
                return "FAIL: Could not find element: " + elementDescription;
            }
        } catch (Exception e) {
            logger.error("Error typing into element: {}", elementDescription, e);
            return "FAIL: " + e.getMessage();
        }
    }
    
    /**
     * Execute a select step
     * @param option Option to select
     * @param elementDescription Description of the dropdown element
     * @return Result of the step execution
     */
    private String executeSelect(String option, String elementDescription) {
        logger.info("Selecting option '{}' from element: {}", option, elementDescription);
        
        try {
            Locator element = findElement(elementDescription);
            if (element != null) {
                element.selectOption(option);
                return "PASS: Selected '" + option + "' from " + elementDescription;
            } else {
                return "FAIL: Could not find element: " + elementDescription;
            }
        } catch (Exception e) {
            logger.error("Error selecting option from element: {}", elementDescription, e);
            return "FAIL: " + e.getMessage();
        }
    }
    
    /**
     * Execute a wait step
     * @param seconds Number of seconds to wait, or null if waiting for an element
     * @param elementDescription Description of the element to wait for, or null if waiting for seconds
     * @return Result of the step execution
     */
    private String executeWait(String seconds, String elementDescription) {
        try {
            if (seconds != null) {
                int timeToWait = Integer.parseInt(seconds);
                logger.info("Waiting for {} seconds", timeToWait);
                page.waitForTimeout(timeToWait * 1000);
                return "PASS: Waited for " + timeToWait + " seconds";
            } else if (elementDescription != null) {
                logger.info("Waiting for element: {}", elementDescription);
                Locator element = findElement(elementDescription);
                if (element != null) {
                    element.waitFor();
                    return "PASS: Waited for element: " + elementDescription;
                } else {
                    return "FAIL: Could not find element: " + elementDescription;
                }
            } else {
                return "FAIL: Invalid wait step";
            }
        } catch (Exception e) {
            logger.error("Error executing wait step", e);
            return "FAIL: " + e.getMessage();
        }
    }
    
    /**
     * Execute a verification step
     * @param elementDescription Description of the element to verify
     * @param expectedValue Expected value or text
     * @return Result of the step execution
     */
    private String executeVerify(String elementDescription, String expectedValue) {
        logger.info("Verifying element {} has value {}", elementDescription, expectedValue);
        
        try {
            Locator element = findElement(elementDescription);
            if (element != null) {
                String actualText = element.textContent();
                if (actualText.contains(expectedValue)) {
                    return "PASS: Verified " + elementDescription + " contains '" + expectedValue + "'";
                } else {
                    return "FAIL: Expected '" + expectedValue + "' but found '" + actualText + "'";
                }
            } else {
                return "FAIL: Could not find element: " + elementDescription;
            }
        } catch (Exception e) {
            logger.error("Error verifying element: {}", elementDescription, e);
            return "FAIL: " + e.getMessage();
        }
    }
    
    /**
     * Find an element based on natural language description
     * @param description Natural language description of the element
     * @return Playwright Locator for the element or null if not found
     */
    private Locator findElement(String description) {
        logger.debug("Finding element: {}", description);
        
        // Try various strategies to find the element
        
        // 1. Try by text
        try {
            Locator byText = page.getByText(description, new Page.GetByTextOptions().setExact(false));
            if (byText.count() > 0) {
                return byText.first();
            }
        } catch (Exception e) {
            logger.debug("Error finding element by text", e);
        }
        
        // 2. Try by role and name
        try {
            // In Playwright 1.39.0, we need to use proper AriaRole enums
            Locator byRole = page.getByRole(com.microsoft.playwright.options.AriaRole.valueOf(guessRole(description).toUpperCase()), 
                                           new Page.GetByRoleOptions().setName(description));
            if (byRole.count() > 0) {
                return byRole.first();
            }
        } catch (Exception e) {
            logger.debug("Error finding element by role", e);
        }
        
        // 3. Try by placeholder
        try {
            Locator byPlaceholder = page.getByPlaceholder(description);
            if (byPlaceholder.count() > 0) {
                return byPlaceholder.first();
            }
        } catch (Exception e) {
            logger.debug("Error finding element by placeholder", e);
        }
        
        // 4. Try by label
        try {
            Locator byLabel = page.getByLabel(description);
            if (byLabel.count() > 0) {
                return byLabel.first();
            }
        } catch (Exception e) {
            logger.debug("Error finding element by label", e);
        }
        
        // 5. Try common attributes
        String[] commonAttrs = {"id", "name", "class", "data-testid", "data-test", "data-cy", "data-qa"};
        for (String attr : commonAttrs) {
            try {
                String selector = String.format("[%s*='%s']", attr, description.toLowerCase().replace(' ', '-'));
                Locator byAttr = page.locator(selector);
                if (byAttr.count() > 0) {
                    return byAttr.first();
                }
            } catch (Exception e) {
                logger.debug("Error finding element by attribute: {}", attr, e);
            }
        }
        
        // 6. If LLM is available, try to get selector suggestions
        if (llmClient != null && llmClient.isInitialized()) {
            try {
                String html = page.content();
                if (html.length() > 10000) {
                    html = html.substring(0, 10000) + "...";
                }
                
                List<String> selectors = llmClient.suggestSelectors(description, html);
                
                for (String selector : selectors) {
                    try {
                        Locator locator = page.locator(selector);
                        if (locator.count() > 0) {
                            logger.info("Found element using LLM-suggested selector: {}", selector);
                            return locator.first();
                        }
                    } catch (Exception e) {
                        logger.debug("Error with suggested selector: {}", selector, e);
                    }
                }
            } catch (Exception e) {
                logger.debug("Error getting selector suggestions from LLM", e);
            }
        }
        
        return null;
    }
    
    /**
     * Guess the role of an element based on its description
     * @param description Natural language description of the element
     * @return Playwright AriaRole as string
     */
    private String guessRole(String description) {
        String desc = description.toLowerCase();
        
        if (desc.contains("button") || desc.contains("btn") || 
                desc.contains("submit") || desc.contains("ok") || 
                desc.contains("cancel") || desc.contains("close")) {
            return "BUTTON";
        } else if (desc.contains("link") || desc.contains("anchor")) {
            return "LINK";
        } else if (desc.contains("checkbox") || desc.contains("check box")) {
            return "CHECKBOX";
        } else if (desc.contains("radio") || desc.contains("option")) {
            return "RADIO";
        } else if (desc.contains("textbox") || desc.contains("text box") || 
                desc.contains("input") || desc.contains("field")) {
            return "TEXTBOX";
        } else if (desc.contains("dropdown") || desc.contains("drop down") || 
                desc.contains("select") || desc.contains("combobox")) {
            return "COMBOBOX";
        } else if (desc.contains("tab")) {
            return "TAB";
        } else if (desc.contains("menu")) {
            return "MENU";
        } else if (desc.contains("image") || desc.contains("img") || 
                desc.contains("icon")) {
            return "IMG";
        } else {
            return "BUTTON";
        }
    }
    
    /**
     * Clean up generated code by removing unnecessary parts
     * @param code Generated code
     * @return Cleaned up code
     */
    private String cleanupGeneratedCode(String code) {
        // Remove import statements
        code = code.replaceAll("import .*?;", "");
        
        // Remove class and method declarations
        code = code.replaceAll("(?s).*?\\{\\s*", "");
        code = code.replaceAll("(?s)\\s*\\}\\s*$", "");
        
        // Remove try-catch blocks but keep the content
        code = code.replaceAll("try\\s*\\{", "");
        code = code.replaceAll("\\}\\s*catch\\s*\\(.*?\\)\\s*\\{.*?\\}", "");
        
        // Remove comments
        code = code.replaceAll("//.*", "");
        code = code.replaceAll("(?s)/\\*.*?\\*/", "");
        
        // Trim whitespace
        code = code.trim();
        
        return code;
    }
    
    /**
     * Execute a list of natural language test steps
     * @param steps List of natural language test steps
     * @return Map of step results with step as key and result as value
     */
    public Map<String, String> executeSteps(List<String> steps) {
        logger.info("Executing {} test steps", steps.size());
        
        Map<String, String> results = new LinkedHashMap<>();
        
        for (String step : steps) {
            logger.info("Executing step: {}", step);
            String result = executeStep(step);
            results.put(step, result);
            
            // If a step fails and stop on error is enabled, stop execution
            if (result.startsWith("FAIL:") && 
                    config.getBooleanProperty("stop.on.error", true)) {
                logger.warn("Stopping test execution due to failure: {}", result);
                break;
            }
        }
        
        return results;
    }
}
