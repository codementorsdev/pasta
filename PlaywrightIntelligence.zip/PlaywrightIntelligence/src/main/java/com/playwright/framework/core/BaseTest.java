package com.playwright.framework.core;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;
import com.playwright.framework.config.FrameworkConfig;
import com.playwright.framework.listeners.TestListener;
import com.playwright.framework.reporting.AllureManager;
import com.playwright.framework.utils.NetworkInterceptor;
import com.playwright.framework.utils.ScreenshotUtil;
import com.playwright.framework.utils.VideoRecorder;
import io.qameta.allure.Step;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.*;

/**
 * Base class for all test classes in the framework.
 * Provides common setup and teardown methods, and utility methods for tests.
 */
@Listeners(TestListener.class)
public abstract class BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(BaseTest.class);
    protected Page page;
    protected PlaywrightFactory playwrightFactory;
    protected FrameworkConfig config;
    protected ScreenshotUtil screenshotUtil;
    protected VideoRecorder videoRecorder;
    protected NetworkInterceptor networkInterceptor;
    protected AllureManager allureManager;
    
    @BeforeSuite
    public void beforeSuite() {
        logger.info("Starting test suite execution");
        config = FrameworkConfig.getInstance();
        allureManager = new AllureManager();
    }
    
    @BeforeClass
    public void beforeClass() {
        logger.info("Starting test class: {}", getClass().getSimpleName());
    }
    
    @BeforeMethod
    public void setup() {
        logger.info("Setting up test environment");
        
        // Initialize Playwright
        playwrightFactory = PlaywrightFactory.getInstance();
        page = playwrightFactory.initializeBrowser();
        
        // Initialize utilities
        screenshotUtil = new ScreenshotUtil(page);
        videoRecorder = new VideoRecorder(playwrightFactory.getBrowserContext());
        networkInterceptor = new NetworkInterceptor(page);
        
        // Start video recording if enabled
        if (config.getBooleanProperty("record.video", false)) {
            videoRecorder.startRecording();
        }
        
        // Set default navigation timeout
        page.setDefaultNavigationTimeout(config.getDefaultTimeout());
        
        // Initialize network interception if enabled
        if (config.getBooleanProperty("network.interception.enabled", true)) {
            networkInterceptor.enableRequestInterception();
        }
    }
    
    @AfterMethod
    public void tearDown() {
        logger.info("Tearing down test environment");
        
        // Take final screenshot if configured
        if (config.getBooleanProperty("take.screenshot.after.test", true)) {
            String screenshotPath = screenshotUtil.takeFullPageScreenshot("final");
            allureManager.attachScreenshot("Final Screenshot", screenshotPath);
        }
        
        // Stop video recording if enabled
        if (config.getBooleanProperty("record.video", false)) {
            String videoPath = videoRecorder.stopRecording();
            allureManager.attachVideo("Test Video", videoPath);
        }
        
        // Cleanup Playwright resources
        if (config.getBooleanProperty("close.browser.after.test", true)) {
            playwrightFactory.closePlaywright();
        }
    }
    
    @AfterClass
    public void afterClass() {
        logger.info("Finished test class: {}", getClass().getSimpleName());
    }
    
    @AfterSuite
    public void afterSuite() {
        logger.info("Finished test suite execution");
    }
    
    /**
     * Navigate to a URL
     * @param url URL to navigate to
     */
    @Step("Navigating to {url}")
    protected void navigateTo(String url) {
        logger.info("Navigating to URL: {}", url);
        page.navigate(url);
        waitForPageLoad();
    }
    
    /**
     * Wait for the page to load completely
     */
    @Step("Waiting for page to load")
    protected void waitForPageLoad() {
        logger.info("Waiting for page to load completely");
        page.waitForLoadState(LoadState.NETWORKIDLE);
    }
    
    /**
     * Take a screenshot and attach it to the report
     * @param name Name for the screenshot
     */
    @Step("Taking screenshot: {name}")
    protected void takeScreenshot(String name) {
        logger.info("Taking screenshot: {}", name);
        String path = screenshotUtil.takeFullPageScreenshot(name);
        allureManager.attachScreenshot(name, path);
    }
    
    /**
     * Take a screenshot of a specific element and attach it to the report
     * @param selector CSS or XPath selector for the element
     * @param name Name for the screenshot
     */
    @Step("Taking element screenshot of {selector}: {name}")
    protected void takeElementScreenshot(String selector, String name) {
        logger.info("Taking element screenshot of {}: {}", selector, name);
        String path = screenshotUtil.takeElementScreenshot(selector, name);
        allureManager.attachScreenshot(name, path);
    }
    
    /**
     * Enable network request and response logging
     */
    @Step("Enabling network request and response logging")
    protected void enableNetworkLogging() {
        logger.info("Enabling network request and response logging");
        networkInterceptor.enableRequestLogging();
        networkInterceptor.enableResponseLogging();
    }
    
    /**
     * Add a network request interception rule
     * @param urlPattern URL pattern to match
     * @param handler Handler function for the interception
     */
    @Step("Adding network interception for {urlPattern}")
    protected void addNetworkInterception(String urlPattern) {
        logger.info("Adding network interception for URL pattern: {}", urlPattern);
        networkInterceptor.interceptRequest(urlPattern);
    }
    
    /**
     * Get the page instance
     * @return Playwright Page instance
     */
    protected Page getPage() {
        return page;
    }
}
