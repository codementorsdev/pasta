package com.playwright.framework.dataprovider;

import com.playwright.framework.config.FrameworkConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Factory class for creating data providers based on data source type.
 * Supports JSON, CSV, Excel, and other data sources.
 */
public class DataProviderFactory {
    private static final Logger logger = LoggerFactory.getLogger(DataProviderFactory.class);
    private static final FrameworkConfig config = FrameworkConfig.getInstance();
    
    /**
     * Get a data provider for the specified type
     * @param type Data source type (json, csv, excel, etc.)
     * @param filePath Path to the data file
     * @return The appropriate data provider instance
     */
    public static Object getDataProvider(String type, String filePath) {
        logger.info("Creating data provider of type: {} for file: {}", type, filePath);
        
        switch (type.toLowerCase()) {
            case "json":
                return new JsonDataProvider(filePath);
            case "csv":
                return new CsvDataProvider(filePath);
            case "excel":
                return new ExcelDataProvider(filePath);
            default:
                logger.error("Unsupported data provider type: {}", type);
                throw new IllegalArgumentException("Unsupported data provider type: " + type);
        }
    }
    
    /**
     * Create a data provider based on file extension
     * @param filePath Path to the data file
     * @return The appropriate data provider instance
     */
    public static Object getDataProviderFromFile(String filePath) {
        logger.info("Creating data provider based on file extension for: {}", filePath);
        
        if (filePath.toLowerCase().endsWith(".json")) {
            return new JsonDataProvider(filePath);
        } else if (filePath.toLowerCase().endsWith(".csv")) {
            return new CsvDataProvider(filePath);
        } else if (filePath.toLowerCase().endsWith(".xlsx") || filePath.toLowerCase().endsWith(".xls")) {
            return new ExcelDataProvider(filePath);
        } else {
            logger.error("Unsupported file type: {}", filePath);
            throw new IllegalArgumentException("Unsupported file type: " + filePath);
        }
    }
    
    /**
     * Get the default test data directory
     * @return Path to the test data directory
     */
    public static String getTestDataDir() {
        return config.getTestDataDir();
    }
    
    /**
     * Get the full path to a test data file
     * @param fileName Name of the file in the test data directory
     * @return Full path to the file
     */
    public static String getTestDataFilePath(String fileName) {
        return getTestDataDir() + "/" + fileName;
    }
}
