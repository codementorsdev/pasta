package com.playwright.framework.core;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.RecordVideoSize;
import com.playwright.framework.config.BrowserConfig;
import com.playwright.framework.config.FrameworkConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Paths;

/**
 * Factory class for creating and managing Playwright instances.
 * Implements a singleton pattern for Playwright, Browser, and BrowserContext instances.
 */
public class PlaywrightFactory {
    private static final Logger logger = LoggerFactory.getLogger(PlaywrightFactory.class);
    private static PlaywrightFactory instance;
    private final FrameworkConfig config;
    private final BrowserConfig browserConfig;
    
    private Playwright playwright;
    private Browser browser;
    private BrowserContext context;
    private Page page;
    
    private PlaywrightFactory() {
        config = FrameworkConfig.getInstance();
        browserConfig = new BrowserConfig();
    }
    
    /**
     * Get the singleton instance of PlaywrightFactory
     * @return The PlaywrightFactory instance
     */
    public static synchronized PlaywrightFactory getInstance() {
        if (instance == null) {
            instance = new PlaywrightFactory();
        }
        return instance;
    }
    
    /**
     * Initialize Playwright, Browser, BrowserContext, and Page
     * @return The initialized Page
     */
    public synchronized Page initializeBrowser() {
        try {
            logger.info("Initializing Playwright with browser: {}", config.getBrowserType());
            
            if (playwright == null) {
                playwright = Playwright.create();
            }
            
            if (browser == null) {
                browser = createBrowser();
            }
            
            if (context == null) {
                context = createBrowserContext();
            }
            
            if (page == null) {
                page = createPage();
            }
            
            return page;
        } catch (Exception e) {
            logger.error("Failed to initialize Playwright", e);
            throw new RuntimeException("Failed to initialize Playwright: " + e.getMessage(), e);
        }
    }
    
    /**
     * Create a browser instance based on configuration
     * @return The Browser instance
     */
    private Browser createBrowser() {
        String browserType = config.getBrowserType().toLowerCase();
        BrowserType.LaunchOptions launchOptions = browserConfig.getLaunchOptions();
        
        logger.info("Creating browser: {} with options: {}", browserType, launchOptions);
        
        switch (browserType) {
            case "chromium":
                return playwright.chromium().launch(launchOptions);
            case "firefox":
                return playwright.firefox().launch(launchOptions);
            case "webkit":
                return playwright.webkit().launch(launchOptions);
            default:
                logger.warn("Unknown browser type: {}. Using chromium as default.", browserType);
                return playwright.chromium().launch(launchOptions);
        }
    }
    
    /**
     * Create a browser context with configured options
     * @return The BrowserContext instance
     */
    private BrowserContext createBrowserContext() {
        Browser.NewContextOptions contextOptions = browserConfig.getContextOptions();
        
        // Configure video recording if enabled
        if (config.getBooleanProperty("record.video", false)) {
            contextOptions.setRecordVideoDir(Paths.get(config.getVideosDir()));
            contextOptions.setRecordVideoSize(new RecordVideoSize(
                    config.getIntProperty("video.width", 1280),
                    config.getIntProperty("video.height", 720)
            ));
        }
        
        logger.info("Creating browser context with options: {}", contextOptions);
        return browser.newContext(contextOptions);
    }
    
    /**
     * Create a new page in the current context
     * @return The Page instance
     */
    private Page createPage() {
        logger.info("Creating new page");
        Page newPage = context.newPage();
        newPage.setDefaultTimeout(config.getDefaultTimeout());
        
        // Set extra HTTP headers if configured
        newPage.setExtraHTTPHeaders(browserConfig.getExtraHTTPHeaders());
        
        return newPage;
    }
    
    /**
     * Get the current page instance
     * @return The current Page
     */
    public Page getPage() {
        if (page == null) {
            return initializeBrowser();
        }
        return page;
    }
    
    /**
     * Get the current browser context
     * @return The current BrowserContext
     */
    public BrowserContext getBrowserContext() {
        return context;
    }
    
    /**
     * Get the current browser instance
     * @return The current Browser
     */
    public Browser getBrowser() {
        return browser;
    }
    
    /**
     * Get the Playwright instance
     * @return The Playwright instance
     */
    public Playwright getPlaywright() {
        return playwright;
    }
    
    /**
     * Close and cleanup all Playwright resources
     */
    public synchronized void closePlaywright() {
        logger.info("Closing Playwright resources");
        
        try {
            if (page != null) {
                page.close();
                page = null;
            }
            
            if (context != null) {
                context.close();
                context = null;
            }
            
            if (browser != null) {
                browser.close();
                browser = null;
            }
            
            if (playwright != null) {
                playwright.close();
                playwright = null;
            }
        } catch (Exception e) {
            logger.error("Error while closing Playwright resources", e);
        }
    }
    
    /**
     * Create a new page while reusing existing browser and context
     * @return A new Page instance
     */
    public Page createNewPage() {
        if (context == null) {
            initializeBrowser();
        } else {
            page = createPage();
        }
        return page;
    }
}
