package com.playwright.framework.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * This class manages the configuration properties for the framework.
 * It loads the properties from the config.properties file and provides
 * methods to retrieve configuration values.
 */
public class FrameworkConfig {
    private static final Logger logger = LoggerFactory.getLogger(FrameworkConfig.class);
    private static final Properties properties = new Properties();
    private static final FrameworkConfig INSTANCE = new FrameworkConfig();

    private FrameworkConfig() {
        loadProperties();
    }

    /**
     * Get the singleton instance of the FrameworkConfig
     * @return The FrameworkConfig instance
     */
    public static FrameworkConfig getInstance() {
        return INSTANCE;
    }

    /**
     * Load properties from the config.properties file
     */
    private void loadProperties() {
        Path configPath = Paths.get("src", "main", "resources", "config.properties");
        try (InputStream input = new FileInputStream(configPath.toFile())) {
            properties.load(input);
            logger.info("Configuration properties loaded successfully");
        } catch (IOException e) {
            logger.error("Failed to load config.properties file", e);
        }
    }

    /**
     * Get a property value
     * @param key The property key
     * @return The property value or null if not found
     */
    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    /**
     * Get a property value with a default value
     * @param key The property key
     * @param defaultValue The default value to return if the key is not found
     * @return The property value or the default value if not found
     */
    public String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    /**
     * Get a boolean property value
     * @param key The property key
     * @param defaultValue The default value to return if the key is not found
     * @return The boolean property value or the default value if not found
     */
    public boolean getBooleanProperty(String key, boolean defaultValue) {
        String value = properties.getProperty(key);
        return (value != null) ? Boolean.parseBoolean(value) : defaultValue;
    }

    /**
     * Get an integer property value
     * @param key The property key
     * @param defaultValue The default value to return if the key is not found or is not a valid integer
     * @return The integer property value or the default value if not found or not a valid integer
     */
    public int getIntProperty(String key, int defaultValue) {
        String value = properties.getProperty(key);
        if (value != null) {
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                logger.warn("Could not parse property '{}' as integer. Using default value: {}", key, defaultValue);
            }
        }
        return defaultValue;
    }

    /**
     * Get the browser type from configuration
     * @return The browser type (e.g., "chromium", "firefox", "webkit")
     */
    public String getBrowserType() {
        return getProperty("browser.type", "chromium");
    }

    /**
     * Get the base URL for tests
     * @return The base URL
     */
    public String getBaseUrl() {
        return getProperty("base.url", "https://www.example.com");
    }

    /**
     * Get the headless mode setting
     * @return true if browser should run in headless mode, false otherwise
     */
    public boolean isHeadless() {
        return getBooleanProperty("browser.headless", true);
    }

    /**
     * Get the default timeout in milliseconds
     * @return The default timeout in milliseconds
     */
    public int getDefaultTimeout() {
        return getIntProperty("default.timeout", 30000);
    }

    /**
     * Get the OpenAI API key
     * @return The OpenAI API key
     */
    public String getOpenAIApiKey() {
        // First try to get from environment variable, then from properties
        String apiKey = System.getenv("OPENAI_API_KEY");
        return (apiKey != null && !apiKey.isEmpty()) ? apiKey : getProperty("openai.api.key", "");
    }

    /**
     * Get the test data directory path
     * @return The test data directory path
     */
    public String getTestDataDir() {
        return getProperty("testdata.dir", "src/test/resources/testdata");
    }

    /**
     * Get the screenshots directory path
     * @return The screenshots directory path
     */
    public String getScreenshotsDir() {
        return getProperty("screenshots.dir", "target/screenshots");
    }

    /**
     * Get the videos directory path
     * @return The videos directory path
     */
    public String getVideosDir() {
        return getProperty("videos.dir", "target/videos");
    }

    /**
     * Get the allure results directory path
     * @return The allure results directory path
     */
    public String getAllureResultsDir() {
        return getProperty("allure.results.dir", "target/allure-results");
    }
}
