package com.playwright.framework.llm;

import java.util.List;
import java.util.Map;

/**
 * Interface for LLM client implementations.
 * Provides methods for interacting with language models.
 */
public interface LlmClient {

    /**
     * Initialize the LLM client with necessary configuration
     */
    void initialize();

    /**
     * Check if the client is initialized and ready to use
     * @return true if initialized, false otherwise
     */
    boolean isInitialized();

    /**
     * Send a completion request to the language model
     * @param prompt The text prompt to send
     * @return The generated completion response
     */
    String getCompletion(String prompt);

    /**
     * Send a completion request with additional parameters
     * @param prompt The text prompt to send
     * @param options Additional parameters for the request
     * @return The generated completion response
     */
    String getCompletion(String prompt, Map<String, Object> options);

    /**
     * Generate a list of test steps from a natural language test description
     * @param testDescription The natural language description of a test
     * @return List of parsed test steps
     */
    List<String> generateTestSteps(String testDescription);

    /**
     * Generate code for a specific test step
     * @param step The test step in natural language
     * @param context Additional context information
     * @return Generated code for the test step
     */
    String generateStepCode(String step, Map<String, Object> context);

    /**
     * Analyze and suggest selectors for a UI element based on description
     * @param elementDescription Natural language description of the element
     * @param pageSource HTML source of the page
     * @return Suggested selectors for the element
     */
    List<String> suggestSelectors(String elementDescription, String pageSource);

    /**
     * Generate a complete test script from a natural language description
     * @param testDescription The natural language description of a test
     * @param options Additional options for test generation
     * @return Generated test script as a string
     */
    String generateTestScript(String testDescription, Map<String, Object> options);

    /**
     * Extract data from unstructured text
     * @param text The text to extract data from
     * @param schema The schema defining what data to extract
     * @return Extracted data as a map
     */
    Map<String, Object> extractData(String text, Map<String, String> schema);

    /**
     * Classify text into predefined categories
     * @param text The text to classify
     * @param categories List of possible categories
     * @return The most likely category
     */
    String classifyText(String text, List<String> categories);

    /**
     * Close the client and release resources
     */
    void close();
}
