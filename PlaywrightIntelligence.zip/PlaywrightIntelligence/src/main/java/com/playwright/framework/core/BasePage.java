package com.playwright.framework.core;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;
import com.playwright.framework.config.FrameworkConfig;
import com.playwright.framework.utils.ElementHighlighter;
import io.qameta.allure.Step;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.file.Paths;

/**
 * Base class for all Page Objects in the framework.
 * Provides common page interaction methods with proper logging and reporting.
 */
public abstract class BasePage {
    private static final Logger logger = LoggerFactory.getLogger(BasePage.class);
    protected final Page page;
    protected final ElementHighlighter highlighter;
    protected final FrameworkConfig config;
    private final String pageUrl;
    
    /**
     * Constructor for BasePage
     * @param page Playwright Page instance
     * @param pageUrl URL of the page
     */
    public BasePage(Page page, String pageUrl) {
        this.page = page;
        this.pageUrl = pageUrl;
        this.config = FrameworkConfig.getInstance();
        this.highlighter = new ElementHighlighter(page);
    }
    
    /**
     * Get the page title
     * @return Page title
     */
    public String getTitle() {
        return page.title();
    }
    
    /**
     * Navigate to the page URL
     * @return The current page instance
     */
    @Step("Navigating to {pageUrl}")
    public BasePage navigate() {
        logger.info("Navigating to: {}", pageUrl);
        page.navigate(pageUrl);
        waitForPageLoad();
        return this;
    }
    
    /**
     * Wait for the page to load completely
     */
    @Step("Waiting for page to load")
    public void waitForPageLoad() {
        logger.info("Waiting for page to load completely");
        page.waitForLoadState(LoadState.NETWORKIDLE);
        page.waitForLoadState(LoadState.DOMCONTENTLOADED);
        page.waitForLoadState(LoadState.LOAD);
    }
    
    /**
     * Click on an element identified by selector
     * @param selector CSS or XPath selector
     * @param description Description of the element for logging and reporting
     */
    @Step("Clicking on {description}")
    public void click(String selector, String description) {
        logger.info("Clicking on element: {} ({})", description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before clicking if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        locator.click();
    }
    
    /**
     * Type text into an input field
     * @param selector CSS or XPath selector
     * @param text Text to type
     * @param description Description of the element for logging and reporting
     */
    @Step("Typing '{text}' into {description}")
    public void type(String selector, String text, String description) {
        logger.info("Typing '{}' into element: {} ({})", text, description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before typing if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        // Clear the field first if configured
        if (config.getBooleanProperty("clear.before.type", true)) {
            locator.clear();
        }
        
        locator.fill(text);
    }
    
    /**
     * Get text from an element
     * @param selector CSS or XPath selector
     * @param description Description of the element for logging and reporting
     * @return Text content of the element
     */
    @Step("Getting text from {description}")
    public String getText(String selector, String description) {
        logger.info("Getting text from element: {} ({})", description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before getting text if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        return locator.textContent();
    }
    
    /**
     * Check if an element exists on the page
     * @param selector CSS or XPath selector
     * @param description Description of the element for logging and reporting
     * @return true if element exists, false otherwise
     */
    @Step("Checking if {description} exists")
    public boolean isElementPresent(String selector, String description) {
        logger.info("Checking if element exists: {} ({})", description, selector);
        return page.locator(selector).count() > 0;
    }
    
    /**
     * Wait for an element to be visible
     * @param selector CSS or XPath selector
     * @param description Description of the element for logging and reporting
     */
    @Step("Waiting for {description} to be visible")
    public void waitForElementVisible(String selector, String description) {
        logger.info("Waiting for element to be visible: {} ({})", description, selector);
        page.locator(selector).waitFor();
    }
    
    /**
     * Select an option from a dropdown by visible text
     * @param selector CSS or XPath selector for the select element
     * @param optionText Text of the option to select
     * @param description Description of the dropdown for logging and reporting
     */
    @Step("Selecting '{optionText}' from {description} dropdown")
    public void selectByText(String selector, String optionText, String description) {
        logger.info("Selecting '{}' from dropdown: {} ({})", optionText, description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before selecting if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        // In Playwright 1.39.0, we need to pass the option text directly
        locator.selectOption(optionText);
    }
    
    /**
     * Select an option from a dropdown by value
     * @param selector CSS or XPath selector for the select element
     * @param value Value of the option to select
     * @param description Description of the dropdown for logging and reporting
     */
    @Step("Selecting value '{value}' from {description} dropdown")
    public void selectByValue(String selector, String value, String description) {
        logger.info("Selecting value '{}' from dropdown: {} ({})", value, description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before selecting if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        locator.selectOption(value);
    }
    
    /**
     * Check a checkbox or radio button
     * @param selector CSS or XPath selector
     * @param description Description of the element for logging and reporting
     */
    @Step("Checking {description}")
    public void check(String selector, String description) {
        logger.info("Checking element: {} ({})", description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before checking if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        locator.check();
    }
    
    /**
     * Uncheck a checkbox
     * @param selector CSS or XPath selector
     * @param description Description of the element for logging and reporting
     */
    @Step("Unchecking {description}")
    public void uncheck(String selector, String description) {
        logger.info("Unchecking element: {} ({})", description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before unchecking if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        locator.uncheck();
    }
    
    /**
     * Hover over an element
     * @param selector CSS or XPath selector
     * @param description Description of the element for logging and reporting
     */
    @Step("Hovering over {description}")
    public void hover(String selector, String description) {
        logger.info("Hovering over element: {} ({})", description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before hovering if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        locator.hover();
    }
    
    /**
     * Get an attribute value from an element
     * @param selector CSS or XPath selector
     * @param attributeName Name of the attribute
     * @param description Description of the element for logging and reporting
     * @return Attribute value
     */
    @Step("Getting '{attributeName}' attribute from {description}")
    public String getAttribute(String selector, String attributeName, String description) {
        logger.info("Getting '{}' attribute from element: {} ({})", attributeName, description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before getting attribute if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        return locator.getAttribute(attributeName);
    }
    
    /**
     * Press a key on an element
     * @param selector CSS or XPath selector
     * @param key Key to press (e.g., "Enter", "Tab")
     * @param description Description of the element for logging and reporting
     */
    @Step("Pressing {key} key on {description}")
    public void pressKey(String selector, String key, String description) {
        logger.info("Pressing {} key on element: {} ({})", key, description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before pressing key if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        locator.press(key);
    }
    
    /**
     * Upload a file to an input element
     * @param selector CSS or XPath selector for the file input
     * @param filePath Path to the file to upload
     * @param description Description of the element for logging and reporting
     */
    @Step("Uploading file '{filePath}' to {description}")
    public void uploadFile(String selector, String filePath, String description) {
        logger.info("Uploading file '{}' to element: {} ({})", filePath, description, selector);
        Locator locator = page.locator(selector);
        
        // Highlight element before uploading if configured
        if (config.getBooleanProperty("highlight.elements", true)) {
            highlighter.highlightElement(locator);
        }
        
        // In Playwright 1.39.0, we need to pass a Path object
        locator.setInputFiles(Paths.get(filePath));
    }
    
    /**
     * Refresh the current page
     */
    @Step("Refreshing the page")
    public void refresh() {
        logger.info("Refreshing the page");
        page.reload();
        waitForPageLoad();
    }
    
    /**
     * Navigate back in browser history
     */
    @Step("Navigating back")
    public void navigateBack() {
        logger.info("Navigating back in browser history");
        page.goBack();
        waitForPageLoad();
    }
    
    /**
     * Navigate forward in browser history
     */
    @Step("Navigating forward")
    public void navigateForward() {
        logger.info("Navigating forward in browser history");
        page.goForward();
        waitForPageLoad();
    }
    
    /**
     * Execute JavaScript in the browser
     * @param script JavaScript code to execute
     * @param description Description of the script for logging and reporting
     * @return Result of the script execution
     */
    @Step("Executing JavaScript: {description}")
    public Object executeScript(String script, String description) {
        logger.info("Executing JavaScript: {}", description);
        return page.evaluate(script);
    }
}
