package com.playwright.framework.utils;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.playwright.framework.config.FrameworkConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class to highlight elements on the page before interacting with them.
 * Helps with visual debugging and recording.
 */
public class ElementHighlighter {
    private static final Logger logger = LoggerFactory.getLogger(ElementHighlighter.class);
    private final Page page;
    private final FrameworkConfig config;
    
    public ElementHighlighter(Page page) {
        this.page = page;
        this.config = FrameworkConfig.getInstance();
    }
    
    /**
     * Highlight an element identified by a selector
     * @param selector CSS or XPath selector
     */
    public void highlightElement(String selector) {
        try {
            logger.debug("Highlighting element: {}", selector);
            Locator locator = page.locator(selector);
            highlightElement(locator);
        } catch (Exception e) {
            logger.warn("Failed to highlight element with selector: {}", selector, e);
        }
    }
    
    /**
     * Highlight a Playwright Locator
     * @param locator Playwright Locator
     */
    public void highlightElement(Locator locator) {
        try {
            ElementHandle element = locator.elementHandle();
            if (element != null) {
                highlightElementHandle(element);
                element.dispose();
            } else {
                logger.warn("Element not found for highlighting");
            }
        } catch (Exception e) {
            logger.warn("Failed to highlight element with locator", e);
        }
    }
    
    /**
     * Highlight a Playwright ElementHandle
     * @param element Playwright ElementHandle
     */
    public void highlightElementHandle(ElementHandle element) {
        try {
            if (element == null) {
                logger.warn("Element is null, cannot highlight");
                return;
            }
            
            // Get highlight parameters from configuration
            String borderColor = config.getProperty("highlight.border.color", "red");
            String backgroundColor = config.getProperty("highlight.background.color", "rgba(255, 0, 0, 0.2)");
            int borderWidth = config.getIntProperty("highlight.border.width", 3);
            int duration = config.getIntProperty("highlight.duration", 1000);
            
            // Create JavaScript to highlight and then restore the element
            String highlightJS = String.format(
                "() => {" +
                "  const element = arguments[0];" +
                "  const originalStyle = element.getAttribute('style') || '';" +
                "  element.setAttribute('style', originalStyle + " +
                "    '; border: %dpx solid %s !important;" +
                "    background-color: %s !important;');" +
                "  setTimeout(() => {" +
                "    element.setAttribute('style', originalStyle);" +
                "  }, %d);" +
                "  return originalStyle;" +
                "}", borderWidth, borderColor, backgroundColor, duration);
            
            // Execute the JavaScript
            element.evaluate(highlightJS);
            
            // Sleep for the highlight duration
            Thread.sleep(duration);
        } catch (Exception e) {
            logger.warn("Failed to highlight element", e);
        }
    }
    
    /**
     * Highlight multiple elements matching a selector
     * @param selector CSS or XPath selector
     */
    public void highlightAllElements(String selector) {
        try {
            logger.debug("Highlighting all elements matching: {}", selector);
            
            // Get all elements matching the selector
            Locator locator = page.locator(selector);
            int count = locator.count();
            
            logger.debug("Found {} elements to highlight", count);
            
            // Highlight each element
            for (int i = 0; i < count; i++) {
                Locator elementLocator = locator.nth(i);
                highlightElement(elementLocator);
            }
        } catch (Exception e) {
            logger.warn("Failed to highlight all elements with selector: {}", selector, e);
        }
    }
    
    /**
     * Scroll to an element and highlight it
     * @param selector CSS or XPath selector
     */
    public void scrollToAndHighlight(String selector) {
        try {
            logger.debug("Scrolling to and highlighting element: {}", selector);
            
            // Get the element
            Locator locator = page.locator(selector);
            
            // Scroll the element into view
            locator.scrollIntoViewIfNeeded();
            
            // Highlight the element
            highlightElement(locator);
        } catch (Exception e) {
            logger.warn("Failed to scroll to and highlight element: {}", selector, e);
        }
    }
}
