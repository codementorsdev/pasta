package com.playwright.framework.dataprovider;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.DataProvider;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Data provider for CSV data sources.
 * Supports reading test data from CSV files.
 */
public class CsvDataProvider {
    private static final Logger logger = LoggerFactory.getLogger(CsvDataProvider.class);
    private final String filePath;
    
    /**
     * Constructor for CsvDataProvider
     * @param filePath Path to the CSV file
     */
    public CsvDataProvider(String filePath) {
        this.filePath = filePath;
        logger.info("Initialized CsvDataProvider with file: {}", filePath);
    }
    
    /**
     * Parse the CSV file and return the data as a list of maps
     * @return List of maps, each representing a row of data
     * @throws IOException If the file cannot be read or parsed
     */
    public List<Map<String, String>> getData() throws IOException {
        logger.debug("Reading CSV data from file: {}", filePath);
        List<Map<String, String>> dataList = new ArrayList<>();
        
        try (Reader reader = Files.newBufferedReader(Paths.get(filePath));
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            // Get the header names
            Map<String, Integer> headerMap = csvParser.getHeaderMap();
            
            for (CSVRecord record : csvParser) {
                Map<String, String> row = new HashMap<>();
                
                // Add each field to the row map
                for (String header : headerMap.keySet()) {
                    row.put(header, record.get(header));
                }
                
                dataList.add(row);
            }
            
            logger.debug("Read {} rows from CSV file", dataList.size());
            return dataList;
        }
    }
    
    /**
     * Get specific data column from the CSV file
     * @param columnName Name of the column
     * @return List of values in the column
     * @throws IOException If the file cannot be read or parsed
     */
    public List<String> getColumn(String columnName) throws IOException {
        logger.debug("Reading column '{}' from CSV file: {}", columnName, filePath);
        List<String> columnData = new ArrayList<>();
        
        try (Reader reader = Files.newBufferedReader(Paths.get(filePath));
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            for (CSVRecord record : csvParser) {
                String value = record.get(columnName);
                columnData.add(value);
            }
            
            logger.debug("Read {} values from column '{}'", columnData.size(), columnName);
            return columnData;
        }
    }
    
    /**
     * Get a specific row from the CSV file by index
     * @param rowIndex Index of the row (0-based)
     * @return Map representing the row
     * @throws IOException If the file cannot be read or parsed
     */
    public Map<String, String> getRow(int rowIndex) throws IOException {
        logger.debug("Reading row {} from CSV file: {}", rowIndex, filePath);
        
        try (Reader reader = Files.newBufferedReader(Paths.get(filePath));
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            // Get the header names
            Map<String, Integer> headerMap = csvParser.getHeaderMap();
            
            List<CSVRecord> records = csvParser.getRecords();
            if (rowIndex < 0 || rowIndex >= records.size()) {
                logger.warn("Row index out of bounds: {}", rowIndex);
                return new HashMap<>();
            }
            
            CSVRecord record = records.get(rowIndex);
            Map<String, String> row = new HashMap<>();
            
            // Add each field to the row map
            for (String header : headerMap.keySet()) {
                row.put(header, record.get(header));
            }
            
            return row;
        }
    }
    
    /**
     * Get a specific cell value from the CSV file
     * @param rowIndex Index of the row (0-based)
     * @param columnName Name of the column
     * @return Value of the cell
     * @throws IOException If the file cannot be read or parsed
     */
    public String getValue(int rowIndex, String columnName) throws IOException {
        Map<String, String> row = getRow(rowIndex);
        return row.get(columnName);
    }
    
    /**
     * TestNG DataProvider method to provide test data from CSV
     * @return Object array for TestNG data-driven testing
     */
    @DataProvider(name = "csvData")
    public Object[][] provideData() {
        try {
            List<Map<String, String>> dataList = getData();
            Object[][] data = new Object[dataList.size()][1];
            
            for (int i = 0; i < dataList.size(); i++) {
                data[i][0] = dataList.get(i);
            }
            
            logger.info("Provided {} rows of test data from CSV", dataList.size());
            return data;
        } catch (IOException e) {
            logger.error("Failed to read CSV data from file: {}", filePath, e);
            return new Object[0][0];
        }
    }
    
    /**
     * Get the number of rows in the CSV file (excluding header)
     * @return Number of data rows
     * @throws IOException If the file cannot be read or parsed
     */
    public int getRowCount() throws IOException {
        try (Reader reader = Files.newBufferedReader(Paths.get(filePath));
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            return csvParser.getRecords().size();
        }
    }
    
    /**
     * Get the header names from the CSV file
     * @return List of header names
     * @throws IOException If the file cannot be read or parsed
     */
    public List<String> getHeaders() throws IOException {
        try (Reader reader = Files.newBufferedReader(Paths.get(filePath));
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
            
            return new ArrayList<>(csvParser.getHeaderMap().keySet());
        }
    }
}
