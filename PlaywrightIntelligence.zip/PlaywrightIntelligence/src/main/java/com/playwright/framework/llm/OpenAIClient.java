package com.playwright.framework.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.playwright.framework.config.FrameworkConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

/**
 * Implementation of LlmClient interface for OpenAI GPT models.
 * Provides methods to interact with OpenAI's API for natural language processing.
 */
public class OpenAIClient implements LlmClient {
    private static final Logger logger = LoggerFactory.getLogger(OpenAIClient.class);
    private static final String API_ENDPOINT = "https://api.openai.com/v1/chat/completions";
    private static final String DEFAULT_MODEL = "gpt-3.5-turbo";
    private static final int DEFAULT_MAX_TOKENS = 1000;
    private static final double DEFAULT_TEMPERATURE = 0.7;
    
    private final FrameworkConfig config;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;
    
    private String apiKey;
    private String model;
    private boolean initialized = false;
    
    /**
     * Constructor for OpenAIClient
     */
    public OpenAIClient() {
        this.config = FrameworkConfig.getInstance();
        this.objectMapper = new ObjectMapper();
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();
    }
    
    @Override
    public void initialize() {
        logger.info("Initializing OpenAI client");
        
        // Get API key from configuration
        this.apiKey = config.getOpenAIApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            logger.error("OpenAI API key is not configured. Please set it in the configuration or environment variable.");
            return;
        }
        
        // Get model from configuration or use default
        this.model = config.getProperty("openai.model", DEFAULT_MODEL);
        
        logger.info("OpenAI client initialized with model: {}", model);
        initialized = true;
    }
    
    @Override
    public boolean isInitialized() {
        return initialized;
    }
    
    @Override
    public String getCompletion(String prompt) {
        return getCompletion(prompt, Collections.emptyMap());
    }
    
    @Override
    public String getCompletion(String prompt, Map<String, Object> options) {
        if (!initialized) {
            logger.error("OpenAI client is not initialized. Call initialize() first.");
            return "";
        }
        
        try {
            logger.debug("Sending completion request to OpenAI");
            
            // Prepare request payload
            ObjectNode requestPayload = objectMapper.createObjectNode();
            requestPayload.put("model", options.getOrDefault("model", model).toString());
            
            // Set messages
            ArrayNode messages = requestPayload.putArray("messages");
            ObjectNode userMessage = messages.addObject();
            userMessage.put("role", "user");
            userMessage.put("content", prompt);
            
            // Add system message if provided
            if (options.containsKey("system_message")) {
                ObjectNode systemMessage = objectMapper.createObjectNode();
                systemMessage.put("role", "system");
                systemMessage.put("content", options.get("system_message").toString());
                // Insert at the beginning of the array
                messages.insert(0, systemMessage);
            }
            
            // Set other parameters
            requestPayload.put("temperature", options.containsKey("temperature") ? 
                    Double.parseDouble(options.get("temperature").toString()) : DEFAULT_TEMPERATURE);
            requestPayload.put("max_tokens", options.containsKey("max_tokens") ? 
                    Integer.parseInt(options.get("max_tokens").toString()) : DEFAULT_MAX_TOKENS);
            
            if (options.containsKey("top_p")) {
                requestPayload.put("top_p", Double.parseDouble(options.get("top_p").toString()));
            }
            
            if (options.containsKey("presence_penalty")) {
                requestPayload.put("presence_penalty", Double.parseDouble(options.get("presence_penalty").toString()));
            }
            
            if (options.containsKey("frequency_penalty")) {
                requestPayload.put("frequency_penalty", Double.parseDouble(options.get("frequency_penalty").toString()));
            }
            
            String requestBody = objectMapper.writeValueAsString(requestPayload);
            
            // Create HTTP request
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_ENDPOINT))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();
            
            // Send request and get response
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() != 200) {
                logger.error("OpenAI API request failed with status code: {}", response.statusCode());
                logger.error("Response body: {}", response.body());
                return "";
            }
            
            // Parse response
            JsonNode responseJson = objectMapper.readTree(response.body());
            JsonNode choices = responseJson.get("choices");
            
            if (choices != null && choices.isArray() && choices.size() > 0) {
                JsonNode firstChoice = choices.get(0);
                JsonNode message = firstChoice.get("message");
                if (message != null) {
                    String content = message.get("content").asText();
                    logger.debug("Received completion from OpenAI");
                    return content;
                }
            }
            
            logger.error("Failed to parse completion from OpenAI response");
            return "";
        } catch (IOException | InterruptedException e) {
            logger.error("Error while sending request to OpenAI", e);
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            return "";
        }
    }
    
    @Override
    public List<String> generateTestSteps(String testDescription) {
        logger.info("Generating test steps from description");
        
        Map<String, Object> options = new HashMap<>();
        options.put("system_message", "You are a test automation expert. " +
                "Parse the given test description into clear, numbered steps that can be automated. " +
                "Each step should be a single action or verification.");
        options.put("temperature", 0.3); // Lower temperature for more deterministic output
        options.put("max_tokens", 2000);
        
        String prompt = "Generate a list of numbered test steps from the following test description:\n\n" + 
                testDescription + "\n\nFormat each step as a single line with a number followed by a simple instruction.";
        
        String completion = getCompletion(prompt, options);
        
        // Parse the numbered steps from the completion
        List<String> steps = new ArrayList<>();
        for (String line : completion.split("\n")) {
            line = line.trim();
            if (line.matches("^\\d+\\..*")) {
                // Remove the number and period at the beginning
                String step = line.replaceFirst("^\\d+\\.\\s*", "").trim();
                if (!step.isEmpty()) {
                    steps.add(step);
                }
            }
        }
        
        logger.info("Generated {} test steps", steps.size());
        return steps;
    }
    
    @Override
    public String generateStepCode(String step, Map<String, Object> context) {
        logger.info("Generating code for test step: {}", step);
        
        StringBuilder contextString = new StringBuilder();
        if (context != null && !context.isEmpty()) {
            contextString.append("Context information:\n");
            context.forEach((key, value) -> 
                contextString.append("- ").append(key).append(": ").append(value).append("\n"));
        }
        
        Map<String, Object> options = new HashMap<>();
        options.put("system_message", "You are a Playwright Java test automation expert. " +
                "Generate Java code for the given test step using Playwright's Java API. " +
                "Use appropriate selectors and methods. The code should be part of a test method, " +
                "not a complete class. The Playwright Page object is available as 'page'.");
        options.put("temperature", 0.2); // Lower temperature for more deterministic output
        options.put("max_tokens", 1000);
        
        String prompt = "Generate Java code for the following test step using Playwright:\n\n" + 
                "Step: " + step + "\n\n" +
                contextString.toString() + "\n" +
                "Return only the Java code without explanations.";
        
        return getCompletion(prompt, options);
    }
    
    @Override
    public List<String> suggestSelectors(String elementDescription, String pageSource) {
        logger.info("Suggesting selectors for element: {}", elementDescription);
        
        Map<String, Object> options = new HashMap<>();
        options.put("system_message", "You are a Playwright test automation expert. " +
                "Analyze the HTML source and suggest effective selectors for the described element. " +
                "Prioritize selectors in this order: ID, data-testid, aria attributes, CSS selectors, XPath.");
        options.put("temperature", 0.3);
        options.put("max_tokens", 1000);
        
        String prompt = "Suggest the best selectors for the following element based on this HTML source:\n\n" + 
                "Element description: " + elementDescription + "\n\n" +
                "HTML source (partial):\n" + pageSource + "\n\n" +
                "Return a numbered list of selectors from most to least recommended.";
        
        String completion = getCompletion(prompt, options);
        
        // Parse the numbered selectors from the completion
        List<String> selectors = new ArrayList<>();
        for (String line : completion.split("\n")) {
            line = line.trim();
            if (line.matches("^\\d+\\..*")) {
                // Extract just the selector, not the explanation
                String selectorLine = line.replaceFirst("^\\d+\\.\\s*", "").trim();
                
                // Try to extract just the selector from explanatory text
                String selector = extractSelector(selectorLine);
                if (selector != null && !selector.isEmpty()) {
                    selectors.add(selector);
                }
            }
        }
        
        logger.info("Suggested {} selectors", selectors.size());
        return selectors;
    }
    
    @Override
    public String generateTestScript(String testDescription, Map<String, Object> options) {
        logger.info("Generating complete test script from description");
        
        Map<String, Object> completionOptions = new HashMap<>();
        completionOptions.put("system_message", "You are a Playwright Java test automation expert. " +
                "Generate a complete TestNG test class using Playwright's Java API based on the test description. " +
                "The test should extend BaseTest class which provides the page object and other utilities. " +
                "Use appropriate assertions and include proper error handling.");
        completionOptions.put("temperature", 0.3);
        completionOptions.put("max_tokens", 3000);
        
        StringBuilder prompt = new StringBuilder();
        prompt.append("Generate a complete Java TestNG test class using Playwright for the following test description:\n\n");
        prompt.append(testDescription).append("\n\n");
        
        if (options != null && !options.isEmpty()) {
            prompt.append("Additional requirements:\n");
            options.forEach((key, value) -> 
                prompt.append("- ").append(key).append(": ").append(value).append("\n"));
        }
        
        prompt.append("\nThe test class should extend BaseTest and implement the test described above. ");
        prompt.append("Include appropriate setup, test method, assertions, and cleanup. ");
        prompt.append("The base test provides a 'page' object and methods like navigateTo(), takeScreenshot(), etc.");
        
        return getCompletion(prompt.toString(), completionOptions);
    }
    
    @Override
    public Map<String, Object> extractData(String text, Map<String, String> schema) {
        logger.info("Extracting data from text with schema size: {}", schema.size());
        
        StringBuilder schemaString = new StringBuilder();
        schema.forEach((key, value) -> 
            schemaString.append("- ").append(key).append(": ").append(value).append("\n"));
        
        Map<String, Object> options = new HashMap<>();
        options.put("system_message", "You are a data extraction expert. " +
                "Extract structured data from the provided text according to the given schema. " +
                "Return the data in a simple key-value format, one item per line.");
        options.put("temperature", 0.1); // Very low temperature for consistent extraction
        options.put("max_tokens", 1000);
        
        String prompt = "Extract the following data points from this text:\n\n" + 
                schemaString.toString() + "\n\n" +
                "Text to extract from:\n" + text + "\n\n" +
                "Return the extracted data in this format:\n" +
                "key1: value1\n" +
                "key2: value2";
        
        String completion = getCompletion(prompt, options);
        
        // Parse the extracted data
        Map<String, Object> extractedData = new HashMap<>();
        for (String line : completion.split("\n")) {
            line = line.trim();
            if (line.contains(":")) {
                String[] parts = line.split(":", 2);
                if (parts.length == 2) {
                    String key = parts[0].trim();
                    String value = parts[1].trim();
                    extractedData.put(key, value);
                }
            }
        }
        
        logger.info("Extracted {} data points", extractedData.size());
        return extractedData;
    }
    
    @Override
    public String classifyText(String text, List<String> categories) {
        logger.info("Classifying text into {} categories", categories.size());
        
        StringBuilder categoriesString = new StringBuilder();
        for (int i = 0; i < categories.size(); i++) {
            categoriesString.append(i + 1).append(". ").append(categories.get(i)).append("\n");
        }
        
        Map<String, Object> options = new HashMap<>();
        options.put("system_message", "You are a text classification expert. " +
                "Classify the given text into exactly one of the provided categories. " +
                "Return only the category name without explanation.");
        options.put("temperature", 0.1); // Very low temperature for deterministic classification
        options.put("max_tokens", 100);
        
        String prompt = "Classify the following text into exactly one of these categories:\n\n" + 
                categoriesString.toString() + "\n\n" +
                "Text to classify:\n" + text + "\n\n" +
                "Return only the category name.";
        
        String completion = getCompletion(prompt, options);
        
        // Clean up the response to get just the category
        String category = completion.trim();
        
        // Try to match the response to one of the categories
        for (String validCategory : categories) {
            if (category.equalsIgnoreCase(validCategory) || 
                    category.toLowerCase().contains(validCategory.toLowerCase())) {
                return validCategory;
            }
        }
        
        // If no match, return the raw completion
        logger.warn("Classification result '{}' doesn't match any category exactly", category);
        return category;
    }
    
    @Override
    public void close() {
        logger.info("Closing OpenAI client");
        initialized = false;
    }
    
    /**
     * Extract a selector from a line of text that may contain explanations
     * @param line The line of text containing a selector
     * @return The extracted selector or null if not found
     */
    private String extractSelector(String line) {
        // Common selector patterns
        String[] patterns = {
            "\"([#.]?[\\w-]+)\"", // ID or class selectors in quotes
            "'([#.]?[\\w-]+)'", // ID or class selectors in single quotes
            "\\[([\\w-]+=[\"'][\\w-]+[\"'])\\]", // Attribute selectors
            "//([\\w/\\[\\]@=\"']+)" // XPath selectors
        };
        
        for (String pattern : patterns) {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(line);
            if (m.find()) {
                return m.group(1);
            }
        }
        
        // If no pattern matches but line contains code-like syntax, return the whole line
        if (line.contains("#") || line.contains(".") || line.contains("[") || 
                line.contains("//") || line.contains("text=")) {
            return line;
        }
        
        return null;
    }
}
