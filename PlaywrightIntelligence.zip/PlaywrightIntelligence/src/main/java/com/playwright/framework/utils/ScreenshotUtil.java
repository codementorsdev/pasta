package com.playwright.framework.utils;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.playwright.framework.config.FrameworkConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility class for taking screenshots with Playwright.
 * Supports full page and element screenshots.
 */
public class ScreenshotUtil {
    private static final Logger logger = LoggerFactory.getLogger(ScreenshotUtil.class);
    private final Page page;
    private final FrameworkConfig config;
    private final String screenshotsDir;
    
    public ScreenshotUtil(Page page) {
        this.page = page;
        this.config = FrameworkConfig.getInstance();
        this.screenshotsDir = config.getScreenshotsDir();
    }
    
    /**
     * Take a full page screenshot
     * @param name Base name for the screenshot file
     * @return Path to the saved screenshot
     */
    public String takeFullPageScreenshot(String name) {
        try {
            String fileName = generateFileName(name);
            Path path = Paths.get(screenshotsDir, fileName);
            
            logger.info("Taking full page screenshot: {}", path);
            
            // Create directory if it doesn't exist
            Path directory = path.getParent();
            if (directory != null) {
                directory.toFile().mkdirs();
            }
            
            // Take the screenshot - using built-in options directly
            page.screenshot(new Page.ScreenshotOptions()
                    .setFullPage(true)
                    .setPath(path)
                    .setQuality(fileName.toLowerCase().endsWith(".png") ? null : config.getIntProperty("screenshot.quality", 90)));
            
            logger.info("Full page screenshot saved to: {}", path);
            return path.toString();
        } catch (Exception e) {
            logger.error("Failed to take full page screenshot", e);
            return null;
        }
    }
    
    /**
     * Take a screenshot of a specific element
     * @param selector CSS or XPath selector for the element
     * @param name Base name for the screenshot file
     * @return Path to the saved screenshot
     */
    public String takeElementScreenshot(String selector, String name) {
        try {
            String fileName = generateFileName(name);
            Path path = Paths.get(screenshotsDir, fileName);
            
            logger.info("Taking element screenshot of '{}': {}", selector, path);
            
            // Create directory if it doesn't exist
            Path directory = path.getParent();
            if (directory != null) {
                directory.toFile().mkdirs();
            }
            
            // Find the element and take screenshot - using built-in options directly
            Locator locator = page.locator(selector);
            locator.screenshot(new Locator.ScreenshotOptions()
                    .setPath(path)
                    .setQuality(fileName.toLowerCase().endsWith(".png") ? null : config.getIntProperty("screenshot.quality", 90)));
            
            logger.info("Element screenshot saved to: {}", path);
            return path.toString();
        } catch (Exception e) {
            logger.error("Failed to take element screenshot", e);
            return null;
        }
    }
    
    /**
     * Take a screenshot with a custom viewport size
     * @param name Base name for the screenshot file
     * @param width Viewport width
     * @param height Viewport height
     * @return Path to the saved screenshot
     */
    public String takeScreenshotWithViewport(String name, int width, int height) {
        try {
            String fileName = generateFileName(name);
            Path path = Paths.get(screenshotsDir, fileName);
            
            logger.info("Taking screenshot with viewport {}x{}: {}", width, height, path);
            
            // Create directory if it doesn't exist
            Path directory = path.getParent();
            if (directory != null) {
                directory.toFile().mkdirs();
            }
            
            // Save current viewport size
            int oldWidth = page.viewportSize().width;
            int oldHeight = page.viewportSize().height;
            
            // Set temporary viewport size
            page.setViewportSize(width, height);
            
            // Take the screenshot - using built-in options directly
            page.screenshot(new Page.ScreenshotOptions()
                    .setFullPage(false)
                    .setPath(path)
                    .setQuality(fileName.toLowerCase().endsWith(".png") ? null : config.getIntProperty("screenshot.quality", 90)));
            
            // Restore original viewport size
            page.setViewportSize(oldWidth, oldHeight);
            
            logger.info("Screenshot with custom viewport saved to: {}", path);
            return path.toString();
        } catch (Exception e) {
            logger.error("Failed to take screenshot with custom viewport", e);
            return null;
        }
    }
    
    /**
     * Generate a unique filename for a screenshot
     * @param baseName Base name for the screenshot
     * @return Generated filename with timestamp
     */
    private String generateFileName(String baseName) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String extension = config.getProperty("screenshot.format", "png").toLowerCase();
        
        // Clean the base name to be filesystem safe
        String cleanBaseName = baseName.replaceAll("[^a-zA-Z0-9-_]", "_");
        
        return String.format("%s_%s.%s", cleanBaseName, timestamp, extension);
    }
}
