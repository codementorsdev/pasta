package com.playwright.framework.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Request;
import com.microsoft.playwright.Response;
import com.microsoft.playwright.Route;
import com.playwright.framework.config.FrameworkConfig;
import io.qameta.allure.Attachment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Utility class to intercept and modify network requests and responses.
 * Provides methods for logging, mocking, and manipulating network traffic.
 */
public class NetworkInterceptor {
    private static final Logger logger = LoggerFactory.getLogger(NetworkInterceptor.class);
    private final Page page;
    private final FrameworkConfig config;
    private final ObjectMapper objectMapper;
    private final Map<String, Request> capturedRequests = new ConcurrentHashMap<>();
    private final Map<String, APIResponse> capturedResponses = new ConcurrentHashMap<>();
    private boolean requestLoggingEnabled = false;
    private boolean responseLoggingEnabled = false;
    
    public NetworkInterceptor(Page page) {
        this.page = page;
        this.config = FrameworkConfig.getInstance();
        this.objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
    }
    
    /**
     * Enable request interception for handling network requests
     */
    public void enableRequestInterception() {
        logger.info("Enabling request interception");
        page.route("**/*", this::handleInterception);
    }
    
    /**
     * Intercept specific requests matching a URL pattern
     * @param urlPattern URL pattern to match (supports glob and regex)
     */
    public void interceptRequest(String urlPattern) {
        logger.info("Adding request interception for URL pattern: {}", urlPattern);
        page.route(urlPattern, this::handleInterception);
    }
    
    /**
     * Enable request logging for all requests
     */
    public void enableRequestLogging() {
        logger.info("Enabling request logging");
        requestLoggingEnabled = true;
    }
    
    /**
     * Enable response logging for all responses
     */
    public void enableResponseLogging() {
        logger.info("Enabling response logging");
        responseLoggingEnabled = true;
    }
    
    /**
     * Get a captured request by URL
     * @param url URL of the request
     * @return The captured request or null if not found
     */
    public Request getCapturedRequest(String url) {
        return capturedRequests.get(url);
    }
    
    /**
     * Get a captured response by URL
     * @param url URL of the request
     * @return The captured response or null if not found
     */
    public APIResponse getCapturedResponse(String url) {
        return capturedResponses.get(url);
    }
    
    /**
     * Get all captured requests
     * @return Map of captured requests with URL as key
     */
    public Map<String, Request> getAllCapturedRequests() {
        return Collections.unmodifiableMap(capturedRequests);
    }
    
    /**
     * Get all captured responses
     * @return Map of captured responses with URL as key
     */
    public Map<String, APIResponse> getAllCapturedResponses() {
        return Collections.unmodifiableMap(capturedResponses);
    }
    
    /**
     * Clear all captured requests and responses
     */
    public void clearCapturedData() {
        logger.info("Clearing all captured network data");
        capturedRequests.clear();
        capturedResponses.clear();
    }
    
    /**
     * Mock a response for a specific URL pattern
     * @param urlPattern URL pattern to match
     * @param status HTTP status code
     * @param headers Response headers
     * @param body Response body
     */
    public void mockResponse(String urlPattern, int status, Map<String, String> headers, String body) {
        logger.info("Setting up mock response for URL pattern: {}", urlPattern);
        
        page.route(urlPattern, route -> {
            logger.debug("Mocking response for request: {}", route.request().url());
            
            // Build response options
            Route.FulfillOptions options = new Route.FulfillOptions()
                    .setStatus(status)
                    .setBody(body);
            
            // Add headers if provided
            if (headers != null && !headers.isEmpty()) {
                options.setHeaders(headers);
            }
            
            // Fulfill the request with mock response
            route.fulfill(options);
        });
    }
    
    /**
     * Block requests matching a URL pattern
     * @param urlPattern URL pattern to match
     */
    public void blockRequests(String urlPattern) {
        logger.info("Blocking requests for URL pattern: {}", urlPattern);
        
        page.route(urlPattern, route -> {
            logger.debug("Blocking request: {}", route.request().url());
            route.abort();
        });
    }
    
    /**
     * Modify request headers for matching URL pattern
     * @param urlPattern URL pattern to match
     * @param headers Headers to add or replace
     */
    public void modifyRequestHeaders(String urlPattern, Map<String, String> headers) {
        logger.info("Setting up request header modification for URL pattern: {}", urlPattern);
        
        page.route(urlPattern, route -> {
            Request request = route.request();
            logger.debug("Modifying headers for request: {}", request.url());
            
            // Get existing headers
            Map<String, String> newHeaders = new HashMap<>(request.headers());
            
            // Add or replace headers
            newHeaders.putAll(headers);
            
            // Continue with modified headers
            route.resume(new Route.ResumeOptions().setHeaders(newHeaders));
        });
    }
    
    /**
     * Delay responses for matching URL pattern
     * @param urlPattern URL pattern to match
     * @param delayMs Delay in milliseconds
     */
    public void delayResponse(String urlPattern, int delayMs) {
        logger.info("Setting up response delay of {}ms for URL pattern: {}", delayMs, urlPattern);
        
        page.route(urlPattern, route -> {
            String url = route.request().url();
            logger.debug("Delaying response for request: {}", url);
            
            try {
                Thread.sleep(delayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.warn("Interrupted while delaying response", e);
            }
            
            route.resume();
        });
    }
    
    /**
     * Handle intercepted requests and responses
     * @param route Playwright Route
     */
    private void handleInterception(Route route) {
        Request request = route.request();
        String url = request.url();
        
        // Capture the request
        capturedRequests.put(url, request);
        
        // Log request if enabled
        if (requestLoggingEnabled) {
            logRequest(request);
        }
        
        // For Playwright 1.39.0, we need to use fetch and fulfill
        APIResponse response = route.fetch(new Route.FetchOptions());
        if (response != null) {
            // Capture the response
            capturedResponses.put(url, response);
            
            // Log response if enabled
            if (responseLoggingEnabled) {
                logResponse(response);
            }
            
            // Continue the route after processing
            route.fulfill(new Route.FulfillOptions().setResponse(response));
        } else {
            // If response is null, just resume the route
            route.resume();
        }
        
    }
    
    /**
     * Log request details
     * @param request Playwright Request
     */
    private void logRequest(Request request) {
        try {
            String url = request.url();
            String method = request.method();
            Map<String, String> headers = request.headers();
            
            logger.info("Request: {} {}", method, url);
            logger.debug("Request headers: {}", headers);
            
            // Log request post data if available
            if ("POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method)) {
                String postData = request.postData();
                if (postData != null) {
                    try {
                        // Try to format as JSON if it's JSON
                        JsonNode jsonNode = objectMapper.readTree(postData);
                        logger.debug("Request body (JSON): {}", objectMapper.writeValueAsString(jsonNode));
                    } catch (Exception e) {
                        // Not JSON, log as is
                        logger.debug("Request body: {}", postData);
                    }
                }
            }
        } catch (Exception e) {
            logger.warn("Error logging request", e);
        }
    }
    
    /**
     * Log response details
     * @param response Playwright APIResponse
     */
    private void logResponse(APIResponse response) {
        try {
            String url = response.url();
            int status = response.status();
            Map<String, String> headers = response.headers();
            
            logger.info("Response: status {} for {}", status, url);
            logger.debug("Response headers: {}", headers);
            
            // Log response body for API calls if configured
            String contentType = headers.getOrDefault("content-type", "");
            if (contentType != null && 
                (contentType.contains("application/json") || 
                 contentType.contains("application/xml") ||
                 contentType.contains("text/")) &&
                config.getBooleanProperty("log.response.body", true)) {
                
                try {
                    String body = response.text();
                    
                    if (contentType.contains("application/json")) {
                        // Format JSON for better readability
                        JsonNode jsonNode = objectMapper.readTree(body);
                        logger.debug("Response body (JSON): {}", objectMapper.writeValueAsString(jsonNode));
                    } else {
                        // Log other content types as is
                        logger.debug("Response body: {}", body);
                    }
                } catch (Exception e) {
                    logger.warn("Error parsing response body", e);
                }
            }
        } catch (Exception e) {
            logger.warn("Error logging response", e);
        }
    }
    
    /**
     * Create a report of captured network traffic and attach to Allure
     * @param name Report name
     * @return The report content
     */
    @Attachment(value = "{name}", type = "text/plain")
    public String createNetworkTrafficReport(String name) {
        StringBuilder report = new StringBuilder();
        report.append("Network Traffic Report: ").append(name).append("\n\n");
        
        report.append("=== REQUESTS ===\n");
        capturedRequests.forEach((url, request) -> {
            report.append("Request: ").append(request.method()).append(" ").append(url).append("\n");
            report.append("Headers: ").append(request.headers()).append("\n");
            
            if ("POST".equalsIgnoreCase(request.method()) || "PUT".equalsIgnoreCase(request.method())) {
                String postData = request.postData();
                if (postData != null) {
                    report.append("Body: ").append(postData).append("\n");
                }
            }
            
            report.append("\n");
        });
        
        report.append("=== RESPONSES ===\n");
        capturedResponses.forEach((url, response) -> {
            report.append("Response for: ").append(url).append("\n");
            report.append("Status: ").append(response.status()).append("\n");
            report.append("Headers: ").append(response.headers()).append("\n");
            
            try {
                String contentType = response.headers().get("content-type");
                if (contentType != null && 
                    (contentType.contains("application/json") || 
                     contentType.contains("application/xml") ||
                     contentType.contains("text/"))) {
                    
                    String body = response.text();
                    report.append("Body: ").append(body).append("\n");
                }
            } catch (Exception e) {
                report.append("Error getting response body: ").append(e.getMessage()).append("\n");
            }
            
            report.append("\n");
        });
        
        return report.toString();
    }
}
