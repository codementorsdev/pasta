package com.playwright.framework.llm;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.playwright.framework.config.FrameworkConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Processes natural language commands and executes them using Playwright.
 * Uses LLM to interpret natural language and convert it to actions.
 */
public class NaturalLanguageProcessor {
    private static final Logger logger = LoggerFactory.getLogger(NaturalLanguageProcessor.class);
    private final LlmClient llmClient;
    private final Page page;
    private final FrameworkConfig config;
    
    // Patterns for common actions (fallback when LLM is not available)
    private static final Pattern NAVIGATE_PATTERN = Pattern.compile("(?i)(?:navigate|go|open)\\s+(?:to)?\\s+(https?://[^\\s]+)");
    private static final Pattern CLICK_PATTERN = Pattern.compile("(?i)click\\s+(?:on\\s+)?(?:the\\s+)?([\\w\\s]+)(?:\\s+button)?");
    private static final Pattern TYPE_PATTERN = Pattern.compile("(?i)(?:type|enter|input)\\s+(?:the\\s+)?(?:text\\s+)?[\"']([^\"']+)[\"']\\s+(?:in|into|on)\\s+(?:the\\s+)?([\\w\\s]+)");
    
    /**
     * Constructor for NaturalLanguageProcessor
     * @param page Playwright Page object
     * @param llmClient LLM client for natural language processing
     */
    public NaturalLanguageProcessor(Page page, LlmClient llmClient) {
        this.page = page;
        this.llmClient = llmClient;
        this.config = FrameworkConfig.getInstance();
        logger.info("Initialized NaturalLanguageProcessor");
    }
    
    /**
     * Process and execute a natural language command
     * @param command Natural language command
     * @return Result of the command execution
     */
    public String processCommand(String command) {
        logger.info("Processing natural language command: {}", command);
        
        try {
            // Try to use LLM for processing if available
            if (llmClient != null && llmClient.isInitialized()) {
                return processWithLlm(command);
            } else {
                // Fallback to pattern matching
                logger.warn("LLM client not available, using pattern matching fallback");
                return processWithPatterns(command);
            }
        } catch (Exception e) {
            logger.error("Error processing command: {}", command, e);
            return "Error: " + e.getMessage();
        }
    }
    
    /**
     * Process a natural language command using LLM
     * @param command Natural language command
     * @return Result of the command execution
     */
    private String processWithLlm(String command) {
        logger.debug("Processing command with LLM: {}", command);
        
        // Provide context about the current page
        Map<String, Object> context = new HashMap<>();
        context.put("url", page.url());
        context.put("title", page.title());
        
        // Get HTML snapshot for context (limit size)
        String html = page.content();
        if (html.length() > 5000) {
            html = html.substring(0, 5000) + "...";
        }
        context.put("html_snapshot", html);
        
        // Generate code for the command
        String code = llmClient.generateStepCode(command, context);
        
        if (code == null || code.isEmpty()) {
            logger.warn("LLM returned empty code for command: {}", command);
            return "Error: Could not generate code for command";
        }
        
        logger.debug("Generated code: {}", code);
        
        // Execute the generated code
        try {
            Object result = executeGeneratedCode(code);
            return "Command executed successfully" + (result != null ? ": " + result : "");
        } catch (Exception e) {
            logger.error("Error executing generated code", e);
            return "Error executing command: " + e.getMessage();
        }
    }
    
    /**
     * Process a natural language command using regex patterns
     * @param command Natural language command
     * @return Result of the command execution
     */
    private String processWithPatterns(String command) {
        logger.debug("Processing command with patterns: {}", command);
        
        // Try to match navigate pattern
        Matcher navigateMatcher = NAVIGATE_PATTERN.matcher(command);
        if (navigateMatcher.find()) {
            String url = navigateMatcher.group(1);
            logger.info("Navigating to URL: {}", url);
            page.navigate(url);
            return "Navigated to " + url;
        }
        
        // Try to match click pattern
        Matcher clickMatcher = CLICK_PATTERN.matcher(command);
        if (clickMatcher.find()) {
            String element = clickMatcher.group(1).trim();
            logger.info("Clicking on element: {}", element);
            
            // Try different selector strategies
            Locator locator = findElement(element);
            if (locator != null) {
                locator.click();
                return "Clicked on " + element;
            } else {
                return "Error: Could not find element " + element;
            }
        }
        
        // Try to match type pattern
        Matcher typeMatcher = TYPE_PATTERN.matcher(command);
        if (typeMatcher.find()) {
            String text = typeMatcher.group(1);
            String element = typeMatcher.group(2).trim();
            logger.info("Typing '{}' into element: {}", text, element);
            
            // Try different selector strategies
            Locator locator = findElement(element);
            if (locator != null) {
                locator.fill(text);
                return "Typed '" + text + "' into " + element;
            } else {
                return "Error: Could not find element " + element;
            }
        }
        
        return "Error: Could not understand command";
    }
    
    /**
     * Find an element based on natural language description
     * @param description Natural language description of the element
     * @return Playwright Locator for the element or null if not found
     */
    private Locator findElement(String description) {
        logger.debug("Finding element: {}", description);
        
        // Try to find by text first
        try {
            Locator byText = page.getByText(description);
            if (byText.count() > 0) {
                return byText.first();
            }
        } catch (Exception e) {
            logger.debug("Error finding element by text", e);
        }
        
        // Try to find by role and name
        try {
            // In Playwright 1.39.0, we need to use proper AriaRole enums
            Locator byRole = page.getByRole(com.microsoft.playwright.options.AriaRole.valueOf(guessRole(description).toUpperCase()), 
                                           new Page.GetByRoleOptions().setName(description));
            if (byRole.count() > 0) {
                return byRole.first();
            }
        } catch (Exception e) {
            logger.debug("Error finding element by role", e);
        }
        
        // Try to find by placeholder
        try {
            Locator byPlaceholder = page.getByPlaceholder(description);
            if (byPlaceholder.count() > 0) {
                return byPlaceholder.first();
            }
        } catch (Exception e) {
            logger.debug("Error finding element by placeholder", e);
        }
        
        // Try to find by label
        try {
            Locator byLabel = page.getByLabel(description);
            if (byLabel.count() > 0) {
                return byLabel.first();
            }
        } catch (Exception e) {
            logger.debug("Error finding element by label", e);
        }
        
        // If LLM is available, try to get selector suggestions
        if (llmClient != null && llmClient.isInitialized()) {
            try {
                String html = page.content();
                List<String> selectors = llmClient.suggestSelectors(description, html);
                
                for (String selector : selectors) {
                    try {
                        Locator locator = page.locator(selector);
                        if (locator.count() > 0) {
                            logger.info("Found element using LLM-suggested selector: {}", selector);
                            return locator.first();
                        }
                    } catch (Exception e) {
                        logger.debug("Error with suggested selector: {}", selector, e);
                    }
                }
            } catch (Exception e) {
                logger.debug("Error getting selector suggestions from LLM", e);
            }
        }
        
        return null;
    }
    
    /**
     * Guess the role of an element based on its description
     * @param description Natural language description of the element
     * @return Playwright AriaRole as string
     */
    private String guessRole(String description) {
        String desc = description.toLowerCase();
        
        if (desc.contains("button") || desc.contains("btn") || 
                desc.contains("submit") || desc.contains("ok") || 
                desc.contains("cancel") || desc.contains("close")) {
            return "BUTTON";
        } else if (desc.contains("link") || desc.contains("anchor")) {
            return "LINK";
        } else if (desc.contains("checkbox") || desc.contains("check box")) {
            return "CHECKBOX";
        } else if (desc.contains("radio") || desc.contains("option")) {
            return "RADIO";
        } else if (desc.contains("textbox") || desc.contains("text box") || 
                desc.contains("input") || desc.contains("field")) {
            return "TEXTBOX";
        } else if (desc.contains("dropdown") || desc.contains("drop down") || 
                desc.contains("select") || desc.contains("combobox")) {
            return "COMBOBOX";
        } else if (desc.contains("tab")) {
            return "TAB";
        } else if (desc.contains("menu")) {
            return "MENU";
        } else if (desc.contains("image") || desc.contains("img") || 
                desc.contains("icon")) {
            return "IMG";
        } else {
            return "BUTTON"; // Default to BUTTON as a fallback
        }
    }
    
    /**
     * Execute generated JavaScript code on the page
     * @param code The JavaScript code to execute
     * @return Result of the execution
     */
    private Object executeGeneratedCode(String code) {
        logger.debug("Executing generated code");
        
        // Check if the code is JavaScript
        if (code.contains("page.evaluate") || code.startsWith("function") || 
                code.contains("document.") || code.contains("window.")) {
            
            // Extract the JavaScript part if it's wrapped in page.evaluate
            String jsCode = code;
            if (code.contains("page.evaluate(")) {
                Pattern pattern = Pattern.compile("page\\.evaluate\\(([^)]+)\\)");
                Matcher matcher = pattern.matcher(code);
                if (matcher.find()) {
                    jsCode = matcher.group(1);
                }
            }
            
            // Execute the JavaScript
            return page.evaluate(jsCode);
        } else {
            // For Java code, we would need to compile and execute it dynamically
            // This is complex and potentially risky, so we'll just log the code for now
            logger.info("Would execute Java code: {}", code);
            
            // In a more complete implementation, we could use reflection or a script engine
            // to execute the Java code, but that's beyond the scope of this example
            
            return "Java code execution not implemented";
        }
    }
    
    /**
     * Execute a list of natural language test steps
     * @param steps List of natural language test steps
     * @return List of results for each step
     */
    public List<String> executeTestSteps(List<String> steps) {
        logger.info("Executing {} natural language test steps", steps.size());
        
        List<String> results = new java.util.ArrayList<>();
        
        for (String step : steps) {
            logger.info("Executing step: {}", step);
            String result = processCommand(step);
            results.add(result);
            
            // If a step fails, we may want to stop execution
            if (result.startsWith("Error:") && 
                    config.getBooleanProperty("stop.on.error", true)) {
                logger.warn("Stopping test execution due to error: {}", result);
                break;
            }
        }
        
        return results;
    }
}
