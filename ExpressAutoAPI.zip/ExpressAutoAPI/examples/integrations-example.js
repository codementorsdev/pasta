/**
 * DB-API Framework - Integration Examples
 * 
 * This file demonstrates how to set up integrations with:
 * - Email services (SendGrid, Mailgun)
 * - Payment processors (Stripe, PayPal)
 * - Messaging platforms (Slack, Discord)
 * - Analytics services (Google Analytics, Mixpanel)
 * - CRM systems (Salesforce, HubSpot)
 */

const { DBAPIFramework } = require('../server/framework');

async function setupIntegrations() {
  const framework = new DBAPIFramework('./config.yaml');
  await framework.initialize();
  
  const integrations = framework.getIntegrationManager();

  // 1. EMAIL SERVICE INTEGRATIONS

  // SendGrid email notifications
  integrations.addIntegration({
    name: 'sendgrid_notifications',
    type: 'webhook',
    enabled: true,
    config: {
      url: 'https://api.sendgrid.com/v3/mail/send',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.SENDGRID_API_KEY}`,
        'Content-Type': 'application/json'
      }
    },
    triggers: [
      { event: 'create', table: 'users' },
      { event: 'create', table: 'orders' },
      { event: 'update', table: 'orders', conditions: { status: 'completed' } }
    ],
    transformations: [
      { source_field: 'email', target_field: 'personalizations.0.to.0.email' },
      { source_field: 'name', target_field: 'personalizations.0.to.0.name' }
    ]
  });

  // 2. PAYMENT PROCESSOR INTEGRATIONS

  // Stripe payment processing
  integrations.addIntegration({
    name: 'stripe_payments',
    type: 'api',
    enabled: true,
    config: {
      base_url: 'https://api.stripe.com/v1',
      authentication: {
        type: 'bearer',
        credentials: { token: process.env.STRIPE_SECRET_KEY }
      },
      endpoints: {
        create_orders: {
          path: '/payment_intents',
          method: 'POST',
          mapping: {
            'total': 'amount',
            'user_id': 'metadata.customer_id',
            'id': 'metadata.order_id'
          }
        },
        update_orders: {
          path: '/payment_intents/{payment_intent_id}',
          method: 'POST',
          mapping: {
            'status': 'metadata.order_status'
          }
        }
      }
    },
    triggers: [
      { event: 'create', table: 'orders' },
      { event: 'update', table: 'orders' }
    ]
  });

  // 3. MESSAGING PLATFORM INTEGRATIONS

  // Slack notifications for important events
  integrations.addIntegration({
    name: 'slack_alerts',
    type: 'webhook',
    enabled: true,
    config: {
      url: process.env.SLACK_WEBHOOK_URL,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    },
    triggers: [
      { event: 'create', table: 'orders' },
      { event: 'update', table: 'orders', conditions: { status: 'completed' } }
    ]
  });

  // 4. ANALYTICS SERVICE INTEGRATIONS

  // Google Analytics event tracking
  integrations.addIntegration({
    name: 'google_analytics',
    type: 'webhook',
    enabled: true,
    config: {
      url: 'https://www.google-analytics.com/mp/collect',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    },
    triggers: [
      { event: 'create', table: 'orders' },
      { event: 'create', table: 'users' }
    ]
  });

  // 5. CRM INTEGRATIONS

  // HubSpot contact and deal sync
  integrations.addIntegration({
    name: 'hubspot_sync',
    type: 'api',
    enabled: true,
    config: {
      base_url: 'https://api.hubapi.com',
      authentication: {
        type: 'bearer',
        credentials: { token: process.env.HUBSPOT_API_KEY }
      },
      endpoints: {
        create_users: {
          path: '/crm/v3/objects/contacts',
          method: 'POST',
          mapping: {
            'email': 'properties.email',
            'name': 'properties.firstname',
            'username': 'properties.lastname'
          }
        },
        create_orders: {
          path: '/crm/v3/objects/deals',
          method: 'POST',
          mapping: {
            'total': 'properties.amount',
            'status': 'properties.dealstage',
            'user_id': 'associations.contacts'
          }
        }
      }
    },
    triggers: [
      { event: 'create', table: 'users' },
      { event: 'create', table: 'orders' }
    ]
  });

  // 6. INVENTORY MANAGEMENT INTEGRATIONS

  // Shopify inventory sync
  integrations.addIntegration({
    name: 'shopify_inventory',
    type: 'api',
    enabled: true,
    config: {
      base_url: `https://${process.env.SHOPIFY_SHOP_DOMAIN}.myshopify.com/admin/api/2023-01`,
      authentication: {
        type: 'api_key',
        credentials: { 
          header: 'X-Shopify-Access-Token',
          key: process.env.SHOPIFY_ACCESS_TOKEN 
        }
      },
      endpoints: {
        update_products: {
          path: '/products/{product_id}/variants/{variant_id}.json',
          method: 'PUT',
          mapping: {
            'stock': 'variant.inventory_quantity',
            'price': 'variant.price'
          }
        }
      }
    },
    triggers: [
      { event: 'update', table: 'products' }
    ]
  });

  // 7. CUSTOM WEBHOOK INTEGRATIONS

  // Custom order processing webhook
  integrations.addIntegration({
    name: 'order_processing',
    type: 'webhook',
    enabled: true,
    config: {
      url: process.env.ORDER_PROCESSING_WEBHOOK,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': process.env.ORDER_PROCESSING_API_KEY
      },
      retry_policy: {
        max_attempts: 3,
        delay_ms: 1000,
        exponential_backoff: true
      }
    },
    triggers: [
      { event: 'create', table: 'orders' },
      { event: 'update', table: 'orders' }
    ],
    transformations: [
      { source_field: 'id', target_field: 'order_id' },
      { source_field: 'total', target_field: 'amount' },
      { source_field: 'user_id', target_field: 'customer_id' },
      { source_field: 'status', target_field: 'order_status' }
    ]
  });

  // 8. REAL-TIME ANALYTICS INTEGRATION

  // Mixpanel event tracking
  integrations.addIntegration({
    name: 'mixpanel_analytics',
    type: 'webhook',
    enabled: true,
    config: {
      url: 'https://api.mixpanel.com/track',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    },
    triggers: [
      { event: 'create', table: 'users' },
      { event: 'create', table: 'orders' },
      { event: 'update', table: 'orders', conditions: { status: 'completed' } }
    ]
  });

  // 9. FILE STORAGE INTEGRATIONS

  // AWS S3 for file uploads
  integrations.addIntegration({
    name: 'aws_s3_storage',
    type: 'api',
    enabled: true,
    config: {
      base_url: `https://s3.${process.env.AWS_REGION}.amazonaws.com`,
      authentication: {
        type: 'custom',
        credentials: {
          access_key: process.env.AWS_ACCESS_KEY_ID,
          secret_key: process.env.AWS_SECRET_ACCESS_KEY
        }
      }
    },
    triggers: [
      { event: 'create', table: 'products' },
      { event: 'update', table: 'products' }
    ]
  });

  // 10. MONITORING AND LOGGING INTEGRATIONS

  // Datadog logging
  integrations.addIntegration({
    name: 'datadog_logging',
    type: 'webhook',
    enabled: true,
    config: {
      url: `https://http-intake.logs.datadoghq.com/v1/input/${process.env.DATADOG_API_KEY}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'DD-API-KEY': process.env.DATADOG_API_KEY
      }
    },
    triggers: [
      { event: 'create', table: 'orders' },
      { event: 'update', table: 'orders' },
      { event: 'delete', table: 'orders' }
    ]
  });

  console.log('✅ All integrations configured successfully');
  
  // Setup built-in integrations with environment variables
  if (process.env.SLACK_WEBHOOK_URL) {
    integrations.setupSlackIntegration(process.env.SLACK_WEBHOOK_URL);
  }
  
  if (process.env.STRIPE_SECRET_KEY) {
    integrations.setupStripeIntegration(process.env.STRIPE_SECRET_KEY);
  }

  return framework;
}

// Configuration helper for common integrations
function getIntegrationConfig(service) {
  const configs = {
    sendgrid: {
      name: 'sendgrid_emails',
      type: 'webhook',
      config: {
        url: 'https://api.sendgrid.com/v3/mail/send',
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.SENDGRID_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    },
    
    stripe: {
      name: 'stripe_payments',
      type: 'api',
      config: {
        base_url: 'https://api.stripe.com/v1',
        authentication: {
          type: 'bearer',
          credentials: { token: process.env.STRIPE_SECRET_KEY }
        }
      }
    },
    
    slack: {
      name: 'slack_notifications',
      type: 'webhook',
      config: {
        url: process.env.SLACK_WEBHOOK_URL,
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      }
    }
  };

  return configs[service];
}

// Example usage
if (require.main === module) {
  setupIntegrations().then(framework => {
    const app = framework.getApp();
    app.listen(5000, () => {
      console.log('🚀 Server running on port 5000 with integrations');
      console.log('🔗 Integrations active:', 
        framework.getIntegrationManager().getIntegrations().length);
    });
  });
}

module.exports = { 
  setupIntegrations, 
  getIntegrationConfig 
};