/**
 * DB-API Framework - Custom Endpoints Examples
 * 
 * This file demonstrates how to create custom endpoints for:
 * - Business logic
 * - Data aggregation
 * - Analytics
 * - Data transformations
 * - Third-party integrations
 */

const { DBAPIFramework } = require('../server/framework');

async function setupCustomEndpoints() {
  // Initialize the framework
  const framework = new DBAPIFramework('./config.yaml');
  await framework.initialize();
  
  const customEndpoints = framework.getCustomEndpointManager();
  const integrations = framework.getIntegrationManager();

  // 1. BUSINESS LOGIC ENDPOINTS
  
  // Customer lifetime value calculation
  customEndpoints.addEndpoint({
    path: '/business/customer-ltv/:userId',
    method: 'GET',
    description: 'Calculate customer lifetime value',
    handler: async (req, res, context) => {
      const { userId } = req.params;
      const { period_months = 12 } = req.query;

      const customerData = await context.db.raw(`
        SELECT 
          u.id,
          u.username,
          u.created_at as customer_since,
          COUNT(o.id) as total_orders,
          SUM(o.total) as total_spent,
          AVG(o.total) as avg_order_value,
          MIN(o.created_at) as first_order,
          MAX(o.created_at) as last_order
        FROM users u
        LEFT JOIN orders o ON u.id = o.user_id
        WHERE u.id = ?
        GROUP BY u.id, u.username, u.created_at
      `, [userId]);

      const customer = customerData.rows[0];
      
      if (!customer) {
        return res.status(404).json({ error: 'Customer not found' });
      }

      // Calculate LTV based on historical data
      const monthlySpend = customer.total_spent / period_months;
      const ltv = monthlySpend * 36; // 3 year projection
      
      res.json({
        customer_id: customer.id,
        username: customer.username,
        metrics: {
          total_orders: customer.total_orders,
          total_spent: customer.total_spent,
          avg_order_value: customer.avg_order_value,
          monthly_spend_avg: monthlySpend,
          projected_ltv: ltv,
          customer_since: customer.customer_since,
          last_order: customer.last_order
        }
      });
    }
  });

  // Inventory management with business rules
  customEndpoints.addEndpoint({
    path: '/business/inventory/reorder-alerts',
    method: 'GET',
    description: 'Get products that need reordering based on business rules',
    handler: async (req, res, context) => {
      const { threshold_days = 7 } = req.query;

      const results = await context.db.raw(`
        WITH sales_velocity AS (
          SELECT 
            p.id,
            p.name,
            p.stock,
            COUNT(oi.id) as units_sold_30d,
            COUNT(oi.id) / 30.0 as daily_velocity
          FROM products p
          LEFT JOIN order_items oi ON p.id = oi.product_id
          LEFT JOIN orders o ON oi.order_id = o.id
          WHERE o.created_at >= CURRENT_DATE - INTERVAL '30 days'
          GROUP BY p.id, p.name, p.stock
        )
        SELECT 
          *,
          CASE 
            WHEN daily_velocity > 0 THEN stock / daily_velocity
            ELSE 999
          END as days_until_stockout,
          daily_velocity * ? as reorder_quantity
        FROM sales_velocity
        WHERE stock / NULLIF(daily_velocity, 0) <= ?
        ORDER BY days_until_stockout
      `, [threshold_days * 2, threshold_days]);

      res.json({
        reorder_alerts: results.rows,
        alert_criteria: {
          threshold_days,
          evaluation_period: '30 days'
        }
      });
    }
  });

  // 2. ADVANCED ANALYTICS ENDPOINTS
  
  // Customer segmentation based on RFM analysis
  customEndpoints.addEndpoint({
    path: '/analytics/customer-segments',
    method: 'GET',
    description: 'RFM (Recency, Frequency, Monetary) customer segmentation',
    handler: async (req, res, context) => {
      const rfmData = await context.db.raw(`
        WITH customer_rfm AS (
          SELECT 
            u.id,
            u.username,
            EXTRACT(DAYS FROM (CURRENT_DATE - MAX(o.created_at))) as recency,
            COUNT(o.id) as frequency,
            SUM(o.total) as monetary
          FROM users u
          LEFT JOIN orders o ON u.id = o.user_id
          WHERE o.created_at >= CURRENT_DATE - INTERVAL '12 months'
          GROUP BY u.id, u.username
        ),
        rfm_scores AS (
          SELECT *,
            CASE 
              WHEN recency <= 30 THEN 5
              WHEN recency <= 60 THEN 4
              WHEN recency <= 90 THEN 3
              WHEN recency <= 180 THEN 2
              ELSE 1
            END as r_score,
            CASE 
              WHEN frequency >= 10 THEN 5
              WHEN frequency >= 7 THEN 4
              WHEN frequency >= 4 THEN 3
              WHEN frequency >= 2 THEN 2
              ELSE 1
            END as f_score,
            CASE 
              WHEN monetary >= 1000 THEN 5
              WHEN monetary >= 500 THEN 4
              WHEN monetary >= 250 THEN 3
              WHEN monetary >= 100 THEN 2
              ELSE 1
            END as m_score
          FROM customer_rfm
        )
        SELECT *,
          CASE 
            WHEN r_score >= 4 AND f_score >= 4 AND m_score >= 4 THEN 'Champions'
            WHEN r_score >= 3 AND f_score >= 3 AND m_score >= 3 THEN 'Loyal Customers'
            WHEN r_score >= 4 AND f_score <= 2 THEN 'New Customers'
            WHEN r_score <= 2 AND f_score >= 3 THEN 'At Risk'
            WHEN r_score <= 2 AND f_score <= 2 THEN 'Lost Customers'
            ELSE 'Regular Customers'
          END as segment
        FROM rfm_scores
        ORDER BY r_score DESC, f_score DESC, m_score DESC
      `);

      // Group by segments for summary
      const segments = {};
      rfmData.rows.forEach(customer => {
        if (!segments[customer.segment]) {
          segments[customer.segment] = {
            count: 0,
            total_revenue: 0,
            avg_recency: 0,
            customers: []
          };
        }
        segments[customer.segment].count++;
        segments[customer.segment].total_revenue += customer.monetary;
        segments[customer.segment].customers.push({
          id: customer.id,
          username: customer.username,
          rfm_score: `${customer.r_score}${customer.f_score}${customer.m_score}`
        });
      });

      res.json({
        segments,
        total_customers: rfmData.rows.length,
        analysis_period: '12 months'
      });
    }
  });

  // 3. DATA TRANSFORMATION ENDPOINTS

  // Product catalog enrichment
  customEndpoints.addEndpoint({
    path: '/transform/product-catalog',
    method: 'POST',
    description: 'Enrich product catalog with calculated fields and formatting',
    handler: async (req, res, context) => {
      const { include_analytics = true } = req.body;

      const transformRules = [
        {
          field: 'name',
          operation: { type: 'format', function: 'capitalize' }
        },
        {
          field: 'price',
          operation: { type: 'format', function: 'currency', options: { currency: 'USD' } }
        },
        {
          field: 'description',
          operation: { type: 'map', function: 'truncate', parameters: { length: 100 } }
        }
      ];

      if (include_analytics) {
        transformRules.push({
          field: 'performance_score',
          operation: { 
            type: 'calculate', 
            function: 'custom',
            parameters: { 
              formula: '(stock * 0.3) + (price_tier * 0.7)'
            }
          }
        });
      }

      const transformedData = await context.transform.processData(
        'products', 
        transformRules
      );

      res.json({
        products: transformedData,
        transformations_applied: transformRules.length,
        include_analytics
      });
    }
  });

  // 4. INTEGRATION ENDPOINTS

  // Webhook endpoint for order fulfillment
  customEndpoints.addEndpoint({
    path: '/integrations/fulfill-order',
    method: 'POST',
    description: 'Process order fulfillment with external systems',
    handler: async (req, res, context) => {
      const { order_id, fulfillment_data } = req.body;

      try {
        // Update order status
        await context.db('orders')
          .where('id', order_id)
          .update({ 
            status: 'fulfilled',
            fulfillment_data: JSON.stringify(fulfillment_data)
          });

        // Trigger integrations
        const orderData = await context.db('orders')
          .where('id', order_id)
          .first();

        await integrations.triggerIntegrations('update', 'orders', orderData);

        res.json({
          success: true,
          order_id,
          status: 'fulfilled',
          message: 'Order fulfillment processed successfully'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    }
  });

  // Bulk data processing endpoint
  customEndpoints.addEndpoint({
    path: '/processing/bulk-update',
    method: 'POST',
    description: 'Process bulk updates with validation and rollback',
    handler: async (req, res, context) => {
      const { table, updates, validation_rules } = req.body;
      const trx = await context.db.transaction();

      try {
        const results = [];
        let processed = 0;
        let errors = 0;

        for (const update of updates) {
          try {
            // Apply validation if provided
            if (validation_rules) {
              // Basic validation logic
              for (const rule of validation_rules) {
                if (rule.required && !update.data[rule.field]) {
                  throw new Error(`Required field ${rule.field} is missing`);
                }
              }
            }

            // Process the update
            await trx(table)
              .where('id', update.id)
              .update(update.data);

            results.push({
              id: update.id,
              status: 'success'
            });
            processed++;

          } catch (error) {
            results.push({
              id: update.id,
              status: 'error',
              error: error.message
            });
            errors++;
          }
        }

        await trx.commit();

        res.json({
          summary: {
            total: updates.length,
            processed,
            errors
          },
          results
        });

      } catch (error) {
        await trx.rollback();
        res.status(500).json({
          error: 'Bulk update failed',
          message: error.message
        });
      }
    }
  });

  console.log('✅ Custom endpoints configured successfully');
  return framework;
}

// Example usage
if (require.main === module) {
  setupCustomEndpoints().then(framework => {
    const app = framework.getApp();
    app.listen(5000, () => {
      console.log('🚀 Server running on port 5000');
      console.log('📚 API docs: http://localhost:5000/docs');
      console.log('🎯 Custom endpoints: http://localhost:5000/api/custom/*');
    });
  });
}

module.exports = { setupCustomEndpoints };