const { BasePlugin } = require('db-api-framework');

/**
 * Analytics Plugin for DB-API Framework
 * 
 * This plugin demonstrates how to extend the framework with custom endpoints
 * for business intelligence and analytics functionality.
 */
class AnalyticsPlugin extends BasePlugin {
  constructor() {
    super('Analytics', '1.0.0');
  }

  /**
   * Initialize the plugin - called when the framework starts
   */
  async onInitialize() {
    console.log('🔌 Initializing Analytics Plugin...');
    
    // Add custom analytics endpoints
    this.addRoute('get', '/api/analytics/overview', this.getOverview.bind(this));
    this.addRoute('get', '/api/analytics/revenue', this.getRevenue.bind(this));
    this.addRoute('get', '/api/analytics/top-products', this.getTopProducts.bind(this));
    this.addRoute('get', '/api/analytics/user-stats', this.getUserStats.bind(this));
    this.addRoute('get', '/api/analytics/order-trends', this.getOrderTrends.bind(this));
    
    console.log('✅ Analytics Plugin initialized successfully');
  }

  /**
   * Get overview statistics
   */
  async getOverview(req, res) {
    try {
      const [
        totalUsers,
        totalOrders,
        totalProducts,
        totalRevenue
      ] = await Promise.all([
        this.getTotalCount('users'),
        this.getTotalCount('orders'),
        this.getTotalCount('products'),
        this.getTotalRevenue()
      ]);

      res.json({
        timestamp: new Date().toISOString(),
        overview: {
          totalUsers: totalUsers.count,
          totalOrders: totalOrders.count,
          totalProducts: totalProducts.count,
          totalRevenue: parseFloat(totalRevenue.sum) || 0,
        }
      });
    } catch (error) {
      console.error('Analytics overview error:', error);
      res.status(500).json({ error: 'Failed to fetch overview statistics' });
    }
  }

  /**
   * Get revenue analytics with date filtering
   */
  async getRevenue(req, res) {
    try {
      const { start_date, end_date, group_by = 'day' } = req.query;
      
      let dateFormat;
      switch (group_by) {
        case 'hour':
          dateFormat = '%Y-%m-%d %H:00:00';
          break;
        case 'day':
          dateFormat = '%Y-%m-%d';
          break;
        case 'week':
          dateFormat = '%Y-%u';
          break;
        case 'month':
          dateFormat = '%Y-%m';
          break;
        case 'year':
          dateFormat = '%Y';
          break;
        default:
          dateFormat = '%Y-%m-%d';
      }

      let query = `
        SELECT 
          DATE_FORMAT(created_at, '${dateFormat}') as period,
          SUM(total_amount) as revenue,
          COUNT(*) as order_count,
          AVG(total_amount) as avg_order_value
        FROM orders 
        WHERE status IN ('confirmed', 'processing', 'shipped', 'delivered')
      `;

      const params = [];
      
      if (start_date) {
        query += ' AND created_at >= ?';
        params.push(start_date);
      }
      
      if (end_date) {
        query += ' AND created_at <= ?';
        params.push(end_date);
      }
      
      query += ' GROUP BY period ORDER BY period DESC';

      const result = await this.query(query, params);
      
      res.json({
        timestamp: new Date().toISOString(),
        period: group_by,
        data: result.rows || result,
      });
    } catch (error) {
      console.error('Revenue analytics error:', error);
      res.status(500).json({ error: 'Failed to fetch revenue analytics' });
    }
  }

  /**
   * Get top performing products
   */
  async getTopProducts(req, res) {
    try {
      const { limit = 10, period_days = 30 } = req.query;
      
      const query = `
        SELECT 
          p.id,
          p.name,
          p.sku,
          p.price,
          SUM(oi.quantity) as total_sold,
          SUM(oi.total_price) as total_revenue,
          COUNT(DISTINCT oi.order_id) as order_count,
          AVG(r.rating) as avg_rating,
          COUNT(r.id) as review_count
        FROM products p
        LEFT JOIN order_items oi ON p.id = oi.product_id
        LEFT JOIN orders o ON oi.order_id = o.id
        LEFT JOIN reviews r ON p.id = r.product_id
        WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
          AND o.status IN ('confirmed', 'processing', 'shipped', 'delivered')
        GROUP BY p.id, p.name, p.sku, p.price
        ORDER BY total_sold DESC
        LIMIT ?
      `;

      const result = await this.query(query, [period_days, parseInt(limit)]);
      
      res.json({
        timestamp: new Date().toISOString(),
        period_days: parseInt(period_days),
        products: result.rows || result,
      });
    } catch (error) {
      console.error('Top products error:', error);
      res.status(500).json({ error: 'Failed to fetch top products' });
    }
  }

  /**
   * Get user statistics
   */
  async getUserStats(req, res) {
    try {
      const [
        newUsersToday,
        newUsersThisWeek,
        newUsersThisMonth,
        activeUsers,
        topCustomers
      ] = await Promise.all([
        this.getNewUsers(1),
        this.getNewUsers(7),
        this.getNewUsers(30),
        this.getActiveUsers(),
        this.getTopCustomers()
      ]);

      res.json({
        timestamp: new Date().toISOString(),
        userStats: {
          newUsersToday: newUsersToday.count,
          newUsersThisWeek: newUsersThisWeek.count,
          newUsersThisMonth: newUsersThisMonth.count,
          activeUsers: activeUsers.count,
          topCustomers: topCustomers.rows || topCustomers,
        }
      });
    } catch (error) {
      console.error('User stats error:', error);
      res.status(500).json({ error: 'Failed to fetch user statistics' });
    }
  }

  /**
   * Get order trends
   */
  async getOrderTrends(req, res) {
    try {
      const { days = 30 } = req.query;
      
      const query = `
        SELECT 
          DATE(created_at) as date,
          COUNT(*) as order_count,
          SUM(total_amount) as revenue,
          AVG(total_amount) as avg_order_value,
          COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders
        FROM orders 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
        GROUP BY DATE(created_at)
        ORDER BY date DESC
      `;

      const result = await this.query(query, [parseInt(days)]);
      
      res.json({
        timestamp: new Date().toISOString(),
        period_days: parseInt(days),
        trends: result.rows || result,
      });
    } catch (error) {
      console.error('Order trends error:', error);
      res.status(500).json({ error: 'Failed to fetch order trends' });
    }
  }

  // Helper methods
  async getTotalCount(table) {
    const result = await this.query(`SELECT COUNT(*) as count FROM ${table}`);
    return (result.rows && result.rows[0]) || result[0];
  }

  async getTotalRevenue() {
    const result = await this.query(`
      SELECT SUM(total_amount) as sum 
      FROM orders 
      WHERE status IN ('confirmed', 'processing', 'shipped', 'delivered')
    `);
    return (result.rows && result.rows[0]) || result[0];
  }

  async getNewUsers(days) {
    const result = await this.query(`
      SELECT COUNT(*) as count 
      FROM users 
      WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
    `, [days]);
    return (result.rows && result.rows[0]) || result[0];
  }

  async getActiveUsers() {
    const result = await this.query(`
      SELECT COUNT(DISTINCT user_id) as count 
      FROM orders 
      WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    `);
    return (result.rows && result.rows[0]) || result[0];
  }

  async getTopCustomers() {
    return await this.query(`
      SELECT 
        u.id,
        u.first_name,
        u.last_name,
        u.email,
        COUNT(o.id) as order_count,
        SUM(o.total_amount) as total_spent,
        MAX(o.created_at) as last_order_date
      FROM users u
      JOIN orders o ON u.id = o.user_id
      WHERE o.status IN ('confirmed', 'processing', 'shipped', 'delivered')
      GROUP BY u.id, u.first_name, u.last_name, u.email
      ORDER BY total_spent DESC
      LIMIT 10
    `);
  }
}

module.exports = AnalyticsPlugin;

// Example of how to use this plugin:
// 
// 1. Save this file as plugins/analytics.js
// 2. Add to your config.yaml:
//    plugins:
//      - name: analytics
//        path: ./plugins/analytics.js
//        enabled: true
// 3. Start your server: db-api start
// 4. Access analytics endpoints:
//    - GET /api/analytics/overview
//    - GET /api/analytics/revenue?start_date=2024-01-01&group_by=month
//    - GET /api/analytics/top-products?limit=5&period_days=7
//    - GET /api/analytics/user-stats
//    - GET /api/analytics/order-trends?days=14
