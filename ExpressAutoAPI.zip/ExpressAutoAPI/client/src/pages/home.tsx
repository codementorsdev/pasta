import Header from "@/components/header";
import Hero from "@/components/hero";
import Features from "@/components/features";
import Configuration from "@/components/configuration";
import ApiExplorer from "@/components/api-explorer";
import CustomEndpoints from "@/components/custom-endpoints";
import Performance from "@/components/performance";
import CTA from "@/components/cta";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      <Hero />
      <Features />
      <Configuration />
      <ApiExplorer />
      <CustomEndpoints />
      <Performance />
      <CTA />
      <Footer />
    </div>
  );
}
