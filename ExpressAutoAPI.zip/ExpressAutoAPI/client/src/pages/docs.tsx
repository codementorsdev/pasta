import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Code, Database, Settings, Zap } from "lucide-react";

export default function Docs() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Documentation
          </h1>
          <p className="text-xl text-slate-600">
            Everything you need to get started with DB-API Framework
          </p>
        </div>

        <Tabs defaultValue="quickstart" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="quickstart">Quick Start</TabsTrigger>
            <TabsTrigger value="configuration">Configuration</TabsTrigger>
            <TabsTrigger value="api">API Reference</TabsTrigger>
            <TabsTrigger value="plugins">Plugins</TabsTrigger>
          </TabsList>

          <TabsContent value="quickstart" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-primary-600" />
                  Getting Started
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Installation</h3>
                  <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm text-slate-300">
                    <div className="text-emerald-400">$ npm install -g db-api-framework</div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Initialize Project</h3>
                  <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm text-slate-300">
                    <div className="text-emerald-400">$ db-api init</div>
                    <div className="text-slate-400 mt-2">✅ Created sample configuration: config.yaml</div>
                    <div className="text-slate-400">✅ Created plugins directory</div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-2">Start Server</h3>
                  <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm text-slate-300">
                    <div className="text-emerald-400">$ db-api start</div>
                    <div className="text-slate-400 mt-2">🚀 Server running on http://localhost:3000</div>
                    <div className="text-slate-400">📚 API docs available at http://localhost:3000/docs</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="configuration" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-primary-600" />
                  Configuration Reference
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Database Configuration</h3>
                  <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm">
                    <div className="space-y-1 text-slate-300">
                      <div><span className="text-blue-400">database:</span></div>
                      <div className="ml-4"><span className="text-yellow-400">type:</span> <span className="text-green-400">postgres</span> <span className="text-slate-500"># postgres, mysql, sqlite, mssql, oracle</span></div>
                      <div className="ml-4"><span className="text-yellow-400">host:</span> <span className="text-green-400">localhost</span></div>
                      <div className="ml-4"><span className="text-yellow-400">port:</span> <span className="text-orange-400">5432</span></div>
                      <div className="ml-4"><span className="text-yellow-400">user:</span> <span className="text-green-400">admin</span></div>
                      <div className="ml-4"><span className="text-yellow-400">password:</span> <span className="text-green-400">password</span></div>
                      <div className="ml-4"><span className="text-yellow-400">database:</span> <span className="text-green-400">ecommerce</span></div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Access Control</h3>
                  <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm">
                    <div className="space-y-1 text-slate-300">
                      <div><span className="text-blue-400">accessControl:</span></div>
                      <div className="ml-4"><span className="text-yellow-400">whitelistTables:</span> <span className="text-slate-400">[</span><span className="text-green-400">"users", "orders", "products"</span><span className="text-slate-400">]</span></div>
                      <div className="ml-4"><span className="text-yellow-400">operations:</span></div>
                      <div className="ml-8"><span className="text-yellow-400">users:</span> <span className="text-slate-400">[</span><span className="text-green-400">"GET", "POST"</span><span className="text-slate-400">]</span></div>
                      <div className="ml-8"><span className="text-yellow-400">orders:</span> <span className="text-slate-400">[</span><span className="text-green-400">"GET"</span><span className="text-slate-400">]</span></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="w-5 h-5 text-primary-600" />
                  API Endpoints
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                    <div className="flex items-center space-x-4">
                      <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">GET</Badge>
                      <code className="text-sm">/api/{"{table}"}</code>
                    </div>
                    <span className="text-sm text-slate-600">List all records</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                    <div className="flex items-center space-x-4">
                      <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">GET</Badge>
                      <code className="text-sm">/api/{"{table}"}/{"{id}"}</code>
                    </div>
                    <span className="text-sm text-slate-600">Get record by ID</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                    <div className="flex items-center space-x-4">
                      <Badge variant="secondary" className="bg-blue-100 text-blue-700">POST</Badge>
                      <code className="text-sm">/api/{"{table}"}</code>
                    </div>
                    <span className="text-sm text-slate-600">Create new record</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                    <div className="flex items-center space-x-4">
                      <Badge variant="secondary" className="bg-amber-100 text-amber-700">PUT</Badge>
                      <code className="text-sm">/api/{"{table}"}/{"{id}"}</code>
                    </div>
                    <span className="text-sm text-slate-600">Update record</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border">
                    <div className="flex items-center space-x-4">
                      <Badge variant="secondary" className="bg-red-100 text-red-700">DELETE</Badge>
                      <code className="text-sm">/api/{"{table}"}/{"{id}"}</code>
                    </div>
                    <span className="text-sm text-slate-600">Delete record</span>
                  </div>
                </div>

                <div className="mt-6">
                  <h4 className="font-semibold mb-3">Query Parameters</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between py-2 border-b border-slate-100">
                      <code className="text-sm text-primary-600">limit</code>
                      <span className="text-sm text-slate-600">Number of records to return</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-slate-100">
                      <code className="text-sm text-primary-600">offset</code>
                      <span className="text-sm text-slate-600">Number of records to skip</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-slate-100">
                      <code className="text-sm text-primary-600">sort</code>
                      <span className="text-sm text-slate-600">Sort fields (comma-separated)</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-slate-100">
                      <code className="text-sm text-primary-600">include</code>
                      <span className="text-sm text-slate-600">Related resources to include</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="plugins" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="w-5 h-5 text-primary-600" />
                  Plugin Development
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Creating a Plugin</h3>
                  <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm">
                    <div className="space-y-1 text-slate-300">
                      <div><span className="text-purple-400">const</span> {"{"} <span className="text-blue-400">BasePlugin</span> {"}"} = <span className="text-emerald-400">require</span>(<span className="text-green-400">'db-api-framework'</span>);</div>
                      <div className="mt-4"><span className="text-purple-400">class</span> <span className="text-yellow-400">MyPlugin</span> <span className="text-purple-400">extends</span> <span className="text-blue-400">BasePlugin</span> {"{"}</div>
                      <div className="ml-4"><span className="text-purple-400">constructor</span>() {"{"}</div>
                      <div className="ml-8"><span className="text-purple-400">super</span>(<span className="text-green-400">'MyPlugin'</span>, <span className="text-green-400">'1.0.0'</span>);</div>
                      <div className="ml-4">{"}"}</div>
                      <div className="mt-4 ml-4"><span className="text-purple-400">async</span> <span className="text-blue-400">onInitialize</span>() {"{"}</div>
                      <div className="ml-8"><span className="text-purple-400">this</span>.<span className="text-blue-400">addRoute</span>(<span className="text-green-400">'get'</span>, <span className="text-green-400">'/api/custom'</span>, <span className="text-purple-400">this</span>.<span className="text-blue-400">handler</span>);</div>
                      <div className="ml-4">{"}"}</div>
                      <div className="mt-4 ml-4"><span className="text-blue-400">handler</span>(<span className="text-orange-400">req</span>, <span className="text-orange-400">res</span>) {"{"}</div>
                      <div className="ml-8"><span className="text-orange-400">res</span>.<span className="text-blue-400">json</span>({"{"} <span className="text-yellow-400">message</span>: <span className="text-green-400">'Hello from plugin!'</span> {"}"});</div>
                      <div className="ml-4">{"}"}</div>
                      <div>{"}"}</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Plugin Configuration</h3>
                  <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm">
                    <div className="space-y-1 text-slate-300">
                      <div><span className="text-blue-400">plugins:</span></div>
                      <div className="ml-4">- <span className="text-yellow-400">name:</span> <span className="text-green-400">my-plugin</span></div>
                      <div className="ml-6"><span className="text-yellow-400">path:</span> <span className="text-green-400">./plugins/my-plugin.js</span></div>
                      <div className="ml-6"><span className="text-yellow-400">enabled:</span> <span className="text-orange-400">true</span></div>
                      <div className="ml-6"><span className="text-yellow-400">options:</span></div>
                      <div className="ml-8"><span className="text-yellow-400">customOption:</span> <span className="text-green-400">value</span></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  );
}
