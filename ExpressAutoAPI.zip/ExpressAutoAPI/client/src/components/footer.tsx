import { Database } from "lucide-react";

const footerSections = [
  {
    title: "Documentation",
    links: [
      { name: "Quick Start", href: "#" },
      { name: "Configuration", href: "#" },
      { name: "API Reference", href: "#" },
      { name: "Examples", href: "#" },
    ]
  },
  {
    title: "Community",
    links: [
      { name: "GitHub", href: "#" },
      { name: "Discord", href: "#" },
      { name: "Stack Overflow", href: "#" },
      { name: "Twitter", href: "#" },
    ]
  },
  {
    title: "Resources",
    links: [
      { name: "Changelog", href: "#" },
      { name: "Contributing", href: "#" },
      { name: "License", href: "#" },
      { name: "Security", href: "#" },
    ]
  },
];

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Database className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-white">DB-API Framework</span>
            </div>
            <p className="text-slate-400 text-sm">
              Auto-generate production-ready REST APIs from any relational database.
            </p>
          </div>
          
          {footerSections.map((section, index) => (
            <div key={index}>
              <h4 className="font-semibold text-white mb-4">{section.title}</h4>
              <ul className="space-y-2 text-sm">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a href={link.href} className="hover:text-white transition-colors">
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        <div className="border-t border-slate-800 mt-8 pt-8 text-center text-sm text-slate-400">
          <p>&copy; 2024 DB-API Framework. Released under MIT License.</p>
        </div>
      </div>
    </footer>
  );
}
