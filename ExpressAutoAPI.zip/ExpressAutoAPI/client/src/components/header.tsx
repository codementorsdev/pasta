import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Database, Menu, X, Github } from "lucide-react";

export default function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <div className="flex items-center space-x-2 cursor-pointer">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Database className="w-4 h-4 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold text-slate-900">DB-API Framework</span>
              </div>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/#features">
              <a className="text-slate-600 hover:text-slate-900 font-medium">Features</a>
            </Link>
            <Link href="/docs">
              <a className={`font-medium ${location === '/docs' ? 'text-slate-900' : 'text-slate-600 hover:text-slate-900'}`}>
                Documentation
              </a>
            </Link>
            <Link href="/#examples">
              <a className="text-slate-600 hover:text-slate-900 font-medium">Examples</a>
            </Link>
            <a 
              href="https://github.com" 
              className="text-slate-600 hover:text-slate-900 font-medium flex items-center"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Github className="w-4 h-4 mr-2" />
              GitHub
            </a>
            <Button className="bg-primary hover:bg-primary/90">
              Get Started
            </Button>
          </div>
          
          <button 
            className="md:hidden text-slate-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-slate-200">
            <div className="flex flex-col space-y-4">
              <Link href="/#features">
                <a className="text-slate-600 hover:text-slate-900 font-medium">Features</a>
              </Link>
              <Link href="/docs">
                <a className="text-slate-600 hover:text-slate-900 font-medium">Documentation</a>
              </Link>
              <Link href="/#examples">
                <a className="text-slate-600 hover:text-slate-900 font-medium">Examples</a>
              </Link>
              <a 
                href="https://github.com" 
                className="text-slate-600 hover:text-slate-900 font-medium flex items-center"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Github className="w-4 h-4 mr-2" />
                GitHub
              </a>
              <Button className="bg-primary hover:bg-primary/90 w-fit">
                Get Started
              </Button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
