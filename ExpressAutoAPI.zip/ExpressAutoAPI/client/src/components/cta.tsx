import { Button } from "@/components/ui/button";
import { Download, Github } from "lucide-react";

export default function CTA() {
  return (
    <section className="py-20 bg-gradient-to-r from-primary to-primary/80">
      <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-white mb-6">Ready to Transform Your Database into APIs?</h2>
        <p className="text-xl text-primary-foreground/90 mb-8">
          Join thousands of developers who've accelerated their API development with DB-API Framework
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-white text-primary hover:bg-primary-50">
            <Download className="w-4 h-4 mr-2" />
            Install Now
          </Button>
          <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
            <Github className="w-4 h-4 mr-2" />
            View Documentation
          </Button>
        </div>
        <div className="mt-8 text-primary-foreground/80">
          <p className="text-sm font-mono">npm install -g db-api-framework</p>
        </div>
      </div>
    </section>
  );
}
