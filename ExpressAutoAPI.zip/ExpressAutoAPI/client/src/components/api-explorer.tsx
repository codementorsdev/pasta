import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play } from "lucide-react";

const endpoints = [
  { method: "GET", path: "/api/users", description: "List users", active: true },
  { method: "POST", path: "/api/users", description: "Create user", active: false },
  { method: "GET", path: "/api/orders", description: "List orders", active: false },
  { method: "GET", path: "/api/products", description: "List products", active: false },
];

const queryParams = [
  { name: "limit", type: "integer", description: "Number of records to return (max: 100)" },
  { name: "offset", type: "integer", description: "Number of records to skip" },
  { name: "sort", type: "string", description: "Sort field (created_at, name)" },
];

export default function ApiExplorer() {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <section id="docs" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Interactive API Documentation</h2>
          <p className="text-xl text-slate-600">Auto-generated Swagger docs with live API testing</p>
        </div>

        <div className="bg-slate-50 rounded-xl p-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <h4 className="font-semibold text-slate-900 mb-4">Endpoints</h4>
              <div className="space-y-2">
                {endpoints.map((endpoint, index) => (
                  <Card key={index} className={`border-l-4 ${endpoint.active ? 'border-l-emerald-500 bg-white' : 'border-l-slate-200 bg-slate-100'}`}>
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-sm text-slate-700">{endpoint.path}</span>
                        <Badge 
                          variant="secondary" 
                          className={endpoint.method === 'GET' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}
                        >
                          {endpoint.method}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-2">
              <Card className="border border-slate-200">
                {/* Tabs */}
                <div className="border-b border-slate-200">
                  <div className="flex">
                    {["overview", "parameters", "response"].map((tab) => (
                      <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`px-6 py-3 font-medium capitalize ${
                          activeTab === tab
                            ? "border-b-2 border-primary text-primary"
                            : "text-slate-600 hover:text-slate-900"
                        }`}
                      >
                        {tab}
                      </button>
                    ))}
                  </div>
                </div>

                <CardContent className="p-6">
                  {activeTab === "overview" && (
                    <div>
                      <div className="mb-6">
                        <h3 className="text-xl font-bold text-slate-900 mb-2">GET /api/users</h3>
                        <p className="text-slate-600">Retrieve a paginated list of users with optional filtering and sorting.</p>
                      </div>
                    </div>
                  )}

                  {activeTab === "parameters" && (
                    <div>
                      <h4 className="font-semibold text-slate-900 mb-3">Query Parameters</h4>
                      <div className="space-y-3">
                        {queryParams.map((param, index) => (
                          <div key={index} className="flex items-center justify-between py-2 border-b border-slate-100">
                            <div>
                              <span className="font-mono text-sm text-primary">{param.name}</span>
                              <span className="text-slate-400 ml-2">{param.type}</span>
                            </div>
                            <span className="text-sm text-slate-600">{param.description}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === "response" && (
                    <div>
                      <h4 className="font-semibold text-slate-900 mb-3">Example Response</h4>
                      <Card className="bg-slate-900 border-0">
                        <CardContent className="p-4 font-mono text-sm">
                          <div className="text-slate-300">
                            <div>{"{"}</div>
                            <div className="ml-2"><span className="text-blue-400">"data"</span>: [</div>
                            <div className="ml-4">{"{"}</div>
                            <div className="ml-6"><span className="text-blue-400">"id"</span>: <span className="text-orange-400">1</span>,</div>
                            <div className="ml-6"><span className="text-blue-400">"name"</span>: <span className="text-green-400">"John Doe"</span>,</div>
                            <div className="ml-6"><span className="text-blue-400">"email"</span>: <span className="text-green-400">"john@example.com"</span>,</div>
                            <div className="ml-6"><span className="text-blue-400">"created_at"</span>: <span className="text-green-400">"2024-01-15T10:30:00Z"</span></div>
                            <div className="ml-4">{"}"}</div>
                            <div className="ml-2">],</div>
                            <div className="ml-2"><span className="text-blue-400">"pagination"</span>: {"{"}</div>
                            <div className="ml-4"><span className="text-blue-400">"total"</span>: <span className="text-orange-400">142</span>,</div>
                            <div className="ml-4"><span className="text-blue-400">"limit"</span>: <span className="text-orange-400">25</span>,</div>
                            <div className="ml-4"><span className="text-blue-400">"offset"</span>: <span className="text-orange-400">0</span></div>
                            <div className="ml-2">{"}"}</div>
                            <div>{"}"}</div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  )}

                  <Button className="mt-6 bg-primary hover:bg-primary/90">
                    <Play className="w-4 h-4 mr-2" />
                    Try it out
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
