import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Rocket, Github } from "lucide-react";

export default function Hero() {
  return (
    <section className="bg-gradient-to-br from-primary/5 to-slate-100 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-slate-900 mb-6">
            Auto-Generate <span className="text-primary">REST APIs</span><br />
            from Any Database
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
            Production-grade Express.js framework that connects to any relational database, 
            introspects schema at runtime, and auto-generates RESTful CRUD endpoints with 
            configurable access control, pagination, and relationship loading.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90">
              <Rocket className="w-4 h-4 mr-2" />
              Quick Start
            </Button>
            <Button size="lg" variant="outline">
              <Github className="w-4 h-4 mr-2" />
              View on GitHub
            </Button>
          </div>
        </div>

        {/* Quick Demo */}
        <Card className="max-w-4xl mx-auto">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Get Running in 3 Commands</h3>
              <p className="text-slate-600">From zero to full REST API in under 5 minutes</p>
            </div>
            <div className="bg-slate-900 rounded-lg p-6 font-mono text-sm">
              <div className="space-y-2">
                <div className="text-emerald-400">$ npm install -g db-api-framework</div>
                <div className="text-emerald-400">$ db-api init</div>
                <div className="text-emerald-400">$ db-api start</div>
                <div className="text-slate-400 mt-4">🚀 Server running on http://localhost:3000</div>
                <div className="text-slate-400">📚 API docs available at http://localhost:3000/docs</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
