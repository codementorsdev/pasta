import { Card, CardContent } from "@/components/ui/card";
import { Plug, Filter, BarChart3 } from "lucide-react";

const pluginFeatures = [
  {
    icon: Plug,
    title: "Custom Endpoints",
    description: "Add custom routes for complex business logic, aggregations, and data processing.",
    color: "text-primary",
    code: `// custom/analytics.js
exports.routes = {
  '/api/analytics/revenue': getRevenue
}`
  },
  {
    icon: Filter,
    title: "Middleware Hooks",
    description: "Inject custom logic before/after database operations for validation and transformation.",
    color: "text-emerald-600",
    code: `beforeCreate: validateUser,
afterRead: sanitizeData`
  },
  {
    icon: BarChart3,
    title: "Data Aggregation",
    description: "Built-in support for complex queries, joins, and aggregation functions.",
    color: "text-amber-600",
    code: `// Complex aggregation support
SELECT SUM(total) FROM orders`
  },
];

export default function CustomEndpoints() {
  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Custom Business Logic</h2>
          <p className="text-xl text-slate-600">Extend with custom endpoints, aggregations, and processing</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-6">Plugin Architecture</h3>
            <div className="space-y-6">
              {pluginFeatures.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <Card key={index} className="bg-white border border-slate-200">
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-slate-900 mb-3 flex items-center">
                        <Icon className={`${feature.color} w-5 h-5 mr-2`} />
                        {feature.title}
                      </h4>
                      <p className="text-slate-600 mb-4">{feature.description}</p>
                      <div className="bg-slate-50 rounded p-3 font-mono text-sm">
                        {feature.code}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          <Card className="bg-slate-900 border-0">
            <CardContent className="p-6 font-mono text-sm">
              <div className="text-slate-400 mb-4">// plugins/revenue-analytics.js</div>
              <div className="space-y-1 text-slate-300">
                <div><span className="text-purple-400">const</span> {"{"} <span className="text-blue-400">Plugin</span> {"}"} = <span className="text-emerald-400">require</span>(<span className="text-green-400">'db-api-framework'</span>);</div>
                <div className="mt-4"><span className="text-purple-400">class</span> <span className="text-yellow-400">RevenueAnalytics</span> <span className="text-purple-400">extends</span> <span className="text-blue-400">Plugin</span> {"{"}</div>
                <div className="ml-4"><span className="text-blue-400">routes</span>() {"{"}</div>
                <div className="ml-8"><span className="text-purple-400">return</span> {"{"}</div>
                <div className="ml-12"><span className="text-green-400">'/api/analytics/revenue'</span>: {"{"}</div>
                <div className="ml-16"><span className="text-yellow-400">method</span>: <span className="text-green-400">'GET'</span>,</div>
                <div className="ml-16"><span className="text-yellow-400">handler</span>: <span className="text-purple-400">this</span>.<span className="text-blue-400">getRevenue</span></div>
                <div className="ml-12">{"},"}</div>
                <div className="ml-8">{"}"}</div>
                <div className="ml-4">{"}"}</div>
                <div className="mt-4"><span className="text-purple-400">async</span> <span className="text-blue-400">getRevenue</span>(<span className="text-orange-400">req</span>, <span className="text-orange-400">res</span>) {"{"}</div>
                <div className="ml-8"><span className="text-purple-400">const</span> <span className="text-orange-400">result</span> = <span className="text-purple-400">await</span> <span className="text-purple-400">this</span>.<span className="text-blue-400">db</span>.<span className="text-blue-400">query</span>(</div>
                <div className="ml-12"><span className="text-green-400">`SELECT DATE(created_at) as date,</span></div>
                <div className="ml-16"><span className="text-green-400">SUM(total) as revenue</span></div>
                <div className="ml-12"><span className="text-green-400">FROM orders WHERE created_at {'>'}= ?`</span>,</div>
                <div className="ml-12">[<span className="text-orange-400">req</span>.<span className="text-blue-400">query</span>.<span className="text-blue-400">start_date</span>]</div>
                <div className="ml-8">);</div>
                <div className="ml-8"><span className="text-orange-400">res</span>.<span className="text-blue-400">json</span>(<span className="text-orange-400">result</span>);</div>
                <div className="ml-4">{"}"}</div>
                <div>{"}"}</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
