import { Card, CardContent } from "@/components/ui/card";
import { Database, ServerCog, Shield, Link, FileCode, Puzzle } from "lucide-react";

const features = [
  {
    icon: Database,
    title: "Multi-Database Support",
    description: "PostgreSQL, MySQL, SQLite, MSSQL, and Oracle with automatic schema introspection and relationship mapping.",
    bgColor: "bg-primary/10",
    iconColor: "text-primary",
  },
  {
    icon: ServerCog,
    title: "Auto-Generated APIs",
    description: "CRUD endpoints generated automatically with pagination, sorting, filtering, and relationship loading.",
    bgColor: "bg-emerald-100",
    iconColor: "text-emerald-600",
  },
  {
    icon: Shield,
    title: "Access Control",
    description: "Granular permissions per table and operation with whitelist/blacklist configuration.",
    bgColor: "bg-amber-100",
    iconColor: "text-amber-600",
  },
  {
    icon: Link,
    title: "Smart Relationships",
    description: "Configurable lazy/eager loading of related data with automatic foreign key detection.",
    bgColor: "bg-purple-100",
    iconColor: "text-purple-600",
  },
  {
    icon: FileCode,
    title: "Auto Documentation",
    description: "Swagger/OpenAPI documentation generated automatically with interactive API explorer.",
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600",
  },
  {
    icon: Puzzle,
    title: "Extensible Architecture",
    description: "Plugin system for custom endpoints, middleware, and business logic integration.",
    bgColor: "bg-red-100",
    iconColor: "text-red-600",
  },
];

export default function Features() {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Powerful Features</h2>
          <p className="text-xl text-slate-600">Everything you need for production-grade API generation</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="bg-slate-50 border-0 hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${feature.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                    <Icon className={`${feature.iconColor} w-6 h-6`} />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">{feature.title}</h3>
                  <p className="text-slate-600">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
