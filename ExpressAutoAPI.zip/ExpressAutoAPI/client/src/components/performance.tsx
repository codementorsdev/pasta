import { Gauge, Brain, Search, TrendingUp } from "lucide-react";

const performanceFeatures = [
  {
    icon: Gauge,
    title: "Connection Pooling",
    description: "Optimized database connections with automatic pool management",
    color: "text-primary",
    bgColor: "bg-primary/10"
  },
  {
    icon: Brain,
    title: "Query Caching",
    description: "Intelligent caching of frequently accessed data and metadata",
    color: "text-emerald-600",
    bgColor: "bg-emerald-100"
  },
  {
    icon: Search,
    title: "Query Optimization",
    description: "Automatic query optimization and index recommendations",
    color: "text-amber-600",
    bgColor: "bg-amber-100"
  },
  {
    icon: TrendingUp,
    title: "Monitoring",
    description: "Built-in metrics and performance monitoring dashboard",
    color: "text-purple-600",
    bgColor: "bg-purple-100"
  },
];

export default function Performance() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Production-Ready Performance</h2>
          <p className="text-xl text-slate-600">Built for scale with enterprise-grade optimizations</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {performanceFeatures.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="text-center">
                <div className={`w-16 h-16 ${feature.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Icon className={`${feature.color} w-8 h-8`} />
                </div>
                <h4 className="font-semibold text-slate-900 mb-2">{feature.title}</h4>
                <p className="text-slate-600 text-sm">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
