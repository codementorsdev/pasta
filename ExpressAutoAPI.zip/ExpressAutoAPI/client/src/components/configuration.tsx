import { Card, CardContent } from "@/components/ui/card";

const configSteps = [
  {
    number: "1",
    title: "Database Connection",
    description: "Configure connection to PostgreSQL, MySQL, SQLite, or other supported databases.",
  },
  {
    number: "2", 
    title: "Table Access Control",
    description: "Whitelist tables and specify allowed operations (GET, POST, PUT, DELETE) per table.",
  },
  {
    number: "3",
    title: "Relationship Loading", 
    description: "Configure which relationships load eagerly vs. on-demand with query parameters.",
  },
];

export default function Configuration() {
  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Simple Configuration</h2>
          <p className="text-xl text-slate-600">Control everything with a single YAML file</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-6">Configure Your API in Minutes</h3>
            <div className="space-y-6">
              {configSteps.map((step) => (
                <div key={step.number} className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-primary font-bold text-sm">{step.number}</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">{step.title}</h4>
                    <p className="text-slate-600">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Card className="bg-slate-900 border-0">
            <CardContent className="p-6 font-mono text-sm">
              <div className="text-slate-400 mb-4"># config.yaml</div>
              <div className="space-y-1">
                <div><span className="text-blue-400">database:</span></div>
                <div className="ml-4"><span className="text-yellow-400">type:</span> <span className="text-green-400">postgres</span></div>
                <div className="ml-4"><span className="text-yellow-400">host:</span> <span className="text-green-400">localhost</span></div>
                <div className="ml-4"><span className="text-yellow-400">port:</span> <span className="text-orange-400">5432</span></div>
                <div className="ml-4"><span className="text-yellow-400">name:</span> <span className="text-green-400">ecommerce</span></div>
                <div className="mt-4"><span className="text-blue-400">accessControl:</span></div>
                <div className="ml-4"><span className="text-yellow-400">whitelistTables:</span></div>
                <div className="ml-8"><span className="text-slate-400">- </span><span className="text-green-400">users</span></div>
                <div className="ml-8"><span className="text-slate-400">- </span><span className="text-green-400">orders</span></div>
                <div className="ml-8"><span className="text-slate-400">- </span><span className="text-green-400">products</span></div>
                <div className="ml-4"><span className="text-yellow-400">operations:</span></div>
                <div className="ml-8"><span className="text-yellow-400">users:</span> <span className="text-slate-400">[</span><span className="text-green-400">"GET", "POST"</span><span className="text-slate-400">]</span></div>
                <div className="ml-8"><span className="text-yellow-400">orders:</span> <span className="text-slate-400">[</span><span className="text-green-400">"GET"</span><span className="text-slate-400">]</span></div>
                <div className="mt-4"><span className="text-blue-400">relationships:</span></div>
                <div className="ml-4"><span className="text-yellow-400">orders:</span></div>
                <div className="ml-8"><span className="text-yellow-400">eagerLoad:</span> <span className="text-slate-400">[</span><span className="text-green-400">"user", "order_items"</span><span className="text-slate-400">]</span></div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
