import type { Express } from "express";
import { createServer, type Server } from "http";
import { DBAPIFramework } from "./framework";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize DB-API Framework
  const framework = new DBAPIFramework();
  
  try {
    await framework.initialize();
    
    // Mount framework routes
    app.use('/', framework.getApp());
    
    console.log('✅ DB-API Framework routes registered successfully');
  } catch (error) {
    console.error('❌ Failed to initialize DB-API Framework:', error);
    // Continue with basic server setup even if framework fails
  }

  const httpServer = createServer(app);
  return httpServer;
}
