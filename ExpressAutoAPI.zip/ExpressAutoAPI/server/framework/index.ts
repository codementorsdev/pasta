import express, { Express, Request, Response } from 'express';
import yaml from 'js-yaml';
import fs from 'fs';
import path from 'path';
import { DatabaseFactory } from './database/factory';
import { SchemaIntrospector } from './database/introspector';
import { RelationshipMapper } from './database/relationship-mapper';
import { DynamicRouter } from './routes/dynamic-router';
import { AccessControlMiddleware } from './middleware/access-control';
import { PaginationMiddleware } from './middleware/pagination';
import { RelationshipLoaderMiddleware } from './middleware/relationship-loader';
import { ErrorHandlerMiddleware } from './middleware/error-handler';
import { SwaggerGenerator } from './swagger/swagger-generator';
import { ConfigManager, FrameworkConfig } from './config';
import { BasePlugin } from './plugins/base-plugin';
import { CustomEndpointManager } from './extensions/custom-endpoints';
import { IntegrationManager } from './extensions/integration-manager';

export class DBAPIFramework {
  private app: Express;
  private config: FrameworkConfig;
  private database: any;
  private schemaIntrospector: SchemaIntrospector;
  private relationshipMapper: RelationshipMapper;
  private dynamicRouter: DynamicRouter;
  private swaggerGenerator: SwaggerGenerator;
  private plugins: BasePlugin[] = [];
  private customEndpointManager: CustomEndpointManager;
  private integrationManager: IntegrationManager;

  constructor(configPath?: string) {
    this.app = express();
    this.config = ConfigManager.load(configPath);
    this.setupMiddleware();
  }

  private setupMiddleware() {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    
    // CORS middleware
    this.app.use((req, res, next) => {
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
      if (req.method === 'OPTIONS') {
        res.sendStatus(200);
      } else {
        next();
      }
    });
  }

  async initialize(): Promise<void> {
    try {
      // Initialize database connection
      console.log('🔗 Creating database connection...');
      this.database = await DatabaseFactory.create(this.config.database);
      
      // Test database connection
      console.log('🧪 Testing database connection...');
      await this.database.raw('SELECT 1 as test');
      console.log('✅ Database connection test successful');
      
      // Initialize schema introspector
      console.log('🔍 Initializing schema introspector...');
      this.schemaIntrospector = new SchemaIntrospector(this.database, this.config.database.type);
      await this.schemaIntrospector.introspect();
      
      // Initialize relationship mapper
      this.relationshipMapper = new RelationshipMapper(
        this.schemaIntrospector.getSchema(),
        this.config.relationships
      );
      await this.relationshipMapper.mapRelationships();
      
      // Initialize dynamic router
      this.dynamicRouter = new DynamicRouter(
        this.database,
        this.schemaIntrospector,
        this.relationshipMapper,
        this.config
      );

      // Initialize extensions
      this.customEndpointManager = new CustomEndpointManager(
        this.database,
        this.schemaIntrospector
      );

      this.integrationManager = new IntegrationManager(
        this.database,
        this.schemaIntrospector
      );
      
      // Initialize Swagger documentation first (before middleware)
      this.swaggerGenerator = new SwaggerGenerator(
        this.schemaIntrospector,
        this.relationshipMapper,
        this.config
      );
      this.setupSwaggerDocs();
      
      // Setup middleware
      this.setupFrameworkMiddleware();
      
      // Generate and serve API routes
      await this.setupAPIRoutes();
      
      // Load plugins
      await this.loadPlugins();
      
      console.log('DB-API Framework initialized successfully');
    } catch (error) {
      console.error('Failed to initialize DB-API Framework:', error);
      throw error;
    }
  }

  private setupFrameworkMiddleware() {
    // Access control middleware
    this.app.use('/api', AccessControlMiddleware.create(this.config.accessControl));
    
    // Pagination middleware
    this.app.use('/api', PaginationMiddleware.create(this.config.pagination));
    
    // Relationship loader middleware
    this.app.use('/api', RelationshipLoaderMiddleware.create(
      this.relationshipMapper,
      this.config.relationships
    ));
  }

  private async setupAPIRoutes() {
    const routes = await this.dynamicRouter.generateRoutes();
    this.app.use('/api', routes);
    
    // Mount custom endpoints
    this.app.use('/api/custom', this.customEndpointManager.getRouter());
  }

  private setupSwaggerDocs() {
    const swaggerSpec = this.swaggerGenerator.generate();
    
    // Serve Swagger JSON (before API middleware)
    this.app.get('/api-docs.json', (req: Request, res: Response) => {
      res.json(swaggerSpec);
    });
    
    // Serve Swagger UI (before API middleware)
    this.app.get('/docs', (req: Request, res: Response) => {
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>DB-API Framework - API Documentation</title>
          <link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@4.15.5/swagger-ui.css" />
        </head>
        <body>
          <div id="swagger-ui"></div>
          <script src="https://unpkg.com/swagger-ui-dist@4.15.5/swagger-ui-bundle.js"></script>
          <script>
            SwaggerUIBundle({
              url: '/api-docs.json',
              dom_id: '#swagger-ui',
              presets: [
                SwaggerUIBundle.presets.apis,
                SwaggerUIBundle.presets.standalone
              ]
            });
          </script>
        </body>
        </html>
      `);
    });
  }

  private async loadPlugins() {
    if (this.config.plugins) {
      for (const pluginConfig of this.config.plugins) {
        try {
          const PluginClass = require(pluginConfig.path);
          const plugin = new PluginClass(pluginConfig.options);
          await plugin.initialize(this.app, this.database, this.config);
          this.plugins.push(plugin);
          console.log(`Plugin loaded: ${pluginConfig.name}`);
        } catch (error) {
          console.error(`Failed to load plugin ${pluginConfig.name}:`, error);
        }
      }
    }
  }

  use(plugin: BasePlugin) {
    this.plugins.push(plugin);
    plugin.initialize(this.app, this.database, this.config);
  }

  getApp(): Express {
    return this.app;
  }

  getCustomEndpointManager(): CustomEndpointManager {
    return this.customEndpointManager;
  }

  getIntegrationManager(): IntegrationManager {
    return this.integrationManager;
  }

  async start(port: number = 3000, host: string = '0.0.0.0'): Promise<void> {
    // Setup error handler middleware last
    this.app.use(ErrorHandlerMiddleware.create());
    
    return new Promise((resolve, reject) => {
      const server = this.app.listen(port, host, () => {
        console.log(`🚀 DB-API Framework server running on http://${host}:${port}`);
        console.log(`📚 API documentation available at http://${host}:${port}/docs`);
        resolve();
      });
      
      server.on('error', reject);
    });
  }
}

export * from './config';
export * from './plugins/base-plugin';
