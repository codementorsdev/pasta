import { SchemaIntrospector, TableInfo, ColumnInfo } from '../database/introspector';
import { RelationshipMapper, Relationship } from '../database/relationship-mapper';
import { FrameworkConfig } from '../config';

export class SwaggerGenerator {
  private introspector: SchemaIntrospector;
  private relationshipMapper: RelationshipMapper;
  private config: FrameworkConfig;

  constructor(
    introspector: SchemaIntrospector,
    relationshipMapper: RelationshipMapper,
    config: FrameworkConfig
  ) {
    this.introspector = introspector;
    this.relationshipMapper = relationshipMapper;
    this.config = config;
  }

  generate(): any {
    const spec = {
      openapi: '3.0.0',
      info: {
        title: 'DB-API Framework - Auto-Generated API',
        version: '1.0.0',
        description: 'Automatically generated REST API from database schema',
      },
      servers: [
        {
          url: '/api',
          description: 'Development server',
        },
      ],
      paths: {},
      components: {
        schemas: {},
        parameters: {
          limitParam: {
            name: 'limit',
            in: 'query',
            description: 'Number of items to return',
            required: false,
            schema: {
              type: 'integer',
              minimum: 1,
              maximum: this.config.pagination?.maxLimit || 100,
              default: this.config.pagination?.defaultLimit || 25,
            },
          },
          offsetParam: {
            name: 'offset',
            in: 'query',
            description: 'Number of items to skip',
            required: false,
            schema: {
              type: 'integer',
              minimum: 0,
              default: 0,
            },
          },
          sortParam: {
            name: 'sort',
            in: 'query',
            description: 'Sort fields (comma-separated, prefix with - for descending)',
            required: false,
            schema: {
              type: 'string',
            },
          },
          includeParam: {
            name: 'include',
            in: 'query',
            description: 'Related resources to include (comma-separated)',
            required: false,
            schema: {
              type: 'string',
            },
          },
        },
      },
    };

    const tables = this.introspector.getTables();

    for (const tableName of tables) {
      if (!this.isTableAllowed(tableName)) {
        continue;
      }

      const tableInfo = this.introspector.getTable(tableName)!;
      const allowedOps = this.getAllowedOperations(tableName);

      // Generate schema definitions
      this.generateSchemas(spec, tableName, tableInfo);

      // Generate API paths
      this.generatePaths(spec, tableName, tableInfo, allowedOps);
    }

    return spec;
  }

  private generateSchemas(spec: any, tableName: string, tableInfo: TableInfo): void {
    const properties: any = {};
    const required: string[] = [];

    for (const column of tableInfo.columns) {
      properties[column.name] = this.columnToSwaggerProperty(column);
      
      if (!column.nullable && !column.defaultValue && !column.isPrimaryKey) {
        required.push(column.name);
      }
    }

    // Add relationships
    const relationships = this.relationshipMapper.getRelationships(tableName);
    for (const relationship of relationships) {
      const alias = this.relationshipMapper.getRelationshipAlias(relationship);
      if (relationship.type === 'belongsTo' || relationship.type === 'hasOne') {
        properties[alias] = {
          $ref: `#/components/schemas/${relationship.toTable}`,
        };
      } else {
        properties[alias] = {
          type: 'array',
          items: {
            $ref: `#/components/schemas/${relationship.toTable}`,
          },
        };
      }
    }

    // Full schema with relationships
    spec.components.schemas[tableName] = {
      type: 'object',
      properties,
      required: required.length > 0 ? required : undefined,
    };

    // Create schema without relationships for input
    const inputProperties = { ...properties };
    for (const relationship of relationships) {
      const alias = this.relationshipMapper.getRelationshipAlias(relationship);
      delete inputProperties[alias];
    }

    // Remove auto-generated fields from input schema
    const primaryKeys = tableInfo.primaryKeys;
    for (const pk of primaryKeys) {
      delete inputProperties[pk];
    }
    
    // Remove created_at, updated_at fields
    delete inputProperties.created_at;
    delete inputProperties.updated_at;

    spec.components.schemas[`${tableName}Input`] = {
      type: 'object',
      properties: inputProperties,
      required: required.filter(field => 
        !primaryKeys.includes(field) && 
        field !== 'created_at' && 
        field !== 'updated_at'
      ),
    };
  }

  private generatePaths(spec: any, tableName: string, tableInfo: TableInfo, allowedOps: string[]): void {
    const paths: any = {};

    // List endpoint
    if (allowedOps.includes('GET')) {
      paths.get = {
        summary: `List ${tableName}`,
        description: `Retrieve a paginated list of ${tableName}`,
        parameters: [
          { $ref: '#/components/parameters/limitParam' },
          { $ref: '#/components/parameters/offsetParam' },
          { $ref: '#/components/parameters/sortParam' },
          { $ref: '#/components/parameters/includeParam' },
        ],
        responses: {
          200: {
            description: 'Successful response',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    data: {
                      type: 'array',
                      items: { $ref: `#/components/schemas/${tableName}` },
                    },
                    pagination: {
                      type: 'object',
                      properties: {
                        total: { type: 'integer' },
                        limit: { type: 'integer' },
                        offset: { type: 'integer' },
                      },
                    },
                  },
                },
              },
            },
          },
          403: { $ref: '#/components/responses/ForbiddenError' },
          500: { $ref: '#/components/responses/InternalError' },
        },
      };
    }

    // Create endpoint
    if (allowedOps.includes('POST')) {
      paths.post = {
        summary: `Create ${tableName}`,
        description: `Create a new ${tableName} record`,
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: `#/components/schemas/${tableName}Input` },
            },
          },
        },
        responses: {
          201: {
            description: 'Created successfully',
            content: {
              'application/json': {
                schema: { $ref: `#/components/schemas/${tableName}` },
              },
            },
          },
          400: { $ref: '#/components/responses/ValidationError' },
          403: { $ref: '#/components/responses/ForbiddenError' },
          500: { $ref: '#/components/responses/InternalError' },
        },
      };
    }

    spec.paths[`/${tableName}`] = paths;

    // Individual resource endpoints
    const itemPaths: any = {};

    // Get by ID endpoint
    if (allowedOps.includes('GET')) {
      itemPaths.get = {
        summary: `Get ${tableName} by ID`,
        description: `Retrieve a single ${tableName} record by ID`,
        parameters: [
          {
            name: 'id',
            in: 'path',
            required: true,
            schema: { type: 'string' },
          },
          { $ref: '#/components/parameters/includeParam' },
        ],
        responses: {
          200: {
            description: 'Successful response',
            content: {
              'application/json': {
                schema: { $ref: `#/components/schemas/${tableName}` },
              },
            },
          },
          404: { $ref: '#/components/responses/NotFoundError' },
          403: { $ref: '#/components/responses/ForbiddenError' },
          500: { $ref: '#/components/responses/InternalError' },
        },
      };
    }

    // Update endpoint
    if (allowedOps.includes('PUT')) {
      itemPaths.put = {
        summary: `Update ${tableName}`,
        description: `Update a ${tableName} record`,
        parameters: [
          {
            name: 'id',
            in: 'path',
            required: true,
            schema: { type: 'string' },
          },
        ],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: `#/components/schemas/${tableName}Input` },
            },
          },
        },
        responses: {
          200: {
            description: 'Updated successfully',
            content: {
              'application/json': {
                schema: { $ref: `#/components/schemas/${tableName}` },
              },
            },
          },
          400: { $ref: '#/components/responses/ValidationError' },
          404: { $ref: '#/components/responses/NotFoundError' },
          403: { $ref: '#/components/responses/ForbiddenError' },
          500: { $ref: '#/components/responses/InternalError' },
        },
      };
    }

    // Delete endpoint
    if (allowedOps.includes('DELETE')) {
      itemPaths.delete = {
        summary: `Delete ${tableName}`,
        description: `Delete a ${tableName} record`,
        parameters: [
          {
            name: 'id',
            in: 'path',
            required: true,
            schema: { type: 'string' },
          },
        ],
        responses: {
          204: { description: 'Deleted successfully' },
          404: { $ref: '#/components/responses/NotFoundError' },
          403: { $ref: '#/components/responses/ForbiddenError' },
          500: { $ref: '#/components/responses/InternalError' },
        },
      };
    }

    spec.paths[`/${tableName}/{id}`] = itemPaths;

    // Add common response schemas
    if (!spec.components.responses) {
      spec.components.responses = {
        ValidationError: {
          description: 'Validation error',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  error: {
                    type: 'object',
                    properties: {
                      message: { type: 'string' },
                      statusCode: { type: 'integer' },
                      details: { type: 'object' },
                    },
                  },
                },
              },
            },
          },
        },
        NotFoundError: {
          description: 'Resource not found',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  error: { type: 'string' },
                },
              },
            },
          },
        },
        ForbiddenError: {
          description: 'Access denied',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  error: { type: 'string' },
                  message: { type: 'string' },
                },
              },
            },
          },
        },
        InternalError: {
          description: 'Internal server error',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  error: {
                    type: 'object',
                    properties: {
                      message: { type: 'string' },
                      statusCode: { type: 'integer' },
                    },
                  },
                },
              },
            },
          },
        },
      };
    }
  }

  private columnToSwaggerProperty(column: ColumnInfo): any {
    const property: any = {
      type: this.mapColumnTypeToSwagger(column.type),
    };

    if (column.maxLength) {
      property.maxLength = column.maxLength;
    }

    if (column.defaultValue !== null) {
      property.default = column.defaultValue;
    }

    if (!column.nullable) {
      property.nullable = false;
    }

    return property;
  }

  private mapColumnTypeToSwagger(type: string): string {
    switch (type) {
      case 'string':
        return 'string';
      case 'number':
        return 'number';
      case 'boolean':
        return 'boolean';
      case 'date':
        return 'string';
      case 'buffer':
        return 'string';
      default:
        return 'string';
    }
  }

  private isTableAllowed(tableName: string): boolean {
    const accessControl = this.config.accessControl;
    
    if (!accessControl) {
      return true;
    }
    
    if (accessControl.blacklistTables?.includes(tableName)) {
      return false;
    }
    
    if (accessControl.whitelistTables && accessControl.whitelistTables.length > 0) {
      return accessControl.whitelistTables.includes(tableName);
    }
    
    return true;
  }

  private getAllowedOperations(tableName: string): string[] {
    const accessControl = this.config.accessControl;
    
    if (!accessControl) {
      return ['GET', 'POST', 'PUT', 'DELETE'];
    }
    
    const tableOps = accessControl.operations?.[tableName];
    if (tableOps) {
      return tableOps;
    }
    
    return accessControl.defaultOperations || ['GET'];
  }
}
