import yaml from 'js-yaml';
import fs from 'fs';
import path from 'path';
import { z } from 'zod';

const DatabaseConfigSchema = z.object({
  type: z.enum(['postgres', 'mysql', 'sqlite', 'mssql', 'oracle']),
  host: z.string().optional(),
  port: z.number().optional(),
  user: z.string().optional(),
  password: z.string().optional(),
  database: z.string().optional(),
  filename: z.string().optional(), // for SQLite
  connectionString: z.string().optional(),
  pool: z.object({
    min: z.number().default(2),
    max: z.number().default(10),
    acquireTimeoutMillis: z.number().default(30000),
    idleTimeoutMillis: z.number().default(600000),
  }).optional(),
});

const AccessControlConfigSchema = z.object({
  whitelistTables: z.array(z.string()).optional(),
  blacklistTables: z.array(z.string()).optional(),
  operations: z.record(z.array(z.enum(['GET', 'POST', 'PUT', 'DELETE']))).optional(),
  defaultOperations: z.array(z.enum(['GET', 'POST', 'PUT', 'DELETE'])).default(['GET']),
});

const PaginationConfigSchema = z.object({
  defaultLimit: z.number().default(25),
  maxLimit: z.number().default(100),
  defaultOffset: z.number().default(0),
});

const SortingConfigSchema = z.object({
  defaultFields: z.record(z.array(z.string())).optional(),
  allowedFields: z.record(z.array(z.string())).optional(),
});

const RelationshipConfigSchema = z.object({
  eagerLoad: z.record(z.array(z.string())).optional(),
  lazyLoad: z.record(z.array(z.string())).optional(),
  maxDepth: z.number().default(3),
});

const PluginConfigSchema = z.object({
  name: z.string(),
  path: z.string(),
  enabled: z.boolean().default(true),
  options: z.record(z.any()).optional(),
});

const FrameworkConfigSchema = z.object({
  database: DatabaseConfigSchema,
  accessControl: AccessControlConfigSchema.optional(),
  pagination: PaginationConfigSchema.optional(),
  sorting: SortingConfigSchema.optional(),
  relationships: RelationshipConfigSchema.optional(),
  plugins: z.array(PluginConfigSchema).optional(),
  logging: z.object({
    level: z.enum(['error', 'warn', 'info', 'debug']).default('info'),
    format: z.enum(['json', 'simple']).default('simple'),
  }).optional(),
  security: z.object({
    enableCors: z.boolean().default(true),
    rateLimiting: z.object({
      windowMs: z.number().default(900000), // 15 minutes
      max: z.number().default(100), // limit each IP to 100 requests per windowMs
    }).optional(),
  }).optional(),
});

export type DatabaseConfig = z.infer<typeof DatabaseConfigSchema>;
export type AccessControlConfig = z.infer<typeof AccessControlConfigSchema>;
export type PaginationConfig = z.infer<typeof PaginationConfigSchema>;
export type SortingConfig = z.infer<typeof SortingConfigSchema>;
export type RelationshipConfig = z.infer<typeof RelationshipConfigSchema>;
export type PluginConfig = z.infer<typeof PluginConfigSchema>;
export type FrameworkConfig = z.infer<typeof FrameworkConfigSchema>;

export class ConfigManager {
  private static defaultConfig: Partial<FrameworkConfig> = {
    accessControl: {
      defaultOperations: ['GET'],
    },
    pagination: {
      defaultLimit: 25,
      maxLimit: 100,
      defaultOffset: 0,
    },
    relationships: {
      maxDepth: 3,
    },
    logging: {
      level: 'info',
      format: 'simple',
    },
    security: {
      enableCors: true,
    },
  };

  static load(configPath?: string): FrameworkConfig {
    let config: any = { ...this.defaultConfig };

    if (configPath && fs.existsSync(configPath)) {
      const fileContent = fs.readFileSync(configPath, 'utf8');
      const fileConfig = yaml.load(fileContent) as any;
      config = this.mergeDeep(config, fileConfig);
    } else if (fs.existsSync('config.yaml')) {
      const fileContent = fs.readFileSync('config.yaml', 'utf8');
      const fileConfig = yaml.load(fileContent) as any;
      config = this.mergeDeep(config, fileConfig);
    } else if (fs.existsSync('config.yml')) {
      const fileContent = fs.readFileSync('config.yml', 'utf8');
      const fileConfig = yaml.load(fileContent) as any;
      config = this.mergeDeep(config, fileConfig);
    }

    // Override with environment variables
    this.loadFromEnvironment(config);

    // Validate configuration
    const result = FrameworkConfigSchema.safeParse(config);
    if (!result.success) {
      throw new Error(`Invalid configuration: ${result.error.message}`);
    }

    return result.data;
  }

  private static loadFromEnvironment(config: any) {
    // Database configuration from environment
    if (process.env.DATABASE_URL) {
      config.database = config.database || {};
      config.database.connectionString = process.env.DATABASE_URL;
    }
    
    if (process.env.DB_TYPE) {
      config.database = config.database || {};
      config.database.type = process.env.DB_TYPE;
    }
    
    if (process.env.DB_HOST) {
      config.database = config.database || {};
      config.database.host = process.env.DB_HOST;
    }
    
    if (process.env.DB_PORT) {
      config.database = config.database || {};
      config.database.port = parseInt(process.env.DB_PORT);
    }

    if (process.env.DB_USER) {
      config.database = config.database || {};
      config.database.user = process.env.DB_USER;
    }

    if (process.env.DB_PASSWORD) {
      config.database = config.database || {};
      config.database.password = process.env.DB_PASSWORD;
    }

    if (process.env.DB_NAME) {
      config.database = config.database || {};
      config.database.database = process.env.DB_NAME;
    }
  }

  private static mergeDeep(target: any, source: any): any {
    const output = Object.assign({}, target);
    if (this.isObject(target) && this.isObject(source)) {
      Object.keys(source).forEach(key => {
        if (this.isObject(source[key])) {
          if (!(key in target)) {
            Object.assign(output, { [key]: source[key] });
          } else {
            output[key] = this.mergeDeep(target[key], source[key]);
          }
        } else {
          Object.assign(output, { [key]: source[key] });
        }
      });
    }
    return output;
  }

  private static isObject(item: any): boolean {
    return item && typeof item === 'object' && !Array.isArray(item);
  }

  static generateSampleConfig(): string {
    const sampleConfig = {
      database: {
        type: 'postgres',
        host: 'localhost',
        port: 5432,
        user: 'admin',
        password: 'password',
        database: 'ecommerce',
        pool: {
          min: 2,
          max: 10,
        },
      },
      accessControl: {
        whitelistTables: ['users', 'orders', 'products', 'order_items'],
        operations: {
          users: ['GET', 'POST'],
          orders: ['GET'],
          order_items: ['GET', 'POST', 'PUT'],
          products: ['GET'],
        },
      },
      pagination: {
        defaultLimit: 25,
        maxLimit: 100,
      },
      sorting: {
        defaultFields: {
          users: ['created_at', 'name'],
          products: ['price', 'created_at'],
        },
      },
      relationships: {
        eagerLoad: {
          orders: ['user', 'order_items'],
        },
        lazyLoad: {
          order_items: ['product'],
          users: [],
        },
      },
      plugins: [
        {
          name: 'analytics',
          path: './plugins/analytics.js',
          enabled: true,
          options: {
            enableRevenueEndpoint: true,
          },
        },
      ],
    };

    return yaml.dump(sampleConfig, { indent: 2 });
  }
}
