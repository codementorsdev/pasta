import { Router, Request, Response } from 'express';
import { Knex } from 'knex';
import { SchemaIntrospector } from '../database/introspector';
import { AggregationEngine } from './aggregation-engine';
import { TransformEngine } from './transform-engine';

export interface CustomEndpointConfig {
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  handler: string | CustomEndpointHandler;
  middleware?: string[];
  description?: string;
  parameters?: EndpointParameter[];
  responses?: EndpointResponse[];
}

export interface EndpointParameter {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array';
  required?: boolean;
  description?: string;
  default?: any;
}

export interface EndpointResponse {
  status: number;
  description: string;
  schema?: any;
}

export type CustomEndpointHandler = (
  req: Request,
  res: Response,
  context: EndpointContext
) => Promise<void> | void;

export interface EndpointContext {
  db: Knex;
  introspector: SchemaIntrospector;
  aggregation: AggregationEngine;
  transform: TransformEngine;
}

export class CustomEndpointManager {
  private router: Router;
  private db: Knex;
  private introspector: SchemaIntrospector;
  private aggregation: AggregationEngine;
  private transform: TransformEngine;
  private endpoints: Map<string, CustomEndpointConfig> = new Map();

  constructor(db: Knex, introspector: SchemaIntrospector) {
    this.router = Router();
    this.db = db;
    this.introspector = introspector;
    this.aggregation = new AggregationEngine(db, introspector);
    this.transform = new TransformEngine(db, introspector);
    
    this.setupBuiltInEndpoints();
  }

  private setupBuiltInEndpoints() {
    // Built-in aggregation endpoints
    this.addEndpoint({
      path: '/stats/:table',
      method: 'GET',
      description: 'Get statistical summary of a table',
      handler: async (req, res, context) => {
        const { table } = req.params;
        const stats = await context.aggregation.getTableStats(table);
        res.json(stats);
      }
    });

    // Built-in custom aggregation endpoint
    this.addEndpoint({
      path: '/aggregate',
      method: 'POST',
      description: 'Execute custom aggregation query',
      handler: async (req, res, context) => {
        const query = req.body;
        const result = await context.aggregation.execute(query);
        res.json({ data: result });
      }
    });

    // Built-in data transformation endpoint
    this.addEndpoint({
      path: '/transform/:table',
      method: 'POST',
      description: 'Transform table data using custom rules',
      handler: async (req, res, context) => {
        const { table } = req.params;
        const { rules, filters } = req.body;
        const result = await context.transform.processData(table, rules, filters);
        res.json({ data: result });
      }
    });

    // Built-in analytics endpoints
    this.addEndpoint({
      path: '/analytics/revenue',
      method: 'GET',
      description: 'Get revenue analytics over time',
      handler: async (req, res, context) => {
        const { start_date, end_date, group_by = 'day' } = req.query;
        
        let dateFormat = 'YYYY-MM-DD';
        if (group_by === 'month') dateFormat = 'YYYY-MM';
        if (group_by === 'year') dateFormat = 'YYYY';

        const result = await context.db.raw(`
          SELECT 
            TO_CHAR(created_at, '${dateFormat}') as period,
            SUM(total) as revenue,
            COUNT(*) as order_count,
            AVG(total) as avg_order_value
          FROM orders 
          WHERE created_at >= ? AND created_at <= ?
          GROUP BY TO_CHAR(created_at, '${dateFormat}')
          ORDER BY period
        `, [start_date, end_date]);

        res.json({ data: result.rows });
      }
    });

    // Built-in user analytics
    this.addEndpoint({
      path: '/analytics/users',
      method: 'GET',
      description: 'Get user growth and activity analytics',
      handler: async (req, res, context) => {
        const stats = await context.db.raw(`
          SELECT 
            COUNT(*) as total_users,
            COUNT(CASE WHEN created_at >= CURRENT_DATE - INTERVAL '30 days' THEN 1 END) as new_users_30d,
            COUNT(CASE WHEN created_at >= CURRENT_DATE - INTERVAL '7 days' THEN 1 END) as new_users_7d
          FROM users
        `);

        const growth = await context.db.raw(`
          SELECT 
            TO_CHAR(created_at, 'YYYY-MM') as month,
            COUNT(*) as new_users
          FROM users 
          WHERE created_at >= CURRENT_DATE - INTERVAL '12 months'
          GROUP BY TO_CHAR(created_at, 'YYYY-MM')
          ORDER BY month
        `);

        res.json({
          summary: stats.rows[0],
          growth: growth.rows
        });
      }
    });
  }

  addEndpoint(config: CustomEndpointConfig): void {
    const key = `${config.method}:${config.path}`;
    this.endpoints.set(key, config);

    const context: EndpointContext = {
      db: this.db,
      introspector: this.introspector,
      aggregation: this.aggregation,
      transform: this.transform
    };

    // Register the route
    const method = config.method.toLowerCase() as 'get' | 'post' | 'put' | 'delete';
    this.router[method](config.path, async (req: Request, res: Response) => {
      try {
        if (typeof config.handler === 'string') {
          // Load handler from file or module
          const handler = await this.loadHandler(config.handler);
          await handler(req, res, context);
        } else {
          await config.handler(req, res, context);
        }
      } catch (error) {
        console.error('Custom endpoint error:', error);
        res.status(500).json({
          error: 'Internal server error',
          message: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    });
  }

  private async loadHandler(handlerPath: string): Promise<CustomEndpointHandler> {
    // This would load handlers from files in a real implementation
    throw new Error(`Handler loading not implemented: ${handlerPath}`);
  }

  getRouter(): Router {
    return this.router;
  }

  getEndpoints(): CustomEndpointConfig[] {
    return Array.from(this.endpoints.values());
  }

  // Helper method to create business logic endpoints
  createBusinessEndpoint(name: string, logic: (context: EndpointContext) => any): void {
    this.addEndpoint({
      path: `/business/${name}`,
      method: 'GET',
      description: `Business logic endpoint: ${name}`,
      handler: async (req, res, context) => {
        const result = await logic(context);
        res.json(result);
      }
    });
  }
}