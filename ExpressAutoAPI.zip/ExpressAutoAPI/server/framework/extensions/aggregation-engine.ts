import { Knex } from 'knex';
import { SchemaIntrospector } from '../database/introspector';

export interface AggregationQuery {
  table: string;
  fields: AggregationField[];
  groupBy?: string[];
  having?: string;
  orderBy?: string;
  limit?: number;
  filters?: Record<string, any>;
}

export interface AggregationField {
  field: string;
  operation: 'sum' | 'count' | 'avg' | 'min' | 'max' | 'count_distinct';
  alias?: string;
}

export class AggregationEngine {
  private db: Knex;
  private introspector: SchemaIntrospector;

  constructor(db: Knex, introspector: SchemaIntrospector) {
    this.db = db;
    this.introspector = introspector;
  }

  async execute(query: AggregationQuery): Promise<any[]> {
    let knexQuery = this.db(query.table);

    // Apply filters
    if (query.filters) {
      Object.entries(query.filters).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          knexQuery = knexQuery.whereIn(key, value);
        } else if (typeof value === 'string' && value.includes('%')) {
          knexQuery = knexQuery.whereLike(key, value);
        } else {
          knexQuery = knexQuery.where(key, value);
        }
      });
    }

    // Apply aggregation fields
    const selectFields: string[] = [];
    query.fields.forEach(field => {
      const alias = field.alias || `${field.operation}_${field.field}`;
      switch (field.operation) {
        case 'sum':
          selectFields.push(`SUM(${field.field}) as ${alias}`);
          break;
        case 'count':
          selectFields.push(`COUNT(${field.field}) as ${alias}`);
          break;
        case 'count_distinct':
          selectFields.push(`COUNT(DISTINCT ${field.field}) as ${alias}`);
          break;
        case 'avg':
          selectFields.push(`AVG(${field.field}) as ${alias}`);
          break;
        case 'min':
          selectFields.push(`MIN(${field.field}) as ${alias}`);
          break;
        case 'max':
          selectFields.push(`MAX(${field.field}) as ${alias}`);
          break;
      }
    });

    knexQuery = knexQuery.select(this.db.raw(selectFields.join(', ')));

    // Apply GROUP BY
    if (query.groupBy) {
      knexQuery = knexQuery.groupBy(query.groupBy);
      // Add group by fields to select
      query.groupBy.forEach(field => {
        knexQuery = knexQuery.select(field);
      });
    }

    // Apply HAVING
    if (query.having) {
      knexQuery = knexQuery.havingRaw(query.having);
    }

    // Apply ORDER BY
    if (query.orderBy) {
      const [field, direction] = query.orderBy.split(':');
      knexQuery = knexQuery.orderBy(field, direction || 'asc');
    }

    // Apply LIMIT
    if (query.limit) {
      knexQuery = knexQuery.limit(query.limit);
    }

    return await knexQuery;
  }

  // Pre-built aggregation endpoints
  async getTableStats(tableName: string): Promise<any> {
    const totalCount = await this.db(tableName).count('* as total').first();
    
    // Get numeric columns for aggregation
    const tableInfo = this.introspector.getTable(tableName);
    const numericColumns = tableInfo?.columns.filter(col => 
      ['number', 'integer', 'decimal', 'float'].includes(col.type)
    ) || [];

    const stats: any = { total: totalCount?.total || 0 };

    for (const col of numericColumns) {
      const colStats = await this.db(tableName)
        .select(
          this.db.raw(`MIN(${col.name}) as min`),
          this.db.raw(`MAX(${col.name}) as max`),
          this.db.raw(`AVG(${col.name}) as avg`),
          this.db.raw(`SUM(${col.name}) as sum`)
        )
        .first();
      
      stats[col.name] = colStats;
    }

    return stats;
  }
}