import { Knex } from 'knex';
import { SchemaIntrospector } from '../database/introspector';

export interface IntegrationConfig {
  name: string;
  type: 'webhook' | 'api' | 'queue' | 'stream';
  enabled: boolean;
  config: any;
  triggers?: IntegrationTrigger[];
  transformations?: IntegrationTransformation[];
}

export interface IntegrationTrigger {
  event: 'create' | 'update' | 'delete';
  table: string;
  conditions?: Record<string, any>;
}

export interface IntegrationTransformation {
  source_field: string;
  target_field: string;
  transform?: string;
}

export interface WebhookIntegration {
  url: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH';
  headers?: Record<string, string>;
  authentication?: {
    type: 'bearer' | 'basic' | 'api_key';
    credentials: Record<string, string>;
  };
  retry_policy?: {
    max_attempts: number;
    delay_ms: number;
    exponential_backoff: boolean;
  };
}

export interface APIIntegration {
  base_url: string;
  authentication?: {
    type: 'bearer' | 'basic' | 'oauth2' | 'api_key';
    credentials: Record<string, string>;
  };
  endpoints: {
    [key: string]: {
      path: string;
      method: string;
      mapping: Record<string, string>;
    };
  };
}

export class IntegrationManager {
  private db: Knex;
  private introspector: SchemaIntrospector;
  private integrations: Map<string, IntegrationConfig> = new Map();

  constructor(db: Knex, introspector: SchemaIntrospector) {
    this.db = db;
    this.introspector = introspector;
    this.setupBuiltInIntegrations();
  }

  private setupBuiltInIntegrations() {
    // Example: Email notification integration
    this.addIntegration({
      name: 'email_notifications',
      type: 'webhook',
      enabled: true,
      config: {
        url: process.env.EMAIL_WEBHOOK_URL,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.EMAIL_API_KEY}`
        }
      },
      triggers: [
        {
          event: 'create',
          table: 'users',
        },
        {
          event: 'create',
          table: 'orders',
        }
      ],
      transformations: [
        { source_field: 'email', target_field: 'to' },
        { source_field: 'name', target_field: 'recipient_name' }
      ]
    });

    // Example: Analytics tracking integration
    this.addIntegration({
      name: 'analytics_tracking',
      type: 'webhook',
      enabled: true,
      config: {
        url: process.env.ANALYTICS_WEBHOOK_URL,
        method: 'POST'
      },
      triggers: [
        { event: 'create', table: 'orders' },
        { event: 'update', table: 'orders', conditions: { status: 'completed' } }
      ]
    });
  }

  addIntegration(config: IntegrationConfig): void {
    this.integrations.set(config.name, config);
  }

  async triggerIntegrations(
    event: 'create' | 'update' | 'delete',
    table: string,
    data: any,
    oldData?: any
  ): Promise<void> {
    const relevantIntegrations = Array.from(this.integrations.values())
      .filter(integration => 
        integration.enabled && 
        integration.triggers?.some(trigger => 
          trigger.event === event && 
          trigger.table === table &&
          this.matchesConditions(data, trigger.conditions)
        )
      );

    const promises = relevantIntegrations.map(integration => 
      this.executeIntegration(integration, event, table, data, oldData)
    );

    await Promise.allSettled(promises);
  }

  private matchesConditions(data: any, conditions?: Record<string, any>): boolean {
    if (!conditions) return true;
    
    return Object.entries(conditions).every(([key, value]) => 
      data[key] === value
    );
  }

  private async executeIntegration(
    integration: IntegrationConfig,
    event: string,
    table: string,
    data: any,
    oldData?: any
  ): Promise<void> {
    try {
      switch (integration.type) {
        case 'webhook':
          await this.executeWebhookIntegration(integration, event, table, data, oldData);
          break;
        case 'api':
          await this.executeAPIIntegration(integration, event, table, data, oldData);
          break;
        case 'queue':
          await this.executeQueueIntegration(integration, event, table, data, oldData);
          break;
        default:
          console.warn(`Unsupported integration type: ${integration.type}`);
      }
    } catch (error) {
      console.error(`Integration ${integration.name} failed:`, error);
    }
  }

  private async executeWebhookIntegration(
    integration: IntegrationConfig,
    event: string,
    table: string,
    data: any,
    oldData?: any
  ): Promise<void> {
    const config = integration.config as WebhookIntegration;
    
    const payload = {
      event,
      table,
      data: this.transformData(data, integration.transformations),
      old_data: oldData ? this.transformData(oldData, integration.transformations) : null,
      timestamp: new Date().toISOString()
    };

    const response = await fetch(config.url, {
      method: config.method,
      headers: {
        'Content-Type': 'application/json',
        ...config.headers
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Webhook failed: ${response.status} ${response.statusText}`);
    }
  }

  private async executeAPIIntegration(
    integration: IntegrationConfig,
    event: string,
    table: string,
    data: any,
    oldData?: any
  ): Promise<void> {
    const config = integration.config as APIIntegration;
    
    // Find relevant endpoint for this event/table
    const endpointKey = `${event}_${table}`;
    const endpoint = config.endpoints[endpointKey];
    
    if (!endpoint) return;

    const url = `${config.base_url}${endpoint.path}`;
    const transformedData = this.transformDataWithMapping(data, endpoint.mapping);

    const response = await fetch(url, {
      method: endpoint.method,
      headers: {
        'Content-Type': 'application/json',
        ...this.getAuthHeaders(config.authentication)
      },
      body: JSON.stringify(transformedData)
    });

    if (!response.ok) {
      throw new Error(`API integration failed: ${response.status} ${response.statusText}`);
    }
  }

  private async executeQueueIntegration(
    integration: IntegrationConfig,
    event: string,
    table: string,
    data: any,
    oldData?: any
  ): Promise<void> {
    // Queue integration would use Redis, SQS, or similar
    // For now, we'll log it as a placeholder
    console.log(`Queue integration ${integration.name}:`, {
      event,
      table,
      data,
      oldData
    });
  }

  private transformData(
    data: any,
    transformations?: IntegrationTransformation[]
  ): any {
    if (!transformations) return data;

    const transformed: any = {};
    
    transformations.forEach(t => {
      transformed[t.target_field] = data[t.source_field];
    });

    return transformed;
  }

  private transformDataWithMapping(data: any, mapping: Record<string, string>): any {
    const transformed: any = {};
    
    Object.entries(mapping).forEach(([sourceField, targetField]) => {
      transformed[targetField] = data[sourceField];
    });

    return transformed;
  }

  private getAuthHeaders(auth?: any): Record<string, string> {
    if (!auth) return {};

    switch (auth.type) {
      case 'bearer':
        return { 'Authorization': `Bearer ${auth.credentials.token}` };
      case 'basic':
        const credentials = Buffer.from(`${auth.credentials.username}:${auth.credentials.password}`).toString('base64');
        return { 'Authorization': `Basic ${credentials}` };
      case 'api_key':
        return { [auth.credentials.header || 'X-API-Key']: auth.credentials.key };
      default:
        return {};
    }
  }

  // Pre-built integrations for common services
  setupSlackIntegration(webhookUrl: string): void {
    this.addIntegration({
      name: 'slack_notifications',
      type: 'webhook',
      enabled: true,
      config: {
        url: webhookUrl,
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      },
      triggers: [
        { event: 'create', table: 'orders' },
        { event: 'update', table: 'orders', conditions: { status: 'completed' } }
      ]
    });
  }

  setupStripeIntegration(apiKey: string): void {
    this.addIntegration({
      name: 'stripe_payments',
      type: 'api',
      enabled: true,
      config: {
        base_url: 'https://api.stripe.com/v1',
        authentication: {
          type: 'bearer',
          credentials: { token: apiKey }
        },
        endpoints: {
          create_orders: {
            path: '/payment_intents',
            method: 'POST',
            mapping: {
              'total': 'amount',
              'user_id': 'customer',
              'id': 'metadata.order_id'
            }
          }
        }
      },
      triggers: [
        { event: 'create', table: 'orders' }
      ]
    });
  }

  getIntegrations(): IntegrationConfig[] {
    return Array.from(this.integrations.values());
  }
}