import { Knex } from 'knex';
import { SchemaIntrospector } from '../database/introspector';

export interface TransformRule {
  field: string;
  operation: TransformOperation;
  parameters?: any;
}

export interface TransformOperation {
  type: 'map' | 'filter' | 'aggregate' | 'join' | 'format' | 'calculate';
  function: string | TransformFunction;
  options?: any;
}

export type TransformFunction = (value: any, row: any, context: any) => any;

export class TransformEngine {
  private db: Knex;
  private introspector: SchemaIntrospector;

  constructor(db: Knex, introspector: SchemaIntrospector) {
    this.db = db;
    this.introspector = introspector;
  }

  async processData(
    tableName: string, 
    rules: TransformRule[], 
    filters?: Record<string, any>
  ): Promise<any[]> {
    // Get raw data
    let query = this.db(tableName);
    
    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        query = query.where(key, value);
      });
    }

    const rawData = await query;

    // Apply transformation rules
    let transformedData = rawData;

    for (const rule of rules) {
      transformedData = await this.applyRule(transformedData, rule);
    }

    return transformedData;
  }

  private async applyRule(data: any[], rule: TransformRule): Promise<any[]> {
    switch (rule.operation.type) {
      case 'map':
        return this.applyMapTransform(data, rule);
      case 'filter':
        return this.applyFilterTransform(data, rule);
      case 'format':
        return this.applyFormatTransform(data, rule);
      case 'calculate':
        return this.applyCalculateTransform(data, rule);
      default:
        return data;
    }
  }

  private applyMapTransform(data: any[], rule: TransformRule): any[] {
    if (typeof rule.operation.function === 'string') {
      // Built-in transform functions
      const transform = this.getBuiltInTransform(rule.operation.function);
      return data.map(row => ({
        ...row,
        [rule.field]: transform(row[rule.field], row, rule.parameters)
      }));
    }

    return data.map(row => ({
      ...row,
      [rule.field]: (rule.operation.function as TransformFunction)(
        row[rule.field], 
        row, 
        rule.parameters || {}
      )
    }));
  }

  private applyFilterTransform(data: any[], rule: TransformRule): any[] {
    if (typeof rule.operation.function === 'string') {
      const filterFn = this.getBuiltInFilter(rule.operation.function);
      return data.filter(row => filterFn(row[rule.field], row, rule.parameters || {}));
    }

    return data.filter(row => 
      (rule.operation.function as TransformFunction)(
        row[rule.field], 
        row, 
        rule.parameters || {}
      )
    );
  }

  private applyFormatTransform(data: any[], rule: TransformRule): any[] {
    const formatter = this.getBuiltInFormatter(rule.operation.function as string);
    
    return data.map(row => ({
      ...row,
      [rule.field]: formatter(row[rule.field], rule.parameters || {})
    }));
  }

  private applyCalculateTransform(data: any[], rule: TransformRule): any[] {
    return data.map(row => {
      const calculator = this.getBuiltInCalculator(rule.operation.function as string);
      return {
        ...row,
        [rule.field]: calculator(row, rule.parameters || {})
      };
    });
  }

  private getBuiltInTransform(name: string): TransformFunction {
    const transforms: Record<string, TransformFunction> = {
      'uppercase': (value: string) => value?.toUpperCase(),
      'lowercase': (value: string) => value?.toLowerCase(),
      'trim': (value: string) => value?.trim(),
      'truncate': (value: string, row: any, params: { length: number }) => 
        value?.substring(0, params.length),
      'replace': (value: string, row: any, params: { search: string, replace: string }) =>
        value?.replace(new RegExp(params.search, 'g'), params.replace),
      'multiply': (value: number, row: any, params: { factor: number }) =>
        value * params.factor,
      'round': (value: number, row: any, params: { decimals: number }) =>
        Math.round(value * Math.pow(10, params.decimals)) / Math.pow(10, params.decimals)
    };

    return transforms[name] || ((value: any) => value);
  }

  private getBuiltInFilter(name: string): TransformFunction {
    const filters: Record<string, TransformFunction> = {
      'not_null': (value: any) => value != null,
      'not_empty': (value: string) => value != null && value.trim() !== '',
      'greater_than': (value: number, row: any, params: { threshold: number }) =>
        value > params.threshold,
      'less_than': (value: number, row: any, params: { threshold: number }) =>
        value < params.threshold,
      'contains': (value: string, row: any, params: { substring: string }) =>
        value?.includes(params.substring),
      'regex': (value: string, row: any, params: { pattern: string }) =>
        new RegExp(params.pattern).test(value)
    };

    return filters[name] || (() => true);
  }

  private getBuiltInFormatter(name: string): TransformFunction {
    const formatters: Record<string, TransformFunction> = {
      'currency': (value: number, params: { currency: string, locale: string }) =>
        new Intl.NumberFormat(params.locale || 'en-US', {
          style: 'currency',
          currency: params.currency || 'USD'
        }).format(value),
      'date': (value: Date, params: { format: string, locale: string }) =>
        new Intl.DateTimeFormat(params.locale || 'en-US').format(new Date(value)),
      'percentage': (value: number, params: { decimals: number }) =>
        `${(value * 100).toFixed(params.decimals || 2)}%`,
      'phone': (value: string) =>
        value?.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3'),
      'capitalize': (value: string) =>
        value?.split(' ').map(word => 
          word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
        ).join(' ')
    };

    return formatters[name] || ((value: any) => value);
  }

  private getBuiltInCalculator(name: string): TransformFunction {
    const calculators: Record<string, TransformFunction> = {
      'total': (row: any, params: { fields: string[] }) =>
        params.fields.reduce((sum, field) => sum + (row[field] || 0), 0),
      'average': (row: any, params: { fields: string[] }) =>
        params.fields.reduce((sum, field) => sum + (row[field] || 0), 0) / params.fields.length,
      'discount': (row: any, params: { price_field: string, discount_field: string }) =>
        row[params.price_field] * (1 - row[params.discount_field] / 100),
      'age_from_birthdate': (row: any, params: { birthdate_field: string }) => {
        const birthDate = new Date(row[params.birthdate_field]);
        const today = new Date();
        return Math.floor((today.getTime() - birthDate.getTime()) / (365.25 * 24 * 60 * 60 * 1000));
      },
      'days_since': (row: any, params: { date_field: string }) => {
        const date = new Date(row[params.date_field]);
        const today = new Date();
        return Math.floor((today.getTime() - date.getTime()) / (24 * 60 * 60 * 1000));
      }
    };

    return calculators[name] || ((row: any) => null);
  }

  // Pre-built transformation pipelines
  async createUserProfileSummary(userId: string): Promise<any> {
    const user = await this.db('users').where('id', userId).first();
    const orders = await this.db('orders').where('user_id', userId);
    const totalSpent = orders.reduce((sum, order) => sum + order.total, 0);

    return {
      ...user,
      order_count: orders.length,
      total_spent: totalSpent,
      average_order_value: orders.length > 0 ? totalSpent / orders.length : 0,
      last_order_date: orders.length > 0 ? Math.max(...orders.map(o => new Date(o.created_at).getTime())) : null,
      customer_since: user.created_at,
      profile_completeness: this.calculateProfileCompleteness(user)
    };
  }

  private calculateProfileCompleteness(user: any): number {
    const fields = ['name', 'email', 'username'];
    const completed = fields.filter(field => user[field] && user[field].trim() !== '');
    return Math.round((completed.length / fields.length) * 100);
  }
}