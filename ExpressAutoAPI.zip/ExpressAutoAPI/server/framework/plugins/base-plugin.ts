import { Express } from 'express';
import { Knex } from 'knex';
import { FrameworkConfig } from '../config';

export abstract class BasePlugin {
  protected name: string;
  protected version: string;
  protected app?: Express;
  protected db?: Knex;
  protected config?: FrameworkConfig;

  constructor(name: string, version: string = '1.0.0') {
    this.name = name;
    this.version = version;
  }

  /**
   * Initialize the plugin
   * @param app Express application instance
   * @param db Database connection
   * @param config Framework configuration
   */
  async initialize(app: Express, db: Knex, config: FrameworkConfig): Promise<void> {
    this.app = app;
    this.db = db;
    this.config = config;
    
    console.log(`🔌 Initializing plugin: ${this.name} v${this.version}`);
    
    // Override in subclasses
    await this.onInitialize();
  }

  /**
   * Override this method in your plugin
   */
  protected async onInitialize(): Promise<void> {
    // Default implementation - override in subclasses
  }

  /**
   * Add custom routes to the application
   */
  protected addRoute(method: 'get' | 'post' | 'put' | 'delete', path: string, handler: any): void {
    if (!this.app) {
      throw new Error('Plugin not initialized - app is not available');
    }
    
    this.app[method](path, handler);
    console.log(`📍 Plugin ${this.name} added route: ${method.toUpperCase()} ${path}`);
  }

  /**
   * Execute database query
   */
  protected async query(sql: string, params?: any[]): Promise<any> {
    if (!this.db) {
      throw new Error('Plugin not initialized - database is not available');
    }
    
    return this.db.raw(sql, params);
  }

  /**
   * Get plugin information
   */
  getInfo(): { name: string; version: string } {
    return {
      name: this.name,
      version: this.version,
    };
  }

  /**
   * Plugin cleanup (called on server shutdown)
   */
  async cleanup(): Promise<void> {
    // Override in subclasses if needed
  }
}

// Example Analytics Plugin
export class AnalyticsPlugin extends BasePlugin {
  constructor() {
    super('Analytics', '1.0.0');
  }

  protected async onInitialize(): Promise<void> {
    // Add analytics endpoints
    this.addRoute('get', '/api/analytics/tables', this.getTableStats.bind(this));
    this.addRoute('get', '/api/analytics/queries', this.getQueryStats.bind(this));
  }

  private async getTableStats(req: any, res: any): Promise<void> {
    try {
      const tables = await this.query(`
        SELECT 
          schemaname,
          tablename,
          n_tup_ins as inserts,
          n_tup_upd as updates,
          n_tup_del as deletes
        FROM pg_stat_user_tables
        ORDER BY tablename
      `);
      
      res.json({
        timestamp: new Date().toISOString(),
        tables: tables.rows || tables,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch table statistics' });
    }
  }

  private async getQueryStats(req: any, res: any): Promise<void> {
    try {
      // This is a simplified example - actual implementation would vary by database
      res.json({
        timestamp: new Date().toISOString(),
        message: 'Query statistics endpoint - implementation depends on database type',
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch query statistics' });
    }
  }
}
