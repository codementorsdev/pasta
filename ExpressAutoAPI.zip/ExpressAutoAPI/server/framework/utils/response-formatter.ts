import { RelationshipMapper } from '../database/relationship-mapper';

export class ResponseFormatter {
  private relationshipMapper: RelationshipMapper;

  constructor(relationshipMapper: RelationshipMapper) {
    this.relationshipMapper = relationshipMapper;
  }

  async formatList(
    records: any[],
    tableName: string,
    includeRelationships: string[] = []
  ): Promise<any[]> {
    if (!records.length) {
      return records;
    }

    // Load eager relationships
    const eagerRelationships = this.relationshipMapper.getEagerRelationships(tableName);
    const allIncludes = [...includeRelationships];
    
    // Add eager relationships to includes if not already present
    for (const relationship of eagerRelationships) {
      const alias = this.relationshipMapper.getRelationshipAlias(relationship);
      if (!allIncludes.includes(alias)) {
        allIncludes.push(alias);
      }
    }

    // Format each record
    return records.map(record => this.formatSingleRecord(record, tableName, allIncludes));
  }

  async formatSingle(
    record: any,
    tableName: string,
    includeRelationships: string[] = []
  ): Promise<any> {
    if (!record) {
      return record;
    }

    // Load eager relationships
    const eagerRelationships = this.relationshipMapper.getEagerRelationships(tableName);
    const allIncludes = [...includeRelationships];
    
    // Add eager relationships to includes if not already present
    for (const relationship of eagerRelationships) {
      const alias = this.relationshipMapper.getRelationshipAlias(relationship);
      if (!allIncludes.includes(alias)) {
        allIncludes.push(alias);
      }
    }

    return this.formatSingleRecord(record, tableName, allIncludes);
  }

  private formatSingleRecord(
    record: any,
    tableName: string,
    includeRelationships: string[]
  ): any {
    // Create a copy of the record
    const formatted = { ...record };

    // Clean up internal fields (optional)
    delete formatted._meta;

    // Add relationship placeholders for included relationships
    for (const relationshipName of includeRelationships) {
      if (!(relationshipName in formatted)) {
        const relationship = this.relationshipMapper.resolveRelationshipName(tableName, relationshipName);
        if (relationship) {
          if (relationship.type === 'belongsTo' || relationship.type === 'hasOne') {
            formatted[relationshipName] = null;
          } else {
            formatted[relationshipName] = [];
          }
        }
      }
    }

    return formatted;
  }

  formatError(error: Error, statusCode: number = 500): any {
    return {
      error: {
        message: error.message,
        statusCode,
        timestamp: new Date().toISOString(),
      },
    };
  }

  formatValidationError(errors: Record<string, string[]>): any {
    return {
      error: {
        message: 'Validation failed',
        statusCode: 400,
        details: errors,
        timestamp: new Date().toISOString(),
      },
    };
  }

  formatPaginatedResponse(
    data: any[],
    total: number,
    limit: number,
    offset: number
  ): any {
    return {
      data,
      pagination: {
        total,
        limit,
        offset,
        pages: Math.ceil(total / limit),
        currentPage: Math.floor(offset / limit) + 1,
        hasNext: offset + limit < total,
        hasPrev: offset > 0,
      },
    };
  }
}
