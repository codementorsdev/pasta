import { Knex } from 'knex';
import { SchemaIntrospector } from '../database/introspector';
import { RelationshipMapper, Relationship } from '../database/relationship-mapper';

export interface QueryOptions {
  limit?: number;
  offset?: number;
  sort?: string;
  include?: string;
  filters?: Record<string, any>;
}

export class QueryBuilder {
  private db: Knex;
  private introspector: SchemaIntrospector;
  private relationshipMapper: RelationshipMapper;

  constructor(
    db: Knex,
    introspector: SchemaIntrospector,
    relationshipMapper: RelationshipMapper
  ) {
    this.db = db;
    this.introspector = introspector;
    this.relationshipMapper = relationshipMapper;
  }

  async buildListQuery(tableName: string, options: QueryOptions): Promise<Knex.QueryBuilder> {
    let query = this.db(tableName);
    
    // Apply filters
    if (options.filters) {
      query = this.applyFilters(query, options.filters);
    }
    
    // Apply sorting
    if (options.sort) {
      query = this.applySorting(query, tableName, options.sort);
    }
    
    // Apply pagination
    if (options.limit) {
      query = query.limit(options.limit);
    }
    
    if (options.offset) {
      query = query.offset(options.offset);
    }
    
    // Apply eager loading
    const eagerRelationships = this.relationshipMapper.getEagerRelationships(tableName);
    if (eagerRelationships.length > 0) {
      query = await this.applyEagerLoading(query, tableName, eagerRelationships);
    }
    
    return query;
  }

  async buildGetByIdQuery(tableName: string, id: string, options: QueryOptions): Promise<Knex.QueryBuilder> {
    let query = this.db(tableName).where('id', id);
    
    // Apply eager loading
    const eagerRelationships = this.relationshipMapper.getEagerRelationships(tableName);
    if (eagerRelationships.length > 0) {
      query = await this.applyEagerLoading(query, tableName, eagerRelationships);
    }
    
    return query;
  }

  private applyFilters(query: Knex.QueryBuilder, filters: Record<string, any>): Knex.QueryBuilder {
    for (const [field, value] of Object.entries(filters)) {
      if (value !== undefined && value !== null) {
        if (Array.isArray(value)) {
          query = query.whereIn(field, value);
        } else if (typeof value === 'string' && value.includes('%')) {
          query = query.where(field, 'like', value);
        } else {
          query = query.where(field, value);
        }
      }
    }
    return query;
  }

  private applySorting(query: Knex.QueryBuilder, tableName: string, sort: string): Knex.QueryBuilder {
    const sortFields = sort.split(',');
    
    for (const sortField of sortFields) {
      const trimmed = sortField.trim();
      let field = trimmed;
      let direction: 'asc' | 'desc' = 'asc';
      
      if (trimmed.startsWith('-')) {
        field = trimmed.substring(1);
        direction = 'desc';
      } else if (trimmed.startsWith('+')) {
        field = trimmed.substring(1);
      }
      
      // Validate that the field exists in the table
      const tableInfo = this.introspector.getTable(tableName);
      if (tableInfo && tableInfo.columns.some(col => col.name === field)) {
        query = query.orderBy(field, direction);
      }
    }
    
    return query;
  }

  private async applyEagerLoading(
    query: Knex.QueryBuilder,
    tableName: string,
    relationships: Relationship[]
  ): Promise<Knex.QueryBuilder> {
    // For now, we'll handle eager loading in the response formatter
    // Advanced implementations could use JOIN queries here
    return query;
  }

  async loadRelationships(
    records: any[],
    tableName: string,
    relationshipNames: string[]
  ): Promise<any[]> {
    if (!records.length || !relationshipNames.length) {
      return records;
    }

    const relationships = this.relationshipMapper.getRelationships(tableName);
    
    for (const relationshipName of relationshipNames) {
      const relationship = this.relationshipMapper.resolveRelationshipName(tableName, relationshipName);
      
      if (!relationship) {
        continue;
      }
      
      await this.loadSingleRelationship(records, relationship);
    }
    
    return records;
  }

  private async loadSingleRelationship(records: any[], relationship: Relationship): Promise<void> {
    const ids = records.map(record => record[relationship.fromColumn]).filter(id => id != null);
    
    if (ids.length === 0) {
      return;
    }
    
    let relatedRecords: any[] = [];
    
    switch (relationship.type) {
      case 'belongsTo':
      case 'hasOne':
        relatedRecords = await this.db(relationship.toTable)
          .whereIn(relationship.toColumn, ids);
        break;
        
      case 'hasMany':
        relatedRecords = await this.db(relationship.toTable)
          .whereIn(relationship.foreignKey, ids);
        break;
        
      case 'manyToMany':
        // Handle junction table queries
        const junctionTable = relationship.foreignKey; // Junction table name
        relatedRecords = await this.db(relationship.toTable)
          .join(junctionTable, `${relationship.toTable}.id`, `${junctionTable}.${relationship.toTable}_id`)
          .whereIn(`${junctionTable}.${relationship.fromTable}_id`, ids);
        break;
    }
    
    // Map related records to parent records
    const relationshipAlias = this.relationshipMapper.getRelationshipAlias(relationship);
    
    for (const record of records) {
      const recordId = record[relationship.fromColumn];
      
      if (relationship.type === 'belongsTo' || relationship.type === 'hasOne') {
        record[relationshipAlias] = relatedRecords.find(
          rel => rel[relationship.toColumn] === recordId
        ) || null;
      } else {
        record[relationshipAlias] = relatedRecords.filter(
          rel => rel[relationship.foreignKey] === recordId || 
                 rel[`${relationship.fromTable}_id`] === recordId
        );
      }
    }
  }
}
