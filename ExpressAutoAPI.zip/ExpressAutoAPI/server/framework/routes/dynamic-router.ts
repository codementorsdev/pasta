import { Router, Request, Response, NextFunction } from 'express';
import { Knex } from 'knex';
import { SchemaIntrospector, TableInfo } from '../database/introspector';
import { RelationshipMapper, Relationship } from '../database/relationship-mapper';
import { FrameworkConfig } from '../config';
import { QueryBuilder } from '../utils/query-builder';
import { ResponseFormatter } from '../utils/response-formatter';

export interface QueryParams {
  limit?: number;
  offset?: number;
  sort?: string;
  include?: string;
  [key: string]: any;
}

export class DynamicRouter {
  private db: Knex;
  private introspector: SchemaIntrospector;
  private relationshipMapper: RelationshipMapper;
  private config: FrameworkConfig;
  private queryBuilder: QueryBuilder;
  private responseFormatter: ResponseFormatter;

  constructor(
    db: Knex,
    introspector: SchemaIntrospector,
    relationshipMapper: RelationshipMapper,
    config: FrameworkConfig
  ) {
    this.db = db;
    this.introspector = introspector;
    this.relationshipMapper = relationshipMapper;
    this.config = config;
    this.queryBuilder = new QueryBuilder(db, introspector, relationshipMapper);
    this.responseFormatter = new ResponseFormatter(relationshipMapper);
  }

  async generateRoutes(): Promise<Router> {
    const router = Router();
    const tables = this.introspector.getTables();

    console.log('🚀 Generating dynamic routes...');

    for (const tableName of tables) {
      // Check if table is allowed
      if (!this.isTableAllowed(tableName)) {
        continue;
      }

      const tableInfo = this.introspector.getTable(tableName)!;
      
      // Generate CRUD routes for each table
      this.generateTableRoutes(router, tableName, tableInfo);
    }

    console.log(`✅ Generated routes for ${tables.length} tables`);
    return router;
  }

  private generateTableRoutes(router: Router, tableName: string, tableInfo: TableInfo): void {
    const allowedOps = this.getAllowedOperations(tableName);

    // GET /api/tablename - List all records
    if (allowedOps.includes('GET')) {
      router.get(`/${tableName}`, async (req: Request, res: Response, next: NextFunction) => {
        try {
          await this.handleList(req, res, tableName);
        } catch (error) {
          next(error);
        }
      });

      // GET /api/tablename/:id - Get single record
      router.get(`/${tableName}/:id`, async (req: Request, res: Response, next: NextFunction) => {
        try {
          await this.handleGetById(req, res, tableName);
        } catch (error) {
          next(error);
        }
      });
    }

    // POST /api/tablename - Create new record
    if (allowedOps.includes('POST')) {
      router.post(`/${tableName}`, async (req: Request, res: Response, next: NextFunction) => {
        try {
          await this.handleCreate(req, res, tableName, tableInfo);
        } catch (error) {
          next(error);
        }
      });
    }

    // PUT /api/tablename/:id - Update record
    if (allowedOps.includes('PUT')) {
      router.put(`/${tableName}/:id`, async (req: Request, res: Response, next: NextFunction) => {
        try {
          await this.handleUpdate(req, res, tableName, tableInfo);
        } catch (error) {
          next(error);
        }
      });
    }

    // DELETE /api/tablename/:id - Delete record
    if (allowedOps.includes('DELETE')) {
      router.delete(`/${tableName}/:id`, async (req: Request, res: Response, next: NextFunction) => {
        try {
          await this.handleDelete(req, res, tableName);
        } catch (error) {
          next(error);
        }
      });
    }
  }

  private async handleList(req: Request, res: Response, tableName: string): Promise<void> {
    const queryParams = req.query as QueryParams;
    
    // Build base query
    const query = await this.queryBuilder.buildListQuery(tableName, queryParams);
    
    // Execute query
    const results = await query;
    
    // Get total count for pagination
    const countQuery = this.db(tableName).count('* as count');
    const [{ count }] = await countQuery;
    
    // Format response
    const formattedResults = await this.responseFormatter.formatList(
      results,
      tableName,
      queryParams.include?.split(',') || []
    );
    
    res.json({
      data: formattedResults,
      pagination: {
        total: parseInt(count as string),
        limit: queryParams.limit || this.config.pagination?.defaultLimit || 25,
        offset: queryParams.offset || 0,
      },
    });
  }

  private async handleGetById(req: Request, res: Response, tableName: string): Promise<void> {
    const { id } = req.params;
    const queryParams = req.query as QueryParams;
    
    // Build query with ID filter
    const query = await this.queryBuilder.buildGetByIdQuery(tableName, id, queryParams);
    
    // Execute query
    const results = await query;
    
    if (results.length === 0) {
      res.status(404).json({ error: 'Resource not found' });
      return;
    }
    
    // Format response
    const formattedResult = await this.responseFormatter.formatSingle(
      results[0],
      tableName,
      queryParams.include?.split(',') || []
    );
    
    res.json(formattedResult);
  }

  private async handleCreate(req: Request, res: Response, tableName: string, tableInfo: TableInfo): Promise<void> {
    const data = req.body;
    
    // Validate required fields
    this.validateCreateData(data, tableInfo);
    
    // Insert record
    const [result] = await this.db(tableName).insert(data).returning('*');
    
    // Format response
    const formattedResult = await this.responseFormatter.formatSingle(result, tableName, []);
    
    res.status(201).json(formattedResult);
  }

  private async handleUpdate(req: Request, res: Response, tableName: string, tableInfo: TableInfo): Promise<void> {
    const { id } = req.params;
    const data = req.body;
    
    // Validate data
    this.validateUpdateData(data, tableInfo);
    
    // Update record
    const results = await this.db(tableName)
      .where('id', id)
      .update(data)
      .returning('*');
    
    if (results.length === 0) {
      res.status(404).json({ error: 'Resource not found' });
      return;
    }
    
    // Format response
    const formattedResult = await this.responseFormatter.formatSingle(results[0], tableName, []);
    
    res.json(formattedResult);
  }

  private async handleDelete(req: Request, res: Response, tableName: string): Promise<void> {
    const { id } = req.params;
    
    // Delete record
    const deletedCount = await this.db(tableName).where('id', id).del();
    
    if (deletedCount === 0) {
      res.status(404).json({ error: 'Resource not found' });
      return;
    }
    
    res.status(204).send();
  }

  private isTableAllowed(tableName: string): boolean {
    const accessControl = this.config.accessControl;
    
    if (!accessControl) {
      return true;
    }
    
    // Check blacklist first
    if (accessControl.blacklistTables?.includes(tableName)) {
      return false;
    }
    
    // Check whitelist
    if (accessControl.whitelistTables && accessControl.whitelistTables.length > 0) {
      return accessControl.whitelistTables.includes(tableName);
    }
    
    return true;
  }

  private getAllowedOperations(tableName: string): string[] {
    const accessControl = this.config.accessControl;
    
    if (!accessControl) {
      return ['GET', 'POST', 'PUT', 'DELETE'];
    }
    
    // Check table specific operations
    const tableOps = accessControl.operations?.[tableName];
    if (tableOps) {
      return tableOps;
    }
    
    // Return default operations
    return accessControl.defaultOperations || ['GET'];
  }

  private validateCreateData(data: any, tableInfo: TableInfo): void {
    const requiredColumns = tableInfo.columns.filter(
      col => !col.nullable && !col.defaultValue && !col.isPrimaryKey
    );
    
    for (const column of requiredColumns) {
      if (!(column.name in data) || data[column.name] === null || data[column.name] === undefined) {
        throw new Error(`Missing required field: ${column.name}`);
      }
    }
  }

  private validateUpdateData(data: any, tableInfo: TableInfo): void {
    // Remove primary key fields from update data
    const primaryKeys = tableInfo.primaryKeys;
    for (const pk of primaryKeys) {
      delete data[pk];
    }
    
    // Validate column types (basic validation)
    for (const [key, value] of Object.entries(data)) {
      const column = tableInfo.columns.find(col => col.name === key);
      if (column && !column.nullable && (value === null || value === undefined)) {
        throw new Error(`Field ${key} cannot be null`);
      }
    }
  }
}
