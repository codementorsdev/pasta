#!/usr/bin/env node

import { Command } from 'commander';
import fs from 'fs';
import path from 'path';
import { ConfigManager } from '../config';
import { DBAPIFramework } from '../index';

const program = new Command();

program
  .name('db-api')
  .description('DB-API Framework CLI')
  .version('1.0.0');

// Initialize command
program
  .command('init')
  .description('Initialize a new DB-API Framework project')
  .option('-c, --config <path>', 'Configuration file path', 'config.yaml')
  .action(async (options) => {
    try {
      console.log('🚀 Initializing DB-API Framework project...');
      
      const configPath = options.config;
      
      // Create sample configuration
      if (!fs.existsSync(configPath)) {
        const sampleConfig = ConfigManager.generateSampleConfig();
        fs.writeFileSync(configPath, sampleConfig);
        console.log(`✅ Created sample configuration: ${configPath}`);
      } else {
        console.log(`⏭️  Configuration file already exists: ${configPath}`);
      }
      
      // Create plugins directory
      if (!fs.existsSync('plugins')) {
        fs.mkdirSync('plugins');
        console.log('✅ Created plugins directory');
        
        // Create sample plugin
        const samplePlugin = `const { BasePlugin } = require('db-api-framework');

class SamplePlugin extends BasePlugin {
  async initialize(app, db, config) {
    console.log('Sample plugin initialized');
    
    // Add custom routes
    app.get('/api/custom/hello', (req, res) => {
      res.json({ message: 'Hello from custom endpoint!' });
    });
  }
}

module.exports = SamplePlugin;
`;
        fs.writeFileSync('plugins/sample.js', samplePlugin);
        console.log('✅ Created sample plugin: plugins/sample.js');
      }
      
      console.log('🎉 Project initialized successfully!');
      console.log('📝 Next steps:');
      console.log(`   1. Edit ${configPath} to configure your database`);
      console.log('   2. Run: db-api start');
      
    } catch (error) {
      console.error('❌ Initialization failed:', error);
      process.exit(1);
    }
  });

// Start command
program
  .command('start')
  .description('Start the DB-API Framework server')
  .option('-c, --config <path>', 'Configuration file path')
  .option('-p, --port <number>', 'Server port', '3000')
  .option('-h, --host <string>', 'Server host', '0.0.0.0')
  .action(async (options) => {
    try {
      console.log('🚀 Starting DB-API Framework server...');
      
      const framework = new DBAPIFramework(options.config);
      await framework.initialize();
      
      const port = parseInt(options.port, 10);
      const host = options.host;
      
      await framework.start(port, host);
      
      // Handle graceful shutdown
      process.on('SIGINT', () => {
        console.log('\n👋 Shutting down gracefully...');
        process.exit(0);
      });
      
    } catch (error) {
      console.error('❌ Failed to start server:', error);
      process.exit(1);
    }
  });

// Validate command
program
  .command('validate')
  .description('Validate configuration file')
  .option('-c, --config <path>', 'Configuration file path')
  .action(async (options) => {
    try {
      console.log('🔍 Validating configuration...');
      
      const config = ConfigManager.load(options.config);
      console.log('✅ Configuration is valid');
      console.log('📋 Configuration summary:');
      console.log(`   Database: ${config.database.type}`);
      console.log(`   Host: ${config.database.host || 'N/A'}`);
      console.log(`   Tables: ${config.accessControl?.whitelistTables?.length || 'All'} allowed`);
      
    } catch (error) {
      console.error('❌ Configuration validation failed:', error);
      process.exit(1);
    }
  });

// Info command
program
  .command('info')
  .description('Show framework information')
  .option('-c, --config <path>', 'Configuration file path')
  .action(async (options) => {
    try {
      const config = ConfigManager.load(options.config);
      
      console.log('📊 DB-API Framework Information');
      console.log('================================');
      console.log(`Version: 1.0.0`);
      console.log(`Database Type: ${config.database.type}`);
      console.log(`Pagination Limit: ${config.pagination?.defaultLimit || 25}`);
      console.log(`Max Limit: ${config.pagination?.maxLimit || 100}`);
      
      if (config.accessControl?.whitelistTables) {
        console.log(`Allowed Tables: ${config.accessControl.whitelistTables.join(', ')}`);
      }
      
      if (config.plugins) {
        console.log(`Plugins: ${config.plugins.length}`);
        config.plugins.forEach(plugin => {
          console.log(`  - ${plugin.name} (${plugin.enabled ? 'enabled' : 'disabled'})`);
        });
      }
      
    } catch (error) {
      console.error('❌ Failed to load configuration:', error);
      process.exit(1);
    }
  });

program.parse();
