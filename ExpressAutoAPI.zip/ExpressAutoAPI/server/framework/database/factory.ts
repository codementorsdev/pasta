import knex, { Knex } from 'knex';
import { DatabaseConfig } from '../config';

export class DatabaseFactory {
  static async create(config: DatabaseConfig): Promise<Knex> {
    let knexConfig: Knex.Config;

    switch (config.type) {
      case 'postgres':
        knexConfig = {
          client: 'pg',
          connection: config.connectionString || {
            host: config.host,
            port: config.port,
            user: config.user,
            password: config.password,
            database: config.database,
          },
          pool: config.pool || {
            min: 2,
            max: 10,
          },
        };
        break;

      case 'mysql':
        knexConfig = {
          client: 'mysql2',
          connection: config.connectionString || {
            host: config.host,
            port: config.port,
            user: config.user,
            password: config.password,
            database: config.database,
          },
          pool: config.pool || {
            min: 2,
            max: 10,
          },
        };
        break;

      case 'sqlite':
        knexConfig = {
          client: 'sqlite3',
          connection: {
            filename: config.filename || config.database || 'database.sqlite',
          },
          useNullAsDefault: true,
        };
        break;

      case 'mssql':
        knexConfig = {
          client: 'mssql',
          connection: config.connectionString || {
            server: config.host,
            port: config.port,
            user: config.user,
            password: config.password,
            database: config.database,
            options: {
              encrypt: true,
              trustServerCertificate: true,
            },
          },
          pool: config.pool || {
            min: 2,
            max: 10,
          },
        };
        break;

      case 'oracle':
        knexConfig = {
          client: 'oracledb',
          connection: config.connectionString || {
            host: config.host,
            port: config.port,
            user: config.user,
            password: config.password,
            database: config.database,
          },
          pool: config.pool || {
            min: 2,
            max: 10,
          },
        };
        break;

      default:
        throw new Error(`Unsupported database type: ${config.type}`);
    }

    const db = knex(knexConfig);

    // Test connection
    try {
      await db.raw('SELECT 1');
      console.log(`✅ Connected to ${config.type} database`);
    } catch (error) {
      console.error(`❌ Failed to connect to ${config.type} database:`, error);
      throw error;
    }

    return db;
  }
}
