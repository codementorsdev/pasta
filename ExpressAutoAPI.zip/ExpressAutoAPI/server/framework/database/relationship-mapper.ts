import { TableInfo, ForeignKeyInfo } from './introspector';
import { RelationshipConfig } from '../config';

export interface Relationship {
  type: 'hasOne' | 'hasMany' | 'belongsTo' | 'manyToMany';
  fromTable: string;
  toTable: string;
  fromColumn: string;
  toColumn: string;
  foreignKey: string;
  loadType: 'eager' | 'lazy';
}

export class RelationshipMapper {
  private schema: Map<string, TableInfo>;
  private config: RelationshipConfig;
  private relationships: Map<string, Relationship[]> = new Map();

  constructor(schema: Map<string, TableInfo>, config: RelationshipConfig = {}) {
    this.schema = schema;
    this.config = config;
  }

  async mapRelationships(): Promise<void> {
    console.log('🔗 Mapping table relationships...');
    
    // Clear existing relationships
    this.relationships.clear();
    
    // Map foreign key relationships
    for (const [tableName, tableInfo] of this.schema) {
      const tableRelationships: Relationship[] = [];
      
      // Process foreign keys (belongsTo relationships)
      for (const fk of tableInfo.foreignKeys) {
        const belongsToRel: Relationship = {
          type: 'belongsTo',
          fromTable: tableName,
          toTable: fk.referencedTable,
          fromColumn: fk.columnName,
          toColumn: fk.referencedColumn,
          foreignKey: fk.columnName,
          loadType: this.getLoadType(tableName, fk.referencedTable),
        };
        tableRelationships.push(belongsToRel);
        
        // Create corresponding hasMany/hasOne relationship
        const referencedTableRels = this.relationships.get(fk.referencedTable) || [];
        const hasRel: Relationship = {
          type: 'hasMany', // Default to hasMany, could be refined later
          fromTable: fk.referencedTable,
          toTable: tableName,
          fromColumn: fk.referencedColumn,
          toColumn: fk.columnName,
          foreignKey: fk.columnName,
          loadType: this.getLoadType(fk.referencedTable, tableName),
        };
        referencedTableRels.push(hasRel);
        this.relationships.set(fk.referencedTable, referencedTableRels);
      }
      
      this.relationships.set(tableName, tableRelationships);
    }
    
    // Detect many-to-many relationships through junction tables
    this.detectManyToManyRelationships();
    
    console.log(`✅ Mapped relationships for ${this.relationships.size} tables`);
  }

  private detectManyToManyRelationships(): void {
    for (const [tableName, tableInfo] of this.schema) {
      // A junction table typically has:
      // 1. Only foreign key columns (and maybe an ID)
      // 2. Exactly 2 foreign keys
      // 3. No other significant columns
      
      if (tableInfo.foreignKeys.length === 2) {
        const nonFkColumns = tableInfo.columns.filter(col => 
          !col.isForeignKey && !col.isPrimaryKey
        );
        
        // If there are few non-FK columns, this might be a junction table
        if (nonFkColumns.length <= 1) {
          const [fk1, fk2] = tableInfo.foreignKeys;
          
          // Create many-to-many relationships
          this.createManyToManyRelationship(fk1.referencedTable, fk2.referencedTable, tableName);
          this.createManyToManyRelationship(fk2.referencedTable, fk1.referencedTable, tableName);
        }
      }
    }
  }

  private createManyToManyRelationship(fromTable: string, toTable: string, junctionTable: string): void {
    const fromTableRels = this.relationships.get(fromTable) || [];
    
    const manyToManyRel: Relationship = {
      type: 'manyToMany',
      fromTable,
      toTable,
      fromColumn: '', // Will be determined at query time
      toColumn: '',   // Will be determined at query time
      foreignKey: junctionTable, // Use junction table name as foreign key
      loadType: this.getLoadType(fromTable, toTable),
    };
    
    fromTableRels.push(manyToManyRel);
    this.relationships.set(fromTable, fromTableRels);
  }

  private getLoadType(fromTable: string, toTable: string): 'eager' | 'lazy' {
    // Check eager load configuration
    const eagerTables = this.config.eagerLoad?.[fromTable] || [];
    if (eagerTables.includes(toTable)) {
      return 'eager';
    }
    
    // Check lazy load configuration
    const lazyTables = this.config.lazyLoad?.[fromTable] || [];
    if (lazyTables.includes(toTable)) {
      return 'lazy';
    }
    
    // Default to lazy loading
    return 'lazy';
  }

  getRelationships(tableName: string): Relationship[] {
    return this.relationships.get(tableName) || [];
  }

  getAllRelationships(): Map<string, Relationship[]> {
    return this.relationships;
  }

  getEagerRelationships(tableName: string): Relationship[] {
    return this.getRelationships(tableName).filter(rel => rel.loadType === 'eager');
  }

  getLazyRelationships(tableName: string): Relationship[] {
    return this.getRelationships(tableName).filter(rel => rel.loadType === 'lazy');
  }

  canIncludeRelationship(tableName: string, relationshipName: string): boolean {
    const relationships = this.getRelationships(tableName);
    return relationships.some(rel => 
      rel.toTable === relationshipName || 
      this.getRelationshipAlias(rel) === relationshipName
    );
  }

  getRelationshipAlias(relationship: Relationship): string {
    // Generate a friendly alias for the relationship
    if (relationship.type === 'belongsTo') {
      return relationship.toTable.replace(/s$/, ''); // Remove trailing 's' for singular
    } else if (relationship.type === 'hasMany') {
      return relationship.toTable; // Keep plural for collections
    } else if (relationship.type === 'manyToMany') {
      return relationship.toTable; // Keep plural for collections
    }
    return relationship.toTable;
  }

  resolveRelationshipName(tableName: string, includeParam: string): Relationship | null {
    const relationships = this.getRelationships(tableName);
    
    // Try exact table name match first
    let relationship = relationships.find(rel => rel.toTable === includeParam);
    
    // Try alias match
    if (!relationship) {
      relationship = relationships.find(rel => 
        this.getRelationshipAlias(rel) === includeParam
      );
    }
    
    return relationship || null;
  }
}
