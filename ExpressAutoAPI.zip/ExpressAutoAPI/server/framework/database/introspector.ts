import { Knex } from 'knex';

export interface TableInfo {
  name: string;
  columns: ColumnInfo[];
  primaryKeys: string[];
  foreignKeys: ForeignKeyInfo[];
}

export interface ColumnInfo {
  name: string;
  type: string;
  nullable: boolean;
  defaultValue: any;
  isPrimaryKey: boolean;
  isForeignKey: boolean;
  maxLength?: number;
  precision?: number;
  scale?: number;
}

export interface ForeignKeyInfo {
  columnName: string;
  referencedTable: string;
  referencedColumn: string;
  constraintName: string;
}

export class SchemaIntrospector {
  private db: Knex;
  private dbType: string;
  private schema: Map<string, TableInfo> = new Map();

  constructor(db: Knex, dbType: string) {
    this.db = db;
    this.dbType = dbType;
  }

  async introspect(): Promise<void> {
    console.log('🔍 Introspecting database schema...');
    
    try {
      const tables = await this.getTablesFromDatabase();
      console.log(`📋 Found ${tables.length} tables:`, tables);
      
      for (const tableName of tables) {
        const tableInfo = await this.getTableInfo(tableName);
        this.schema.set(tableName, tableInfo);
      }
      
      console.log(`✅ Introspected ${tables.length} tables`);
    } catch (error) {
      console.error('❌ Error during introspection:', error);
    }
  }

  private async getTablesFromDatabase(): Promise<string[]> {
    try {
      console.log(`🔍 Getting tables for database type: ${this.dbType}`);
      
      switch (this.dbType) {
        case 'postgres':
          const pgResult = await this.db.raw(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_type = 'BASE TABLE'
          `);
          console.log(`📊 Found PostgreSQL tables:`, pgResult.rows);
          return pgResult.rows.map((row: any) => row.table_name);

        case 'mysql':
          const mysqlResult = await this.db.raw(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = DATABASE() 
            AND table_type = 'BASE TABLE'
          `);
          return mysqlResult[0].map((row: any) => row.TABLE_NAME);

        case 'sqlite':
          const sqliteResult = await this.db.raw(`
            SELECT name 
            FROM sqlite_master 
            WHERE type = 'table' 
            AND name NOT LIKE 'sqlite_%'
          `);
          return sqliteResult.map((row: any) => row.name);

        case 'mssql':
          const mssqlResult = await this.db.raw(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_type = 'BASE TABLE'
          `);
          return mssqlResult.map((row: any) => row.table_name);

        default:
          throw new Error(`Table introspection not implemented for ${this.dbType}`);
      }
    } catch (error) {
      console.error('❌ Error getting tables:', error);
      return [];
    }
  }

  private async getTableInfo(tableName: string): Promise<TableInfo> {
    const columns = await this.getColumns(tableName);
    const primaryKeys = await this.getPrimaryKeys(tableName);
    const foreignKeys = await this.getForeignKeys(tableName);

    return {
      name: tableName,
      columns,
      primaryKeys,
      foreignKeys,
    };
  }

  private async getColumns(tableName: string): Promise<ColumnInfo[]> {
    switch (this.dbType) {
      case 'postgres':
        const pgResult = await this.db.raw(`
          SELECT 
            column_name,
            data_type,
            is_nullable,
            column_default,
            character_maximum_length,
            numeric_precision,
            numeric_scale
          FROM information_schema.columns 
          WHERE table_name = ? 
          AND table_schema = 'public'
          ORDER BY ordinal_position
        `, [tableName]);
        
        return pgResult.rows.map((row: any) => ({
          name: row.column_name,
          type: this.mapDataType(row.data_type, this.dbType),
          nullable: row.is_nullable === 'YES',
          defaultValue: row.column_default,
          isPrimaryKey: false, // Will be set later
          isForeignKey: false, // Will be set later
          maxLength: row.character_maximum_length,
          precision: row.numeric_precision,
          scale: row.numeric_scale,
        }));

      case 'mysql':
        const mysqlResult = await this.db.raw(`
          SELECT 
            column_name,
            data_type,
            is_nullable,
            column_default,
            character_maximum_length,
            numeric_precision,
            numeric_scale
          FROM information_schema.columns 
          WHERE table_name = ? 
          AND table_schema = DATABASE()
          ORDER BY ordinal_position
        `, [tableName]);
        
        return mysqlResult[0].map((row: any) => ({
          name: row.COLUMN_NAME,
          type: this.mapDataType(row.DATA_TYPE, this.dbType),
          nullable: row.IS_NULLABLE === 'YES',
          defaultValue: row.COLUMN_DEFAULT,
          isPrimaryKey: false,
          isForeignKey: false,
          maxLength: row.CHARACTER_MAXIMUM_LENGTH,
          precision: row.NUMERIC_PRECISION,
          scale: row.NUMERIC_SCALE,
        }));

      case 'sqlite':
        const sqliteResult = await this.db.raw(`PRAGMA table_info(${tableName})`);
        
        return sqliteResult.map((row: any) => ({
          name: row.name,
          type: this.mapDataType(row.type, this.dbType),
          nullable: !row.notnull,
          defaultValue: row.dflt_value,
          isPrimaryKey: !!row.pk,
          isForeignKey: false,
        }));

      default:
        throw new Error(`Column introspection not implemented for ${this.dbType}`);
    }
  }

  private async getPrimaryKeys(tableName: string): Promise<string[]> {
    switch (this.dbType) {
      case 'postgres':
        const pgResult = await this.db.raw(`
          SELECT column_name
          FROM information_schema.key_column_usage
          WHERE table_name = ?
          AND constraint_name IN (
            SELECT constraint_name
            FROM information_schema.table_constraints
            WHERE table_name = ? AND constraint_type = 'PRIMARY KEY'
          )
        `, [tableName, tableName]);
        return pgResult.rows.map((row: any) => row.column_name);

      case 'mysql':
        const mysqlResult = await this.db.raw(`
          SELECT column_name
          FROM information_schema.key_column_usage
          WHERE table_name = ? AND constraint_name = 'PRIMARY'
        `, [tableName]);
        return mysqlResult[0].map((row: any) => row.COLUMN_NAME);

      case 'sqlite':
        const sqliteResult = await this.db.raw(`PRAGMA table_info(${tableName})`);
        return sqliteResult.filter((row: any) => row.pk).map((row: any) => row.name);

      default:
        return [];
    }
  }

  private async getForeignKeys(tableName: string): Promise<ForeignKeyInfo[]> {
    switch (this.dbType) {
      case 'postgres':
        const pgResult = await this.db.raw(`
          SELECT 
            kcu.column_name,
            ccu.table_name AS referenced_table,
            ccu.column_name AS referenced_column,
            tc.constraint_name
          FROM information_schema.table_constraints tc
          JOIN information_schema.key_column_usage kcu 
            ON tc.constraint_name = kcu.constraint_name
          JOIN information_schema.constraint_column_usage ccu 
            ON ccu.constraint_name = tc.constraint_name
          WHERE tc.constraint_type = 'FOREIGN KEY' 
            AND tc.table_name = ?
        `, [tableName]);
        
        return pgResult.rows.map((row: any) => ({
          columnName: row.column_name,
          referencedTable: row.referenced_table,
          referencedColumn: row.referenced_column,
          constraintName: row.constraint_name,
        }));

      case 'sqlite':
        const sqliteResult = await this.db.raw(`PRAGMA foreign_key_list(${tableName})`);
        
        return sqliteResult.map((row: any) => ({
          columnName: row.from,
          referencedTable: row.table,
          referencedColumn: row.to,
          constraintName: `fk_${tableName}_${row.from}`,
        }));

      default:
        return [];
    }
  }

  private mapDataType(dbType: string, dbEngine: string): string {
    const typeMap: Record<string, Record<string, string>> = {
      postgres: {
        'character varying': 'string',
        'varchar': 'string',
        'text': 'string',
        'integer': 'number',
        'bigint': 'number',
        'numeric': 'number',
        'decimal': 'number',
        'real': 'number',
        'double precision': 'number',
        'boolean': 'boolean',
        'timestamp': 'date',
        'timestamptz': 'date',
        'date': 'date',
        'uuid': 'string',
      },
      mysql: {
        'varchar': 'string',
        'text': 'string',
        'int': 'number',
        'bigint': 'number',
        'decimal': 'number',
        'float': 'number',
        'double': 'number',
        'boolean': 'boolean',
        'tinyint': 'boolean',
        'timestamp': 'date',
        'datetime': 'date',
        'date': 'date',
      },
      sqlite: {
        'TEXT': 'string',
        'INTEGER': 'number',
        'REAL': 'number',
        'BLOB': 'buffer',
        'NUMERIC': 'number',
      },
    };

    return typeMap[dbEngine]?.[dbType.toLowerCase()] || 'string';
  }

  getSchema(): Map<string, TableInfo> {
    return this.schema;
  }

  getTable(tableName: string): TableInfo | undefined {
    return this.schema.get(tableName);
  }

  getTables(): string[] {
    return Array.from(this.schema.keys());
  }
}
