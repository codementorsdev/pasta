import { Request, Response, NextFunction } from 'express';
import { RelationshipMapper } from '../database/relationship-mapper';
import { RelationshipConfig } from '../config';

export class RelationshipLoaderMiddleware {
  static create(relationshipMapper: RelationshipMapper, config?: RelationshipConfig) {
    return (req: Request, res: Response, next: NextFunction) => {
      const path = req.path;
      const include = req.query.include as string;
      
      // Extract table name from path
      const pathParts = path.split('/').filter(part => part);
      if (pathParts.length === 0) {
        return next();
      }
      
      const tableName = pathParts[0];
      
      // Validate include parameters
      if (include) {
        const includeList = include.split(',').map(rel => rel.trim());
        const invalidRelationships: string[] = [];
        
        for (const relationshipName of includeList) {
          if (!relationshipMapper.canIncludeRelationship(tableName, relationshipName)) {
            invalidRelationships.push(relationshipName);
          }
        }
        
        if (invalidRelationships.length > 0) {
          return res.status(400).json({
            error: 'Invalid relationships',
            message: `The following relationships are not valid for table '${tableName}': ${invalidRelationships.join(', ')}`,
            availableRelationships: relationshipMapper.getRelationships(tableName)
              .map(rel => relationshipMapper.getRelationshipAlias(rel)),
          });
        }
      }
      
      // Add relationship info to request
      (req as any).relationships = {
        tableName,
        include: include ? include.split(',').map(rel => rel.trim()) : [],
        eager: relationshipMapper.getEagerRelationships(tableName),
        lazy: relationshipMapper.getLazyRelationships(tableName),
      };
      
      next();
    };
  }
}
