import { Request, Response, NextFunction } from 'express';
import { PaginationConfig } from '../config';

export interface PaginationParams {
  limit: number;
  offset: number;
}

export class PaginationMiddleware {
  static create(config?: PaginationConfig) {
    return (req: Request, res: Response, next: NextFunction) => {
      const defaultLimit = config?.defaultLimit || 25;
      const maxLimit = config?.maxLimit || 100;
      const defaultOffset = config?.defaultOffset || 0;
      
      // Parse limit parameter
      let limit = defaultLimit;
      if (req.query.limit) {
        const parsedLimit = parseInt(req.query.limit as string, 10);
        if (!isNaN(parsedLimit) && parsedLimit > 0) {
          limit = Math.min(parsedLimit, maxLimit);
        }
      }
      
      // Parse offset parameter
      let offset = defaultOffset;
      if (req.query.offset) {
        const parsedOffset = parseInt(req.query.offset as string, 10);
        if (!isNaN(parsedOffset) && parsedOffset >= 0) {
          offset = parsedOffset;
        }
      }
      
      // Add pagination params to request
      (req as any).pagination = { limit, offset };
      
      next();
    };
  }
}
