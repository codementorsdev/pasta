import { Request, Response, NextFunction } from 'express';

export interface APIError extends Error {
  statusCode?: number;
  code?: string;
}

export class ErrorHandlerMiddleware {
  static create() {
    return (error: APIError, req: Request, res: Response, next: NextFunction) => {
      console.error('API Error:', error);
      
      // Default error response
      let statusCode = error.statusCode || 500;
      let message = error.message || 'Internal Server Error';
      let code = error.code || 'INTERNAL_ERROR';
      
      // Handle specific error types
      if (error.message?.includes('duplicate key') || error.message?.includes('UNIQUE constraint')) {
        statusCode = 409;
        message = 'Resource already exists';
        code = 'DUPLICATE_RESOURCE';
      } else if (error.message?.includes('foreign key constraint')) {
        statusCode = 400;
        message = 'Invalid reference to related resource';
        code = 'INVALID_REFERENCE';
      } else if (error.message?.includes('not found')) {
        statusCode = 404;
        message = 'Resource not found';
        code = 'NOT_FOUND';
      } else if (error.message?.includes('Missing required field')) {
        statusCode = 400;
        code = 'VALIDATION_ERROR';
      } else if (error.message?.includes('Access denied') || error.message?.includes('not allowed')) {
        statusCode = 403;
        code = 'ACCESS_DENIED';
      }
      
      // Send error response
      res.status(statusCode).json({
        error: {
          code,
          message,
          statusCode,
          ...(process.env.NODE_ENV === 'development' && {
            stack: error.stack,
            details: error,
          }),
        },
      });
    };
  }
}
