import { Request, Response, NextFunction } from 'express';
import { AccessControlConfig } from '../config';

export class AccessControlMiddleware {
  static create(config?: AccessControlConfig) {
    return (req: Request, res: Response, next: NextFunction) => {
      if (!config) {
        return next();
      }

      const path = req.path;
      const method = req.method;
      
      // Skip access control for documentation and custom endpoints
      if (path.startsWith('/docs') || 
          path.startsWith('/api-docs') || 
          path.startsWith('/swagger') ||
          path.startsWith('/custom')) {
        return next();
      }
      
      // Extract table name from path (e.g., /api/users -> users)
      const pathParts = path.split('/').filter(part => part);
      if (pathParts.length === 0) {
        return next();
      }
      
      // Skip access control for custom endpoints (e.g., /api/custom/*)
      if (pathParts.length > 1 && pathParts[1] === 'custom') {
        return next();
      }
      
      const tableName = pathParts[0];
      
      // Check if table is blacklisted
      if (config.blacklistTables?.includes(tableName)) {
        return res.status(403).json({
          error: 'Access denied',
          message: `Table '${tableName}' is not accessible`,
        });
      }
      
      // Check if table is whitelisted (if whitelist exists)
      if (config.whitelistTables && config.whitelistTables.length > 0) {
        if (!config.whitelistTables.includes(tableName)) {
          return res.status(403).json({
            error: 'Access denied',
            message: `Table '${tableName}' is not in the allowed list`,
          });
        }
      }
      
      // Check if operation is allowed for this table
      const allowedOps = config.operations?.[tableName] || config.defaultOperations || ['GET'];
      if (!allowedOps.includes(method)) {
        return res.status(403).json({
          error: 'Operation not allowed',
          message: `${method} operation is not allowed on table '${tableName}'`,
        });
      }
      
      next();
    };
  }
}
