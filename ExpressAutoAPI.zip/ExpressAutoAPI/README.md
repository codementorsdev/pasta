# DB-API Framework

> A production-grade Node.js/Express.js library that automatically generates REST APIs from any relational database. Zero configuration, maximum productivity.

[![NPM Version](https://img.shields.io/badge/npm-v1.0.0-blue)](https://www.npmjs.com/package/db-api-framework)
[![License](https://img.shields.io/badge/license-MIT-green)](https://github.com/db-api-framework/db-api-framework/blob/main/LICENSE)
[![Node.js](https://img.shields.io/badge/node-%3E%3D16.0.0-brightgreen)](https://nodejs.org/)

## ✨ Features

- 🗄️ **Multi-Database Support** - PostgreSQL, MySQL, SQLite, MSSQL, Oracle
- 🔍 **Automatic Schema Introspection** - Discovers tables, columns, and relationships at runtime
- 🚀 **Zero-Config CRUD APIs** - RESTful endpoints generated automatically
- 🔐 **Granular Access Control** - Table and operation-level permissions
- 🔗 **Smart Relationship Loading** - Configurable eager/lazy loading with query optimization
- 📄 **Auto-Generated Documentation** - Interactive Swagger/OpenAPI 3.0 docs
- 📦 **Plugin Architecture** - Extensible with custom endpoints and business logic
- ⚡ **Production Ready** - Connection pooling, error handling, logging
- 🎛️ **YAML Configuration** - Simple, declarative configuration
- 🔄 **Hot Reload** - Schema changes detected automatically

## 🚀 Quick Start

### Prerequisites

- Node.js 16.0.0 or higher
- Database (PostgreSQL, MySQL, SQLite, MSSQL, or Oracle)

### Installation

```bash
# Install globally for CLI usage
npm install -g db-api-framework

# Or install locally in your project
npm install db-api-framework
```

### Basic Usage

1. **Initialize a new project:**
```bash
db-api init my-project
cd my-project
```

2. **Create your configuration (`config.yaml`):**
```yaml
database:
  type: postgres
  connectionString: ${DATABASE_URL}
  pool:
    min: 2
    max: 10

accessControl:
  whitelistTables:
    - users
    - orders
    - products
  operations:
    users: [GET, POST, PUT]
    orders: [GET, POST]
    products: [GET, PUT]

pagination:
  defaultLimit: 25
  maxLimit: 100
```

3. **Start the server:**
```bash
# Using the CLI
db-api start

# Or programmatically
npm start
```

4. **Access your auto-generated APIs:**
- REST API: `http://localhost:5000/api/users`
- Documentation: `http://localhost:5000/docs`
- OpenAPI Spec: `http://localhost:5000/api-docs.json`

## 📖 Complete Setup Guide

### 1. Database Configuration

The framework supports multiple database types with automatic connection pooling:

#### PostgreSQL
```yaml
database:
  type: postgres
  connectionString: postgresql://user:password@host:5432/database
  # Or individual parameters
  host: localhost
  port: 5432
  user: postgres
  password: secret
  database: myapp
  pool:
    min: 2
    max: 10
```

#### MySQL
```yaml
database:
  type: mysql
  host: localhost
  port: 3306
  user: root
  password: secret
  database: myapp
```

#### SQLite
```yaml
database:
  type: sqlite
  filename: ./database.sqlite
```

### 2. Access Control Configuration

Control which tables and operations are exposed:

```yaml
accessControl:
  # Allow only specific tables
  whitelistTables:
    - users
    - orders
    - products
    - order_items
  
  # Block specific tables  
  blacklistTables:
    - internal_logs
    - migrations
  
  # Control operations per table
  operations:
    users: [GET, POST, PUT]     # Users can be read, created, updated
    orders: [GET, POST]         # Orders are read-only after creation
    products: [GET, PUT]        # Products can be read and updated
    order_items: [GET, POST, PUT, DELETE]  # Full CRUD
  
  # Default operations for tables not explicitly configured
  defaultOperations: [GET]
```

### 3. Pagination & Sorting

Configure default pagination and sorting behavior:

```yaml
pagination:
  defaultLimit: 25
  maxLimit: 100
  defaultOffset: 0

sorting:
  defaultFields:
    users: [created_at]
    orders: [order_date]
  allowedFields:
    users: [id, username, created_at, email]
    orders: [id, order_date, total_amount, status]
```

### 4. Relationship Management

Configure how related data is loaded:

```yaml
relationships:
  # Always load these relationships
  eagerLoad:
    orders:
      - user          # Load user info with orders
      - order_items   # Load items with orders
    order_items:
      - product       # Load product info with order items
  
  # Load relationships only when requested
  lazyLoad:
    users:
      - orders        # Load user orders on demand
    products:
      - order_items   # Load product order items on demand
  
  maxDepth: 3         # Maximum relationship depth to prevent infinite loops
```

## 🔌 API Usage Examples

### Basic CRUD Operations

**Get all users:**
```bash
GET /api/users
```

**Get users with pagination:**
```bash
GET /api/users?limit=10&offset=20
```

**Get users with sorting:**
```bash
GET /api/users?sort=created_at,-username
```

**Get specific user:**
```bash
GET /api/users/123
```

**Create new user:**
```bash
POST /api/users
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "name": "John Doe"
}
```

**Update user:**
```bash
PUT /api/users/123
Content-Type: application/json

{
  "name": "John Smith",
  "email": "john.smith@example.com"
}
```

**Delete user:**
```bash
DELETE /api/users/123
```

### Advanced Querying

**Include related data:**
```bash
GET /api/orders?include=user,order_items
GET /api/orders/123?include=user,order_items.product
```

**Filter by fields:**
```bash
GET /api/products?category_id=1&active=true
GET /api/orders?status=pending&total_amount>=100
```

**Complex sorting:**
```bash
GET /api/products?sort=category_id,price,-created_at
```

## 🔧 Programmatic Usage

### Basic Server Setup

```javascript
const { DBAPIFramework } = require('db-api-framework');

// Initialize framework
const framework = new DBAPIFramework('./config.yaml');

// Start server
async function startServer() {
  await framework.initialize();
  const app = framework.getApp();
  
  app.listen(5000, () => {
    console.log('DB-API Framework running on port 5000');
    console.log('Documentation: http://localhost:5000/docs');
  });
}

startServer();
```

### Express Integration

```javascript
const express = require('express');
const { DBAPIFramework } = require('db-api-framework');

const app = express();
const framework = new DBAPIFramework();

// Initialize framework
framework.initialize().then(() => {
  // Mount the framework routes
  app.use('/api/v1', framework.getRouter());
  
  // Add custom routes
  app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
  });
  
  app.listen(3000);
});
```

## 🔌 Advanced Features

The DB-API Framework provides powerful extensions for custom business logic, data processing, and third-party integrations.

### Custom Endpoints & Business Logic

Create sophisticated business logic endpoints that go beyond basic CRUD operations:

```javascript
const framework = new DBAPIFramework('./config.yaml');
await framework.initialize();

const customEndpoints = framework.getCustomEndpointManager();

// Customer lifetime value calculation
customEndpoints.addEndpoint({
  path: '/business/customer-ltv/:userId',
  method: 'GET',
  description: 'Calculate customer lifetime value',
  handler: async (req, res, context) => {
    const { userId } = req.params;
    
    const customerData = await context.db.raw(`
      SELECT 
        COUNT(o.id) as total_orders,
        SUM(o.total) as total_spent,
        AVG(o.total) as avg_order_value
      FROM users u
      LEFT JOIN orders o ON u.id = o.user_id
      WHERE u.id = ?
      GROUP BY u.id
    `, [userId]);

    const ltv = customerData.rows[0].total_spent * 2.5; // 2.5x multiplier
    res.json({ customer_id: userId, projected_ltv: ltv });
  }
});
```

### Data Aggregation Engine

Built-in aggregation capabilities for analytics and reporting:

```javascript
const aggregationEngine = framework.getAggregationEngine();

// Revenue analytics
const revenueData = await aggregationEngine.execute({
  table: 'orders',
  fields: [
    { field: 'total', operation: 'sum', alias: 'total_revenue' },
    { field: 'id', operation: 'count', alias: 'order_count' },
    { field: 'total', operation: 'avg', alias: 'avg_order_value' }
  ],
  groupBy: ['DATE(created_at)'],
  filters: { status: 'completed' },
  orderBy: 'created_at:desc',
  limit: 30
});
```

**Available aggregation operations:**
- `sum` - Sum of values
- `count` - Count of records
- `count_distinct` - Count unique values
- `avg` - Average value
- `min` - Minimum value
- `max` - Maximum value

**Built-in endpoints:**
- `GET /api/custom/stats/:table` - Get table statistics
- `POST /api/custom/aggregate` - Execute custom aggregation
- `GET /api/custom/analytics/revenue` - Revenue analytics over time
- `GET /api/custom/analytics/users` - User growth analytics

### Data Transformation Engine

Transform and enrich your data with built-in transformation functions:

```javascript
const transformEngine = framework.getTransformEngine();

const transformRules = [
  {
    field: 'name',
    operation: { type: 'format', function: 'capitalize' }
  },
  {
    field: 'price',
    operation: { 
      type: 'format', 
      function: 'currency',
      options: { currency: 'USD', locale: 'en-US' }
    }
  },
  {
    field: 'total_value',
    operation: {
      type: 'calculate',
      function: 'total',
      parameters: { fields: ['price', 'tax', 'shipping'] }
    }
  }
];

const transformedData = await transformEngine.processData(
  'products', 
  transformRules,
  { category_id: 1 }
);
```

**Transform operations:**
- `map` - Transform field values
- `filter` - Filter records based on conditions
- `format` - Format values (currency, date, phone, etc.)
- `calculate` - Calculate derived fields

**Built-in transform functions:**
- **Text**: uppercase, lowercase, trim, truncate, replace, capitalize
- **Numbers**: multiply, round, format_currency
- **Dates**: format_date, days_since, age_from_birthdate
- **Calculations**: total, average, discount

### Integration Manager

Connect your database changes to external services automatically:

```javascript
const integrations = framework.getIntegrationManager();

// Email notifications
integrations.addIntegration({
  name: 'email_notifications',
  type: 'webhook',
  enabled: true,
  config: {
    url: 'https://api.sendgrid.com/v3/mail/send',
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.SENDGRID_API_KEY}`,
      'Content-Type': 'application/json'
    }
  },
  triggers: [
    { event: 'create', table: 'users' },
    { event: 'create', table: 'orders' }
  ],
  transformations: [
    { source_field: 'email', target_field: 'to' },
    { source_field: 'name', target_field: 'recipient_name' }
  ]
});

// Slack notifications for high-value orders
integrations.addIntegration({
  name: 'slack_alerts',
  type: 'webhook',
  enabled: true,
  config: {
    url: process.env.SLACK_WEBHOOK_URL,
    method: 'POST'
  },
  triggers: [
    { 
      event: 'create', 
      table: 'orders',
      conditions: { total: { '>=': 1000 } }
    }
  ]
});
```

**Integration types:**
- `webhook` - HTTP webhook calls
- `api` - RESTful API integrations
- `queue` - Message queue publishing
- `stream` - Real-time data streams

**Built-in integrations:**
- **Email**: SendGrid, Mailgun
- **Payments**: Stripe, PayPal
- **Messaging**: Slack, Discord
- **Analytics**: Google Analytics, Mixpanel
- **CRM**: HubSpot, Salesforce

## 🔌 Plugin Development

Extend the framework with custom endpoints and business logic:

### Advanced Configuration

Enable advanced features in your YAML configuration:

```yaml
# Enable custom endpoints
customEndpoints:
  analytics:
    - path: /revenue-analytics
      description: "Revenue analytics with time grouping"
      enabled: true
    - path: /customer-segments
      description: "RFM customer segmentation"
      enabled: true
      
  business:
    - path: /customer-ltv
      description: "Customer lifetime value calculation" 
      enabled: true

# Data transformations
transformations:
  products:
    - field: name
      operation: capitalize
    - field: price
      operation: format_currency
      parameters: { currency: USD }
  orders:
    - field: total
      operation: format_currency
    - field: created_at
      operation: format_date

# Integrations
integrations:
  - name: email_service
    type: webhook
    enabled: true
    config:
      url: ${EMAIL_WEBHOOK_URL}
      headers:
        Authorization: "Bearer ${EMAIL_API_KEY}"
    triggers:
      - event: create
        table: users
        template: welcome_email
      - event: create
        table: orders
        template: order_confirmation

# Business rules
businessRules:
  orders:
    validation:
      - field: total
        rule: greater_than
        value: 0
    processing:
      - trigger: after_create
        action: send_confirmation
```

### Example Implementation

See complete working examples in the `/examples` directory:

**Custom Endpoints** (`examples/custom-endpoints-example.js`):
- Customer lifetime value calculation
- Inventory reorder alerts
- RFM customer segmentation
- Bulk data processing with validation
- Revenue analytics with time grouping

**Integrations** (`examples/integrations-example.js`):
- SendGrid email notifications
- Stripe payment processing
- Slack alerts for important events
- HubSpot CRM synchronization
- Google Analytics event tracking

### Creating a Plugin

```javascript
// plugins/analytics-plugin.js
const { BasePlugin } = require('db-api-framework');

class AnalyticsPlugin extends BasePlugin {
  routes() {
    return {
      '/analytics/revenue': {
        method: 'GET',
        handler: this.getRevenue.bind(this)
      },
      '/analytics/users': {
        method: 'GET', 
        handler: this.getUserStats.bind(this)
      }
    };
  }

  async getRevenue(req, res) {
    const { start_date, end_date } = req.query;
    
    const result = await this.db.raw(`
      SELECT DATE(created_at) as date, SUM(total_amount) as revenue
      FROM orders 
      WHERE created_at >= ? AND created_at <= ?
      GROUP BY DATE(created_at)
      ORDER BY date
    `, [start_date, end_date]);
    
    res.json(result.rows);
  }

  async getUserStats(req, res) {
    const stats = await this.db.raw(`
      SELECT 
        COUNT(*) as total_users,
        COUNT(CASE WHEN created_at >= CURRENT_DATE - INTERVAL '30 days' THEN 1 END) as new_users_30d
      FROM users
    `);
    
    res.json(stats.rows[0]);
  }
}

module.exports = AnalyticsPlugin;
```

### Plugin Configuration

```yaml
plugins:
  - name: analytics
    path: ./plugins/analytics-plugin.js
    enabled: true
    options:
      cache_ttl: 300
```

## 📊 Schema Introspection

The framework automatically discovers your database schema:

### Supported Features

- **Tables**: All user tables (excludes system tables)
- **Columns**: Data types, constraints, defaults
- **Primary Keys**: Single and composite keys
- **Foreign Keys**: Automatic relationship detection
- **Indexes**: Performance optimization hints

### Type Mapping

| Database Type | API Type | Validation |
|---------------|----------|------------|
| VARCHAR, TEXT | string | maxLength |
| INTEGER, BIGINT | number | integer |
| DECIMAL, FLOAT | number | decimal |
| BOOLEAN | boolean | true/false |
| DATE, TIMESTAMP | string | ISO 8601 |
| JSON, JSONB | object | JSON schema |

## 🛡️ Security Features

### Access Control

- **Table-level permissions**: Control which tables are accessible
- **Operation-level permissions**: Control CRUD operations per table
- **Field-level filtering**: Hide sensitive columns (coming soon)

### Input Validation

- **Schema-based validation**: Automatic validation based on database schema
- **Type checking**: Ensures data types match database constraints
- **SQL injection prevention**: Parameterized queries only

### Rate Limiting

```yaml
security:
  enableCors: true
  rateLimiting:
    windowMs: 900000  # 15 minutes
    max: 100          # Max requests per window
```

## 🚀 Production Deployment

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://user:password@host:5432/database
NODE_ENV=production

# Server
PORT=5000
HOST=0.0.0.0

# Security
API_KEY_REQUIRED=true
CORS_ORIGINS=https://yourdomain.com,https://api.yourdomain.com
```

### Docker Deployment

```dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
EXPOSE 5000

CMD ["npm", "start"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  api:
    build: .
    ports:
      - "5000:5000"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/myapp
    depends_on:
      - db
  
  db:
    image: postgres:14
    environment:
      - POSTGRES_DB=myapp
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

### Performance Optimization

1. **Connection Pooling**: Configure appropriate pool sizes
2. **Caching**: Enable Redis for query result caching
3. **Indexing**: Ensure proper database indexes
4. **Rate Limiting**: Protect against abuse

## 📚 API Reference

### Configuration Schema

Complete YAML configuration reference:

```yaml
database:
  type: postgres | mysql | sqlite | mssql | oracle
  connectionString?: string
  host?: string
  port?: number
  user?: string
  password?: string
  database?: string
  filename?: string  # SQLite only
  pool?:
    min: number
    max: number
    acquireTimeoutMillis?: number
    idleTimeoutMillis?: number

accessControl?:
  whitelistTables?: string[]
  blacklistTables?: string[]
  operations?: Record<string, ('GET' | 'POST' | 'PUT' | 'DELETE')[]>
  defaultOperations?: ('GET' | 'POST' | 'PUT' | 'DELETE')[]

pagination?:
  defaultLimit: number
  maxLimit: number
  defaultOffset?: number

sorting?:
  defaultFields?: Record<string, string[]>
  allowedFields?: Record<string, string[]>

relationships?:
  eagerLoad?: Record<string, string[]>
  lazyLoad?: Record<string, string[]>
  maxDepth?: number

plugins?:
  - name: string
    path: string
    enabled?: boolean
    options?: Record<string, any>

logging?:
  level: error | warn | info | debug
  format: json | simple

security?:
  enableCors: boolean
  rateLimiting?:
    windowMs: number
    max: number
```

## 🔧 Advanced Usage Examples

### Business Logic Endpoints

**Customer Analytics:**
```bash
# Get customer lifetime value
GET /api/custom/business/customer-ltv/123

# Customer segmentation analysis
GET /api/custom/analytics/customer-segments

# Inventory reorder alerts
GET /api/custom/business/inventory/reorder-alerts?threshold_days=7
```

**Revenue Analytics:**
```bash
# Daily revenue breakdown
GET /api/custom/analytics/revenue?start_date=2024-01-01&end_date=2024-01-31&group_by=day

# Monthly revenue trends
GET /api/custom/analytics/revenue?group_by=month

# User growth metrics
GET /api/custom/analytics/users
```

### Data Aggregation

**Custom Aggregation Query:**
```bash
POST /api/custom/aggregate
Content-Type: application/json

{
  "table": "orders",
  "fields": [
    { "field": "total", "operation": "sum", "alias": "revenue" },
    { "field": "id", "operation": "count", "alias": "order_count" }
  ],
  "groupBy": ["user_id"],
  "filters": { "status": "completed" },
  "orderBy": "revenue:desc",
  "limit": 10
}
```

**Table Statistics:**
```bash
# Get comprehensive statistics for any table
GET /api/custom/stats/products
GET /api/custom/stats/orders
GET /api/custom/stats/users
```

### Data Transformation

**Transform Product Catalog:**
```bash
POST /api/custom/transform/products
Content-Type: application/json

{
  "rules": [
    {
      "field": "name",
      "operation": { "type": "format", "function": "capitalize" }
    },
    {
      "field": "price", 
      "operation": { 
        "type": "format", 
        "function": "currency",
        "parameters": { "currency": "USD" }
      }
    }
  ],
  "filters": { "active": true }
}
```

### Bulk Operations

**Bulk Data Processing:**
```bash
POST /api/custom/processing/bulk-update
Content-Type: application/json

{
  "table": "products",
  "updates": [
    {
      "id": "product-1",
      "data": { "price": 29.99, "stock": 100 }
    },
    {
      "id": "product-2", 
      "data": { "price": 39.99, "stock": 50 }
    }
  ],
  "validation_rules": [
    { "field": "price", "required": true, "type": "number" }
  ]
}
```

## 🔧 CLI Commands

### Project Management

```bash
# Initialize new project
db-api init <project-name>

# Start development server
db-api start [--config config.yaml] [--port 5000]

# Generate API documentation
db-api docs

# Validate configuration
db-api validate

# Database introspection
db-api introspect

# Generate client SDKs
db-api generate client --language typescript --output ./sdk
```

### Development Tools

```bash
# Watch for schema changes
db-api watch

# Run tests
db-api test

# Lint configuration
db-api lint

# Database migration helpers
db-api migrate status
db-api migrate up
db-api migrate down
```

## 🤝 Contributing

We welcome contributions! Please read our [Contributing Guide](CONTRIBUTING.md) for details.

### Development Setup

```bash
git clone https://github.com/db-api-framework/db-api-framework.git
cd db-api-framework
npm install
npm run dev
```

### Running Tests

```bash
npm test
npm run test:integration
npm run test:e2e
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- 📖 [Documentation](https://db-api-framework.com/docs)
- 💬 [Discord Community](https://discord.gg/db-api-framework)
- 🐛 [Issue Tracker](https://github.com/db-api-framework/db-api-framework/issues)
- 📧 [Email Support](mailto:support@db-api-framework.com)

## 🎯 Advanced Features Summary

### ✅ Currently Available

- **Custom Business Logic Endpoints** - Create sophisticated business rules and calculations
- **Data Aggregation Engine** - Built-in analytics and reporting capabilities
- **Data Transformation Pipeline** - Transform, format, and enrich your data
- **Integration Manager** - Connect to external services automatically
- **Webhook Support** - Real-time notifications and event processing
- **Bulk Operations** - Process large datasets with validation and rollback
- **Advanced Analytics** - Customer segmentation, LTV calculation, revenue analytics

### 🔧 Built-in Endpoints

The framework automatically provides these advanced endpoints:

**Analytics & Reporting:**
- `/api/custom/stats/:table` - Table statistics and summaries
- `/api/custom/analytics/revenue` - Revenue analytics over time
- `/api/custom/analytics/users` - User growth and activity metrics
- `/api/custom/analytics/customer-segments` - RFM customer segmentation

**Business Logic:**
- `/api/custom/business/customer-ltv/:userId` - Customer lifetime value
- `/api/custom/business/inventory/reorder-alerts` - Inventory management alerts

**Data Processing:**
- `/api/custom/aggregate` - Execute custom aggregation queries
- `/api/custom/transform/:table` - Apply data transformations
- `/api/custom/processing/bulk-update` - Bulk data operations
- `/api/custom/integrations/fulfill-order` - Order fulfillment processing

### 📋 Configuration Examples

Complete configuration examples available in:
- `config/advanced-config.yaml` - Full-featured configuration
- `examples/custom-endpoints-example.js` - Business logic implementations  
- `examples/integrations-example.js` - Third-party service integrations

### 🚀 Getting Started with Advanced Features

1. **Copy the advanced configuration:**
```bash
cp config/advanced-config.yaml config.yaml
```

2. **Set up environment variables:**
```bash
# Email service
export EMAIL_WEBHOOK_URL="your-email-service-url"
export EMAIL_API_KEY="your-api-key"

# Slack notifications  
export SLACK_WEBHOOK_URL="your-slack-webhook"

# Payment processing
export STRIPE_SECRET_KEY="your-stripe-key"
```

3. **Start with advanced features enabled:**
```bash
db-api start --config config.yaml
```

4. **Test the advanced endpoints:**
```bash
# Get table statistics
curl http://localhost:5000/api/custom/stats/orders

# Run customer segmentation
curl http://localhost:5000/api/custom/analytics/customer-segments

# Calculate customer lifetime value
curl http://localhost:5000/api/custom/business/customer-ltv/user-123
```

## 🗺️ Roadmap

- [ ] GraphQL API generation
- [ ] Role-based access control (RBAC)
- [ ] Real-time subscriptions with WebSockets
- [ ] Caching layer with Redis
- [ ] Client SDK generation
- [ ] Database migration tools
- [ ] Performance analytics dashboard
- [ ] Multi-tenant support
