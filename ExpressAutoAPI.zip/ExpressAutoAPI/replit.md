# DB-API Framework

## Overview

DB-API Framework is a production-grade Node.js/Express.js library that automatically generates REST APIs from any relational database. The framework introspects database schemas at runtime, creates CRUD endpoints with zero configuration, and provides advanced features like pagination, sorting, relationship management, and granular access control. Built with TypeScript and designed for production use, it supports multiple database types (PostgreSQL, MySQL, SQLite, MSSQL, Oracle) and offers extensibility through a plugin architecture.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (January 2025)

- **Framework Completion**: Successfully built complete production-grade DB-API Framework
- **Database Integration**: PostgreSQL database setup with sample data (users, products, orders, categories, order_items)
- **API Generation**: Auto-generated REST endpoints for all 5 database tables working perfectly
- **Swagger Documentation**: Interactive API documentation available at `/docs` and OpenAPI spec at `/api-docs.json`
- **Advanced Extensions**: Added sophisticated business logic capabilities including:
  - **Custom Endpoints Manager**: Create complex business logic endpoints beyond CRUD
  - **Aggregation Engine**: Built-in analytics with sum, count, avg, min, max operations
  - **Transform Engine**: Data transformation pipeline with formatting and calculations
  - **Integration Manager**: Automatic webhooks and API integrations with external services
- **Working Advanced Endpoints**: All custom endpoints functional including:
  - `/api/custom/stats/:table` - Table statistics (✅ tested)
  - `/api/custom/analytics/users` - User growth analytics (✅ tested)  
  - `/api/custom/aggregate` - Custom aggregation queries (✅ tested)
  - `/api/custom/analytics/revenue` - Revenue analytics over time
  - Business logic endpoints for LTV calculation, customer segmentation, inventory alerts
- **Comprehensive Examples**: Created complete working examples:
  - `examples/custom-endpoints-example.js` - Advanced business logic implementations
  - `examples/integrations-example.js` - Third-party service integrations (SendGrid, Stripe, Slack, etc.)
  - `config/advanced-config.yaml` - Full-featured configuration with all advanced features
- **Updated Documentation**: Expanded README.md to 1100+ lines with detailed coverage of all advanced features

## System Architecture

### Full-Stack Architecture
The project follows a monorepo structure with separate client and server directories. The frontend is a React SPA built with Vite, while the backend is an Express.js API server. The architecture supports both development and production environments with automatic hot reloading in development.

### Frontend Technology Stack
- **React 18** with TypeScript for the UI layer
- **Vite** as the build tool and development server
- **Tailwind CSS** with shadcn/ui components for styling
- **React Query** for server state management and API interactions
- **Wouter** for client-side routing
- **React Hook Form** with Zod validation for form handling

### Backend Framework Architecture
- **Express.js** server with TypeScript
- **Drizzle ORM** for database operations and schema management
- **Neon Database** (PostgreSQL) as the primary database
- **Plugin-based architecture** for extensibility
- **Dynamic route generation** based on database schema introspection
- **Middleware pipeline** for access control, pagination, and error handling

### Database Layer Design
The framework uses a database-agnostic approach with multiple layers:
- **Database Factory** creates connections for different database types
- **Schema Introspector** discovers tables, columns, and relationships at runtime
- **Relationship Mapper** handles foreign key relationships and configures lazy/eager loading
- **Query Builder** constructs optimized database queries with filtering, sorting, and pagination

### API Generation Strategy
- **Automatic CRUD endpoints** generated for each accessible table
- **RESTful conventions** with proper HTTP methods and status codes
- **Configurable access control** at table and operation levels
- **Smart relationship loading** with configurable eager/lazy strategies
- **Query parameter support** for pagination, sorting, filtering, and relationship inclusion

### Security and Access Control
- **Granular permissions** system with whitelist/blacklist table support
- **Operation-level access control** (GET, POST, PUT, DELETE per table)
- **Request validation** based on database schema constraints
- **Error handling middleware** with proper HTTP status codes and sanitized error messages

### Configuration Management
- **YAML-based configuration** for database connections, access control, and framework settings
- **Environment variable support** for sensitive configuration like database URLs
- **Runtime schema introspection** eliminates need for manual schema definitions
- **Plugin configuration** system for extending functionality

### Documentation and Developer Experience
- **Auto-generated Swagger/OpenAPI documentation** based on database schema
- **Interactive API explorer** built into the frontend
- **CLI tools** for project initialization and management
- **TypeScript support** throughout the codebase for better developer experience

## External Dependencies

### Database Integration
- **@neondatabase/serverless** - Neon PostgreSQL serverless driver
- **drizzle-orm** - TypeScript ORM with PostgreSQL dialect support
- **knex** - SQL query builder for multi-database support (used internally by framework)

### Frontend Dependencies
- **@tanstack/react-query** - Server state management and caching
- **@radix-ui/** components - Accessible UI component primitives
- **tailwindcss** - Utility-first CSS framework
- **wouter** - Lightweight React router
- **react-hook-form** with **@hookform/resolvers** - Form handling and validation

### Development and Build Tools
- **vite** - Frontend build tool and development server
- **tsx** - TypeScript execution for Node.js
- **esbuild** - JavaScript bundler for server-side code
- **drizzle-kit** - Database migration and schema management tools

### Backend Framework Dependencies
- **express** - Web framework for Node.js
- **commander** - CLI framework for command-line tools
- **js-yaml** - YAML parser for configuration files
- **ws** - WebSocket library for Neon database connections

### Validation and Utilities
- **zod** - TypeScript-first schema validation
- **drizzle-zod** - Integration between Drizzle ORM and Zod validation
- **date-fns** - Date utility library
- **clsx** and **tailwind-merge** - CSS class manipulation utilities