package com.example.core.parser;

import com.example.core.model.TestSuite;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class YamlParserTest {
    private YamlParser parser;

    @BeforeEach
    void setUp() {
        parser = new YamlParser();
    }

    @Test
    void testParseValidYaml() throws ParseException {
        String yaml = """
            suite:
              id: "test-suite"
              variables:
                baseUrl: "https://example.com"
              tests:
                - id: "test1"
                  browser: "chromium"
                  steps:
                    - action: navigate
                      url: "${baseUrl}/login"
                    - action: click
                      selector: "#submit"
            """;

        TestSuite suite = parser.parse(yaml);

        assertNotNull(suite);
        assertEquals("test-suite", suite.getId());
        assertEquals("https://example.com", suite.getVariables().get("baseUrl"));
        assertEquals(1, suite.getTests().size());
        assertEquals("test1", suite.getTests().get(0).getId());
        assertEquals("chromium", suite.getTests().get(0).getBrowser());
        assertEquals(2, suite.getTests().get(0).getSteps().size());
    }

    @Test
    void testParseInvalidYaml() {
        String invalidYaml = "invalid: yaml: content: [";

        assertThrows(ParseException.class, () -> parser.parse(invalidYaml));
    }

    @Test
    void testParseEmptyYaml() {
        String emptyYaml = "";

        assertThrows(ParseException.class, () -> parser.parse(emptyYaml));
    }
}
