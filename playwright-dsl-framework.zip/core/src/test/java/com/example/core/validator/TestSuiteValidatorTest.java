package com.example.core.validator;

import com.example.core.model.Step;
import com.example.core.model.Test;
import com.example.core.model.TestSuite;
import org.junit.jupiter.api.BeforeEach;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class TestSuiteValidatorTest {
    private TestSuiteValidator validator;

    @BeforeEach
    void setUp() {
        validator = new TestSuiteValidator();
    }

    @org.junit.jupiter.api.Test
    void testValidSuite() {
        TestSuite suite = createValidTestSuite();
        ValidationResult result = validator.validate(suite);

        assertTrue(result.isValid());
        assertTrue(result.getErrors().isEmpty());
    }

    @org.junit.jupiter.api.Test
    void testSuiteWithoutId() {
        TestSuite suite = createValidTestSuite();
        suite.setId(null);

        ValidationResult result = validator.validate(suite);

        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("Suite ID is required")));
    }

    @org.junit.jupiter.api.Test
    void testSuiteWithoutTests() {
        TestSuite suite = new TestSuite();
        suite.setId("test-suite");

        ValidationResult result = validator.validate(suite);

        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("At least one test is required")));
    }

    @org.junit.jupiter.api.Test
    void testInvalidAction() {
        TestSuite suite = createValidTestSuite();
        Step invalidStep = new Step();
        invalidStep.setAction("invalid-action");
        suite.getTests().get(0).getSteps().add(invalidStep);

        ValidationResult result = validator.validate(suite);

        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("Unsupported action: invalid-action")));
    }

    @org.junit.jupiter.api.Test
    void testNavigateWithoutUrl() {
        TestSuite suite = createValidTestSuite();
        Step navigateStep = new Step();
        navigateStep.setAction("navigate");
        // Missing URL
        suite.getTests().get(0).getSteps().add(navigateStep);

        ValidationResult result = validator.validate(suite);

        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("URL is required for navigate action")));
    }

    private TestSuite createValidTestSuite() {
        Map<String, String> variables = new HashMap<>();
        variables.put("baseUrl", "https://example.com");

        Step navigateStep = new Step();
        navigateStep.setAction("navigate");
        navigateStep.setUrl("${baseUrl}/login");

        Step clickStep = new Step();
        clickStep.setAction("click");
        clickStep.setSelector("#submit");

        Test test = new Test();
        test.setId("test1");
        test.setBrowser("chromium");
        test.setSteps(Arrays.asList(navigateStep, clickStep));

        TestSuite suite = new TestSuite();
        suite.setId("test-suite");
        suite.setVariables(variables);
        suite.setTests(Arrays.asList(test));

        return suite;
    }
}
