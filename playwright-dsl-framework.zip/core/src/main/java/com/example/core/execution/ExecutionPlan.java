package com.example.core.execution;

import com.example.core.model.TestSuite;

import java.util.Map;

public class ExecutionPlan {
    private final TestSuite testSuite;
    private final Map<String, String> resolvedVariables;
    private final String executionId;

    public ExecutionPlan(TestSuite testSuite, Map<String, String> resolvedVariables, String executionId) {
        this.testSuite = testSuite;
        this.resolvedVariables = resolvedVariables;
        this.executionId = executionId;
    }

    public TestSuite getTestSuite() {
        return testSuite;
    }

    public Map<String, String> getResolvedVariables() {
        return resolvedVariables;
    }

    public String getExecutionId() {
        return executionId;
    }

    public String resolveVariable(String text) {
        if (text == null || resolvedVariables == null) {
            return text;
        }
        
        String result = text;
        for (Map.Entry<String, String> entry : resolvedVariables.entrySet()) {
            String placeholder = "${" + entry.getKey() + "}";
            result = result.replace(placeholder, entry.getValue());
        }
        return result;
    }
}
