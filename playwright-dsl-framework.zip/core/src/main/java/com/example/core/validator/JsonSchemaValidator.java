package com.example.core.validator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class JsonSchemaValidator {
    private final JsonSchema schema;
    private final ObjectMapper objectMapper;

    public JsonSchemaValidator(InputStream schemaStream) {
        JsonSchemaFactory factory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
        this.schema = factory.getSchema(schemaStream);
        this.objectMapper = new ObjectMapper();
    }

    public ValidationResult validateYaml(String yamlContent) {
        try {
            // Convert YAML to JSON for validation
            JsonNode jsonNode = objectMapper.readTree(yamlContent);
            
            // Validate against schema
            Set<ValidationMessage> validationMessages = schema.validate(jsonNode);
            
            List<String> errors = new ArrayList<>();
            for (ValidationMessage message : validationMessages) {
                errors.add(message.getMessage());
            }
            
            return new ValidationResult(errors.isEmpty(), errors, new ArrayList<>());
            
        } catch (Exception e) {
            List<String> errors = new ArrayList<>();
            errors.add("JSON Schema validation failed: " + e.getMessage());
            return new ValidationResult(false, errors, new ArrayList<>());
        }
    }
}
