package com.example.core.validator;

import com.example.core.model.Step;
import com.example.core.model.Test;
import com.example.core.model.TestSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class TestSuiteValidator {
    private static final Set<String> SUPPORTED_ACTIONS = Set.of(
        "navigate", "click", "fill", "expect", "screenshot", "route.mock", "trace-start", "trace-stop"
    );
    
    private static final Set<String> SUPPORTED_BROWSERS = Set.of(
        "chromium", "firefox", "webkit"
    );

    public ValidationResult validate(TestSuite suite) {
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();

        if (suite == null) {
            errors.add("Test suite cannot be null");
            return new ValidationResult(false, errors, warnings);
        }

        // Validate suite ID
        if (suite.getId() == null || suite.getId().trim().isEmpty()) {
            errors.add("Suite ID is required");
        }

        // Validate tests
        if (suite.getTests() == null || suite.getTests().isEmpty()) {
            errors.add("At least one test is required");
        } else {
            for (int i = 0; i < suite.getTests().size(); i++) {
                Test test = suite.getTests().get(i);
                validateTest(test, i, errors, warnings);
            }
        }

        return new ValidationResult(errors.isEmpty(), errors, warnings);
    }

    private void validateTest(Test test, int testIndex, List<String> errors, List<String> warnings) {
        String testPrefix = "Test[" + testIndex + "]: ";

        if (test.getId() == null || test.getId().trim().isEmpty()) {
            errors.add(testPrefix + "Test ID is required");
        }

        if (test.getBrowser() == null || test.getBrowser().trim().isEmpty()) {
            warnings.add(testPrefix + "Browser not specified, defaulting to chromium");
        } else if (!SUPPORTED_BROWSERS.contains(test.getBrowser())) {
            errors.add(testPrefix + "Unsupported browser: " + test.getBrowser() + 
                      ". Supported: " + SUPPORTED_BROWSERS);
        }

        if (test.getSteps() == null || test.getSteps().isEmpty()) {
            errors.add(testPrefix + "At least one step is required");
        } else {
            for (int i = 0; i < test.getSteps().size(); i++) {
                Step step = test.getSteps().get(i);
                validateStep(step, testPrefix + "Step[" + i + "]: ", errors, warnings);
            }
        }
    }

    private void validateStep(Step step, String stepPrefix, List<String> errors, List<String> warnings) {
        if (step.getAction() == null || step.getAction().trim().isEmpty()) {
            errors.add(stepPrefix + "Action is required");
            return;
        }

        String action = step.getAction();
        if (!SUPPORTED_ACTIONS.contains(action)) {
            errors.add(stepPrefix + "Unsupported action: " + action + 
                      ". Supported: " + SUPPORTED_ACTIONS);
            return;
        }

        // Validate action-specific requirements
        switch (action) {
            case "navigate":
                if (step.getUrl() == null || step.getUrl().trim().isEmpty()) {
                    errors.add(stepPrefix + "URL is required for navigate action");
                }
                break;
            case "click":
                if (step.getSelector() == null || step.getSelector().trim().isEmpty()) {
                    errors.add(stepPrefix + "Selector is required for click action");
                }
                break;
            case "fill":
                if (step.getSelector() == null || step.getSelector().trim().isEmpty()) {
                    errors.add(stepPrefix + "Selector is required for fill action");
                }
                if (step.getValue() == null) {
                    errors.add(stepPrefix + "Value is required for fill action");
                }
                break;
            case "expect":
                if (step.getSelector() == null || step.getSelector().trim().isEmpty()) {
                    errors.add(stepPrefix + "Selector is required for expect action");
                }
                if (step.getContains() == null || step.getContains().trim().isEmpty()) {
                    errors.add(stepPrefix + "Contains text is required for expect action");
                }
                break;
            case "screenshot":
                if (step.getName() == null || step.getName().trim().isEmpty()) {
                    warnings.add(stepPrefix + "Screenshot name not specified, will use default");
                }
                break;
            case "route.mock":
                if (step.getPattern() == null || step.getPattern().trim().isEmpty()) {
                    errors.add(stepPrefix + "Pattern is required for route.mock action");
                }
                if (step.getBody() == null) {
                    warnings.add(stepPrefix + "Mock body not specified, will return empty response");
                }
                break;
            case "trace-start":
            case "trace-stop":
                if (step.getName() == null || step.getName().trim().isEmpty()) {
                    warnings.add(stepPrefix + "Trace name not specified, will use default");
                }
                break;
        }
    }
}
