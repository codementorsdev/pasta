package com.example.core.parser;

import com.example.core.model.TestSuite;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import java.io.InputStream;
import java.io.StringReader;

public class YamlParser {
    private final Yaml yaml;

    public YamlParser() {
        Constructor constructor = new Constructor(TestSuite.class);
        this.yaml = new Yaml(constructor);
    }

    public TestSuite parse(String yamlContent) throws ParseException {
        try {
            return yaml.load(new StringReader(yamlContent));
        } catch (Exception e) {
            throw new ParseException("Failed to parse YAML: " + e.getMessage(), e);
        }
    }

    public TestSuite parse(InputStream yamlStream) throws ParseException {
        try {
            return yaml.load(yamlStream);
        } catch (Exception e) {
            throw new ParseException("Failed to parse YAML: " + e.getMessage(), e);
        }
    }
}
