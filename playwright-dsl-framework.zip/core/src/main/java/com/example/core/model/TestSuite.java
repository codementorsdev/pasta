package com.example.core.model;

import java.util.List;
import java.util.Map;

public class TestSuite {
    private String id;
    private Map<String, String> variables;
    private List<Test> tests;

    public TestSuite() {}

    public TestSuite(String id, Map<String, String> variables, List<Test> tests) {
        this.id = id;
        this.variables = variables;
        this.tests = tests;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, String> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, String> variables) {
        this.variables = variables;
    }

    public List<Test> getTests() {
        return tests;
    }

    public void setTests(List<Test> tests) {
        this.tests = tests;
    }
}
