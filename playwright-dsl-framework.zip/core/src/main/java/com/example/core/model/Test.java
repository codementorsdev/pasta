package com.example.core.model;

import java.util.List;

public class Test {
    private String id;
    private String browser;
    private List<Step> steps;

    public Test() {}

    public Test(String id, String browser, List<Step> steps) {
        this.id = id;
        this.browser = browser;
        this.steps = steps;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }

    public List<Step> getSteps() {
        return steps;
    }

    public void setSteps(List<Step> steps) {
        this.steps = steps;
    }
}
