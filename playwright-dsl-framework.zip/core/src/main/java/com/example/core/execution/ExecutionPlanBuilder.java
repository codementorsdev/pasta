package com.example.core.execution;

import com.example.core.model.TestSuite;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ExecutionPlanBuilder {
    
    public ExecutionPlan build(TestSuite testSuite) {
        return build(testSuite, new HashMap<>());
    }
    
    public ExecutionPlan build(TestSuite testSuite, Map<String, String> additionalVariables) {
        String executionId = UUID.randomUUID().toString();
        
        Map<String, String> resolvedVariables = new HashMap<>();
        
        // Add suite variables
        if (testSuite.getVariables() != null) {
            resolvedVariables.putAll(testSuite.getVariables());
        }
        
        // Add additional variables (can override suite variables)
        resolvedVariables.putAll(additionalVariables);
        
        return new ExecutionPlan(testSuite, resolvedVariables, executionId);
    }
}
