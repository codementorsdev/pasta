package com.example.service.integration;

import com.example.service.dto.RunRequest;
import com.example.service.dto.RunResponse;
import com.example.service.dto.SuiteUploadRequest;
import com.example.service.dto.SuiteUploadResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class SmokeTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    @EnabledIfEnvironmentVariable(named = "PLAYWRIGHT_ENABLED", matches = "true")
    void testFullWorkflow() throws Exception {
        // Load sample YAML
        String sampleYaml = Files.readString(Paths.get("../samples/login.yaml"));

        // Upload suite
        SuiteUploadRequest uploadRequest = new SuiteUploadRequest();
        uploadRequest.setYamlContent(sampleYaml);

        ResponseEntity<SuiteUploadResponse> uploadResponse = restTemplate.postForEntity(
            "http://localhost:" + port + "/api/suites",
            uploadRequest,
            SuiteUploadResponse.class
        );

        assertEquals(HttpStatus.OK, uploadResponse.getStatusCode());
        assertTrue(uploadResponse.getBody().isSuccess());
        String suiteId = uploadResponse.getBody().getSuiteId();

        // Run suite
        RunRequest runRequest = new RunRequest();
        runRequest.setHeadless(true);

        ResponseEntity<RunResponse> runResponse = restTemplate.postForEntity(
            "http://localhost:" + port + "/api/suites/" + suiteId + "/run",
            runRequest,
            RunResponse.class
        );

        assertEquals(HttpStatus.OK, runResponse.getStatusCode());
        assertNotNull(runResponse.getBody().getRunId());

        // Check run status
        ResponseEntity<RunResponse> statusResponse = restTemplate.getForEntity(
            "http://localhost:" + port + "/api/runs/" + runResponse.getBody().getRunId(),
            RunResponse.class
        );

        assertEquals(HttpStatus.OK, statusResponse.getStatusCode());
        assertNotNull(statusResponse.getBody());
    }
}
