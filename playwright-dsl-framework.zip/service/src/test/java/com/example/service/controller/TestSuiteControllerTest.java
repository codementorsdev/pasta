package com.example.service.controller;

import com.example.service.dto.SuiteUploadRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureTestMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureTestMvc
class TestSuiteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testUploadValidSuite() throws Exception {
        String validYaml = """
            suite:
              id: "test-suite"
              tests:
                - id: "test1"
                  browser: "chromium"
                  steps:
                    - action: navigate
                      url: "https://example.com"
            """;

        SuiteUploadRequest request = new SuiteUploadRequest();
        request.setYamlContent(validYaml);

        mockMvc.perform(post("/api/suites")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.suiteId").value("test-suite"));
    }

    @Test
    void testUploadInvalidSuite() throws Exception {
        String invalidYaml = """
            suite:
              id: ""
              tests: []
            """;

        SuiteUploadRequest request = new SuiteUploadRequest();
        request.setYamlContent(invalidYaml);

        mockMvc.perform(post("/api/suites")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").exists());
    }

    @Test
    void testRunNonExistentSuite() throws Exception {
        mockMvc.perform(post("/api/suites/non-existent/run")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").exists());
    }
}
