package com.example.service.dto;

import java.util.List;
import java.util.Map;

public class RunResponse {
    private boolean success;
    private String runId;
    private String error;
    private String status;
    private List<TestResultDto> testResults;
    private Map<String, String> artifactLinks;

    public RunResponse() {}

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getRunId() {
        return runId;
    }

    public void setRunId(String runId) {
        this.runId = runId;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<TestResultDto> getTestResults() {
        return testResults;
    }

    public void setTestResults(List<TestResultDto> testResults) {
        this.testResults = testResults;
    }

    public Map<String, String> getArtifactLinks() {
        return artifactLinks;
    }

    public void setArtifactLinks(Map<String, String> artifactLinks) {
        this.artifactLinks = artifactLinks;
    }

    public static class TestResultDto {
        private String testId;
        private boolean success;
        private String error;
        private Map<String, String> artifacts;

        public TestResultDto() {}

        public String getTestId() {
            return testId;
        }

        public void setTestId(String testId) {
            this.testId = testId;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }

        public Map<String, String> getArtifacts() {
            return artifacts;
        }

        public void setArtifacts(Map<String, String> artifacts) {
            this.artifacts = artifacts;
        }
    }
}
