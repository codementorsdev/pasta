package com.example.service.dto;

import java.util.Map;

public class RunRequest {
    private Map<String, String> variables;
    private boolean headless = true;

    public RunRequest() {}

    public Map<String, String> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, String> variables) {
        this.variables = variables;
    }

    public boolean isHeadless() {
        return headless;
    }

    public void setHeadless(boolean headless) {
        this.headless = headless;
    }
}
