package com.example.service.service;

import com.example.core.model.TestSuite;
import com.example.core.parser.ParseException;
import com.example.core.parser.YamlParser;
import com.example.core.validator.TestSuiteValidator;
import com.example.core.validator.ValidationResult;
import com.example.service.dto.SuiteUploadResponse;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

@Service
public class TestSuiteService {
    private final Map<String, TestSuite> suites = new ConcurrentHashMap<>();
    private final YamlParser yamlParser = new YamlParser();
    private final TestSuiteValidator validator = new TestSuiteValidator();

    public SuiteUploadResponse uploadAndValidate(String yamlContent) throws ParseException {
        // Parse YAML
        TestSuite suite = yamlParser.parse(yamlContent);
        
        // Validate
        ValidationResult validationResult = validator.validate(suite);
        
        SuiteUploadResponse response = new SuiteUploadResponse();
        response.setSuccess(validationResult.isValid());
        
        if (validationResult.isValid()) {
            // Store suite
            suites.put(suite.getId(), suite);
            response.setSuiteId(suite.getId());
        } else {
            response.setError("Validation failed: " + String.join(", ", validationResult.getErrors()));
        }
        
        if (validationResult.hasWarnings()) {
            response.setWarnings(validationResult.getWarnings());
        }
        
        return response;
    }

    public TestSuite getSuite(String suiteId) {
        return suites.get(suiteId);
    }
}
