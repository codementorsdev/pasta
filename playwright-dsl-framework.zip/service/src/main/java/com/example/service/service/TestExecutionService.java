package com.example.service.service;

import com.example.core.execution.ExecutionPlan;
import com.example.core.execution.ExecutionPlanBuilder;
import com.example.core.model.TestSuite;
import com.example.pwadapter.ExecutionResult;
import com.example.pwadapter.PlaywrightExecutor;
import com.example.pwadapter.PlaywrightExecutorBuilder;
import com.example.pwadapter.TestResult;
import com.example.service.dto.RunRequest;
import com.example.service.dto.RunResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class TestExecutionService {
    
    @Autowired
    private TestSuiteService testSuiteService;
    
    @Value("${app.artifacts.dir:target/artifacts}")
    private String artifactsDir;
    
    private final Map<String, RunResponse> runResults = new ConcurrentHashMap<>();
    private final ExecutionPlanBuilder planBuilder = new ExecutionPlanBuilder();

    public RunResponse executeSuite(String suiteId, RunRequest request) {
        TestSuite suite = testSuiteService.getSuite(suiteId);
        if (suite == null) {
            throw new RuntimeException("Suite not found: " + suiteId);
        }

        // Build execution plan
        Map<String, String> variables = request != null && request.getVariables() != null 
            ? request.getVariables() 
            : new HashMap<>();
        ExecutionPlan plan = planBuilder.build(suite, variables);

        // Create executor
        boolean headless = request == null || request.isHeadless();
        PlaywrightExecutor executor = new PlaywrightExecutorBuilder()
            .artifactsDir(Paths.get(artifactsDir))
            .headless(headless)
            .build();

        // Execute (synchronous for POC)
        ExecutionResult result = executor.execute(plan);

        // Convert to response
        RunResponse response = convertToRunResponse(result);
        
        // Store result
        runResults.put(result.getExecutionId(), response);
        
        return response;
    }

    public RunResponse getRunStatus(String runId) {
        return runResults.get(runId);
    }

    private RunResponse convertToRunResponse(ExecutionResult result) {
        RunResponse response = new RunResponse();
        response.setRunId(result.getExecutionId());
        response.setSuccess(result.isSuccess());
        response.setError(result.getError());
        response.setStatus(result.isSuccess() ? "COMPLETED" : "FAILED");

        // Convert test results
        List<RunResponse.TestResultDto> testResults = result.getTestResults().stream()
            .map(this::convertTestResult)
            .collect(Collectors.toList());
        response.setTestResults(testResults);

        // Collect artifact links
        Map<String, String> artifactLinks = new HashMap<>();
        for (TestResult testResult : result.getTestResults()) {
            for (Map.Entry<String, String> artifact : testResult.getArtifacts().entrySet()) {
                String key = testResult.getTestId() + "_" + artifact.getKey();
                artifactLinks.put(key, artifact.getValue());
            }
        }
        response.setArtifactLinks(artifactLinks);

        return response;
    }

    private RunResponse.TestResultDto convertTestResult(TestResult testResult) {
        RunResponse.TestResultDto dto = new RunResponse.TestResultDto();
        dto.setTestId(testResult.getTestId());
        dto.setSuccess(testResult.isSuccess());
        dto.setError(testResult.getError());
        dto.setArtifacts(testResult.getArtifacts());
        return dto;
    }
}
