package com.example.service.dto;

public class SuiteUploadRequest {
    private String yamlContent;

    public SuiteUploadRequest() {}

    public String getYamlContent() {
        return yamlContent;
    }

    public void setYamlContent(String yamlContent) {
        this.yamlContent = yamlContent;
    }
}
