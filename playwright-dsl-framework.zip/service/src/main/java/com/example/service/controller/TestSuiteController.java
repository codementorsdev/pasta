package com.example.service.controller;

import com.example.service.dto.RunRequest;
import com.example.service.dto.RunResponse;
import com.example.service.dto.SuiteUploadRequest;
import com.example.service.dto.SuiteUploadResponse;
import com.example.service.service.TestExecutionService;
import com.example.service.service.TestSuiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class TestSuiteController {

    @Autowired
    private TestSuiteService testSuiteService;

    @Autowired
    private TestExecutionService testExecutionService;

    @PostMapping("/suites")
    public ResponseEntity<SuiteUploadResponse> uploadSuite(@RequestBody SuiteUploadRequest request) {
        try {
            SuiteUploadResponse response = testSuiteService.uploadAndValidate(request.getYamlContent());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            SuiteUploadResponse errorResponse = new SuiteUploadResponse();
            errorResponse.setSuccess(false);
            errorResponse.setError(e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @PostMapping("/suites/{id}/run")
    public ResponseEntity<RunResponse> runSuite(@PathVariable String id, @RequestBody(required = false) RunRequest request) {
        try {
            RunResponse response = testExecutionService.executeSuite(id, request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            RunResponse errorResponse = new RunResponse();
            errorResponse.setSuccess(false);
            errorResponse.setError(e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/runs/{id}")
    public ResponseEntity<RunResponse> getRunStatus(@PathVariable String id) {
        try {
            RunResponse response = testExecutionService.getRunStatus(id);
            if (response != null) {
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            RunResponse errorResponse = new RunResponse();
            errorResponse.setSuccess(false);
            errorResponse.setError(e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }
}
