# Playwright DSL Framework

A minimal, runnable Spring Boot 3.x + Playwright (Java) test framework that demonstrates YAML-first DSL → Playwright execution.

## Architecture

\`\`\`
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│     Client      │    │   REST Service  │    │  Playwright     │
│                 │    │   (Spring Boot) │    │   Adapter       │
│ POST /suites    │───▶│                 │───▶│                 │
│ POST /run       │    │ - Upload YAML   │    │ - Execute Tests │
│ GET /runs/{id}  │    │ - Validate DSL  │    │ - Generate      │
│                 │    │ - Manage Runs   │    │   Artifacts     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │   Core DSL      │
                       │                 │
                       │ - YAML Parser   │
                       │ - Validator     │
                       │ - Execution     │
                       │   Plan Builder  │
                       └─────────────────┘
\`\`\`

## Modules

- **core** - DSL model, YAML parser, validator, AST → execution plan
- **pw-adapter** - Playwright Java adapter implementing browser automation
- **service** - Spring Boot REST app with test execution endpoints
- **samples** - Contains sample YAML test definitions

## Quick Start

### Prerequisites

- Java 17+
- Maven 3.6+
- Node.js (for Playwright browser installation)

### Build

\`\`\`bash
# Build all modules
mvn clean package

# Run unit tests only
mvn -T1C -pl core,pw-adapter,service test
\`\`\`

### Install Playwright Browsers

\`\`\`bash
# Install Playwright CLI and browsers
npx playwright install chromium firefox webkit
\`\`\`

### Run the Service

\`\`\`bash
# Start the REST service
java -jar service/target/service-1.0.0-SNAPSHOT.jar

# Service will be available at http://localhost:8080
\`\`\`

### API Usage Examples

#### 1. Upload and Validate a Test Suite

\`\`\`bash
curl -X POST http://localhost:8080/api/suites \
  -H "Content-Type: application/json" \
  -d '{
    "yamlContent": "suite:\n  id: \"my-test\"\n  tests:\n    - id: \"test1\"\n      steps:\n        - action: navigate\n          url: \"https://example.com\""
  }'
\`\`\`

Response:
\`\`\`json
{
  "success": true,
  "suiteId": "my-test",
  "warnings": []
}
\`\`\`

#### 2. Execute a Test Suite

\`\`\`bash
curl -X POST http://localhost:8080/api/suites/my-test/run \
  -H "Content-Type: application/json" \
  -d '{
    "headless": true,
    "variables": {
      "baseUrl": "https://staging.example.com"
    }
  }'
\`\`\`

Response:
\`\`\`json
{
  "success": true,
  "runId": "abc123-def456-789",
  "status": "COMPLETED",
  "testResults": [
    {
      "testId": "test1",
      "success": true,
      "artifacts": {
        "screenshot": "/path/to/screenshot.png"
      }
    }
  ]
}
\`\`\`

#### 3. Check Run Status

\`\`\`bash
curl http://localhost:8080/api/runs/abc123-def456-789
\`\`\`

### Sample YAML Test

See `samples/login.yaml` for a complete example:

\`\`\`yaml
suite:
  id: "login-poc"
  variables:
    baseUrl: "https://example.com"
    username: "testuser"
    password: "password"

tests:
  - id: "login-basic"
    browser: "chromium"
    steps:
      - action: trace-start
        name: "login-trace"
      
      - action: navigate
        url: "${baseUrl}/login"
      
      - action: fill
        selector: "#username"
        value: "${username}"
      
      - action: fill
        selector: "#password"
        value: "${password}"
      
      - action: click
        selector: "button[type=submit]"
      
      - action: expect
        selector: "h1"
        contains: "Welcome"
      
      - action: screenshot
        name: "post-login.png"
      
      - action: trace-stop
        name: "login-trace.zip"
\`\`\`

## Supported Actions

| Action | Description | Required Fields | Optional Fields |
|--------|-------------|----------------|-----------------|
| `navigate` | Navigate to URL | `url` | - |
| `click` | Click element | `selector` | - |
| `fill` | Fill input field | `selector`, `value` | - |
| `expect` | Assert text content | `selector`, `contains` | - |
| `screenshot` | Take screenshot | - | `name` |
| `route.mock` | Mock HTTP requests | `pattern` | `body` |
| `trace-start` | Start Playwright trace | - | `name` |
| `trace-stop` | Stop and save trace | - | `name` |

## Testing

### Unit Tests

\`\`\`bash
# Run all unit tests
mvn test

# Run specific module tests
mvn -pl core test
mvn -pl pw-adapter test
mvn -pl service test
\`\`\`

### Integration Tests (Smoke Test)

\`\`\`bash
# Set environment variable to enable Playwright tests
export PLAYWRIGHT_ENABLED=true

# Run integration test
mvn -pl service test -Dtest=SmokeTest
\`\`\`

**Note**: Integration tests require Playwright browsers to be installed and will be skipped if `PLAYWRIGHT_ENABLED` is not set to `true`.

## CI/CD

The project includes GitHub Actions workflow (`.github/workflows/ci.yml`) that:

1. Runs unit tests on all modules
2. Builds the application
3. Conditionally runs integration tests if Playwright is available
4. Uploads test artifacts and the built JAR

### Enabling Playwright in CI

The CI automatically attempts to install Playwright browsers. If successful, integration tests will run. Otherwise, they're skipped gracefully.

## Artifacts

Test execution generates artifacts in `service/target/artifacts/{runId}/`:
- Screenshots (`.png` files)
- Playwright traces (`.zip` files)

## Configuration

### Application Properties

```properties
# Server port
server.port=8080

# Artifacts directory
app.artifacts.dir=target/artifacts

# Actuator endpoints
management.endpoints.web.exposure.include=health,info
