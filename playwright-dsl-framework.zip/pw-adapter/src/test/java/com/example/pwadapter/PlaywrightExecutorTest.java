package com.example.pwadapter;

import com.example.core.execution.ExecutionPlan;
import com.example.core.execution.ExecutionPlanBuilder;
import com.example.core.model.Step;
import com.example.core.model.Test;
import com.example.core.model.TestSuite;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

class PlaywrightExecutorTest {
    private PlaywrightExecutor executor;
    private ExecutionPlanBuilder planBuilder;

    @BeforeEach
    void setUp() {
        executor = new PlaywrightExecutorBuilder()
            .artifactsDir(Paths.get("target/test-artifacts"))
            .headless(true)
            .build();
        planBuilder = new ExecutionPlanBuilder();
    }

    @org.junit.jupiter.api.Test
    @Disabled("Requires Playwright browsers to be installed")
    void testBasicExecution() {
        // Create a simple test suite
        Step navigateStep = new Step();
        navigateStep.setAction("navigate");
        navigateStep.setUrl("https://example.com");

        Step screenshotStep = new Step();
        screenshotStep.setAction("screenshot");
        screenshotStep.setName("test.png");

        Test test = new Test();
        test.setId("basic-test");
        test.setBrowser("chromium");
        test.setSteps(Arrays.asList(navigateStep, screenshotStep));

        TestSuite suite = new TestSuite();
        suite.setId("basic-suite");
        suite.setTests(Arrays.asList(test));

        ExecutionPlan plan = planBuilder.build(suite);
        ExecutionResult result = executor.execute(plan);

        assertNotNull(result);
        assertNotNull(result.getExecutionId());
        assertEquals(1, result.getTestResults().size());
    }

    @org.junit.jupiter.api.Test
    void testExecutionPlanVariableResolution() {
        TestSuite suite = new TestSuite();
        suite.setId("variable-test");
        suite.setVariables(new HashMap<>());
        suite.getVariables().put("baseUrl", "https://example.com");

        ExecutionPlan plan = planBuilder.build(suite);

        assertEquals("https://example.com/login", plan.resolveVariable("${baseUrl}/login"));
        assertEquals("no variables here", plan.resolveVariable("no variables here"));
    }
}
