package com.example.pwadapter;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PlaywrightExecutorBuilder {
    private Path artifactsDir = Paths.get("target/artifacts");
    private boolean headless = true;

    public PlaywrightExecutorBuilder artifactsDir(Path artifactsDir) {
        this.artifactsDir = artifactsDir;
        return this;
    }

    public PlaywrightExecutorBuilder headless(boolean headless) {
        this.headless = headless;
        return this;
    }

    public PlaywrightExecutor build() {
        return new PlaywrightExecutor(artifactsDir, headless);
    }
}
