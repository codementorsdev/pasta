package com.example.pwadapter;

import com.example.core.execution.ExecutionPlan;
import com.example.core.model.Step;
import com.example.core.model.Test;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.LoadState;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class PlaywrightExecutor {
    private final Path artifactsDir;
    private final boolean headless;
    private Playwright playwright;
    private Browser browser;
    private BrowserContext context;
    private Page page;

    public PlaywrightExecutor(Path artifactsDir, boolean headless) {
        this.artifactsDir = artifactsDir;
        this.headless = headless;
    }

    public ExecutionResult execute(ExecutionPlan plan) {
        ExecutionResult result = new ExecutionResult(plan.getExecutionId());
        
        try {
            initializePlaywright();
            
            for (Test test : plan.getTestSuite().getTests()) {
                TestResult testResult = executeTest(test, plan);
                result.addTestResult(testResult);
                
                if (!testResult.isSuccess()) {
                    result.setSuccess(false);
                    break; // Stop on first failure for POC
                }
            }
            
        } catch (Exception e) {
            result.setSuccess(false);
            result.setError("Execution failed: " + e.getMessage());
        } finally {
            cleanup();
        }
        
        return result;
    }

    private void initializePlaywright() {
        playwright = Playwright.create();
    }

    private TestResult executeTest(Test test, ExecutionPlan plan) {
        TestResult testResult = new TestResult(test.getId());
        
        try {
            // Create browser and context for each test
            String browserType = test.getBrowser() != null ? test.getBrowser() : "chromium";
            browser = createBrowser(browserType);
            context = browser.newContext();
            page = context.newPage();
            
            // Execute steps
            for (Step step : test.getSteps()) {
                executeStep(step, plan, testResult);
                if (!testResult.isSuccess()) {
                    break;
                }
            }
            
        } catch (Exception e) {
            testResult.setSuccess(false);
            testResult.setError("Test execution failed: " + e.getMessage());
        } finally {
            if (context != null) {
                context.close();
            }
            if (browser != null) {
                browser.close();
            }
        }
        
        return testResult;
    }

    private Browser createBrowser(String browserType) {
        BrowserType.LaunchOptions options = new BrowserType.LaunchOptions().setHeadless(headless);
        
        switch (browserType.toLowerCase()) {
            case "firefox":
                return playwright.firefox().launch(options);
            case "webkit":
                return playwright.webkit().launch(options);
            case "chromium":
            default:
                return playwright.chromium().launch(options);
        }
    }

    private void executeStep(Step step, ExecutionPlan plan, TestResult testResult) {
        try {
            String action = step.getAction();
            
            switch (action) {
                case "navigate":
                    executeNavigate(step, plan);
                    break;
                case "click":
                    executeClick(step, plan);
                    break;
                case "fill":
                    executeFill(step, plan);
                    break;
                case "expect":
                    executeExpect(step, plan);
                    break;
                case "screenshot":
                    executeScreenshot(step, plan, testResult);
                    break;
                case "route.mock":
                    executeRouteMock(step, plan);
                    break;
                case "trace-start":
                    executeTraceStart(step, plan);
                    break;
                case "trace-stop":
                    executeTraceStop(step, plan, testResult);
                    break;
                default:
                    throw new RuntimeException("Unsupported action: " + action);
            }
            
        } catch (Exception e) {
            testResult.setSuccess(false);
            testResult.setError("Step '" + step.getAction() + "' failed: " + e.getMessage());
        }
    }

    private void executeNavigate(Step step, ExecutionPlan plan) {
        String url = plan.resolveVariable(step.getUrl());
        page.navigate(url, new Page.NavigateOptions().setWaitUntil(LoadState.DOMCONTENTLOADED));
    }

    private void executeClick(Step step, ExecutionPlan plan) {
        String selector = plan.resolveVariable(step.getSelector());
        page.click(selector);
    }

    private void executeFill(Step step, ExecutionPlan plan) {
        String selector = plan.resolveVariable(step.getSelector());
        String value = plan.resolveVariable(step.getValue());
        page.fill(selector, value);
    }

    private void executeExpect(Step step, ExecutionPlan plan) {
        String selector = plan.resolveVariable(step.getSelector());
        String expectedText = plan.resolveVariable(step.getContains());
        
        String actualText = page.textContent(selector);
        if (actualText == null || !actualText.contains(expectedText)) {
            throw new RuntimeException("Expected text '" + expectedText + "' not found in element. Actual: '" + actualText + "'");
        }
    }

    private void executeScreenshot(Step step, ExecutionPlan plan, TestResult testResult) {
        String name = step.getName() != null ? step.getName() : "screenshot-" + System.currentTimeMillis() + ".png";
        Path screenshotPath = artifactsDir.resolve(plan.getExecutionId()).resolve(name);
        
        // Ensure directory exists
        screenshotPath.getParent().toFile().mkdirs();
        
        page.screenshot(new Page.ScreenshotOptions().setPath(screenshotPath));
        testResult.addArtifact("screenshot", screenshotPath.toString());
    }

    private void executeRouteMock(Step step, ExecutionPlan plan) {
        String pattern = plan.resolveVariable(step.getPattern());
        String body = step.getBody() != null ? plan.resolveVariable(step.getBody()) : "";
        
        page.route(pattern, route -> {
            route.fulfill(new Route.FulfillOptions()
                .setStatus(200)
                .setBody(body)
                .setContentType("application/json"));
        });
    }

    private void executeTraceStart(Step step, ExecutionPlan plan) {
        String name = step.getName() != null ? step.getName() : "trace";
        Path tracePath = artifactsDir.resolve(plan.getExecutionId());
        tracePath.toFile().mkdirs();
        
        context.tracing().start(new Tracing.StartOptions()
            .setScreenshots(true)
            .setSnapshots(true)
            .setSources(true));
    }

    private void executeTraceStop(Step step, ExecutionPlan plan, TestResult testResult) {
        String name = step.getName() != null ? step.getName() : "trace.zip";
        Path tracePath = artifactsDir.resolve(plan.getExecutionId()).resolve(name);
        
        // Ensure directory exists
        tracePath.getParent().toFile().mkdirs();
        
        context.tracing().stop(new Tracing.StopOptions().setPath(tracePath));
        testResult.addArtifact("trace", tracePath.toString());
    }

    private void cleanup() {
        if (playwright != null) {
            playwright.close();
        }
    }
}
