package com.example.pwadapter;

import java.util.ArrayList;
import java.util.List;

public class ExecutionResult {
    private final String executionId;
    private boolean success = true;
    private String error;
    private final List<TestResult> testResults = new ArrayList<>();

    public ExecutionResult(String executionId) {
        this.executionId = executionId;
    }

    public String getExecutionId() {
        return executionId;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public List<TestResult> getTestResults() {
        return testResults;
    }

    public void addTestResult(TestResult testResult) {
        this.testResults.add(testResult);
    }
}
