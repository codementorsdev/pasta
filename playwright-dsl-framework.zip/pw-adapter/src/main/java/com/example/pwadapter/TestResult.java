package com.example.pwadapter;

import java.util.HashMap;
import java.util.Map;

public class TestResult {
    private final String testId;
    private boolean success = true;
    private String error;
    private final Map<String, String> artifacts = new HashMap<>();

    public TestResult(String testId) {
        this.testId = testId;
    }

    public String getTestId() {
        return testId;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public Map<String, String> getArtifacts() {
        return artifacts;
    }

    public void addArtifact(String type, String path) {
        this.artifacts.put(type, path);
    }
}
