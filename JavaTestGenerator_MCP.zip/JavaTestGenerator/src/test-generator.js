/**
 * Test Generator
 * Generates Java REST Assured test cases from OpenAPI specifications
 */

const { TemplateEngine } = require('./template-engine');
const { ensureDirectoryExists, writeFile } = require('./utils/file-utils');
const path = require('path');

class TestGenerator {
    constructor(templatesPath) {
        this.templatesPath = templatesPath;
        this.templateEngine = new TemplateEngine(templatesPath);
    }

    async initialize() {
        await this.templateEngine.loadTemplates();
    }

    /**
     * Generate test cases from OpenAPI specification
     * @param {object} apiSpec - Parsed OpenAPI specification
     * @param {string} outputDir - Output directory for generated tests
     * @param {object} config - Generation configuration
     * @returns {Promise<object>} Generation result
     */
    async generateTests(apiSpec, outputDir, config) {
        const result = {
            filesGenerated: [],
            testClassesCreated: 0,
            endpointsCovered: 0,
            errors: []
        };

        try {
            // Ensure output directory exists
            await ensureDirectoryExists(outputDir);

            // Create package directory structure
            const packagePath = this.createPackagePath(config.basePackage);
            const testPackageDir = path.join(outputDir, 'src', 'test', 'java', packagePath);
            await ensureDirectoryExists(testPackageDir);

            // Generate Maven POM file
            await this.generatePomFile(outputDir, config, apiSpec);
            result.filesGenerated.push('pom.xml');

            // Generate base test class
            await this.generateBaseTestClass(testPackageDir, config, apiSpec);
            result.filesGenerated.push(path.join(packagePath, 'BaseApiTest.java'));

            // Group endpoints by tags or create single test class
            const endpointGroups = this.groupEndpoints(apiSpec, config);

            for (const [groupName, endpoints] of Object.entries(endpointGroups)) {
                const testClassName = this.generateTestClassName(groupName);
                const testFilePath = path.join(testPackageDir, `${testClassName}.java`);

                try {
                    await this.generateTestClass(testFilePath, testClassName, endpoints, config, apiSpec);
                    result.filesGenerated.push(path.join(packagePath, `${testClassName}.java`));
                    result.testClassesCreated++;
                    result.endpointsCovered += endpoints.length;
                } catch (error) {
                    result.errors.push(`Failed to generate ${testClassName}: ${error.message}`);
                }
            }

            // Generate test configuration files
            await this.generateTestConfig(outputDir, config, apiSpec);
            result.filesGenerated.push('src/test/resources/test.properties');

            return result;

        } catch (error) {
            throw new Error(`Test generation failed: ${error.message}`);
        }
    }

    /**
     * Create package directory path from package name
     * @param {string} packageName - Java package name
     * @returns {string} Directory path
     */
    createPackagePath(packageName) {
        return packageName.replace(/\./g, path.sep);
    }

    /**
     * Generate Maven POM file
     * @param {string} outputDir - Output directory
     * @param {object} config - Configuration
     * @param {object} apiSpec - OpenAPI specification
     */
    async generatePomFile(outputDir, config, apiSpec) {
        const pomData = {
            groupId: this.extractGroupId(config.basePackage),
            artifactId: this.generateArtifactId(apiSpec.info?.title || 'api-tests'),
            version: '1.0.0',
            projectName: apiSpec.info?.title || 'API Tests',
            description: apiSpec.info?.description || 'Generated REST Assured tests',
            testFramework: config.testFramework,
            javaVersion: '17',
            isJunit5: config.testFramework === 'junit5',
            isTestNG: config.testFramework === 'testng'
        };

        const pomContent = await this.templateEngine.render('pom', pomData);
        await writeFile(path.join(outputDir, 'pom.xml'), pomContent);
    }

    /**
     * Generate base test class
     * @param {string} testPackageDir - Test package directory
     * @param {object} config - Configuration
     * @param {object} apiSpec - OpenAPI specification
     */
    async generateBaseTestClass(testPackageDir, config, apiSpec) {
        const baseTestData = {
            packageName: config.basePackage,
            baseUrl: this.extractBaseUrl(apiSpec),
            baseUrlPlaceholder: config.baseUrlPlaceholder,
            authType: config.authType,
            testFramework: config.testFramework,
            hasAuth: config.authType !== 'none',
            isJunit5: config.testFramework === 'junit5',
            isTestNG: config.testFramework === 'testng'
        };

        const baseTestContent = await this.templateEngine.render('base-test-class', baseTestData);
        await writeFile(path.join(testPackageDir, 'BaseApiTest.java'), baseTestContent);
    }

    /**
     * Group endpoints by tags or other criteria
     * @param {object} apiSpec - OpenAPI specification
     * @param {object} config - Configuration
     * @returns {object} Grouped endpoints
     */
    groupEndpoints(apiSpec, config) {
        const groups = {};
        
        for (const [path, pathItem] of Object.entries(apiSpec.paths || {})) {
            for (const [method, operation] of Object.entries(pathItem)) {
                if (this.isHttpMethod(method) && typeof operation === 'object') {
                    const endpoint = {
                        path,
                        method: method.toUpperCase(),
                        operation,
                        pathItem
                    };

                    // Group by first tag or use 'default'
                    const groupName = operation.tags?.[0] || 'default';
                    
                    if (!groups[groupName]) {
                        groups[groupName] = [];
                    }
                    
                    groups[groupName].push(endpoint);
                }
            }
        }

        return groups;
    }

    /**
     * Generate test class for a group of endpoints
     * @param {string} filePath - Output file path
     * @param {string} className - Test class name
     * @param {Array} endpoints - Endpoints to test
     * @param {object} config - Configuration
     * @param {object} apiSpec - OpenAPI specification
     */
    async generateTestClass(filePath, className, endpoints, config, apiSpec) {
        const testMethods = [];

        for (let i = 0; i < endpoints.length; i++) {
            const endpoint = endpoints[i];
            const testMethod = await this.generateTestMethod(endpoint, i + 1, config, apiSpec);
            testMethods.push(testMethod);

            // Generate negative test cases
            const negativeTests = await this.generateNegativeTests(endpoint, testMethods.length, config, apiSpec);
            testMethods.push(...negativeTests);
        }

        const testClassData = {
            packageName: config.basePackage,
            className,
            testFramework: config.testFramework,
            imports: this.generateImports(config),
            testMethods: testMethods.join('\n\n')
        };

        const testClassContent = await this.templateEngine.render('test-class', testClassData);
        await writeFile(filePath, testClassContent);
    }

    /**
     * Generate a test method for an endpoint
     * @param {object} endpoint - Endpoint information
     * @param {number} order - Test order
     * @param {object} config - Configuration
     * @param {object} apiSpec - OpenAPI specification
     * @returns {Promise<string>} Generated test method
     */
    async generateTestMethod(endpoint, order, config, apiSpec) {
        const { path, method, operation } = endpoint;
        
        const methodData = {
            methodName: this.generateTestMethodName(operation, method, path, 'success'),
            displayName: this.generateDisplayName(operation, method, path),
            order,
            httpMethod: method.toLowerCase(),
            path: this.convertPathParams(path),
            expectedStatus: this.getSuccessStatusCode(operation.responses),
            pathParams: this.extractPathParameters(endpoint),
            queryParams: this.extractQueryParameters(endpoint),
            headers: this.extractHeaders(endpoint),
            hasBody: this.hasRequestBody(operation),
            requestBody: this.generateRequestBody(operation, apiSpec),
            responseValidation: this.generateResponseValidation(operation, config),
            authRequired: this.requiresAuth(operation, apiSpec),
            authType: config.authType,
            isBearerAuth: config.authType === 'bearer',
            isBasicAuth: config.authType === 'basic',
            isCustomAuth: config.authType === 'custom',
            tag: operation.tags?.[0] || 'api'
        };

        return await this.templateEngine.render('test-method', methodData);
    }

    /**
     * Generate negative test cases for an endpoint
     * @param {object} endpoint - Endpoint information
     * @param {number} startOrder - Starting order number
     * @param {object} config - Configuration
     * @param {object} apiSpec - OpenAPI specification
     * @returns {Promise<Array>} Generated negative test methods
     */
    async generateNegativeTests(endpoint, startOrder, config, apiSpec) {
        const negativeTests = [];
        const { operation } = endpoint;
        
        // Generate test for 400 Bad Request (if applicable)
        if (this.hasRequestBody(operation) && operation.responses?.['400']) {
            const badRequestTest = await this.generateBadRequestTest(endpoint, startOrder + 1, config, apiSpec);
            negativeTests.push(badRequestTest);
        }

        // Generate test for 401 Unauthorized (if auth is required)
        if (this.requiresAuth(operation, apiSpec) && operation.responses?.['401']) {
            const unauthorizedTest = await this.generateUnauthorizedTest(endpoint, startOrder + negativeTests.length + 1, config, apiSpec);
            negativeTests.push(unauthorizedTest);
        }

        // Generate test for 404 Not Found
        if (operation.responses?.['404']) {
            const notFoundTest = await this.generateNotFoundTest(endpoint, startOrder + negativeTests.length + 1, config, apiSpec);
            negativeTests.push(notFoundTest);
        }

        return negativeTests;
    }

    /**
     * Generate bad request test
     */
    async generateBadRequestTest(endpoint, order, config, apiSpec) {
        const { path, method, operation } = endpoint;
        
        const methodData = {
            methodName: this.generateTestMethodName(operation, method, path, 'badRequest'),
            displayName: `${this.generateDisplayName(operation, method, path)} - Bad Request`,
            order,
            httpMethod: method.toLowerCase(),
            path: this.convertPathParams(path),
            expectedStatus: 400,
            pathParams: this.extractPathParameters(endpoint),
            queryParams: [],
            headers: this.extractHeaders(endpoint),
            hasBody: true,
            requestBody: this.generateInvalidRequestBody(operation, apiSpec),
            responseValidation: [],
            authRequired: this.requiresAuth(operation, apiSpec),
            authType: config.authType,
            tag: 'negative'
        };

        return await this.templateEngine.render('test-method', methodData);
    }

    /**
     * Generate unauthorized test
     */
    async generateUnauthorizedTest(endpoint, order, config, apiSpec) {
        const { path, method, operation } = endpoint;
        
        const methodData = {
            methodName: this.generateTestMethodName(operation, method, path, 'unauthorized'),
            displayName: `${this.generateDisplayName(operation, method, path)} - Unauthorized`,
            order,
            httpMethod: method.toLowerCase(),
            path: this.convertPathParams(path),
            expectedStatus: 401,
            pathParams: this.extractPathParameters(endpoint),
            queryParams: this.extractQueryParameters(endpoint),
            headers: this.extractHeaders(endpoint),
            hasBody: this.hasRequestBody(operation),
            requestBody: this.generateRequestBody(operation, apiSpec),
            responseValidation: [],
            authRequired: false, // Don't include auth for unauthorized test
            authType: 'none',
            tag: 'negative'
        };

        return await this.templateEngine.render('test-method', methodData);
    }

    /**
     * Generate not found test
     */
    async generateNotFoundTest(endpoint, order, config, apiSpec) {
        const { path, method, operation } = endpoint;
        
        const methodData = {
            methodName: this.generateTestMethodName(operation, method, path, 'notFound'),
            displayName: `${this.generateDisplayName(operation, method, path)} - Not Found`,
            order,
            httpMethod: method.toLowerCase(),
            path: this.convertPathParams(path, true), // Use invalid path params
            expectedStatus: 404,
            pathParams: this.extractPathParameters(endpoint, true), // Invalid path params
            queryParams: this.extractQueryParameters(endpoint),
            headers: this.extractHeaders(endpoint),
            hasBody: this.hasRequestBody(operation),
            requestBody: this.generateRequestBody(operation, apiSpec),
            responseValidation: [],
            authRequired: this.requiresAuth(operation, apiSpec),
            authType: config.authType,
            tag: 'negative'
        };

        return await this.templateEngine.render('test-method', methodData);
    }

    /**
     * Generate test configuration files
     * @param {string} outputDir - Output directory
     * @param {object} config - Configuration
     * @param {object} apiSpec - OpenAPI specification
     */
    async generateTestConfig(outputDir, config, apiSpec) {
        const configDir = path.join(outputDir, 'src', 'test', 'resources');
        await ensureDirectoryExists(configDir);

        const configContent = [
            `# Generated test configuration`,
            `base.url=${this.extractBaseUrl(apiSpec)}`,
            `api.timeout=30000`,
            `test.framework=${config.testFramework}`,
            `auth.type=${config.authType}`,
            ''
        ].join('\n');

        await writeFile(path.join(configDir, 'test.properties'), configContent);
    }

    // Helper methods

    isHttpMethod(method) {
        const httpMethods = ['get', 'post', 'put', 'delete', 'patch', 'head', 'options', 'trace'];
        return httpMethods.includes(method.toLowerCase());
    }

    extractGroupId(packageName) {
        const parts = packageName.split('.');
        return parts.slice(0, -1).join('.');
    }

    generateArtifactId(title) {
        return title.toLowerCase()
            .replace(/[^a-zA-Z0-9\s]/g, '')
            .replace(/\s+/g, '-')
            .replace(/^-+|-+$/g, '');
    }

    extractBaseUrl(apiSpec) {
        const servers = apiSpec.servers || [];
        return servers.length > 0 ? servers[0].url : 'http://localhost:8080';
    }

    generateTestClassName(groupName) {
        return groupName.charAt(0).toUpperCase() + 
               groupName.slice(1).toLowerCase() + 'ApiTest';
    }

    generateTestMethodName(operation, method, path, suffix = '') {
        let name = operation.operationId || `${method}_${path.replace(/[^a-zA-Z0-9]/g, '_')}`;
        name = name.replace(/[^a-zA-Z0-9]/g, '_').replace(/_+/g, '_');
        
        if (suffix) {
            name += '_' + suffix;
        }
        
        return name;
    }

    generateDisplayName(operation, method, path) {
        return operation.summary || `${method.toUpperCase()} ${path}`;
    }

    convertPathParams(path, useInvalid = false) {
        return path.replace(/\{([^}]+)\}/g, (match, paramName) => {
            return useInvalid ? `{invalid_${paramName}}` : `{${paramName}}`;
        });
    }

    extractPathParameters(endpoint, useInvalid = false) {
        const pathParams = [];
        const allParams = [
            ...(endpoint.pathItem.parameters || []),
            ...(endpoint.operation.parameters || [])
        ];

        allParams.forEach(param => {
            if (param.in === 'path') {
                const paramType = param.schema?.type || 'string';
                pathParams.push({
                    name: param.name,
                    value: useInvalid ? '999999' : this.generateParamValue(param),
                    type: paramType,
                    isString: paramType === 'string',
                    isInteger: paramType === 'integer',
                    isNumber: paramType === 'number'
                });
            }
        });

        return pathParams;
    }

    extractQueryParameters(endpoint) {
        const queryParams = [];
        const allParams = [
            ...(endpoint.pathItem.parameters || []),
            ...(endpoint.operation.parameters || [])
        ];

        allParams.forEach(param => {
            if (param.in === 'query' && param.required) {
                const paramType = param.schema?.type || 'string';
                queryParams.push({
                    name: param.name,
                    value: this.generateParamValue(param),
                    type: paramType,
                    isString: paramType === 'string',
                    isInteger: paramType === 'integer',
                    isNumber: paramType === 'number'
                });
            }
        });

        return queryParams;
    }

    extractHeaders(endpoint) {
        const headers = [];
        const allParams = [
            ...(endpoint.pathItem.parameters || []),
            ...(endpoint.operation.parameters || [])
        ];

        allParams.forEach(param => {
            if (param.in === 'header') {
                headers.push({
                    name: param.name,
                    value: this.generateParamValue(param)
                });
            }
        });

        return headers;
    }

    generateParamValue(param) {
        const schema = param.schema || {};
        const type = schema.type || 'string';

        switch (type) {
            case 'integer':
                return schema.example || 1;
            case 'number':
                return schema.example || 1.0;
            case 'boolean':
                return schema.example || true;
            case 'array':
                return schema.example || ['value'];
            default:
                return schema.example || 'test_value';
        }
    }

    hasRequestBody(operation) {
        return !!operation.requestBody;
    }

    generateRequestBody(operation, apiSpec) {
        if (!operation.requestBody) {
            return null;
        }

        const content = operation.requestBody.content || {};
        const jsonContent = content['application/json'];
        
        if (jsonContent && jsonContent.schema) {
            return this.generateJsonFromSchema(jsonContent.schema, apiSpec);
        }

        return '{}';
    }

    generateInvalidRequestBody(operation, apiSpec) {
        return '{"invalid": "data"}';
    }

    generateJsonFromSchema(schema, apiSpec, depth = 0) {
        if (depth > 3) return '{}'; // Prevent infinite recursion

        if (schema.$ref) {
            // Resolve reference (simplified)
            const refPath = schema.$ref.replace('#/components/schemas/', '');
            const refSchema = apiSpec.components?.schemas?.[refPath];
            if (refSchema) {
                return this.generateJsonFromSchema(refSchema, apiSpec, depth + 1);
            }
        }

        const type = schema.type;
        
        switch (type) {
            case 'object':
                const obj = {};
                if (schema.properties) {
                    for (const [propName, propSchema] of Object.entries(schema.properties)) {
                        obj[propName] = this.generateValueFromSchema(propSchema, apiSpec, depth + 1);
                    }
                }
                return JSON.stringify(obj, null, 2);
            
            case 'array':
                const itemValue = schema.items ? 
                    this.generateValueFromSchema(schema.items, apiSpec, depth + 1) : 'item';
                return JSON.stringify([itemValue]);
            
            default:
                return JSON.stringify(this.generateValueFromSchema(schema, apiSpec, depth));
        }
    }

    generateValueFromSchema(schema, apiSpec, depth = 0) {
        if (schema.example !== undefined) {
            return schema.example;
        }

        const type = schema.type || 'string';
        
        switch (type) {
            case 'integer':
                return 1;
            case 'number':
                return 1.0;
            case 'boolean':
                return true;
            case 'array':
                return ['item'];
            case 'object':
                if (depth > 2) return {};
                const obj = {};
                if (schema.properties) {
                    for (const [propName, propSchema] of Object.entries(schema.properties)) {
                        obj[propName] = this.generateValueFromSchema(propSchema, apiSpec, depth + 1);
                    }
                }
                return obj;
            default:
                return 'test_value';
        }
    }

    getSuccessStatusCode(responses) {
        const successCodes = ['200', '201', '202', '204'];
        for (const code of successCodes) {
            if (responses[code]) {
                return parseInt(code);
            }
        }
        return 200;
    }

    generateResponseValidation(operation, config) {
        const validations = [];
        
        if (config.responseValidationLevel === 'basic') {
            return validations;
        }

        // Add content type validation
        validations.push('contentType(ContentType.JSON)');

        if (config.responseValidationLevel === 'detailed' || config.responseValidationLevel === 'schema') {
            // Add basic JSON structure validation
            const responses = operation.responses || {};
            const successResponse = responses['200'] || responses['201'] || responses['202'];
            
            if (successResponse?.content?.['application/json']?.schema) {
                // Add schema validation if available
                validations.push('body(notNullValue())');
            }
        }

        return validations;
    }

    requiresAuth(operation, apiSpec) {
        return !!(operation.security || apiSpec.security);
    }

    generateImports(config) {
        const imports = [
            'import io.restassured.RestAssured;',
            'import io.restassured.http.ContentType;',
            'import io.restassured.response.Response;',
            'import static io.restassured.RestAssured.given;',
            'import static org.hamcrest.Matchers.*;'
        ];

        if (config.testFramework === 'junit5') {
            imports.push(
                'import org.junit.jupiter.api.*;',
                'import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;'
            );
        } else if (config.testFramework === 'testng') {
            imports.push(
                'import org.testng.annotations.*;'
            );
        }

        return imports.join('\n');
    }
}

module.exports = { TestGenerator };
