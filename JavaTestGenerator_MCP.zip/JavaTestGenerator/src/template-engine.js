/**
 * Template Engine
 * Handles template loading and rendering using Mustache.js
 */

const fs = require('fs').promises;
const path = require('path');
const Mustache = require('mustache');

class TemplateEngine {
    constructor(templatesPath) {
        this.templatesPath = templatesPath;
        this.templates = new Map();
        this.partials = new Map();
    }

    /**
     * Load all templates from the templates directory
     */
    async loadTemplates() {
        try {
            const templateFiles = await this.getTemplateFiles();
            
            for (const file of templateFiles) {
                await this.loadTemplate(file);
            }

            console.log(`Loaded ${this.templates.size} templates`);
        } catch (error) {
            throw new Error(`Failed to load templates: ${error.message}`);
        }
    }

    /**
     * Get list of template files
     * @returns {Promise<Array>} Array of template file paths
     */
    async getTemplateFiles() {
        try {
            const files = await fs.readdir(this.templatesPath);
            return files.filter(file => file.endsWith('.mustache'));
        } catch (error) {
            throw new Error(`Cannot read templates directory ${this.templatesPath}: ${error.message}`);
        }
    }

    /**
     * Load a single template file
     * @param {string} filename - Template filename
     */
    async loadTemplate(filename) {
        try {
            const filePath = path.join(this.templatesPath, filename);
            const content = await fs.readFile(filePath, 'utf8');
            const templateName = path.basename(filename, '.mustache');
            
            this.templates.set(templateName, content);
            
            // If it's a partial template (starts with _), also add it to partials
            if (templateName.startsWith('_')) {
                const partialName = templateName.substring(1);
                this.partials.set(partialName, content);
            }
        } catch (error) {
            throw new Error(`Failed to load template ${filename}: ${error.message}`);
        }
    }

    /**
     * Render a template with data
     * @param {string} templateName - Name of the template
     * @param {object} data - Data to render with
     * @returns {Promise<string>} Rendered template
     */
    async render(templateName, data = {}) {
        if (!this.templates.has(templateName)) {
            throw new Error(`Template '${templateName}' not found. Available templates: ${Array.from(this.templates.keys()).join(', ')}`);
        }

        try {
            const template = this.templates.get(templateName);
            const partials = Object.fromEntries(this.partials);
            
            // Add helper functions to data
            const renderData = {
                ...data,
                ...this.getHelperFunctions()
            };

            // Configure Mustache to not escape HTML for code generation
            Mustache.escape = function(text) { return text; };
            const result = Mustache.render(template, renderData, partials);
            return result;
        } catch (error) {
            throw new Error(`Failed to render template '${templateName}': ${error.message}`);
        }
    }

    /**
     * Get helper functions for templates
     * @returns {object} Helper functions
     */
    getHelperFunctions() {
        return {
            /**
             * Convert string to camelCase
             */
            camelCase: function() {
                return function(text, render) {
                    const rendered = render(text);
                    return rendered.replace(/[-_\s]+(.)?/g, (_, char) => char ? char.toUpperCase() : '');
                };
            },

            /**
             * Convert string to PascalCase
             */
            pascalCase: function() {
                return function(text, render) {
                    const rendered = render(text);
                    const camelCase = rendered.replace(/[-_\s]+(.)?/g, (_, char) => char ? char.toUpperCase() : '');
                    return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
                };
            },

            /**
             * Convert string to snake_case
             */
            snakeCase: function() {
                return function(text, render) {
                    const rendered = render(text);
                    return rendered.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`)
                                  .replace(/[-\s]+/g, '_')
                                  .replace(/^_/, '');
                };
            },

            /**
             * Convert string to UPPER_CASE
             */
            upperCase: function() {
                return function(text, render) {
                    const rendered = render(text);
                    return rendered.toUpperCase();
                };
            },

            /**
             * Escape Java string
             */
            escapeJava: function() {
                return function(text, render) {
                    const rendered = render(text);
                    return rendered.replace(/\\/g, '\\\\')
                                  .replace(/"/g, '\\"')
                                  .replace(/\n/g, '\\n')
                                  .replace(/\r/g, '\\r')
                                  .replace(/\t/g, '\\t');
                };
            },

            /**
             * Format JSON with proper indentation
             */
            formatJson: function() {
                return function(text, render) {
                    const rendered = render(text);
                    try {
                        const parsed = JSON.parse(rendered);
                        return JSON.stringify(parsed, null, 4);
                    } catch {
                        return rendered;
                    }
                };
            },

            /**
             * Check if array has items
             */
            hasItems: function() {
                return function(text, render) {
                    const rendered = render(text);
                    try {
                        const array = JSON.parse(rendered);
                        return Array.isArray(array) && array.length > 0;
                    } catch {
                        return false;
                    }
                };
            },

            /**
             * Join array items with separator
             */
            join: function() {
                return function(text, render) {
                    const rendered = render(text);
                    try {
                        const [arrayStr, separator = ', '] = rendered.split('|');
                        const array = JSON.parse(arrayStr);
                        return Array.isArray(array) ? array.join(separator) : rendered;
                    } catch {
                        return rendered;
                    }
                };
            },

            /**
             * Indent text by specified number of spaces
             */
            indent: function() {
                return function(text, render) {
                    const rendered = render(text);
                    const [content, spaces = '4'] = rendered.split('|');
                    const indentation = ' '.repeat(parseInt(spaces));
                    return content.split('\n').map(line => line ? indentation + line : line).join('\n');
                };
            }
        };
    }

    /**
     * Reload a specific template
     * @param {string} templateName - Name of the template to reload
     */
    async reloadTemplate(templateName) {
        const filename = `${templateName}.mustache`;
        await this.loadTemplate(filename);
    }

    /**
     * Reload all templates
     */
    async reloadAllTemplates() {
        this.templates.clear();
        this.partials.clear();
        await this.loadTemplates();
    }

    /**
     * Get list of available templates
     * @returns {Array} Array of template names
     */
    getAvailableTemplates() {
        return Array.from(this.templates.keys());
    }

    /**
     * Check if template exists
     * @param {string} templateName - Name of the template
     * @returns {boolean} True if template exists
     */
    hasTemplate(templateName) {
        return this.templates.has(templateName);
    }

    /**
     * Add a template dynamically
     * @param {string} name - Template name
     * @param {string} content - Template content
     */
    addTemplate(name, content) {
        this.templates.set(name, content);
        
        if (name.startsWith('_')) {
            const partialName = name.substring(1);
            this.partials.set(partialName, content);
        }
    }

    /**
     * Remove a template
     * @param {string} name - Template name
     */
    removeTemplate(name) {
        this.templates.delete(name);
        
        if (name.startsWith('_')) {
            const partialName = name.substring(1);
            this.partials.delete(partialName);
        }
    }

    /**
     * Get template content
     * @param {string} templateName - Name of the template
     * @returns {string} Template content
     */
    getTemplate(templateName) {
        return this.templates.get(templateName);
    }

    /**
     * Validate template syntax
     * @param {string} content - Template content to validate
     * @returns {object} Validation result
     */
    validateTemplate(content) {
        try {
            // Try to parse the template
            Mustache.parse(content);
            return { valid: true };
        } catch (error) {
            return {
                valid: false,
                error: error.message
            };
        }
    }
}

module.exports = { TemplateEngine };
