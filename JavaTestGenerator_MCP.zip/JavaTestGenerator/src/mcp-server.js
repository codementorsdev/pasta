/**
 * MCP Server Implementation
 * Implements the Model Context Protocol server for REST Assured test generation
 */

const { OpenAPIParser } = require('./openapi-parser');
const { TestGenerator } = require('./test-generator');
const { validateInput, validateOpenAPISpec } = require('./utils/validation');
const { ensureDirectoryExists, writeFile } = require('./utils/file-utils');
const fs = require('fs').promises;
const path = require('path');

class MCPServer {
    constructor(options = {}) {
        this.name = options.name || 'restassured-test-generator';
        this.version = options.version || '1.0.0';
        this.description = options.description || 'Generate Java REST Assured test cases from OpenAPI specifications';
        this.configPath = options.configPath;
        this.templatesPath = options.templatesPath;
        
        this.parser = new OpenAPIParser();
        this.testGenerator = new TestGenerator(this.templatesPath);
        this.isRunning = false;
        
        // Tool definitions
        this.tools = [
            {
                name: 'generate_tests',
                description: 'Generate REST Assured test cases from OpenAPI spec',
                inputSchema: {
                    type: 'object',
                    properties: {
                        spec_path: {
                            type: 'string',
                            description: 'Path to OpenAPI YAML file'
                        },
                        output_dir: {
                            type: 'string',
                            description: 'Output directory for generated tests'
                        },
                        base_package: {
                            type: 'string',
                            description: 'Java package name',
                            default: 'com.api.tests'
                        },
                        test_framework: {
                            type: 'string',
                            enum: ['junit5', 'testng'],
                            description: 'Test framework to use',
                            default: 'junit5'
                        },
                        include_tags: {
                            type: 'array',
                            items: { type: 'string' },
                            description: 'Array of OpenAPI tags to include'
                        },
                        exclude_tags: {
                            type: 'array',
                            items: { type: 'string' },
                            description: 'Array of OpenAPI tags to exclude'
                        },
                        auth_type: {
                            type: 'string',
                            enum: ['none', 'basic', 'bearer', 'oauth2', 'custom'],
                            description: 'Authentication type',
                            default: 'none'
                        },
                        base_url_placeholder: {
                            type: 'string',
                            description: 'Placeholder for base URL',
                            default: '${BASE_URL}'
                        },
                        generate_data_providers: {
                            type: 'boolean',
                            description: 'Generate test data providers',
                            default: false
                        },
                        response_validation_level: {
                            type: 'string',
                            enum: ['basic', 'detailed', 'schema'],
                            description: 'Response validation level',
                            default: 'detailed'
                        }
                    },
                    required: ['spec_path', 'output_dir']
                }
            },
            {
                name: 'validate_spec',
                description: 'Validate OpenAPI specification',
                inputSchema: {
                    type: 'object',
                    properties: {
                        spec_path: {
                            type: 'string',
                            description: 'Path to OpenAPI YAML file'
                        },
                        strict_mode: {
                            type: 'boolean',
                            description: 'Enable strict validation',
                            default: false
                        }
                    },
                    required: ['spec_path']
                }
            },
            {
                name: 'list_endpoints',
                description: 'List all endpoints from OpenAPI spec with metadata',
                inputSchema: {
                    type: 'object',
                    properties: {
                        spec_path: {
                            type: 'string',
                            description: 'Path to OpenAPI YAML file'
                        },
                        format: {
                            type: 'string',
                            enum: ['json', 'table', 'summary'],
                            description: 'Output format',
                            default: 'json'
                        }
                    },
                    required: ['spec_path']
                }
            }
        ];
    }

    async start() {
        if (this.isRunning) {
            throw new Error('Server is already running');
        }

        try {
            // Load configuration if available
            if (this.configPath) {
                await this.loadConfig();
            }

            // Initialize test generator with templates
            await this.testGenerator.initialize();

            this.isRunning = true;
            console.log(`MCP Server ${this.name} v${this.version} started`);
        } catch (error) {
            throw new Error(`Failed to start server: ${error.message}`);
        }
    }

    async shutdown() {
        if (!this.isRunning) {
            return;
        }

        this.isRunning = false;
        console.log('MCP Server shutdown complete');
    }

    async loadConfig() {
        try {
            const configData = await fs.readFile(this.configPath, 'utf8');
            this.config = JSON.parse(configData);
        } catch (error) {
            console.warn(`Could not load config from ${this.configPath}: ${error.message}`);
            this.config = {};
        }
    }

    /**
     * Handle tool execution requests
     * @param {string} toolName - Name of the tool to execute
     * @param {object} args - Tool arguments
     * @returns {Promise<object>} Tool execution result
     */
    async executeTool(toolName, args) {
        if (!this.isRunning) {
            throw new Error('Server is not running');
        }

        switch (toolName) {
            case 'generate_tests':
                return await this.handleGenerateTests(args);
            case 'validate_spec':
                return await this.handleValidateSpec(args);
            case 'list_endpoints':
                return await this.handleListEndpoints(args);
            default:
                throw new Error(`Unknown tool: ${toolName}`);
        }
    }

    /**
     * Handle test generation requests
     */
    async handleGenerateTests(args) {
        try {
            // Validate input arguments
            const validation = validateInput(args, this.tools[0].inputSchema);
            if (!validation.valid) {
                return {
                    success: false,
                    error: `Invalid arguments: ${validation.errors.join(', ')}`
                };
            }

            const {
                spec_path,
                output_dir,
                base_package = 'com.api.tests',
                test_framework = 'junit5',
                include_tags,
                exclude_tags,
                auth_type = 'none',
                base_url_placeholder = '${BASE_URL}',
                generate_data_providers = false,
                response_validation_level = 'detailed'
            } = args;

            // Parse OpenAPI specification
            const apiSpec = await this.parser.parseFromFile(spec_path);
            
            // Validate the parsed specification
            const specValidation = validateOpenAPISpec(apiSpec);
            if (!specValidation.valid) {
                return {
                    success: false,
                    error: `Invalid OpenAPI specification: ${specValidation.errors.join(', ')}`
                };
            }

            // Filter endpoints by tags if specified
            const filteredSpec = this.filterEndpointsByTags(apiSpec, include_tags, exclude_tags);

            // Generate test configuration
            const testConfig = {
                basePackage: base_package,
                testFramework: test_framework,
                authType: auth_type,
                baseUrlPlaceholder: base_url_placeholder,
                generateDataProviders: generate_data_providers,
                responseValidationLevel: response_validation_level
            };

            // Generate tests
            const generationResult = await this.testGenerator.generateTests(
                filteredSpec,
                output_dir,
                testConfig
            );

            return {
                success: true,
                message: 'Tests generated successfully',
                details: {
                    filesGenerated: generationResult.filesGenerated,
                    testClassesCreated: generationResult.testClassesCreated,
                    endpointsCovered: generationResult.endpointsCovered,
                    outputDirectory: output_dir
                }
            };

        } catch (error) {
            return {
                success: false,
                error: `Test generation failed: ${error.message}`
            };
        }
    }

    /**
     * Handle specification validation requests
     */
    async handleValidateSpec(args) {
        try {
            const { spec_path, strict_mode = false } = args;

            // Parse and validate the specification
            const apiSpec = await this.parser.parseFromFile(spec_path);
            const validation = validateOpenAPISpec(apiSpec, strict_mode);

            if (validation.valid) {
                return {
                    success: true,
                    message: 'OpenAPI specification is valid',
                    details: {
                        version: apiSpec.openapi,
                        title: apiSpec.info?.title,
                        version_info: apiSpec.info?.version,
                        paths: Object.keys(apiSpec.paths || {}).length,
                        components: Object.keys(apiSpec.components?.schemas || {}).length
                    }
                };
            } else {
                return {
                    success: false,
                    error: 'OpenAPI specification validation failed',
                    details: {
                        errors: validation.errors,
                        warnings: validation.warnings || []
                    }
                };
            }

        } catch (error) {
            return {
                success: false,
                error: `Validation failed: ${error.message}`
            };
        }
    }

    /**
     * Handle list endpoints requests
     */
    async handleListEndpoints(args) {
        try {
            const { spec_path, format = 'json' } = args;

            // Parse the specification
            const apiSpec = await this.parser.parseFromFile(spec_path);
            const endpoints = this.extractEndpoints(apiSpec);

            switch (format) {
                case 'table':
                    return {
                        success: true,
                        data: this.formatEndpointsAsTable(endpoints)
                    };
                case 'summary':
                    return {
                        success: true,
                        data: this.formatEndpointsSummary(endpoints)
                    };
                default:
                    return {
                        success: true,
                        data: endpoints
                    };
            }

        } catch (error) {
            return {
                success: false,
                error: `Failed to list endpoints: ${error.message}`
            };
        }
    }

    /**
     * Filter endpoints by include/exclude tags
     */
    filterEndpointsByTags(apiSpec, includeTags, excludeTags) {
        if (!includeTags && !excludeTags) {
            return apiSpec;
        }

        const filteredSpec = JSON.parse(JSON.stringify(apiSpec));
        const filteredPaths = {};

        for (const [path, pathItem] of Object.entries(apiSpec.paths || {})) {
            const filteredPathItem = {};

            for (const [method, operation] of Object.entries(pathItem)) {
                if (typeof operation !== 'object' || !operation.tags) {
                    filteredPathItem[method] = operation;
                    continue;
                }

                const operationTags = operation.tags || [];
                
                // Check include tags
                if (includeTags && includeTags.length > 0) {
                    const hasIncludedTag = operationTags.some(tag => includeTags.includes(tag));
                    if (!hasIncludedTag) continue;
                }

                // Check exclude tags
                if (excludeTags && excludeTags.length > 0) {
                    const hasExcludedTag = operationTags.some(tag => excludeTags.includes(tag));
                    if (hasExcludedTag) continue;
                }

                filteredPathItem[method] = operation;
            }

            if (Object.keys(filteredPathItem).length > 0) {
                filteredPaths[path] = filteredPathItem;
            }
        }

        filteredSpec.paths = filteredPaths;
        return filteredSpec;
    }

    /**
     * Extract endpoint information from OpenAPI spec
     */
    extractEndpoints(apiSpec) {
        const endpoints = [];

        for (const [path, pathItem] of Object.entries(apiSpec.paths || {})) {
            for (const [method, operation] of Object.entries(pathItem)) {
                if (typeof operation === 'object' && operation.operationId) {
                    endpoints.push({
                        path,
                        method: method.toUpperCase(),
                        operationId: operation.operationId,
                        summary: operation.summary,
                        description: operation.description,
                        tags: operation.tags || [],
                        parameters: this.extractParameters(operation.parameters, pathItem.parameters),
                        requestBody: operation.requestBody ? true : false,
                        responses: Object.keys(operation.responses || {}),
                        security: operation.security || apiSpec.security || []
                    });
                }
            }
        }

        return endpoints;
    }

    /**
     * Extract parameters from operation and path level
     */
    extractParameters(operationParams = [], pathParams = []) {
        const allParams = [...pathParams, ...operationParams];
        return allParams.map(param => ({
            name: param.name,
            in: param.in,
            required: param.required || false,
            type: param.schema?.type || 'string'
        }));
    }

    /**
     * Format endpoints as a table
     */
    formatEndpointsAsTable(endpoints) {
        const headers = ['Method', 'Path', 'Operation ID', 'Tags', 'Summary'];
        const rows = endpoints.map(endpoint => [
            endpoint.method,
            endpoint.path,
            endpoint.operationId,
            endpoint.tags.join(', '),
            endpoint.summary || ''
        ]);

        return {
            headers,
            rows,
            total: endpoints.length
        };
    }

    /**
     * Format endpoints summary
     */
    formatEndpointsSummary(endpoints) {
        const methodCounts = {};
        const tagCounts = {};

        endpoints.forEach(endpoint => {
            methodCounts[endpoint.method] = (methodCounts[endpoint.method] || 0) + 1;
            endpoint.tags.forEach(tag => {
                tagCounts[tag] = (tagCounts[tag] || 0) + 1;
            });
        });

        return {
            total: endpoints.length,
            byMethod: methodCounts,
            byTag: tagCounts,
            paths: [...new Set(endpoints.map(e => e.path))].length
        };
    }

    /**
     * Get available tools
     */
    getTools() {
        return this.tools;
    }
}

module.exports = { MCPServer };
