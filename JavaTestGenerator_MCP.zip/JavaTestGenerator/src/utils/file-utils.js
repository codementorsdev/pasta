/**
 * File Utilities
 * Provides utility functions for file and directory operations
 */

const fs = require('fs').promises;
const path = require('path');

/**
 * Ensure directory exists, create if it doesn't
 * @param {string} dirPath - Directory path to ensure
 * @returns {Promise<void>}
 */
async function ensureDirectoryExists(dirPath) {
    try {
        await fs.access(dirPath);
    } catch (error) {
        if (error.code === 'ENOENT') {
            await fs.mkdir(dirPath, { recursive: true });
        } else {
            throw new Error(`Failed to access directory ${dirPath}: ${error.message}`);
        }
    }
}

/**
 * Write content to a file
 * @param {string} filePath - File path to write to
 * @param {string} content - Content to write
 * @param {object} options - Write options
 * @returns {Promise<void>}
 */
async function writeFile(filePath, content, options = {}) {
    try {
        const dir = path.dirname(filePath);
        await ensureDirectoryExists(dir);
        
        const writeOptions = {
            encoding: 'utf8',
            ...options
        };
        
        await fs.writeFile(filePath, content, writeOptions);
    } catch (error) {
        throw new Error(`Failed to write file ${filePath}: ${error.message}`);
    }
}

/**
 * Read content from a file
 * @param {string} filePath - File path to read from
 * @param {object} options - Read options
 * @returns {Promise<string>} File content
 */
async function readFile(filePath, options = {}) {
    try {
        const readOptions = {
            encoding: 'utf8',
            ...options
        };
        
        return await fs.readFile(filePath, readOptions);
    } catch (error) {
        throw new Error(`Failed to read file ${filePath}: ${error.message}`);
    }
}

/**
 * Check if file or directory exists
 * @param {string} targetPath - Path to check
 * @returns {Promise<boolean>} True if exists
 */
async function exists(targetPath) {
    try {
        await fs.access(targetPath);
        return true;
    } catch {
        return false;
    }
}

/**
 * Get file statistics
 * @param {string} filePath - File path
 * @returns {Promise<object>} File stats
 */
async function getFileStats(filePath) {
    try {
        const stats = await fs.stat(filePath);
        return {
            isFile: stats.isFile(),
            isDirectory: stats.isDirectory(),
            size: stats.size,
            created: stats.birthtime,
            modified: stats.mtime,
            accessed: stats.atime
        };
    } catch (error) {
        throw new Error(`Failed to get stats for ${filePath}: ${error.message}`);
    }
}

/**
 * List files in a directory
 * @param {string} dirPath - Directory path
 * @param {object} options - List options
 * @returns {Promise<Array>} Array of file names
 */
async function listFiles(dirPath, options = {}) {
    try {
        const {
            recursive = false,
            filter = null,
            includeDirectories = false
        } = options;

        const files = await fs.readdir(dirPath);
        const result = [];

        for (const file of files) {
            const fullPath = path.join(dirPath, file);
            const stats = await fs.stat(fullPath);

            if (stats.isDirectory()) {
                if (includeDirectories) {
                    result.push({
                        name: file,
                        path: fullPath,
                        type: 'directory'
                    });
                }
                
                if (recursive) {
                    const subFiles = await listFiles(fullPath, options);
                    result.push(...subFiles.map(subFile => ({
                        ...subFile,
                        path: path.join(dirPath, subFile.path)
                    })));
                }
            } else {
                const fileInfo = {
                    name: file,
                    path: fullPath,
                    type: 'file',
                    size: stats.size,
                    extension: path.extname(file)
                };

                if (!filter || filter(fileInfo)) {
                    result.push(fileInfo);
                }
            }
        }

        return result;
    } catch (error) {
        throw new Error(`Failed to list files in ${dirPath}: ${error.message}`);
    }
}

/**
 * Copy file from source to destination
 * @param {string} srcPath - Source file path
 * @param {string} destPath - Destination file path
 * @param {object} options - Copy options
 * @returns {Promise<void>}
 */
async function copyFile(srcPath, destPath, options = {}) {
    try {
        const { overwrite = true } = options;

        // Check if destination exists and overwrite is false
        if (!overwrite && await exists(destPath)) {
            throw new Error(`Destination file ${destPath} already exists and overwrite is disabled`);
        }

        // Ensure destination directory exists
        const destDir = path.dirname(destPath);
        await ensureDirectoryExists(destDir);

        await fs.copyFile(srcPath, destPath);
    } catch (error) {
        throw new Error(`Failed to copy file from ${srcPath} to ${destPath}: ${error.message}`);
    }
}

/**
 * Delete file or directory
 * @param {string} targetPath - Path to delete
 * @param {object} options - Delete options
 * @returns {Promise<void>}
 */
async function deleteFile(targetPath, options = {}) {
    try {
        const { recursive = false, force = false } = options;

        const stats = await fs.stat(targetPath);

        if (stats.isDirectory()) {
            if (recursive) {
                await fs.rmdir(targetPath, { recursive: true, force });
            } else {
                await fs.rmdir(targetPath);
            }
        } else {
            await fs.unlink(targetPath);
        }
    } catch (error) {
        if (error.code === 'ENOENT' && options.force) {
            // File doesn't exist but force is true, ignore error
            return;
        }
        throw new Error(`Failed to delete ${targetPath}: ${error.message}`);
    }
}

/**
 * Create temporary file
 * @param {string} prefix - File name prefix
 * @param {string} suffix - File name suffix
 * @param {string} content - File content
 * @returns {Promise<string>} Temporary file path
 */
async function createTempFile(prefix = 'temp', suffix = '.tmp', content = '') {
    const tempDir = require('os').tmpdir();
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(7);
    const fileName = `${prefix}_${timestamp}_${random}${suffix}`;
    const tempPath = path.join(tempDir, fileName);

    await writeFile(tempPath, content);
    return tempPath;
}

/**
 * Move file from source to destination
 * @param {string} srcPath - Source file path
 * @param {string} destPath - Destination file path
 * @param {object} options - Move options
 * @returns {Promise<void>}
 */
async function moveFile(srcPath, destPath, options = {}) {
    try {
        const { overwrite = true } = options;

        // Check if destination exists and overwrite is false
        if (!overwrite && await exists(destPath)) {
            throw new Error(`Destination file ${destPath} already exists and overwrite is disabled`);
        }

        // Ensure destination directory exists
        const destDir = path.dirname(destPath);
        await ensureDirectoryExists(destDir);

        await fs.rename(srcPath, destPath);
    } catch (error) {
        // If rename fails (e.g., across different filesystems), try copy then delete
        if (error.code === 'EXDEV') {
            await copyFile(srcPath, destPath, options);
            await deleteFile(srcPath);
        } else {
            throw new Error(`Failed to move file from ${srcPath} to ${destPath}: ${error.message}`);
        }
    }
}

/**
 * Get absolute path
 * @param {string} relativePath - Relative path
 * @param {string} basePath - Base path (defaults to current working directory)
 * @returns {string} Absolute path
 */
function getAbsolutePath(relativePath, basePath = process.cwd()) {
    if (path.isAbsolute(relativePath)) {
        return relativePath;
    }
    return path.resolve(basePath, relativePath);
}

/**
 * Get relative path
 * @param {string} fromPath - From path
 * @param {string} toPath - To path
 * @returns {string} Relative path
 */
function getRelativePath(fromPath, toPath) {
    return path.relative(fromPath, toPath);
}

/**
 * Normalize path separators
 * @param {string} targetPath - Path to normalize
 * @returns {string} Normalized path
 */
function normalizePath(targetPath) {
    return path.normalize(targetPath);
}

/**
 * Join path segments
 * @param {...string} segments - Path segments
 * @returns {string} Joined path
 */
function joinPath(...segments) {
    return path.join(...segments);
}

/**
 * Get file extension
 * @param {string} filePath - File path
 * @returns {string} File extension (including dot)
 */
function getFileExtension(filePath) {
    return path.extname(filePath);
}

/**
 * Get file name without extension
 * @param {string} filePath - File path
 * @returns {string} File name without extension
 */
function getBaseName(filePath) {
    return path.basename(filePath, path.extname(filePath));
}

/**
 * Get directory name
 * @param {string} filePath - File path
 * @returns {string} Directory name
 */
function getDirName(filePath) {
    return path.dirname(filePath);
}

/**
 * Sanitize file name by removing invalid characters
 * @param {string} fileName - File name to sanitize
 * @returns {string} Sanitized file name
 */
function sanitizeFileName(fileName) {
    // Remove or replace invalid characters for most file systems
    return fileName
        .replace(/[<>:"/\\|?*]/g, '_') // Replace invalid characters with underscore
        .replace(/\s+/g, '_')          // Replace spaces with underscore
        .replace(/_{2,}/g, '_')        // Replace multiple underscores with single
        .replace(/^_|_$/g, '')         // Remove leading/trailing underscores
        .substring(0, 255);            // Limit length to 255 characters
}

/**
 * Create directory if it doesn't exist (alias for ensureDirectoryExists)
 * @param {string} dirPath - Directory path
 * @returns {Promise<void>}
 */
async function mkdirp(dirPath) {
    return ensureDirectoryExists(dirPath);
}

module.exports = {
    ensureDirectoryExists,
    writeFile,
    readFile,
    exists,
    getFileStats,
    listFiles,
    copyFile,
    deleteFile,
    createTempFile,
    moveFile,
    getAbsolutePath,
    getRelativePath,
    normalizePath,
    joinPath,
    getFileExtension,
    getBaseName,
    getDirName,
    sanitizeFileName,
    mkdirp
};
