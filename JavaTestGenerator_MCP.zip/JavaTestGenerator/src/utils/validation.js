/**
 * Validation Utilities
 * Provides validation functions for OpenAPI specifications and input arguments
 */

/**
 * Validate input arguments against a JSON schema
 * @param {object} input - Input object to validate
 * @param {object} schema - JSON schema to validate against
 * @returns {object} Validation result
 */
function validateInput(input, schema) {
    const errors = [];
    const warnings = [];

    try {
        // Check required fields
        if (schema.required) {
            for (const field of schema.required) {
                if (!(field in input)) {
                    errors.push(`Missing required field: ${field}`);
                }
            }
        }

        // Check properties
        if (schema.properties) {
            for (const [field, fieldSchema] of Object.entries(schema.properties)) {
                if (field in input) {
                    const fieldValidation = validateField(input[field], fieldSchema, field);
                    errors.push(...fieldValidation.errors);
                    warnings.push(...fieldValidation.warnings);
                }
            }
        }

        // Check for unknown fields
        if (schema.properties) {
            const allowedFields = Object.keys(schema.properties);
            for (const field of Object.keys(input)) {
                if (!allowedFields.includes(field)) {
                    warnings.push(`Unknown field: ${field}`);
                }
            }
        }

        return {
            valid: errors.length === 0,
            errors,
            warnings
        };

    } catch (error) {
        return {
            valid: false,
            errors: [`Validation error: ${error.message}`],
            warnings
        };
    }
}

/**
 * Validate a single field against its schema
 * @param {*} value - Field value
 * @param {object} fieldSchema - Field schema
 * @param {string} fieldName - Field name for error messages
 * @returns {object} Validation result
 */
function validateField(value, fieldSchema, fieldName) {
    const errors = [];
    const warnings = [];

    // Type validation
    if (fieldSchema.type) {
        const expectedType = fieldSchema.type;
        const actualType = getJavaScriptType(value);

        if (!isTypeCompatible(actualType, expectedType)) {
            errors.push(`Field '${fieldName}' should be of type ${expectedType}, got ${actualType}`);
        }
    }

    // Enum validation
    if (fieldSchema.enum && !fieldSchema.enum.includes(value)) {
        errors.push(`Field '${fieldName}' must be one of: ${fieldSchema.enum.join(', ')}`);
    }

    // Array validation
    if (fieldSchema.type === 'array') {
        if (!Array.isArray(value)) {
            errors.push(`Field '${fieldName}' must be an array`);
        } else if (fieldSchema.items) {
            value.forEach((item, index) => {
                const itemValidation = validateField(item, fieldSchema.items, `${fieldName}[${index}]`);
                errors.push(...itemValidation.errors);
                warnings.push(...itemValidation.warnings);
            });
        }
    }

    // String validation
    if (fieldSchema.type === 'string') {
        if (fieldSchema.minLength && value.length < fieldSchema.minLength) {
            errors.push(`Field '${fieldName}' must be at least ${fieldSchema.minLength} characters long`);
        }
        if (fieldSchema.maxLength && value.length > fieldSchema.maxLength) {
            errors.push(`Field '${fieldName}' must be at most ${fieldSchema.maxLength} characters long`);
        }
        if (fieldSchema.pattern) {
            const regex = new RegExp(fieldSchema.pattern);
            if (!regex.test(value)) {
                errors.push(`Field '${fieldName}' does not match required pattern: ${fieldSchema.pattern}`);
            }
        }
    }

    // Number validation
    if (fieldSchema.type === 'number' || fieldSchema.type === 'integer') {
        if (fieldSchema.minimum !== undefined && value < fieldSchema.minimum) {
            errors.push(`Field '${fieldName}' must be at least ${fieldSchema.minimum}`);
        }
        if (fieldSchema.maximum !== undefined && value > fieldSchema.maximum) {
            errors.push(`Field '${fieldName}' must be at most ${fieldSchema.maximum}`);
        }
    }

    return { errors, warnings };
}

/**
 * Get JavaScript type of a value
 * @param {*} value - Value to check
 * @returns {string} Type name
 */
function getJavaScriptType(value) {
    if (value === null) return 'null';
    if (Array.isArray(value)) return 'array';
    return typeof value;
}

/**
 * Check if JavaScript type is compatible with JSON schema type
 * @param {string} jsType - JavaScript type
 * @param {string} schemaType - JSON schema type
 * @returns {boolean} True if compatible
 */
function isTypeCompatible(jsType, schemaType) {
    const typeMap = {
        'string': ['string'],
        'number': ['number', 'integer'],
        'boolean': ['boolean'],
        'object': ['object'],
        'array': ['array'],
        'null': ['null']
    };

    return typeMap[jsType]?.includes(schemaType) || false;
}

/**
 * Validate OpenAPI specification
 * @param {object} spec - OpenAPI specification object
 * @param {boolean} strict - Enable strict validation
 * @returns {object} Validation result
 */
function validateOpenAPISpec(spec, strict = false) {
    const errors = [];
    const warnings = [];

    try {
        // Check required fields
        if (!spec.openapi) {
            errors.push('Missing required field: openapi');
        } else {
            // Validate OpenAPI version
            if (!spec.openapi.startsWith('3.')) {
                errors.push(`Unsupported OpenAPI version: ${spec.openapi}. Only 3.x versions are supported.`);
            }
        }

        if (!spec.info) {
            errors.push('Missing required field: info');
        } else {
            if (!spec.info.title) {
                errors.push('Missing required field: info.title');
            }
            if (!spec.info.version) {
                errors.push('Missing required field: info.version');
            }
        }

        if (!spec.paths) {
            errors.push('Missing required field: paths');
        } else {
            // Validate paths
            const pathValidation = validatePaths(spec.paths, strict);
            errors.push(...pathValidation.errors);
            warnings.push(...pathValidation.warnings);
        }

        // Validate components if present
        if (spec.components) {
            const componentValidation = validateComponents(spec.components, strict);
            errors.push(...componentValidation.errors);
            warnings.push(...componentValidation.warnings);
        }

        // Validate servers if present
        if (spec.servers) {
            const serverValidation = validateServers(spec.servers, strict);
            errors.push(...serverValidation.errors);
            warnings.push(...serverValidation.warnings);
        }

        return {
            valid: errors.length === 0,
            errors,
            warnings
        };

    } catch (error) {
        return {
            valid: false,
            errors: [`OpenAPI validation error: ${error.message}`],
            warnings
        };
    }
}

/**
 * Validate paths section
 * @param {object} paths - Paths object
 * @param {boolean} strict - Strict validation mode
 * @returns {object} Validation result
 */
function validatePaths(paths, strict) {
    const errors = [];
    const warnings = [];

    if (Object.keys(paths).length === 0) {
        warnings.push('No paths defined in the specification');
    }

    for (const [path, pathItem] of Object.entries(paths)) {
        // Validate path format
        if (!path.startsWith('/')) {
            errors.push(`Path '${path}' must start with '/'`);
        }

        // Validate operations
        const httpMethods = ['get', 'post', 'put', 'delete', 'patch', 'head', 'options', 'trace'];
        
        for (const [method, operation] of Object.entries(pathItem)) {
            if (httpMethods.includes(method.toLowerCase()) && typeof operation === 'object') {
                const operationValidation = validateOperation(operation, `${method.toUpperCase()} ${path}`, strict);
                errors.push(...operationValidation.errors);
                warnings.push(...operationValidation.warnings);
            }
        }
    }

    return { errors, warnings };
}

/**
 * Validate operation object
 * @param {object} operation - Operation object
 * @param {string} operationPath - Operation path for error messages
 * @param {boolean} strict - Strict validation mode
 * @returns {object} Validation result
 */
function validateOperation(operation, operationPath, strict) {
    const errors = [];
    const warnings = [];

    // Check for operation ID
    if (!operation.operationId) {
        if (strict) {
            errors.push(`Missing operationId for ${operationPath}`);
        } else {
            warnings.push(`Missing operationId for ${operationPath}`);
        }
    }

    // Check for responses
    if (!operation.responses) {
        errors.push(`Missing responses for ${operationPath}`);
    } else if (Object.keys(operation.responses).length === 0) {
        errors.push(`No responses defined for ${operationPath}`);
    }

    // Check for summary/description
    if (!operation.summary && !operation.description) {
        warnings.push(`Missing summary and description for ${operationPath}`);
    }

    // Validate parameters
    if (operation.parameters) {
        operation.parameters.forEach((param, index) => {
            const paramValidation = validateParameter(param, `${operationPath} parameter[${index}]`, strict);
            errors.push(...paramValidation.errors);
            warnings.push(...paramValidation.warnings);
        });
    }

    // Validate request body
    if (operation.requestBody) {
        const requestBodyValidation = validateRequestBody(operation.requestBody, operationPath, strict);
        errors.push(...requestBodyValidation.errors);
        warnings.push(...requestBodyValidation.warnings);
    }

    return { errors, warnings };
}

/**
 * Validate parameter object
 * @param {object} param - Parameter object
 * @param {string} context - Context for error messages
 * @param {boolean} strict - Strict validation mode
 * @returns {object} Validation result
 */
function validateParameter(param, context, strict) {
    const errors = [];
    const warnings = [];

    if (!param.name) {
        errors.push(`Missing name for ${context}`);
    }

    if (!param.in) {
        errors.push(`Missing 'in' field for ${context}`);
    } else {
        const validLocations = ['query', 'header', 'path', 'cookie'];
        if (!validLocations.includes(param.in)) {
            errors.push(`Invalid 'in' value for ${context}: ${param.in}`);
        }
    }

    if (param.in === 'path' && !param.required) {
        errors.push(`Path parameter ${param.name} must be required`);
    }

    if (!param.schema && !param.content) {
        warnings.push(`Missing schema or content for ${context}`);
    }

    return { errors, warnings };
}

/**
 * Validate request body object
 * @param {object} requestBody - Request body object
 * @param {string} context - Context for error messages
 * @param {boolean} strict - Strict validation mode
 * @returns {object} Validation result
 */
function validateRequestBody(requestBody, context, strict) {
    const errors = [];
    const warnings = [];

    if (!requestBody.content) {
        errors.push(`Missing content for request body in ${context}`);
    } else if (Object.keys(requestBody.content).length === 0) {
        errors.push(`No content types defined for request body in ${context}`);
    }

    return { errors, warnings };
}

/**
 * Validate components section
 * @param {object} components - Components object
 * @param {boolean} strict - Strict validation mode
 * @returns {object} Validation result
 */
function validateComponents(components, strict) {
    const errors = [];
    const warnings = [];

    // Basic validation for components
    if (components.schemas) {
        for (const [schemaName, schema] of Object.entries(components.schemas)) {
            if (!schema.type && !schema.$ref && !schema.allOf && !schema.oneOf && !schema.anyOf) {
                warnings.push(`Schema '${schemaName}' has no type or composition defined`);
            }
        }
    }

    return { errors, warnings };
}

/**
 * Validate servers section
 * @param {Array} servers - Servers array
 * @param {boolean} strict - Strict validation mode
 * @returns {object} Validation result
 */
function validateServers(servers, strict) {
    const errors = [];
    const warnings = [];

    if (!Array.isArray(servers)) {
        errors.push('Servers must be an array');
        return { errors, warnings };
    }

    servers.forEach((server, index) => {
        if (!server.url) {
            errors.push(`Missing URL for server[${index}]`);
        } else {
            try {
                new URL(server.url);
            } catch {
                // Check if it's a relative URL or template
                if (!server.url.startsWith('/') && !server.url.includes('{')) {
                    warnings.push(`Server[${index}] URL may be invalid: ${server.url}`);
                }
            }
        }
    });

    return { errors, warnings };
}

/**
 * Validate file path
 * @param {string} filePath - File path to validate
 * @returns {object} Validation result
 */
function validateFilePath(filePath) {
    const errors = [];
    const warnings = [];

    if (!filePath || typeof filePath !== 'string') {
        errors.push('File path must be a non-empty string');
        return { valid: false, errors, warnings };
    }

    if (filePath.trim() === '') {
        errors.push('File path cannot be empty');
        return { valid: false, errors, warnings };
    }

    // Check for potentially dangerous path patterns
    if (filePath.includes('..')) {
        warnings.push('File path contains ".." which may be unsafe');
    }

    return {
        valid: errors.length === 0,
        errors,
        warnings
    };
}

/**
 * Validate package name
 * @param {string} packageName - Java package name
 * @returns {object} Validation result
 */
function validatePackageName(packageName) {
    const errors = [];
    const warnings = [];

    if (!packageName || typeof packageName !== 'string') {
        errors.push('Package name must be a non-empty string');
        return { valid: false, errors, warnings };
    }

    // Java package name validation
    const packageRegex = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$/;
    if (!packageRegex.test(packageName)) {
        errors.push('Package name must follow Java naming conventions (lowercase, dots as separators)');
    }

    // Check for reserved keywords
    const reservedKeywords = ['java', 'javax', 'com.sun', 'com.oracle'];
    if (reservedKeywords.some(keyword => packageName.startsWith(keyword))) {
        warnings.push(`Package name starts with reserved keyword: ${packageName}`);
    }

    return {
        valid: errors.length === 0,
        errors,
        warnings
    };
}

module.exports = {
    validateInput,
    validateField,
    validateOpenAPISpec,
    validatePaths,
    validateOperation,
    validateParameter,
    validateRequestBody,
    validateComponents,
    validateServers,
    validateFilePath,
    validatePackageName,
    getJavaScriptType,
    isTypeCompatible
};
