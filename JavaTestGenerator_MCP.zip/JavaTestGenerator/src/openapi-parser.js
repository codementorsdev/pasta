/**
 * OpenAPI Parser
 * Handles parsing and validation of OpenAPI 3.0+ specifications
 */

const fs = require('fs').promises;
const path = require('path');
const yaml = require('js-yaml');

class OpenAPIParser {
    constructor() {
        this.supportedVersions = ['3.0.0', '3.0.1', '3.0.2', '3.0.3', '3.1.0'];
    }

    /**
     * Parse OpenAPI specification from file
     * @param {string} filePath - Path to the OpenAPI file
     * @returns {Promise<object>} Parsed OpenAPI specification
     */
    async parseFromFile(filePath) {
        try {
            const fileContent = await fs.readFile(filePath, 'utf8');
            const fileExtension = path.extname(filePath).toLowerCase();

            let parsedSpec;
            
            if (fileExtension === '.yaml' || fileExtension === '.yml') {
                parsedSpec = yaml.load(fileContent);
            } else if (fileExtension === '.json') {
                parsedSpec = JSON.parse(fileContent);
            } else {
                // Try to parse as YAML first, then JSON
                try {
                    parsedSpec = yaml.load(fileContent);
                } catch {
                    parsedSpec = JSON.parse(fileContent);
                }
            }

            return this.normalizeSpec(parsedSpec);
        } catch (error) {
            throw new Error(`Failed to parse OpenAPI specification from ${filePath}: ${error.message}`);
        }
    }

    /**
     * Parse OpenAPI specification from string content
     * @param {string} content - OpenAPI specification content
     * @param {string} format - Format of the content ('yaml' or 'json')
     * @returns {object} Parsed OpenAPI specification
     */
    parseFromString(content, format = 'yaml') {
        try {
            let parsedSpec;
            
            if (format === 'yaml') {
                parsedSpec = yaml.load(content);
            } else {
                parsedSpec = JSON.parse(content);
            }

            return this.normalizeSpec(parsedSpec);
        } catch (error) {
            throw new Error(`Failed to parse OpenAPI specification: ${error.message}`);
        }
    }

    /**
     * Normalize the OpenAPI specification
     * @param {object} spec - Raw parsed specification
     * @returns {object} Normalized specification
     */
    normalizeSpec(spec) {
        if (!spec || typeof spec !== 'object') {
            throw new Error('Invalid OpenAPI specification: not an object');
        }

        // Validate OpenAPI version
        if (!spec.openapi) {
            throw new Error('Invalid OpenAPI specification: missing openapi version');
        }

        if (!this.supportedVersions.some(version => spec.openapi.startsWith(version.split('.')[0]))) {
            throw new Error(`Unsupported OpenAPI version: ${spec.openapi}. Supported versions: ${this.supportedVersions.join(', ')}`);
        }

        // Ensure required sections exist
        spec.info = spec.info || {};
        spec.paths = spec.paths || {};
        spec.components = spec.components || {};
        spec.components.schemas = spec.components.schemas || {};

        // Normalize paths
        this.normalizePaths(spec);

        // Resolve references (basic implementation)
        this.resolveReferences(spec);

        return spec;
    }

    /**
     * Normalize paths in the specification
     * @param {object} spec - OpenAPI specification
     */
    normalizePaths(spec) {
        const normalizedPaths = {};

        for (const [pathKey, pathItem] of Object.entries(spec.paths)) {
            // Normalize path key (ensure it starts with /)
            const normalizedPath = pathKey.startsWith('/') ? pathKey : `/${pathKey}`;
            
            // Normalize operations
            const normalizedPathItem = {};
            
            for (const [key, value] of Object.entries(pathItem)) {
                if (this.isHttpMethod(key)) {
                    normalizedPathItem[key.toLowerCase()] = this.normalizeOperation(value, key, normalizedPath);
                } else {
                    normalizedPathItem[key] = value;
                }
            }

            normalizedPaths[normalizedPath] = normalizedPathItem;
        }

        spec.paths = normalizedPaths;
    }

    /**
     * Check if a key represents an HTTP method
     * @param {string} key - Key to check
     * @returns {boolean} True if it's an HTTP method
     */
    isHttpMethod(key) {
        const httpMethods = ['get', 'post', 'put', 'delete', 'patch', 'head', 'options', 'trace'];
        return httpMethods.includes(key.toLowerCase());
    }

    /**
     * Normalize an operation
     * @param {object} operation - Operation object
     * @param {string} method - HTTP method
     * @param {string} path - API path
     * @returns {object} Normalized operation
     */
    normalizeOperation(operation, method, path) {
        const normalized = { ...operation };

        // Generate operationId if missing
        if (!normalized.operationId) {
            normalized.operationId = this.generateOperationId(method, path);
        }

        // Ensure responses exist
        normalized.responses = normalized.responses || { '200': { description: 'Success' } };

        // Normalize parameters
        if (normalized.parameters) {
            normalized.parameters = normalized.parameters.map(param => this.normalizeParameter(param));
        }

        // Normalize request body
        if (normalized.requestBody) {
            normalized.requestBody = this.normalizeRequestBody(normalized.requestBody);
        }

        // Ensure tags array exists
        normalized.tags = normalized.tags || [];

        return normalized;
    }

    /**
     * Generate operation ID from method and path
     * @param {string} method - HTTP method
     * @param {string} path - API path
     * @returns {string} Generated operation ID
     */
    generateOperationId(method, path) {
        // Remove path parameters and convert to camelCase
        const cleanPath = path
            .replace(/\{[^}]+\}/g, '') // Remove path parameters
            .replace(/^\/+|\/+$/g, '') // Remove leading/trailing slashes
            .replace(/\/+/g, '_') // Replace slashes with underscores
            .replace(/[^a-zA-Z0-9_]/g, '') // Remove special characters
            .replace(/_+/g, '_'); // Replace multiple underscores with single

        const pathPart = cleanPath ? `_${cleanPath}` : '';
        return `${method.toLowerCase()}${pathPart}`;
    }

    /**
     * Normalize parameter object
     * @param {object} param - Parameter object
     * @returns {object} Normalized parameter
     */
    normalizeParameter(param) {
        const normalized = { ...param };

        // Ensure required fields
        normalized.name = normalized.name || 'unnamed_param';
        normalized.in = normalized.in || 'query';
        normalized.required = normalized.required || false;

        // Normalize schema
        if (!normalized.schema) {
            normalized.schema = { type: 'string' };
        }

        return normalized;
    }

    /**
     * Normalize request body object
     * @param {object} requestBody - Request body object
     * @returns {object} Normalized request body
     */
    normalizeRequestBody(requestBody) {
        const normalized = { ...requestBody };

        // Ensure content exists
        normalized.content = normalized.content || {
            'application/json': {
                schema: { type: 'object' }
            }
        };

        return normalized;
    }

    /**
     * Basic reference resolution
     * @param {object} spec - OpenAPI specification
     */
    resolveReferences(spec) {
        // This is a basic implementation that handles simple $ref resolution
        // For production use, consider using a dedicated OpenAPI resolver library
        
        const resolveRef = (obj, refPath) => {
            const parts = refPath.replace('#/', '').split('/');
            let current = spec;
            
            for (const part of parts) {
                if (current && typeof current === 'object' && current[part] !== undefined) {
                    current = current[part];
                } else {
                    return null;
                }
            }
            
            return current;
        };

        const processObject = (obj) => {
            if (!obj || typeof obj !== 'object') {
                return obj;
            }

            if (Array.isArray(obj)) {
                return obj.map(processObject);
            }

            const processed = {};
            for (const [key, value] of Object.entries(obj)) {
                if (key === '$ref' && typeof value === 'string') {
                    const resolved = resolveRef(obj, value);
                    if (resolved) {
                        Object.assign(processed, processObject(resolved));
                    }
                } else {
                    processed[key] = processObject(value);
                }
            }

            return processed;
        };

        // Process paths and components
        if (spec.paths) {
            spec.paths = processObject(spec.paths);
        }
        
        if (spec.components) {
            spec.components = processObject(spec.components);
        }
    }

    /**
     * Extract all endpoints from the specification
     * @param {object} spec - OpenAPI specification
     * @returns {Array} Array of endpoint objects
     */
    extractEndpoints(spec) {
        const endpoints = [];

        for (const [path, pathItem] of Object.entries(spec.paths || {})) {
            for (const [method, operation] of Object.entries(pathItem)) {
                if (this.isHttpMethod(method) && typeof operation === 'object') {
                    endpoints.push({
                        path,
                        method: method.toUpperCase(),
                        operation,
                        pathItem
                    });
                }
            }
        }

        return endpoints;
    }

    /**
     * Get all schemas from the specification
     * @param {object} spec - OpenAPI specification
     * @returns {object} Schema definitions
     */
    getSchemas(spec) {
        return spec.components?.schemas || {};
    }

    /**
     * Get server information
     * @param {object} spec - OpenAPI specification
     * @returns {Array} Server definitions
     */
    getServers(spec) {
        return spec.servers || [];
    }

    /**
     * Get security definitions
     * @param {object} spec - OpenAPI specification
     * @returns {object} Security scheme definitions
     */
    getSecuritySchemes(spec) {
        return spec.components?.securitySchemes || {};
    }
}

module.exports = { OpenAPIParser };
