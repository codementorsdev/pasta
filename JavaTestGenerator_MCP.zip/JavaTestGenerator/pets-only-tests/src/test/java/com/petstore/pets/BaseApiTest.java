package com.petstore.pets;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.HttpClientConfig;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.qameta.allure.restassured.AllureRestAssured;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInstance;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

import java.util.concurrent.TimeUnit;

/**
 * Base test class for API tests
 * Contains common setup and utility methods
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public abstract class BaseApiTest {

    protected static final String BASE_URL = System.getProperty("base.url", "https://petstore.swagger.io/v3");
    protected static final int DEFAULT_TIMEOUT = Integer.parseInt(System.getProperty("api.timeout", "30000"));
    
    // Authentication properties
    protected static final String AUTH_TOKEN = System.getProperty("auth.token", System.getenv("API_TOKEN"));
    protected static final String USERNAME = System.getProperty("auth.username", System.getenv("API_USERNAME"));
    protected static final String PASSWORD = System.getProperty("auth.password", System.getenv("API_PASSWORD"));

    @BeforeAll
    public void globalSetup() {
        // Configure RestAssured
        RestAssured.baseURI = BASE_URL;
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
        
        // Configure timeouts
        RestAssuredConfig config = RestAssured.config()
            .httpClient(HttpClientConfig.httpClientConfig()
                .setParam("http.connection.timeout", DEFAULT_TIMEOUT)
                .setParam("http.socket.timeout", DEFAULT_TIMEOUT));
        RestAssured.config = config;
    }

    @BeforeEach
    public void setUp() {
        // Setup executed before each test
        // Override in subclasses if needed
    }

    /**
     * Get configured request specification
     * @return RequestSpecification with common settings
     */
    protected RequestSpecification getRequestSpecification() {
        return new RequestSpecBuilder()
            .setBaseUri(BASE_URL)
            .setContentType(ContentType.JSON)
            .addFilter(new AllureRestAssured())
            .addFilter(new RequestLoggingFilter())
            .addFilter(new ResponseLoggingFilter())
            .build();
    }

    /**
     * Get authentication token
     * @return Authentication token
     */
    protected String getAuthToken() {
        if (AUTH_TOKEN == null || AUTH_TOKEN.isEmpty()) {
            throw new RuntimeException("Authentication token not configured. Set auth.token system property or API_TOKEN environment variable.");
        }
        return AUTH_TOKEN;
    }

    /**
     * Get username for basic authentication
     * @return Username
     */
    protected String getUsername() {
        if (USERNAME == null || USERNAME.isEmpty()) {
            throw new RuntimeException("Username not configured. Set auth.username system property or API_USERNAME environment variable.");
        }
        return USERNAME;
    }

    /**
     * Get password for basic authentication
     * @return Password
     */
    protected String getPassword() {
        if (PASSWORD == null || PASSWORD.isEmpty()) {
            throw new RuntimeException("Password not configured. Set auth.password system property or API_PASSWORD environment variable.");
        }
        return PASSWORD;
    }

    /**
     * Get custom authorization header
     * @return Authorization header value
     */
    protected String getAuthHeader() {
        return "Bearer " + getAuthToken();
    }

    /**
     * Log response details for debugging
     * @param response Response to log
     */
    protected void logResponse(Response response) {
        System.out.println("Response Status: " + response.getStatusCode());
        System.out.println("Response Time: " + response.getTime() + "ms");
        System.out.println("Response Headers: " + response.getHeaders());
        
        if (response.getContentType() != null && response.getContentType().contains("json")) {
            System.out.println("Response Body: " + response.getBody().asPrettyString());
        }
    }

    /**
     * Wait for specified duration
     * @param seconds Number of seconds to wait
     */
    protected void waitForSeconds(int seconds) {
        try {
            TimeUnit.SECONDS.sleep(seconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Wait interrupted", e);
        }
    }

    /**
     * Validate response time
     * @param response Response to validate
     * @param maxTimeMs Maximum acceptable response time in milliseconds
     */
    protected void validateResponseTime(Response response, long maxTimeMs) {
        long responseTime = response.getTime();
        if (responseTime > maxTimeMs) {
            throw new AssertionError(String.format("Response time %dms exceeded maximum %dms", responseTime, maxTimeMs));
        }
    }

    /**
     * Extract value from JSON response
     * @param response Response containing JSON
     * @param jsonPath JSON path expression
     * @return Extracted value
     */
    protected Object extractFromJson(Response response, String jsonPath) {
        return response.jsonPath().get(jsonPath);
    }

    /**
     * Validate that response contains expected JSON structure
     * @param response Response to validate
     * @param expectedKeys Expected JSON keys
     */
    protected void validateJsonStructure(Response response, String... expectedKeys) {
        for (String key : expectedKeys) {
            Object value = extractFromJson(response, key);
            if (value == null) {
                throw new AssertionError("Expected JSON key '" + key + "' not found in response");
            }
        }
    }
}
