package com.petstore.testng;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.HttpClientConfig;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.qameta.allure.restassured.AllureRestAssured;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

import java.util.concurrent.TimeUnit;

/**
 * Base test class for API tests
 * Contains common setup and utility methods
 */
public abstract class BaseApiTest {

    protected static final String BASE_URL = System.getProperty("base.url", "https://petstore.swagger.io/v3");
    protected static final int DEFAULT_TIMEOUT = Integer.parseInt(System.getProperty("api.timeout", "30000"));
    

    @BeforeClass
    public void globalSetup() {
        // Configure RestAssured
        RestAssured.baseURI = BASE_URL;
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
        
        // Configure timeouts
        RestAssuredConfig config = RestAssured.config()
            .httpClient(HttpClientConfig.httpClientConfig()
                .setParam("http.connection.timeout", DEFAULT_TIMEOUT)
                .setParam("http.socket.timeout", DEFAULT_TIMEOUT));
        RestAssured.config = config;
    }

    @BeforeMethod
    public void setUp() {
        // Setup executed before each test
        // Override in subclasses if needed
    }

    /**
     * Get configured request specification
     * @return RequestSpecification with common settings
     */
    protected RequestSpecification getRequestSpecification() {
        return new RequestSpecBuilder()
            .setBaseUri(BASE_URL)
            .setContentType(ContentType.JSON)
            .addFilter(new AllureRestAssured())
            .addFilter(new RequestLoggingFilter())
            .addFilter(new ResponseLoggingFilter())
            .build();
    }


    /**
     * Log response details for debugging
     * @param response Response to log
     */
    protected void logResponse(Response response) {
        System.out.println("Response Status: " + response.getStatusCode());
        System.out.println("Response Time: " + response.getTime() + "ms");
        System.out.println("Response Headers: " + response.getHeaders());
        
        if (response.getContentType() != null && response.getContentType().contains("json")) {
            System.out.println("Response Body: " + response.getBody().asPrettyString());
        }
    }

    /**
     * Wait for specified duration
     * @param seconds Number of seconds to wait
     */
    protected void waitForSeconds(int seconds) {
        try {
            TimeUnit.SECONDS.sleep(seconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Wait interrupted", e);
        }
    }

    /**
     * Validate response time
     * @param response Response to validate
     * @param maxTimeMs Maximum acceptable response time in milliseconds
     */
    protected void validateResponseTime(Response response, long maxTimeMs) {
        long responseTime = response.getTime();
        if (responseTime > maxTimeMs) {
            throw new AssertionError(String.format("Response time %dms exceeded maximum %dms", responseTime, maxTimeMs));
        }
    }

    /**
     * Extract value from JSON response
     * @param response Response containing JSON
     * @param jsonPath JSON path expression
     * @return Extracted value
     */
    protected Object extractFromJson(Response response, String jsonPath) {
        return response.jsonPath().get(jsonPath);
    }

    /**
     * Validate that response contains expected JSON structure
     * @param response Response to validate
     * @param expectedKeys Expected JSON keys
     */
    protected void validateJsonStructure(Response response, String... expectedKeys) {
        for (String key : expectedKeys) {
            Object value = extractFromJson(response, key);
            if (value == null) {
                throw new AssertionError("Expected JSON key '" + key + "' not found in response");
            }
        }
    }
}
