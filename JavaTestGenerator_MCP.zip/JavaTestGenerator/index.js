#!/usr/bin/env node

/**
 * MCP Server for REST Assured Test Generation
 * Entry point for the Model Context Protocol server that generates Java REST Assured test cases
 * from OpenAPI specifications.
 */

const { MCPServer } = require('./src/mcp-server');
const path = require('path');

// Initialize the MCP server
const server = new MCPServer({
    name: 'restassured-test-generator',
    version: '1.0.0',
    description: 'Generate Java REST Assured test cases from OpenAPI specifications',
    configPath: path.join(__dirname, 'config', 'default-config.json'),
    templatesPath: path.join(__dirname, 'templates')
});

// Handle graceful shutdown
process.on('SIGINT', async () => {
    console.log('\nShutting down MCP server...');
    await server.shutdown();
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log('\nShutting down MCP server...');
    await server.shutdown();
    process.exit(0);
});

// Start the server
async function main() {
    try {
        await server.start();
        console.log('MCP Server started successfully');
        console.log(`Server name: ${server.name}`);
        console.log(`Version: ${server.version}`);
        console.log('Available tools: generate_tests, validate_spec, list_endpoints');
    } catch (error) {
        console.error('Failed to start MCP server:', error.message);
        process.exit(1);
    }
}

// Only run if this file is executed directly
if (require.main === module) {
    main().catch((error) => {
        console.error('Unhandled error:', error);
        process.exit(1);
    });
}

module.exports = { MCPServer };
