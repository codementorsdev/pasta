# REST Assured Test Generator MCP Server

An MCP (Model Context Protocol) server that automatically generates comprehensive Java REST Assured API test cases from OpenAPI 3.0+ specifications. This tool significantly reduces the manual effort required to create comprehensive API test suites while ensuring high-quality, maintainable test code generation.

## Features

- **OpenAPI 3.0+ Support**: Parse and validate OpenAPI YAML/JSON specifications
- **Comprehensive Test Generation**: Generate positive, negative, and edge case tests
- **Multiple Test Frameworks**: Support for JUnit 5 and TestNG
- **Authentication Support**: Handle various authentication schemes (Bearer, Basic, API Key, OAuth2)
- **Template-Based Generation**: Customizable Mustache templates for code generation
- **Maven Integration**: Generate complete Maven projects with proper dependencies
- **Response Validation**: Configurable validation levels (basic, detailed, schema)
- **Error Handling**: Robust error handling with detailed feedback
- **Test Organization**: Group tests by OpenAPI tags or endpoints

## Installation

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Install Dependencies

```bash
npm install
