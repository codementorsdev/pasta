package com.example.api.tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

/**
 * Generated API test class for PetsApiTest
 * This class contains automated tests generated from OpenAPI specification
 */
@TestMethodOrder(OrderAnnotation.class)
public class PetsApiTest extends BaseApiTest {

    /**
     * List all pets
     */
    @Test
    @Order(1)
    @DisplayName("List all pets")
    @Tag("pets")
    void listPets_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .when()
            .get("/pets")
            .then()
            .statusCode(200)
            .contentType(ContentType.JSON)
            .body(notNullValue())
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * List all pets - Unauthorized
     */
    @Test
    @Order(2)
    @DisplayName("List all pets - Unauthorized")
    @Tag("negative")
    void listPets_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .when()
            .get("/pets")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Add a new pet
     */
    @Test
    @Order(2)
    @DisplayName("Add a new pet")
    @Tag("pets")
    void addPet_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .body({
  "name": "Buddy",
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "photoUrls": [
    "https://example.com/photos/buddy1.jpg"
  ],
  "tags": [
    "item"
  ],
  "status": "test_value"
})
            .when()
            .post("/pets")
            .then()
            .statusCode(201)
            .contentType(ContentType.JSON)
            .body(notNullValue())
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Add a new pet - Bad Request
     */
    @Test
    @Order(4)
    @DisplayName("Add a new pet - Bad Request")
    @Tag("negative")
    void addPet_badRequest() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        
        Response response = given(request)
            .body({"invalid": "data"})
            .when()
            .post("/pets")
            .then()
            .statusCode(400)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Add a new pet - Unauthorized
     */
    @Test
    @Order(5)
    @DisplayName("Add a new pet - Unauthorized")
    @Tag("negative")
    void addPet_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .body({
  "name": "Buddy",
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "photoUrls": [
    "https://example.com/photos/buddy1.jpg"
  ],
  "tags": [
    "item"
  ],
  "status": "test_value"
})
            .when()
            .post("/pets")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Get pet by ID
     */
    @Test
    @Order(3)
    @DisplayName("Get pet by ID")
    @Tag("pets")
    void getPetById_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .pathParam("petId", 1)
            .when()
            .get("/pets/{petId}")
            .then()
            .statusCode(200)
            .contentType(ContentType.JSON)
            .body(notNullValue())
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Get pet by ID - Unauthorized
     */
    @Test
    @Order(7)
    @DisplayName("Get pet by ID - Unauthorized")
    @Tag("negative")
    void getPetById_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .pathParam("petId", 1)
            .when()
            .get("/pets/{petId}")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Get pet by ID - Not Found
     */
    @Test
    @Order(8)
    @DisplayName("Get pet by ID - Not Found")
    @Tag("negative")
    void getPetById_notFound() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        
        Response response = given(request)
            .pathParam("petId", 999999)
            .when()
            .get("/pets/{invalid_petId}")
            .then()
            .statusCode(404)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Update an existing pet
     */
    @Test
    @Order(4)
    @DisplayName("Update an existing pet")
    @Tag("pets")
    void updatePet_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .pathParam("petId", 1)
            .body({
  "id": 10,
  "name": "Buddy",
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "photoUrls": [
    "https://example.com/photos/buddy1.jpg",
    "https://example.com/photos/buddy2.jpg"
  ],
  "tags": [
    "item"
  ],
  "status": "available"
})
            .when()
            .put("/pets/{petId}")
            .then()
            .statusCode(200)
            .contentType(ContentType.JSON)
            .body(notNullValue())
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Update an existing pet - Bad Request
     */
    @Test
    @Order(10)
    @DisplayName("Update an existing pet - Bad Request")
    @Tag("negative")
    void updatePet_badRequest() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        
        Response response = given(request)
            .pathParam("petId", 1)
            .body({"invalid": "data"})
            .when()
            .put("/pets/{petId}")
            .then()
            .statusCode(400)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Update an existing pet - Unauthorized
     */
    @Test
    @Order(11)
    @DisplayName("Update an existing pet - Unauthorized")
    @Tag("negative")
    void updatePet_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .pathParam("petId", 1)
            .body({
  "id": 10,
  "name": "Buddy",
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "photoUrls": [
    "https://example.com/photos/buddy1.jpg",
    "https://example.com/photos/buddy2.jpg"
  ],
  "tags": [
    "item"
  ],
  "status": "available"
})
            .when()
            .put("/pets/{petId}")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Update an existing pet - Not Found
     */
    @Test
    @Order(12)
    @DisplayName("Update an existing pet - Not Found")
    @Tag("negative")
    void updatePet_notFound() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        
        Response response = given(request)
            .pathParam("petId", 999999)
            .body({
  "id": 10,
  "name": "Buddy",
  "category": {
    "id": 1,
    "name": "Dogs"
  },
  "photoUrls": [
    "https://example.com/photos/buddy1.jpg",
    "https://example.com/photos/buddy2.jpg"
  ],
  "tags": [
    "item"
  ],
  "status": "available"
})
            .when()
            .put("/pets/{invalid_petId}")
            .then()
            .statusCode(404)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Delete a pet
     */
    @Test
    @Order(5)
    @DisplayName("Delete a pet")
    @Tag("pets")
    void deletePet_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .pathParam("petId", 1)
            .header("api_key", "test_value")
            .when()
            .delete("/pets/{petId}")
            .then()
            .statusCode(204)
            .contentType(ContentType.JSON)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Delete a pet - Unauthorized
     */
    @Test
    @Order(14)
    @DisplayName("Delete a pet - Unauthorized")
    @Tag("negative")
    void deletePet_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .pathParam("petId", 1)
            .header("api_key", "test_value")
            .when()
            .delete("/pets/{petId}")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Delete a pet - Not Found
     */
    @Test
    @Order(15)
    @DisplayName("Delete a pet - Not Found")
    @Tag("negative")
    void deletePet_notFound() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        
        Response response = given(request)
            .pathParam("petId", 999999)
            .header("api_key", "test_value")
            .when()
            .delete("/pets/{invalid_petId}")
            .then()
            .statusCode(404)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


}
