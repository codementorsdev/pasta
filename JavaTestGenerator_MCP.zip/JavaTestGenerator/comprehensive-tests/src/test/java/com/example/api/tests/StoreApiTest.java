package com.example.api.tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

/**
 * Generated API test class for StoreApiTest
 * This class contains automated tests generated from OpenAPI specification
 */
@TestMethodOrder(OrderAnnotation.class)
public class StoreApiTest extends BaseApiTest {

    /**
     * Returns pet inventories by status
     */
    @Test
    @Order(1)
    @DisplayName("Returns pet inventories by status")
    @Tag("store")
    void getInventory_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .when()
            .get("/store/inventory")
            .then()
            .statusCode(200)
            .contentType(ContentType.JSON)
            .body(notNullValue())
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Returns pet inventories by status - Unauthorized
     */
    @Test
    @Order(2)
    @DisplayName("Returns pet inventories by status - Unauthorized")
    @Tag("negative")
    void getInventory_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .when()
            .get("/store/inventory")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Place an order for a pet
     */
    @Test
    @Order(2)
    @DisplayName("Place an order for a pet")
    @Tag("store")
    void placeOrder_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .body({
  "id": 10,
  "petId": 198772,
  "quantity": 7,
  "shipDate": "2023-10-12T10:12:32.000Z",
  "status": "approved",
  "complete": true
})
            .when()
            .post("/store/order")
            .then()
            .statusCode(201)
            .contentType(ContentType.JSON)
            .body(notNullValue())
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Place an order for a pet - Bad Request
     */
    @Test
    @Order(4)
    @DisplayName("Place an order for a pet - Bad Request")
    @Tag("negative")
    void placeOrder_badRequest() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        
        Response response = given(request)
            .body({"invalid": "data"})
            .when()
            .post("/store/order")
            .then()
            .statusCode(400)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Place an order for a pet - Unauthorized
     */
    @Test
    @Order(5)
    @DisplayName("Place an order for a pet - Unauthorized")
    @Tag("negative")
    void placeOrder_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .body({
  "id": 10,
  "petId": 198772,
  "quantity": 7,
  "shipDate": "2023-10-12T10:12:32.000Z",
  "status": "approved",
  "complete": true
})
            .when()
            .post("/store/order")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Find purchase order by ID
     */
    @Test
    @Order(3)
    @DisplayName("Find purchase order by ID")
    @Tag("store")
    void getOrderById_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .pathParam("orderId", 1)
            .when()
            .get("/store/order/{orderId}")
            .then()
            .statusCode(200)
            .contentType(ContentType.JSON)
            .body(notNullValue())
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Find purchase order by ID - Unauthorized
     */
    @Test
    @Order(7)
    @DisplayName("Find purchase order by ID - Unauthorized")
    @Tag("negative")
    void getOrderById_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .pathParam("orderId", 1)
            .when()
            .get("/store/order/{orderId}")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Find purchase order by ID - Not Found
     */
    @Test
    @Order(8)
    @DisplayName("Find purchase order by ID - Not Found")
    @Tag("negative")
    void getOrderById_notFound() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        
        Response response = given(request)
            .pathParam("orderId", 999999)
            .when()
            .get("/store/order/{invalid_orderId}")
            .then()
            .statusCode(404)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Delete purchase order by ID
     */
    @Test
    @Order(4)
    @DisplayName("Delete purchase order by ID")
    @Tag("store")
    void deleteOrder_success() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        request = request.auth().oauth2(getAuthToken());
        
        Response response = given(request)
            .pathParam("orderId", 1)
            .when()
            .delete("/store/order/{orderId}")
            .then()
            .statusCode(204)
            .contentType(ContentType.JSON)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Delete purchase order by ID - Unauthorized
     */
    @Test
    @Order(10)
    @DisplayName("Delete purchase order by ID - Unauthorized")
    @Tag("negative")
    void deleteOrder_unauthorized() {
        RequestSpecification request = getRequestSpecification();
        
        
        Response response = given(request)
            .pathParam("orderId", 1)
            .when()
            .delete("/store/order/{orderId}")
            .then()
            .statusCode(401)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


    /**
     * Delete purchase order by ID - Not Found
     */
    @Test
    @Order(11)
    @DisplayName("Delete purchase order by ID - Not Found")
    @Tag("negative")
    void deleteOrder_notFound() {
        RequestSpecification request = getRequestSpecification();
        
        // Add authentication
        
        Response response = given(request)
            .pathParam("orderId", 999999)
            .when()
            .delete("/store/order/{invalid_orderId}")
            .then()
            .statusCode(404)
            .extract().response();
        
        // Log response for debugging
        logResponse(response);
        
        // Additional assertions can be added here
        assertThat(response.getTime(), lessThan(5000L));
    }


}
