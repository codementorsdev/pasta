# replit.md

## Overview

MediBook is a comprehensive healthcare appointment booking platform built as a mobile-first Progressive Web App (PWA). The application facilitates connections between patients, doctors, and administrators through a secure, feature-rich platform that handles appointment scheduling, prescription management, medical records, and billing integration with Stripe payments.

The system supports three distinct user roles: patients (who book appointments and manage their health records), doctors (who manage their practice, patients, and issue prescriptions), and administrators (who oversee the entire platform). The application emphasizes mobile-first responsive design with offline capabilities and push notification support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming and dark mode support
- **State Management**: TanStack Query for server state management with React hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **PWA Features**: Service worker for offline caching, manifest.json for installability, and background sync capabilities

### Backend Architecture
- **Server Framework**: Express.js with TypeScript running on Node.js
- **API Design**: RESTful APIs with role-based access control middleware
- **Authentication**: OpenID Connect integration with Replit Auth for secure user management
- **Session Management**: Express sessions with PostgreSQL session store
- **File Structure**: Monorepo structure with shared types and schemas between client and server

### Database Architecture
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Database**: PostgreSQL with Neon serverless integration
- **Schema Design**: Comprehensive relational schema including users, doctor profiles, appointments, prescriptions, medical records, invoices, and availability tracking
- **Migrations**: Drizzle Kit for database schema migrations and version control

### Payment Integration
- **Payment Processor**: Stripe integration for handling consultation fees and billing
- **Implementation**: React Stripe.js components for secure payment collection
- **Features**: Support for one-time payments, customer management, and payment status tracking

### Security & Authorization
- **Authentication Method**: OpenID Connect with JWT tokens and refresh token rotation
- **Role-Based Access**: Middleware-enforced permissions for doctor, patient, and admin roles
- **Session Security**: Secure HTTP-only cookies with proper CSRF protection
- **Data Validation**: Zod schemas for input validation on both client and server

### Mobile-First Design
- **Responsive Strategy**: Mobile-first approach with progressive enhancement for larger screens
- **Navigation**: Adaptive navigation with bottom tab bar for mobile and sidebar for desktop
- **Touch Optimization**: Touch-friendly interface elements and gestures
- **Performance**: Optimized bundle splitting and lazy loading for faster mobile performance

## External Dependencies

### Core Runtime Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL driver for Neon database connectivity
- **drizzle-orm**: Type-safe ORM for database operations with PostgreSQL support
- **@tanstack/react-query**: Server state management and caching for React applications

### UI and Component Libraries
- **@radix-ui/***: Comprehensive set of unstyled, accessible UI primitives including dialogs, dropdowns, forms, and navigation components
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **class-variance-authority**: Type-safe variant API for component styling
- **lucide-react**: Icon library providing consistent iconography

### Authentication and Security
- **openid-client**: OpenID Connect client implementation for secure authentication
- **passport**: Authentication middleware for Node.js applications
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Payment Processing
- **@stripe/stripe-js**: Official Stripe JavaScript SDK for payment processing
- **@stripe/react-stripe-js**: React components for Stripe payment integration

### Development and Build Tools
- **vite**: Fast build tool and development server optimized for modern web development
- **typescript**: Static type checking for enhanced developer experience and code reliability
- **drizzle-kit**: Database migration and introspection tools for Drizzle ORM

### Validation and Data Handling
- **zod**: TypeScript-first schema validation library for runtime type checking
- **date-fns**: Modern JavaScript date utility library for date manipulation and formatting

### PWA and Mobile Features
- **Service Worker**: Custom implementation for offline caching and background sync
- **Web App Manifest**: Configuration for app installation and native-like experience
- **Push Notifications**: Browser-based notification system for appointment reminders