import {
  users,
  doctorProfiles,
  appointments,
  prescriptions,
  medicalRecords,
  invoices,
  doctorAvailability,
  type User,
  type UpsertUser,
  type DoctorProfile,
  type InsertDoctorProfile,
  type Appointment,
  type InsertAppointment,
  type Prescription,
  type InsertPrescription,
  type MedicalRecord,
  type InsertMedicalRecord,
  type Invoice,
  type UserWithProfile,
  type AppointmentWithDetails,
  type PrescriptionWithDetails,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, asc } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserWithProfile(id: string): Promise<UserWithProfile | undefined>;
  
  // Doctor operations
  createDoctorProfile(profile: InsertDoctorProfile): Promise<DoctorProfile>;
  updateDoctorProfile(id: string, profile: Partial<InsertDoctorProfile>): Promise<DoctorProfile>;
  getDoctorProfile(userId: string): Promise<DoctorProfile | undefined>;
  getDoctorsBySpecialization(specialization?: string): Promise<(DoctorProfile & { user: User })[]>;
  approveDoctorProfile(id: string): Promise<DoctorProfile>;
  
  // Appointment operations
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: string, appointment: Partial<InsertAppointment>): Promise<Appointment>;
  getAppointment(id: string): Promise<AppointmentWithDetails | undefined>;
  getAppointmentsByDoctor(doctorId: string, date?: Date): Promise<AppointmentWithDetails[]>;
  getAppointmentsByPatient(patientId: string): Promise<AppointmentWithDetails[]>;
  getTodayAppointments(doctorId: string): Promise<AppointmentWithDetails[]>;
  
  // Prescription operations
  createPrescription(prescription: InsertPrescription): Promise<Prescription>;
  getPrescriptionsByPatient(patientId: string): Promise<PrescriptionWithDetails[]>;
  getPrescriptionsByDoctor(doctorId: string): Promise<PrescriptionWithDetails[]>;
  
  // Medical records operations
  createMedicalRecord(record: InsertMedicalRecord): Promise<MedicalRecord>;
  getMedicalRecordsByPatient(patientId: string): Promise<MedicalRecord[]>;
  
  // Billing operations
  createInvoice(invoice: Omit<Invoice, 'id' | 'createdAt' | 'updatedAt'>): Promise<Invoice>;
  updateInvoicePaymentStatus(id: string, status: 'paid' | 'failed' | 'refunded', stripePaymentIntentId?: string): Promise<Invoice>;
  getInvoicesByPatient(patientId: string): Promise<Invoice[]>;
  getInvoicesByDoctor(doctorId: string): Promise<Invoice[]>;
  
  // Analytics
  getStatsForDoctor(doctorId: string): Promise<{
    todayAppointments: number;
    totalPatients: number;
    monthlyRevenue: number;
    pendingPrescriptions: number;
  }>;
  
  getAdminStats(): Promise<{
    totalUsers: number;
    activeDoctors: number;
    monthlyRevenue: number;
    pendingApprovals: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserWithProfile(id: string): Promise<UserWithProfile | undefined> {
    const [result] = await db
      .select()
      .from(users)
      .leftJoin(doctorProfiles, eq(users.id, doctorProfiles.userId))
      .where(eq(users.id, id));
    
    if (!result) return undefined;
    
    return {
      ...result.users,
      doctorProfile: result.doctor_profiles || undefined,
    };
  }

  // Doctor operations
  async createDoctorProfile(profile: InsertDoctorProfile): Promise<DoctorProfile> {
    const [doctorProfile] = await db
      .insert(doctorProfiles)
      .values(profile)
      .returning();
    return doctorProfile;
  }

  async updateDoctorProfile(id: string, profile: Partial<InsertDoctorProfile>): Promise<DoctorProfile> {
    const [updated] = await db
      .update(doctorProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(doctorProfiles.id, id))
      .returning();
    return updated;
  }

  async getDoctorProfile(userId: string): Promise<DoctorProfile | undefined> {
    const [profile] = await db
      .select()
      .from(doctorProfiles)
      .where(eq(doctorProfiles.userId, userId));
    return profile;
  }

  async getDoctorsBySpecialization(specialization?: string): Promise<(DoctorProfile & { user: User })[]> {
    const query = db
      .select()
      .from(doctorProfiles)
      .innerJoin(users, eq(doctorProfiles.userId, users.id))
      .where(eq(doctorProfiles.isApproved, true));
    
    if (specialization) {
      query.where(and(
        eq(doctorProfiles.isApproved, true),
        eq(doctorProfiles.specialization, specialization)
      ));
    }
    
    const results = await query;
    return results.map(result => ({
      ...result.doctor_profiles,
      user: result.users,
    }));
  }

  async approveDoctorProfile(id: string): Promise<DoctorProfile> {
    const [approved] = await db
      .update(doctorProfiles)
      .set({ isApproved: true, updatedAt: new Date() })
      .where(eq(doctorProfiles.id, id))
      .returning();
    return approved;
  }

  // Appointment operations
  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [created] = await db
      .insert(appointments)
      .values(appointment)
      .returning();
    return created;
  }

  async updateAppointment(id: string, appointment: Partial<InsertAppointment>): Promise<Appointment> {
    const [updated] = await db
      .update(appointments)
      .set({ ...appointment, updatedAt: new Date() })
      .where(eq(appointments.id, id))
      .returning();
    return updated;
  }

  async getAppointment(id: string): Promise<AppointmentWithDetails | undefined> {
    const [result] = await db
      .select()
      .from(appointments)
      .innerJoin(doctorProfiles, eq(appointments.doctorId, doctorProfiles.id))
      .innerJoin(users, eq(doctorProfiles.userId, users.id))
      .leftJoin(users, eq(appointments.patientId, users.id))
      .where(eq(appointments.id, id));
    
    if (!result) return undefined;
    
    return {
      ...result.appointments,
      doctor: {
        ...result.doctor_profiles,
        user: result.users,
      },
      patient: result.users,
    };
  }

  async getAppointmentsByDoctor(doctorId: string, date?: Date): Promise<AppointmentWithDetails[]> {
    let query = db
      .select()
      .from(appointments)
      .innerJoin(doctorProfiles, eq(appointments.doctorId, doctorProfiles.id))
      .innerJoin(users, eq(doctorProfiles.userId, users.id))
      .leftJoin(users, eq(appointments.patientId, users.id))
      .where(eq(appointments.doctorId, doctorId))
      .orderBy(asc(appointments.appointmentDate));
    
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      
      query = query.where(and(
        eq(appointments.doctorId, doctorId),
        gte(appointments.appointmentDate, startOfDay),
        lte(appointments.appointmentDate, endOfDay)
      ));
    }
    
    const results = await query;
    return results.map(result => ({
      ...result.appointments,
      doctor: {
        ...result.doctor_profiles,
        user: result.users,
      },
      patient: result.users,
    }));
  }

  async getAppointmentsByPatient(patientId: string): Promise<AppointmentWithDetails[]> {
    const results = await db
      .select()
      .from(appointments)
      .innerJoin(doctorProfiles, eq(appointments.doctorId, doctorProfiles.id))
      .innerJoin(users, eq(doctorProfiles.userId, users.id))
      .leftJoin(users, eq(appointments.patientId, users.id))
      .where(eq(appointments.patientId, patientId))
      .orderBy(desc(appointments.appointmentDate));
    
    return results.map(result => ({
      ...result.appointments,
      doctor: {
        ...result.doctor_profiles,
        user: result.users,
      },
      patient: result.users,
    }));
  }

  async getTodayAppointments(doctorId: string): Promise<AppointmentWithDetails[]> {
    const today = new Date();
    return this.getAppointmentsByDoctor(doctorId, today);
  }

  // Prescription operations
  async createPrescription(prescription: InsertPrescription): Promise<Prescription> {
    const [created] = await db
      .insert(prescriptions)
      .values(prescription)
      .returning();
    return created;
  }

  async getPrescriptionsByPatient(patientId: string): Promise<PrescriptionWithDetails[]> {
    const results = await db
      .select()
      .from(prescriptions)
      .innerJoin(doctorProfiles, eq(prescriptions.doctorId, doctorProfiles.id))
      .innerJoin(users, eq(doctorProfiles.userId, users.id))
      .leftJoin(users, eq(prescriptions.patientId, users.id))
      .leftJoin(appointments, eq(prescriptions.appointmentId, appointments.id))
      .where(eq(prescriptions.patientId, patientId))
      .orderBy(desc(prescriptions.issuedAt));
    
    return results.map(result => ({
      ...result.prescriptions,
      doctor: {
        ...result.doctor_profiles,
        user: result.users,
      },
      patient: result.users,
      appointment: result.appointments || undefined,
    }));
  }

  async getPrescriptionsByDoctor(doctorId: string): Promise<PrescriptionWithDetails[]> {
    const results = await db
      .select()
      .from(prescriptions)
      .innerJoin(doctorProfiles, eq(prescriptions.doctorId, doctorProfiles.id))
      .innerJoin(users, eq(doctorProfiles.userId, users.id))
      .leftJoin(users, eq(prescriptions.patientId, users.id))
      .leftJoin(appointments, eq(prescriptions.appointmentId, appointments.id))
      .where(eq(prescriptions.doctorId, doctorId))
      .orderBy(desc(prescriptions.issuedAt));
    
    return results.map(result => ({
      ...result.prescriptions,
      doctor: {
        ...result.doctor_profiles,
        user: result.users,
      },
      patient: result.users,
      appointment: result.appointments || undefined,
    }));
  }

  // Medical records operations
  async createMedicalRecord(record: InsertMedicalRecord): Promise<MedicalRecord> {
    const [created] = await db
      .insert(medicalRecords)
      .values(record)
      .returning();
    return created;
  }

  async getMedicalRecordsByPatient(patientId: string): Promise<MedicalRecord[]> {
    return await db
      .select()
      .from(medicalRecords)
      .where(eq(medicalRecords.patientId, patientId))
      .orderBy(desc(medicalRecords.recordDate));
  }

  // Billing operations
  async createInvoice(invoice: Omit<Invoice, 'id' | 'createdAt' | 'updatedAt'>): Promise<Invoice> {
    const [created] = await db
      .insert(invoices)
      .values(invoice)
      .returning();
    return created;
  }

  async updateInvoicePaymentStatus(
    id: string, 
    status: 'paid' | 'failed' | 'refunded', 
    stripePaymentIntentId?: string
  ): Promise<Invoice> {
    const updateData: any = { 
      paymentStatus: status, 
      updatedAt: new Date() 
    };
    
    if (status === 'paid') {
      updateData.paidAt = new Date();
    }
    
    if (stripePaymentIntentId) {
      updateData.stripePaymentIntentId = stripePaymentIntentId;
    }
    
    const [updated] = await db
      .update(invoices)
      .set(updateData)
      .where(eq(invoices.id, id))
      .returning();
    return updated;
  }

  async getInvoicesByPatient(patientId: string): Promise<Invoice[]> {
    return await db
      .select()
      .from(invoices)
      .where(eq(invoices.patientId, patientId))
      .orderBy(desc(invoices.createdAt));
  }

  async getInvoicesByDoctor(doctorId: string): Promise<Invoice[]> {
    return await db
      .select()
      .from(invoices)
      .where(eq(invoices.doctorId, doctorId))
      .orderBy(desc(invoices.createdAt));
  }

  // Analytics
  async getStatsForDoctor(doctorId: string): Promise<{
    todayAppointments: number;
    totalPatients: number;
    monthlyRevenue: number;
    pendingPrescriptions: number;
  }> {
    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    const [todayAppointments, totalPatients, monthlyInvoices, pendingPrescriptions] = await Promise.all([
      this.getTodayAppointments(doctorId),
      db.select().from(appointments).where(eq(appointments.doctorId, doctorId)),
      db.select().from(invoices).where(and(
        eq(invoices.doctorId, doctorId),
        eq(invoices.paymentStatus, 'paid'),
        gte(invoices.paidAt, startOfMonth),
        lte(invoices.paidAt, endOfMonth)
      )),
      db.select().from(prescriptions).where(eq(prescriptions.doctorId, doctorId))
    ]);
    
    const uniquePatients = new Set(totalPatients.map(apt => apt.patientId));
    const monthlyRevenue = monthlyInvoices.reduce((sum, invoice) => sum + parseFloat(invoice.amount || '0'), 0);
    
    return {
      todayAppointments: todayAppointments.length,
      totalPatients: uniquePatients.size,
      monthlyRevenue,
      pendingPrescriptions: pendingPrescriptions.length,
    };
  }

  async getAdminStats(): Promise<{
    totalUsers: number;
    activeDoctors: number;
    monthlyRevenue: number;
    pendingApprovals: number;
  }> {
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    
    const [allUsers, activeDoctors, monthlyInvoices, pendingDoctors] = await Promise.all([
      db.select().from(users),
      db.select().from(doctorProfiles).where(eq(doctorProfiles.isApproved, true)),
      db.select().from(invoices).where(and(
        eq(invoices.paymentStatus, 'paid'),
        gte(invoices.paidAt, startOfMonth)
      )),
      db.select().from(doctorProfiles).where(eq(doctorProfiles.isApproved, false))
    ]);
    
    const monthlyRevenue = monthlyInvoices.reduce((sum, invoice) => sum + parseFloat(invoice.amount || '0'), 0);
    
    return {
      totalUsers: allUsers.length,
      activeDoctors: activeDoctors.length,
      monthlyRevenue,
      pendingApprovals: pendingDoctors.length,
    };
  }
}

export const storage = new DatabaseStorage();
