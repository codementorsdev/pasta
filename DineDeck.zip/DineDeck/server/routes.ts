import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import express from "express";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertAppointmentSchema, insertPrescriptionSchema, insertDoctorProfileSchema } from "@shared/schema";
import { z } from "zod";

// Initialize Stripe only if secret key is available
let stripe: Stripe | null = null;
if (process.env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2025-08-27.basil",
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUserWithProfile(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Doctor Profile Routes
  app.post('/api/doctors/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profileData = insertDoctorProfileSchema.parse({
        ...req.body,
        userId,
      });
      
      const profile = await storage.createDoctorProfile(profileData);
      res.json(profile);
    } catch (error) {
      console.error("Error creating doctor profile:", error);
      res.status(400).json({ message: "Failed to create doctor profile" });
    }
  });

  app.put('/api/doctors/profile/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const profile = await storage.updateDoctorProfile(id, updates);
      res.json(profile);
    } catch (error) {
      console.error("Error updating doctor profile:", error);
      res.status(400).json({ message: "Failed to update doctor profile" });
    }
  });

  app.get('/api/doctors', async (req, res) => {
    try {
      const { specialization } = req.query;
      const doctors = await storage.getDoctorsBySpecialization(specialization as string);
      res.json(doctors);
    } catch (error) {
      console.error("Error fetching doctors:", error);
      res.status(500).json({ message: "Failed to fetch doctors" });
    }
  });

  // Appointment Routes
  app.post('/api/appointments', isAuthenticated, async (req: any, res) => {
    try {
      const patientId = req.user.claims.sub;
      const appointmentData = insertAppointmentSchema.parse({
        ...req.body,
        patientId,
      });
      
      const appointment = await storage.createAppointment(appointmentData);
      
      // Create invoice for the appointment
      const doctor = await storage.getDoctorProfile(appointment.doctorId);
      if (doctor) {
        await storage.createInvoice({
          appointmentId: appointment.id,
          patientId: appointment.patientId,
          doctorId: appointment.doctorId,
          amount: appointment.consultationFee || doctor.consultationFee || '0',
          paymentStatus: 'pending',
          stripePaymentIntentId: null,
          paidAt: null,
        });
      }
      
      res.json(appointment);
    } catch (error) {
      console.error("Error creating appointment:", error);
      res.status(400).json({ message: "Failed to create appointment" });
    }
  });

  app.get('/api/appointments/doctor/:doctorId', isAuthenticated, async (req, res) => {
    try {
      const { doctorId } = req.params;
      const { date } = req.query;
      
      const appointments = await storage.getAppointmentsByDoctor(
        doctorId, 
        date ? new Date(date as string) : undefined
      );
      res.json(appointments);
    } catch (error) {
      console.error("Error fetching doctor appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.get('/api/appointments/patient', isAuthenticated, async (req: any, res) => {
    try {
      const patientId = req.user.claims.sub;
      const appointments = await storage.getAppointmentsByPatient(patientId);
      res.json(appointments);
    } catch (error) {
      console.error("Error fetching patient appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.put('/api/appointments/:id', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const appointment = await storage.updateAppointment(id, updates);
      res.json(appointment);
    } catch (error) {
      console.error("Error updating appointment:", error);
      res.status(400).json({ message: "Failed to update appointment" });
    }
  });

  // Prescription Routes
  app.post('/api/prescriptions', isAuthenticated, async (req: any, res) => {
    try {
      const doctorId = req.user.claims.sub;
      const prescriptionData = insertPrescriptionSchema.parse({
        ...req.body,
        doctorId,
      });
      
      const prescription = await storage.createPrescription(prescriptionData);
      res.json(prescription);
    } catch (error) {
      console.error("Error creating prescription:", error);
      res.status(400).json({ message: "Failed to create prescription" });
    }
  });

  app.get('/api/prescriptions/patient', isAuthenticated, async (req: any, res) => {
    try {
      const patientId = req.user.claims.sub;
      const prescriptions = await storage.getPrescriptionsByPatient(patientId);
      res.json(prescriptions);
    } catch (error) {
      console.error("Error fetching patient prescriptions:", error);
      res.status(500).json({ message: "Failed to fetch prescriptions" });
    }
  });

  app.get('/api/prescriptions/doctor', isAuthenticated, async (req: any, res) => {
    try {
      const doctorId = req.user.claims.sub;
      const prescriptions = await storage.getPrescriptionsByDoctor(doctorId);
      res.json(prescriptions);
    } catch (error) {
      console.error("Error fetching doctor prescriptions:", error);
      res.status(500).json({ message: "Failed to fetch prescriptions" });
    }
  });

  // Medical Records Routes
  app.post('/api/medical-records', isAuthenticated, async (req: any, res) => {
    try {
      const patientId = req.user.claims.sub;
      const recordData = {
        ...req.body,
        patientId,
      };
      
      const record = await storage.createMedicalRecord(recordData);
      res.json(record);
    } catch (error) {
      console.error("Error creating medical record:", error);
      res.status(400).json({ message: "Failed to create medical record" });
    }
  });

  app.get('/api/medical-records/patient', isAuthenticated, async (req: any, res) => {
    try {
      const patientId = req.user.claims.sub;
      const records = await storage.getMedicalRecordsByPatient(patientId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching medical records:", error);
      res.status(500).json({ message: "Failed to fetch medical records" });
    }
  });

  // Billing Routes
  app.get('/api/invoices/patient', isAuthenticated, async (req: any, res) => {
    try {
      const patientId = req.user.claims.sub;
      const invoices = await storage.getInvoicesByPatient(patientId);
      res.json(invoices);
    } catch (error) {
      console.error("Error fetching patient invoices:", error);
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  app.get('/api/invoices/doctor', isAuthenticated, async (req: any, res) => {
    try {
      const doctorId = req.user.claims.sub;
      const invoices = await storage.getInvoicesByDoctor(doctorId);
      res.json(invoices);
    } catch (error) {
      console.error("Error fetching doctor invoices:", error);
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Stripe Payment Routes
  app.post("/api/create-payment-intent", isAuthenticated, async (req: any, res) => {
    if (!stripe) {
      return res.status(503).json({ message: "Payment processing not available. Stripe not configured." });
    }
    
    try {
      const { amount, appointmentId } = req.body;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          appointmentId,
          patientId: req.user.claims.sub,
        },
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Payment webhook
  app.post('/api/webhooks/stripe', express.raw({type: 'application/json'}), async (req, res) => {
    if (!stripe) {
      return res.status(503).json({ message: "Payment processing not available. Stripe not configured." });
    }
    
    const sig = req.headers['stripe-signature'] as string;
    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
    } catch (err: any) {
      console.log(`Webhook signature verification failed.`, err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      const appointmentId = paymentIntent.metadata?.appointmentId;
      
      if (appointmentId) {
        // Update appointment status
        await storage.updateAppointment(appointmentId, { status: 'confirmed' });
        
        // Update invoice payment status
        // Find invoice by appointment ID and update
        // This would need additional storage method to find invoice by appointment
      }
    }

    res.json({received: true});
  });

  // Analytics Routes
  app.get('/api/stats/doctor', isAuthenticated, async (req: any, res) => {
    try {
      const doctorId = req.user.claims.sub;
      const stats = await storage.getStatsForDoctor(doctorId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching doctor stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get('/api/stats/admin', isAuthenticated, async (req: any, res) => {
    try {
      // Check if user is admin
      const user = await storage.getUserWithProfile(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Admin Routes
  app.post('/api/admin/approve-doctor/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUserWithProfile(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const { id } = req.params;
      const profile = await storage.approveDoctorProfile(id);
      res.json(profile);
    } catch (error) {
      console.error("Error approving doctor:", error);
      res.status(400).json({ message: "Failed to approve doctor" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
