export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  profileImageUrl?: string;
  role: 'doctor' | 'patient' | 'admin';
  phone?: string;
  dateOfBirth?: string;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  createdAt: string;
  updatedAt: string;
  doctorProfile?: DoctorProfile;
}

export interface DoctorProfile {
  id: string;
  userId: string;
  specialization: string;
  licenseNumber: string;
  experience: number;
  consultationFee: string;
  bio?: string;
  isApproved: boolean;
  rating: string;
  totalReviews: number;
  createdAt: string;
  updatedAt: string;
  user?: User;
}

export interface Appointment {
  id: string;
  doctorId: string;
  patientId: string;
  appointmentDate: string;
  duration: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  reason?: string;
  notes?: string;
  consultationFee?: string;
  createdAt: string;
  updatedAt: string;
  doctor?: DoctorProfile & { user: User };
  patient?: User;
}

export interface Prescription {
  id: string;
  appointmentId?: string;
  doctorId: string;
  patientId: string;
  diagnosis: string;
  medications: Medication[];
  notes?: string;
  issuedAt: string;
  createdAt: string;
  doctor?: DoctorProfile & { user: User };
  patient?: User;
  appointment?: Appointment;
}

export interface Medication {
  name: string;
  dosage: string;
  duration: string;
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorId?: string;
  appointmentId?: string;
  title: string;
  description?: string;
  fileUrl?: string;
  fileType?: string;
  recordDate: string;
  createdAt: string;
}

export interface Invoice {
  id: string;
  appointmentId: string;
  patientId: string;
  doctorId: string;
  amount: string;
  paymentStatus: 'pending' | 'paid' | 'failed' | 'refunded';
  stripePaymentIntentId?: string;
  paidAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DoctorStats {
  todayAppointments: number;
  totalPatients: number;
  monthlyRevenue: number;
  pendingPrescriptions: number;
}

export interface AdminStats {
  totalUsers: number;
  activeDoctors: number;
  monthlyRevenue: number;
  pendingApprovals: number;
}

export interface ApiError {
  message: string;
  status?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface SearchFilters {
  query?: string;
  specialization?: string;
  status?: string;
  dateFrom?: string;
  dateTo?: string;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}

export interface DoctorAvailability {
  id: string;
  doctorId: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  isAvailable: boolean;
  createdAt: string;
}
