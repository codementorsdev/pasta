import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import StatsCards from "@/components/dashboard/stats-cards";
import TodaySchedule from "@/components/dashboard/today-schedule";
import QuickActions from "@/components/dashboard/quick-actions";
import RecentActivity from "@/components/dashboard/recent-activity";

export default function Home() {
  const { user } = useAuth();
  
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats/doctor"],
    enabled: user?.role === 'doctor',
  });

  const { data: adminStats, isLoading: adminStatsLoading } = useQuery({
    queryKey: ["/api/stats/admin"],
    enabled: user?.role === 'admin',
  });

  if (!user) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const isDoctor = user.role === 'doctor';
  const isAdmin = user.role === 'admin';

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Welcome Section */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-foreground" data-testid="text-welcome-title">
          Welcome back, {user.firstName || 'User'}
        </h2>
        <p className="text-sm text-muted-foreground" data-testid="text-welcome-subtitle">
          {isDoctor ? 'Manage your practice and patients' : 
           isAdmin ? 'System overview and management' : 
           'Your health dashboard'}
        </p>
      </div>

      {/* Stats Cards */}
      <StatsCards 
        stats={isAdmin ? adminStats : stats} 
        isLoading={isAdmin ? adminStatsLoading : statsLoading}
        userRole={user.role}
      />

      {/* Main Content Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Today's Schedule - Only for doctors */}
        {isDoctor && <TodaySchedule />}
        
        {/* Quick Actions */}
        <QuickActions userRole={user.role} />
        
        {/* Recent Activity */}
        <RecentActivity />
      </div>
    </div>
  );
}
