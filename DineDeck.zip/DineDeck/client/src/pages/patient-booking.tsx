import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Search, Star, Calendar, Clock, User, CreditCard } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, addDays } from "date-fns";

interface Doctor {
  id: string;
  specialization: string;
  consultationFee: string;
  experience: number;
  rating: string;
  totalReviews: number;
  user: {
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
  };
}

export default function PatientBooking() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSpecialization, setSelectedSpecialization] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [reason, setReason] = useState("");
  
  const { data: doctors, isLoading } = useQuery({
    queryKey: ["/api/doctors", selectedSpecialization],
    enabled: true,
  });

  const bookAppointmentMutation = useMutation({
    mutationFn: async (appointmentData: any) => {
      return await apiRequest("POST", "/api/appointments", appointmentData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Appointment booked successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setSelectedDoctor(null);
    setSelectedDate("");
    setSelectedTime("");
    setReason("");
  };

  const filteredDoctors = doctors?.filter((doctor: Doctor) =>
    doctor.user.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doctor.user.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doctor.specialization.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const specializations = [
    "cardiology", "dermatology", "endocrinology", "gastroenterology",
    "neurology", "oncology", "orthopedics", "pediatrics", "psychiatry", "general_medicine"
  ];

  // Generate available time slots
  const timeSlots = [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
    "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00"
  ];

  const handleBookAppointment = () => {
    if (!selectedDoctor || !selectedDate || !selectedTime) {
      toast({
        title: "Error",
        description: "Please select a doctor, date, and time",
        variant: "destructive",
      });
      return;
    }

    const appointmentDateTime = new Date(`${selectedDate}T${selectedTime}:00`);
    
    bookAppointmentMutation.mutate({
      doctorId: selectedDoctor.id,
      appointmentDate: appointmentDateTime.toISOString(),
      reason,
      consultationFee: selectedDoctor.consultationFee,
    });
  };

  if (user?.role !== 'patient') {
    return (
      <div className="p-4 md:p-6" data-testid="booking-unauthorized">
        <Card>
          <CardContent className="p-8 text-center">
            <h3 className="text-lg font-medium text-foreground mb-2">Access Denied</h3>
            <p className="text-muted-foreground">This page is only available to patients.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6" data-testid="patient-booking-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-booking-title">
            Book Appointment
          </h1>
          <p className="text-muted-foreground" data-testid="text-booking-subtitle">
            Find and book appointments with qualified doctors
          </p>
        </div>
      </div>

      {!selectedDoctor ? (
        <>
          {/* Search and Filter */}
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search doctors by name or specialization..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-doctors"
              />
            </div>

            {/* Specialization Filter */}
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedSpecialization === "" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedSpecialization("")}
                data-testid="filter-all-specializations"
              >
                All
              </Button>
              {specializations.map((spec) => (
                <Button
                  key={spec}
                  variant={selectedSpecialization === spec ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedSpecialization(spec)}
                  data-testid={`filter-specialization-${spec}`}
                >
                  {spec.charAt(0).toUpperCase() + spec.slice(1).replace('_', ' ')}
                </Button>
              ))}
            </div>
          </div>

          {/* Doctors List */}
          <div className="space-y-4">
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} data-testid={`doctor-skeleton-${i}`}>
                    <CardContent className="p-6">
                      <div className="animate-pulse">
                        <div className="flex items-center space-x-4">
                          <div className="w-16 h-16 bg-muted rounded-full"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-muted rounded mb-2"></div>
                            <div className="h-3 bg-muted rounded w-1/2"></div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : filteredDoctors.length === 0 ? (
              <Card data-testid="no-doctors-card">
                <CardContent className="p-8 text-center">
                  <User className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">No doctors found</h3>
                  <p className="text-muted-foreground">Try adjusting your search criteria</p>
                </CardContent>
              </Card>
            ) : (
              filteredDoctors.map((doctor: Doctor) => (
                <Card key={doctor.id} data-testid={`doctor-card-${doctor.id}`}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        {doctor.user.profileImageUrl ? (
                          <img 
                            src={doctor.user.profileImageUrl}
                            alt={`Dr. ${doctor.user.firstName} ${doctor.user.lastName}`}
                            className="w-16 h-16 rounded-full object-cover"
                            data-testid={`img-doctor-${doctor.id}`}
                          />
                        ) : (
                          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                            <User className="h-8 w-8 text-muted-foreground" />
                          </div>
                        )}
                        
                        <div className="flex-1">
                          <h3 className="text-lg font-medium text-foreground" data-testid={`text-doctor-name-${doctor.id}`}>
                            Dr. {doctor.user.firstName} {doctor.user.lastName}
                          </h3>
                          <p className="text-muted-foreground capitalize" data-testid={`text-doctor-specialization-${doctor.id}`}>
                            {doctor.specialization.replace('_', ' ')}
                          </p>
                          <div className="flex items-center space-x-4 mt-2">
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-400 fill-current" />
                              <span className="text-sm text-muted-foreground ml-1" data-testid={`text-doctor-rating-${doctor.id}`}>
                                {doctor.rating} ({doctor.totalReviews} reviews)
                              </span>
                            </div>
                            <span className="text-sm text-muted-foreground" data-testid={`text-doctor-experience-${doctor.id}`}>
                              {doctor.experience} years exp.
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <p className="text-lg font-bold text-foreground" data-testid={`text-doctor-fee-${doctor.id}`}>
                          ${doctor.consultationFee}
                        </p>
                        <p className="text-sm text-muted-foreground">per consultation</p>
                        <Button 
                          className="mt-2"
                          onClick={() => setSelectedDoctor(doctor)}
                          data-testid={`button-select-doctor-${doctor.id}`}
                        >
                          Select Doctor
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </>
      ) : (
        /* Appointment Booking Form */
        <div className="max-w-2xl mx-auto">
          <Card data-testid="appointment-booking-form">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Book Appointment</span>
                <Button 
                  variant="outline" 
                  onClick={() => setSelectedDoctor(null)}
                  data-testid="button-back-to-doctors"
                >
                  Back to Doctors
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Selected Doctor Info */}
              <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
                {selectedDoctor.user.profileImageUrl ? (
                  <img 
                    src={selectedDoctor.user.profileImageUrl}
                    alt={`Dr. ${selectedDoctor.user.firstName} ${selectedDoctor.user.lastName}`}
                    className="w-12 h-12 rounded-full object-cover"
                    data-testid="img-selected-doctor"
                  />
                ) : (
                  <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center">
                    <User className="h-6 w-6 text-muted-foreground" />
                  </div>
                )}
                <div>
                  <h3 className="font-medium text-foreground" data-testid="text-selected-doctor-name">
                    Dr. {selectedDoctor.user.firstName} {selectedDoctor.user.lastName}
                  </h3>
                  <p className="text-sm text-muted-foreground capitalize" data-testid="text-selected-doctor-specialization">
                    {selectedDoctor.specialization.replace('_', ' ')}
                  </p>
                  <p className="text-sm font-medium text-foreground" data-testid="text-selected-doctor-fee">
                    ${selectedDoctor.consultationFee} per consultation
                  </p>
                </div>
              </div>

              {/* Date Selection */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Select Date</label>
                <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
                  {[...Array(10)].map((_, i) => {
                    const date = addDays(new Date(), i);
                    const dateStr = format(date, 'yyyy-MM-dd');
                    const isSelected = selectedDate === dateStr;
                    
                    return (
                      <Button
                        key={dateStr}
                        variant={isSelected ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedDate(dateStr)}
                        className="flex flex-col h-auto py-2"
                        data-testid={`button-select-date-${dateStr}`}
                      >
                        <span className="text-xs">{format(date, 'EEE')}</span>
                        <span className="font-medium">{format(date, 'MMM d')}</span>
                      </Button>
                    );
                  })}
                </div>
              </div>

              {/* Time Selection */}
              {selectedDate && (
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Select Time</label>
                  <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                    {timeSlots.map((time) => (
                      <Button
                        key={time}
                        variant={selectedTime === time ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedTime(time)}
                        data-testid={`button-select-time-${time}`}
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Reason for Visit */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Reason for Visit (Optional)</label>
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Describe your symptoms or reason for the appointment..."
                  rows={3}
                  data-testid="textarea-appointment-reason"
                />
              </div>

              {/* Book Appointment Button */}
              <Button 
                className="w-full"
                size="lg"
                onClick={handleBookAppointment}
                disabled={!selectedDate || !selectedTime || bookAppointmentMutation.isPending}
                data-testid="button-book-appointment"
              >
                <CreditCard className="h-4 w-4 mr-2" />
                {bookAppointmentMutation.isPending 
                  ? "Booking..." 
                  : `Book Appointment - $${selectedDoctor.consultationFee}`
                }
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
