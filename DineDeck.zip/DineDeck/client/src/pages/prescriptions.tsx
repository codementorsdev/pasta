import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Calendar, User, Download } from "lucide-react";

export default function Prescriptions() {
  const { user } = useAuth();
  
  const { data: prescriptions, isLoading } = useQuery({
    queryKey: user?.role === 'doctor' 
      ? ["/api/prescriptions/doctor"]
      : ["/api/prescriptions/patient"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} data-testid={`prescription-skeleton-${i}`}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-6 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6" data-testid="prescriptions-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-prescriptions-title">
            Prescriptions
          </h1>
          <p className="text-muted-foreground" data-testid="text-prescriptions-subtitle">
            {user?.role === 'doctor' ? 'Manage patient prescriptions' : 'Your prescription history'}
          </p>
        </div>
      </div>

      {/* Prescriptions List */}
      <div className="space-y-4">
        {!prescriptions || prescriptions.length === 0 ? (
          <Card data-testid="no-prescriptions-card">
            <CardContent className="p-8 text-center">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No prescriptions found</h3>
              <p className="text-muted-foreground">
                {user?.role === 'doctor' 
                  ? 'No prescriptions issued yet'
                  : 'You don\'t have any prescriptions yet'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          prescriptions.map((prescription: any) => (
            <Card key={prescription.id} data-testid={`prescription-card-${prescription.id}`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {user?.role === 'doctor' ? (
                      // Show patient info for doctors
                      <>
                        {prescription.patient?.profileImageUrl ? (
                          <img 
                            src={prescription.patient.profileImageUrl}
                            alt={`${prescription.patient.firstName} ${prescription.patient.lastName}`}
                            className="w-10 h-10 rounded-full object-cover"
                            data-testid={`img-patient-${prescription.id}`}
                          />
                        ) : (
                          <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
                            <User className="h-5 w-5 text-muted-foreground" />
                          </div>
                        )}
                        <div>
                          <CardTitle className="text-lg" data-testid={`text-patient-name-${prescription.id}`}>
                            {prescription.patient?.firstName} {prescription.patient?.lastName}
                          </CardTitle>
                          <p className="text-sm text-muted-foreground">Patient</p>
                        </div>
                      </>
                    ) : (
                      // Show doctor info for patients
                      <>
                        {prescription.doctor?.user?.profileImageUrl ? (
                          <img 
                            src={prescription.doctor.user.profileImageUrl}
                            alt={`${prescription.doctor.user.firstName} ${prescription.doctor.user.lastName}`}
                            className="w-10 h-10 rounded-full object-cover"
                            data-testid={`img-doctor-${prescription.id}`}
                          />
                        ) : (
                          <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
                            <User className="h-5 w-5 text-muted-foreground" />
                          </div>
                        )}
                        <div>
                          <CardTitle className="text-lg" data-testid={`text-doctor-name-${prescription.id}`}>
                            Dr. {prescription.doctor?.user?.firstName} {prescription.doctor?.user?.lastName}
                          </CardTitle>
                          <p className="text-sm text-muted-foreground">{prescription.doctor?.specialization}</p>
                        </div>
                      </>
                    )}
                  </div>

                  <div className="flex items-center space-x-2">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span data-testid={`text-prescription-date-${prescription.id}`}>
                        {new Date(prescription.issuedAt).toLocaleDateString()}
                      </span>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      data-testid={`button-download-prescription-${prescription.id}`}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                {/* Diagnosis */}
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-foreground mb-1">Diagnosis</h4>
                  <p className="text-sm text-muted-foreground" data-testid={`text-diagnosis-${prescription.id}`}>
                    {prescription.diagnosis}
                  </p>
                </div>

                {/* Medications */}
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-foreground mb-2">Medications</h4>
                  <div className="space-y-2">
                    {prescription.medications?.map((medication: any, index: number) => (
                      <div 
                        key={index} 
                        className="p-3 bg-muted rounded-lg"
                        data-testid={`medication-${prescription.id}-${index}`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-foreground" data-testid={`text-medication-name-${prescription.id}-${index}`}>
                              {medication.name}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              <span data-testid={`text-medication-dosage-${prescription.id}-${index}`}>
                                {medication.dosage}
                              </span>
                              {' • '}
                              <span data-testid={`text-medication-duration-${prescription.id}-${index}`}>
                                {medication.duration}
                              </span>
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Notes */}
                {prescription.notes && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-1">Additional Notes</h4>
                    <p className="text-sm text-muted-foreground" data-testid={`text-prescription-notes-${prescription.id}`}>
                      {prescription.notes}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
