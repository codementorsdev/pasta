import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreditCard, Calendar, DollarSign, Download, Filter, Search } from "lucide-react";
import { useState } from "react";

export default function Billing() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  
  const { data: invoices, isLoading } = useQuery({
    queryKey: user?.role === 'doctor' 
      ? ["/api/invoices/doctor"]
      : ["/api/invoices/patient"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} data-testid={`invoice-skeleton-${i}`}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-6 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const filteredInvoices = invoices?.filter((invoice: any) => {
    const matchesSearch = searchQuery === "" || 
      invoice.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || invoice.paymentStatus === statusFilter;
    return matchesSearch && matchesStatus;
  }) || [];

  const totalRevenue = invoices?.reduce((sum: number, invoice: any) => 
    invoice.paymentStatus === 'paid' ? sum + parseFloat(invoice.amount || '0') : sum, 0
  ) || 0;

  const pendingAmount = invoices?.reduce((sum: number, invoice: any) => 
    invoice.paymentStatus === 'pending' ? sum + parseFloat(invoice.amount || '0') : sum, 0
  ) || 0;

  return (
    <div className="p-4 md:p-6 space-y-6" data-testid="billing-page">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-billing-title">
            Billing & Payments
          </h1>
          <p className="text-muted-foreground" data-testid="text-billing-subtitle">
            {user?.role === 'doctor' ? 'Manage your consultation fees and payments' : 'View and pay your medical bills'}
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card data-testid="card-total-revenue">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {user?.role === 'doctor' ? 'Total Revenue' : 'Total Paid'}
                </p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-total-revenue">
                  ${totalRevenue.toLocaleString()}
                </p>
              </div>
              <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-pending-amount">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {user?.role === 'doctor' ? 'Pending Payments' : 'Outstanding Bills'}
                </p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-pending-amount">
                  ${pendingAmount.toLocaleString()}
                </p>
              </div>
              <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
                <CreditCard className="h-4 w-4 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-total-invoices">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Invoices</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-total-invoices">
                  {invoices?.length || 0}
                </p>
              </div>
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                <Calendar className="h-4 w-4 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search by invoice ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-invoices"
          />
        </div>
        
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48" data-testid="select-status-filter">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
            <SelectItem value="refunded">Refunded</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Invoices List */}
      <div className="space-y-4">
        {filteredInvoices.length === 0 ? (
          <Card data-testid="no-invoices-card">
            <CardContent className="p-8 text-center">
              <CreditCard className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No invoices found</h3>
              <p className="text-muted-foreground">
                {searchQuery || statusFilter !== "all"
                  ? 'Try adjusting your search criteria'
                  : user?.role === 'doctor' 
                    ? 'Invoices will appear here after appointments'
                    : 'You don\'t have any invoices yet'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredInvoices.map((invoice: any) => (
            <Card key={invoice.id} data-testid={`invoice-card-${invoice.id}`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
                      <CreditCard className="h-6 w-6 text-muted-foreground" />
                    </div>
                    
                    <div>
                      <h3 className="font-medium text-foreground" data-testid={`text-invoice-id-${invoice.id}`}>
                        Invoice #{invoice.id.slice(-8).toUpperCase()}
                      </h3>
                      <div className="flex items-center space-x-4 mt-1">
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3 mr-1" />
                          <span data-testid={`text-invoice-date-${invoice.id}`}>
                            {new Date(invoice.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        {invoice.paidAt && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <span>Paid: {new Date(invoice.paidAt).toLocaleDateString()}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-lg font-bold text-foreground" data-testid={`text-invoice-amount-${invoice.id}`}>
                        ${parseFloat(invoice.amount || '0').toLocaleString()}
                      </p>
                      <Badge 
                        variant={
                          invoice.paymentStatus === 'paid' ? 'default' :
                          invoice.paymentStatus === 'pending' ? 'secondary' :
                          invoice.paymentStatus === 'failed' ? 'destructive' :
                          'outline'
                        }
                        data-testid={`badge-invoice-status-${invoice.id}`}
                      >
                        {invoice.paymentStatus}
                      </Badge>
                    </div>

                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        data-testid={`button-download-invoice-${invoice.id}`}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      
                      {invoice.paymentStatus === 'pending' && user?.role === 'patient' && (
                        <Button 
                          size="sm"
                          data-testid={`button-pay-invoice-${invoice.id}`}
                        >
                          Pay Now
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
