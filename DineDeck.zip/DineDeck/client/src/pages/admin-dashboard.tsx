import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, UserCheck, DollarSign, Shield, Clock, Check, X, User } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: adminStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats/admin"],
    enabled: user?.role === 'admin',
  });

  const { data: pendingDoctors, isLoading: doctorsLoading } = useQuery({
    queryKey: ["/api/admin/pending-doctors"],
    enabled: user?.role === 'admin',
  });

  const approveDoctorMutation = useMutation({
    mutationFn: async (doctorId: string) => {
      return await apiRequest("POST", `/api/admin/approve-doctor/${doctorId}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Doctor approved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pending-doctors"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats/admin"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (user?.role !== 'admin') {
    return (
      <div className="p-4 md:p-6" data-testid="admin-unauthorized">
        <Card>
          <CardContent className="p-8 text-center">
            <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">Access Denied</h3>
            <p className="text-muted-foreground">This page is only available to administrators.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (statsLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} data-testid={`admin-stats-skeleton-${i}`}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-8 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6" data-testid="admin-dashboard-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-admin-title">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground" data-testid="text-admin-subtitle">
            System overview and management
          </p>
        </div>
      </div>

      {/* Admin Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card data-testid="admin-stats-total-users">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-admin-total-users">
                  {adminStats?.totalUsers || 0}
                </p>
              </div>
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                <Users className="h-4 w-4 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="admin-stats-active-doctors">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Doctors</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-admin-active-doctors">
                  {adminStats?.activeDoctors || 0}
                </p>
              </div>
              <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center">
                <UserCheck className="h-4 w-4 text-secondary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="admin-stats-monthly-revenue">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Monthly Revenue</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-admin-monthly-revenue">
                  ${adminStats?.monthlyRevenue?.toLocaleString() || '0'}
                </p>
              </div>
              <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="admin-stats-pending-approvals">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Approvals</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-admin-pending-approvals">
                  {adminStats?.pendingApprovals || 0}
                </p>
              </div>
              <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
                <Clock className="h-4 w-4 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Pending Doctor Approvals */}
        <Card data-testid="pending-doctors-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5" />
              <span>Pending Doctor Approvals</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {doctorsLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-muted rounded-full"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-muted rounded mb-2"></div>
                        <div className="h-3 bg-muted rounded w-1/2"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : !pendingDoctors || pendingDoctors.length === 0 ? (
              <div className="text-center py-8">
                <UserCheck className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No pending doctor approvals</p>
              </div>
            ) : (
              <div className="space-y-4">
                {pendingDoctors.map((doctor: any) => (
                  <div 
                    key={doctor.id} 
                    className="flex items-center justify-between p-4 border border-border rounded-lg"
                    data-testid={`pending-doctor-${doctor.id}`}
                  >
                    <div className="flex items-center space-x-4">
                      {doctor.user?.profileImageUrl ? (
                        <img 
                          src={doctor.user.profileImageUrl}
                          alt={`${doctor.user.firstName} ${doctor.user.lastName}`}
                          className="w-12 h-12 rounded-full object-cover"
                          data-testid={`img-pending-doctor-${doctor.id}`}
                        />
                      ) : (
                        <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                          <User className="h-6 w-6 text-muted-foreground" />
                        </div>
                      )}
                      
                      <div>
                        <h4 className="font-medium text-foreground" data-testid={`text-doctor-name-${doctor.id}`}>
                          Dr. {doctor.user?.firstName} {doctor.user?.lastName}
                        </h4>
                        <p className="text-sm text-muted-foreground" data-testid={`text-doctor-specialization-${doctor.id}`}>
                          {doctor.specialization}
                        </p>
                        <p className="text-xs text-muted-foreground" data-testid={`text-doctor-experience-${doctor.id}`}>
                          {doctor.experience} years experience • License: {doctor.licenseNumber}
                        </p>
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button 
                        size="sm"
                        onClick={() => approveDoctorMutation.mutate(doctor.id)}
                        disabled={approveDoctorMutation.isPending}
                        data-testid={`button-approve-doctor-${doctor.id}`}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      <Button 
                        variant="destructive" 
                        size="sm"
                        data-testid={`button-reject-doctor-${doctor.id}`}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* System Analytics */}
        <Card data-testid="system-analytics-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5" />
              <span>System Analytics</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-foreground">Platform Usage</span>
                  <span className="text-sm font-medium text-foreground">92%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-primary h-2 rounded-full" style={{ width: '92%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-foreground">Doctor Approval Rate</span>
                  <span className="text-sm font-medium text-foreground">85%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-secondary h-2 rounded-full" style={{ width: '85%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-foreground">Patient Satisfaction</span>
                  <span className="text-sm font-medium text-foreground">4.8/5</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-accent h-2 rounded-full" style={{ width: '96%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-foreground">System Uptime</span>
                  <span className="text-sm font-medium text-foreground">99.9%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '99.9%' }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
