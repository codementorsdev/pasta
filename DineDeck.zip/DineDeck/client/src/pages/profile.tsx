import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { User, Stethoscope, Calendar, Mail, Phone, MapPin, Save } from "lucide-react";
import { useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [personalInfo, setPersonalInfo] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
  });

  const [doctorInfo, setDoctorInfo] = useState({
    specialization: '',
    licenseNumber: '',
    experience: '',
    consultationFee: '',
    bio: '',
  });

  // Load user data into form
  useEffect(() => {
    if (user) {
      setPersonalInfo({
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        email: user.email || '',
        phone: user.phone || '',
        dateOfBirth: user.dateOfBirth ? new Date(user.dateOfBirth).toISOString().split('T')[0] : '',
      });

      if (user.doctorProfile) {
        setDoctorInfo({
          specialization: user.doctorProfile.specialization || '',
          licenseNumber: user.doctorProfile.licenseNumber || '',
          experience: user.doctorProfile.experience?.toString() || '',
          consultationFee: user.doctorProfile.consultationFee || '',
          bio: user.doctorProfile.bio || '',
        });
      }
    }
  }, [user]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", "/api/auth/profile", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createDoctorProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/doctors/profile", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Doctor profile created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateDoctorProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", `/api/doctors/profile/${user?.doctorProfile?.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Doctor profile updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handlePersonalInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(personalInfo);
  };

  const handleDoctorInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const doctorData = {
      ...doctorInfo,
      experience: parseInt(doctorInfo.experience) || 0,
      consultationFee: parseFloat(doctorInfo.consultationFee) || 0,
    };

    if (user?.doctorProfile) {
      updateDoctorProfileMutation.mutate(doctorData);
    } else {
      createDoctorProfileMutation.mutate(doctorData);
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6" data-testid="profile-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-profile-title">
            Profile Settings
          </h1>
          <p className="text-muted-foreground" data-testid="text-profile-subtitle">
            Manage your personal information and preferences
          </p>
        </div>
      </div>

      {/* Profile Overview */}
      <Card data-testid="profile-overview-card">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            {user.profileImageUrl ? (
              <img 
                src={user.profileImageUrl}
                alt={`${user.firstName} ${user.lastName}`}
                className="w-16 h-16 rounded-full object-cover"
                data-testid="img-profile-avatar"
              />
            ) : (
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                <User className="h-8 w-8 text-muted-foreground" />
              </div>
            )}
            
            <div className="flex-1">
              <h3 className="text-lg font-medium text-foreground" data-testid="text-profile-name">
                {user.firstName} {user.lastName}
              </h3>
              <div className="flex items-center space-x-4 mt-1">
                <Badge variant="outline" data-testid="badge-user-role">
                  {user.role}
                </Badge>
                {user.doctorProfile && (
                  <Badge 
                    variant={user.doctorProfile.isApproved ? "default" : "secondary"}
                    data-testid="badge-doctor-status"
                  >
                    {user.doctorProfile.isApproved ? "Approved" : "Pending Approval"}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Personal Information */}
      <Card data-testid="personal-info-card">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>Personal Information</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePersonalInfoSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName" data-testid="label-first-name">First Name</Label>
                <Input
                  id="firstName"
                  value={personalInfo.firstName}
                  onChange={(e) => setPersonalInfo(prev => ({ ...prev, firstName: e.target.value }))}
                  data-testid="input-first-name"
                />
              </div>
              
              <div>
                <Label htmlFor="lastName" data-testid="label-last-name">Last Name</Label>
                <Input
                  id="lastName"
                  value={personalInfo.lastName}
                  onChange={(e) => setPersonalInfo(prev => ({ ...prev, lastName: e.target.value }))}
                  data-testid="input-last-name"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email" data-testid="label-email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={personalInfo.email}
                  onChange={(e) => setPersonalInfo(prev => ({ ...prev, email: e.target.value }))}
                  data-testid="input-email"
                />
              </div>
              
              <div>
                <Label htmlFor="phone" data-testid="label-phone">Phone</Label>
                <Input
                  id="phone"
                  value={personalInfo.phone}
                  onChange={(e) => setPersonalInfo(prev => ({ ...prev, phone: e.target.value }))}
                  data-testid="input-phone"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="dateOfBirth" data-testid="label-date-of-birth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={personalInfo.dateOfBirth}
                onChange={(e) => setPersonalInfo(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                data-testid="input-date-of-birth"
              />
            </div>

            <Button 
              type="submit" 
              disabled={updateProfileMutation.isPending}
              data-testid="button-save-personal-info"
            >
              <Save className="h-4 w-4 mr-2" />
              {updateProfileMutation.isPending ? "Saving..." : "Save Personal Information"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Doctor Information - Only show for doctors */}
      {(user.role === 'doctor' || user.doctorProfile) && (
        <Card data-testid="doctor-info-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Stethoscope className="h-5 w-5" />
              <span>Medical Practice Information</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleDoctorInfoSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="specialization" data-testid="label-specialization">Specialization</Label>
                  <Select
                    value={doctorInfo.specialization}
                    onValueChange={(value) => setDoctorInfo(prev => ({ ...prev, specialization: value }))}
                  >
                    <SelectTrigger data-testid="select-specialization">
                      <SelectValue placeholder="Select specialization" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cardiology">Cardiology</SelectItem>
                      <SelectItem value="dermatology">Dermatology</SelectItem>
                      <SelectItem value="endocrinology">Endocrinology</SelectItem>
                      <SelectItem value="gastroenterology">Gastroenterology</SelectItem>
                      <SelectItem value="neurology">Neurology</SelectItem>
                      <SelectItem value="oncology">Oncology</SelectItem>
                      <SelectItem value="orthopedics">Orthopedics</SelectItem>
                      <SelectItem value="pediatrics">Pediatrics</SelectItem>
                      <SelectItem value="psychiatry">Psychiatry</SelectItem>
                      <SelectItem value="general_medicine">General Medicine</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="licenseNumber" data-testid="label-license-number">License Number</Label>
                  <Input
                    id="licenseNumber"
                    value={doctorInfo.licenseNumber}
                    onChange={(e) => setDoctorInfo(prev => ({ ...prev, licenseNumber: e.target.value }))}
                    data-testid="input-license-number"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="experience" data-testid="label-experience">Years of Experience</Label>
                  <Input
                    id="experience"
                    type="number"
                    min="0"
                    value={doctorInfo.experience}
                    onChange={(e) => setDoctorInfo(prev => ({ ...prev, experience: e.target.value }))}
                    data-testid="input-experience"
                  />
                </div>
                
                <div>
                  <Label htmlFor="consultationFee" data-testid="label-consultation-fee">Consultation Fee ($)</Label>
                  <Input
                    id="consultationFee"
                    type="number"
                    min="0"
                    step="0.01"
                    value={doctorInfo.consultationFee}
                    onChange={(e) => setDoctorInfo(prev => ({ ...prev, consultationFee: e.target.value }))}
                    data-testid="input-consultation-fee"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="bio" data-testid="label-bio">Biography</Label>
                <Textarea
                  id="bio"
                  rows={4}
                  value={doctorInfo.bio}
                  onChange={(e) => setDoctorInfo(prev => ({ ...prev, bio: e.target.value }))}
                  placeholder="Tell patients about your background, approach to medicine, and areas of expertise..."
                  data-testid="textarea-bio"
                />
              </div>

              <Button 
                type="submit" 
                disabled={createDoctorProfileMutation.isPending || updateDoctorProfileMutation.isPending}
                data-testid="button-save-doctor-info"
              >
                <Save className="h-4 w-4 mr-2" />
                {(createDoctorProfileMutation.isPending || updateDoctorProfileMutation.isPending) 
                  ? "Saving..." 
                  : user?.doctorProfile ? "Update Medical Information" : "Create Doctor Profile"
                }
              </Button>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
