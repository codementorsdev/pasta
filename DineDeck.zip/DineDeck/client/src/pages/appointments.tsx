import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, User } from "lucide-react";

export default function Appointments() {
  const { user } = useAuth();
  
  const { data: appointments, isLoading } = useQuery({
    queryKey: user?.role === 'doctor' 
      ? ["/api/appointments/doctor", user?.doctorProfile?.id]
      : ["/api/appointments/patient"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} data-testid={`appointment-skeleton-${i}`}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-6 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6" data-testid="appointments-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-appointments-title">
            Appointments
          </h1>
          <p className="text-muted-foreground" data-testid="text-appointments-subtitle">
            {user?.role === 'doctor' ? 'Manage your patient appointments' : 'Your upcoming and past appointments'}
          </p>
        </div>
        
        {user?.role === 'patient' && (
          <Button data-testid="button-book-new-appointment">
            Book Appointment
          </Button>
        )}
      </div>

      {/* Appointments List */}
      <div className="space-y-4">
        {!appointments || appointments.length === 0 ? (
          <Card data-testid="no-appointments-card">
            <CardContent className="p-8 text-center">
              <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No appointments found</h3>
              <p className="text-muted-foreground">
                {user?.role === 'doctor' 
                  ? 'No appointments scheduled yet'
                  : 'You haven\'t booked any appointments yet'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          appointments.map((appointment: any) => (
            <Card key={appointment.id} data-testid={`appointment-card-${appointment.id}`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    {user?.role === 'doctor' ? (
                      // Show patient info for doctors
                      <div className="flex items-center space-x-3">
                        {appointment.patient?.profileImageUrl ? (
                          <img 
                            src={appointment.patient.profileImageUrl}
                            alt={`${appointment.patient.firstName} ${appointment.patient.lastName}`}
                            className="w-12 h-12 rounded-full object-cover"
                            data-testid={`img-patient-${appointment.id}`}
                          />
                        ) : (
                          <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                            <User className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                        <div>
                          <h3 className="font-medium text-foreground" data-testid={`text-patient-name-${appointment.id}`}>
                            {appointment.patient?.firstName} {appointment.patient?.lastName}
                          </h3>
                          <p className="text-sm text-muted-foreground" data-testid={`text-patient-email-${appointment.id}`}>
                            {appointment.patient?.email}
                          </p>
                        </div>
                      </div>
                    ) : (
                      // Show doctor info for patients
                      <div className="flex items-center space-x-3">
                        {appointment.doctor?.user?.profileImageUrl ? (
                          <img 
                            src={appointment.doctor.user.profileImageUrl}
                            alt={`${appointment.doctor.user.firstName} ${appointment.doctor.user.lastName}`}
                            className="w-12 h-12 rounded-full object-cover"
                            data-testid={`img-doctor-${appointment.id}`}
                          />
                        ) : (
                          <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                            <User className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                        <div>
                          <h3 className="font-medium text-foreground" data-testid={`text-doctor-name-${appointment.id}`}>
                            Dr. {appointment.doctor?.user?.firstName} {appointment.doctor?.user?.lastName}
                          </h3>
                          <p className="text-sm text-muted-foreground" data-testid={`text-doctor-specialization-${appointment.id}`}>
                            {appointment.doctor?.specialization}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className="flex items-center text-sm text-muted-foreground mb-1">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span data-testid={`text-appointment-date-${appointment.id}`}>
                          {new Date(appointment.appointmentDate).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="h-4 w-4 mr-1" />
                        <span data-testid={`text-appointment-time-${appointment.id}`}>
                          {new Date(appointment.appointmentDate).toLocaleTimeString('en-US', {
                            hour: 'numeric',
                            minute: '2-digit',
                            hour12: true
                          })}
                        </span>
                      </div>
                    </div>

                    <Badge 
                      variant={
                        appointment.status === 'confirmed' ? 'default' :
                        appointment.status === 'completed' ? 'secondary' :
                        appointment.status === 'cancelled' ? 'destructive' :
                        'outline'
                      }
                      data-testid={`badge-appointment-status-${appointment.id}`}
                    >
                      {appointment.status}
                    </Badge>

                    <Button 
                      variant="outline" 
                      size="sm"
                      data-testid={`button-appointment-actions-${appointment.id}`}
                    >
                      Actions
                    </Button>
                  </div>
                </div>

                {appointment.reason && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground">
                      <span className="font-medium">Reason:</span> {appointment.reason}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
