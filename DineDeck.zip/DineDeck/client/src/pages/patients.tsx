import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, User, Phone, Mail, Calendar, FileText, ChevronRight } from "lucide-react";
import { useState } from "react";
import MedicalHistoryModal from "@/components/modals/medical-history-modal";

export default function Patients() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  
  const { data: appointments, isLoading } = useQuery({
    queryKey: ["/api/appointments/doctor", user?.doctorProfile?.id],
    enabled: !!user?.doctorProfile?.id && user?.role === 'doctor',
  });

  if (user?.role !== 'doctor') {
    return (
      <div className="p-4 md:p-6" data-testid="patients-unauthorized">
        <Card>
          <CardContent className="p-8 text-center">
            <h3 className="text-lg font-medium text-foreground mb-2">Access Denied</h3>
            <p className="text-muted-foreground">This page is only available to doctors.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="p-4 md:p-6 space-y-6">
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} data-testid={`patient-skeleton-${i}`}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-6 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Extract unique patients from appointments
  const patients = appointments?.reduce((acc: any[], appointment: any) => {
    const existingPatient = acc.find(p => p.id === appointment.patient?.id);
    if (!existingPatient && appointment.patient) {
      acc.push({
        ...appointment.patient,
        lastAppointment: appointment.appointmentDate,
        totalAppointments: appointments.filter((apt: any) => apt.patient?.id === appointment.patient.id).length,
        lastDiagnosis: appointment.notes || 'General consultation'
      });
    }
    return acc;
  }, []) || [];

  const filteredPatients = patients.filter((patient: any) =>
    patient.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    patient.lastName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    patient.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <div className="p-4 md:p-6 space-y-6" data-testid="patients-page">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground" data-testid="text-patients-title">
              Patients
            </h1>
            <p className="text-muted-foreground" data-testid="text-patients-subtitle">
              Manage your patient records and medical history
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search patients by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-patients"
          />
        </div>

        {/* Patients List */}
        <div className="space-y-4">
          {filteredPatients.length === 0 ? (
            <Card data-testid="no-patients-card">
              <CardContent className="p-8 text-center">
                <User className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  {searchQuery ? 'No patients found' : 'No patients yet'}
                </h3>
                <p className="text-muted-foreground">
                  {searchQuery 
                    ? 'Try adjusting your search terms'
                    : 'Patients will appear here after their first appointment'
                  }
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredPatients.map((patient: any) => (
              <Card key={patient.id} data-testid={`patient-card-${patient.id}`}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      {patient.profileImageUrl ? (
                        <img 
                          src={patient.profileImageUrl}
                          alt={`${patient.firstName} ${patient.lastName}`}
                          className="w-12 h-12 rounded-full object-cover"
                          data-testid={`img-patient-${patient.id}`}
                        />
                      ) : (
                        <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                          <User className="h-6 w-6 text-muted-foreground" />
                        </div>
                      )}
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-foreground" data-testid={`text-patient-name-${patient.id}`}>
                          {patient.firstName} {patient.lastName}
                        </h3>
                        <div className="flex items-center space-x-4 mt-1">
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Mail className="h-3 w-3 mr-1" />
                            <span data-testid={`text-patient-email-${patient.id}`}>{patient.email}</span>
                          </div>
                          {patient.phone && (
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Phone className="h-3 w-3 mr-1" />
                              <span data-testid={`text-patient-phone-${patient.id}`}>{patient.phone}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="text-right hidden md:block">
                        <div className="flex items-center text-sm text-muted-foreground mb-1">
                          <Calendar className="h-3 w-3 mr-1" />
                          <span data-testid={`text-last-appointment-${patient.id}`}>
                            Last visit: {new Date(patient.lastAppointment).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <FileText className="h-3 w-3 mr-1" />
                          <span data-testid={`text-total-appointments-${patient.id}`}>
                            {patient.totalAppointments} appointment{patient.totalAppointments !== 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>

                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setSelectedPatientId(patient.id)}
                        data-testid={`button-view-history-${patient.id}`}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Medical History
                      </Button>

                      <Button 
                        variant="ghost" 
                        size="sm"
                        data-testid={`button-patient-actions-${patient.id}`}
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Mobile info */}
                  <div className="md:hidden mt-4 pt-4 border-t border-border">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Last visit</p>
                        <p className="font-medium" data-testid={`text-mobile-last-visit-${patient.id}`}>
                          {new Date(patient.lastAppointment).toLocaleDateString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Total visits</p>
                        <p className="font-medium" data-testid={`text-mobile-total-visits-${patient.id}`}>
                          {patient.totalAppointments}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {selectedPatientId && (
        <MedicalHistoryModal
          isOpen={!!selectedPatientId}
          onClose={() => setSelectedPatientId(null)}
          patientId={selectedPatientId}
        />
      )}
    </>
  );
}
