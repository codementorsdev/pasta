import { ReactNode } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import Sidebar from "./sidebar";
import MobileHeader from "./mobile-header";
import MobileBottomNav from "./mobile-bottom-nav";
import PWAInstallPrompt from "@/components/pwa/install-prompt";

interface AppShellProps {
  children: ReactNode;
}

export default function AppShell({ children }: AppShellProps) {
  const isMobile = useIsMobile();

  return (
    <div className="flex h-full">
      {/* Desktop Sidebar */}
      {!isMobile && <Sidebar />}
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Mobile Header */}
        {isMobile && <MobileHeader />}
        
        {/* Desktop Header */}
        {!isMobile && (
          <header className="bg-card border-b border-border px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground" data-testid="text-page-title">Dashboard</h2>
                <p className="text-sm text-muted-foreground" data-testid="text-page-subtitle">Welcome back</p>
              </div>
              <div className="flex items-center space-x-4">
                <button 
                  className="relative p-2 text-muted-foreground hover:text-foreground transition-colors"
                  data-testid="button-notifications"
                >
                  <i className="fas fa-bell"></i>
                  <span className="absolute top-0 right-0 w-2 h-2 bg-destructive rounded-full"></span>
                </button>
                <button 
                  className="p-2 text-muted-foreground hover:text-foreground transition-colors"
                  data-testid="button-theme-toggle"
                >
                  <i className="fas fa-moon"></i>
                </button>
              </div>
            </div>
          </header>
        )}
        
        {/* Content Area */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
      
      {/* Mobile Bottom Navigation */}
      {isMobile && <MobileBottomNav />}
      
      {/* PWA Install Prompt */}
      <PWAInstallPrompt />
    </div>
  );
}
