import { useAuth } from "@/hooks/useAuth";
import { Menu, Bell } from "lucide-react";

export default function MobileHeader() {
  const { user } = useAuth();

  return (
    <header className="bg-card border-b border-border px-4 py-3" data-testid="mobile-header">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button 
            className="p-2 -ml-2 text-muted-foreground hover:text-foreground"
            data-testid="button-menu-toggle"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
              <i className="fas fa-stethoscope text-primary-foreground text-xs"></i>
            </div>
            <h1 className="text-lg font-bold text-foreground" data-testid="text-mobile-app-title">MediBook</h1>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button 
            className="relative p-2 text-muted-foreground hover:text-foreground"
            data-testid="button-mobile-notifications"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
          </button>
          
          {user?.profileImageUrl ? (
            <img 
              src={user.profileImageUrl} 
              alt={`${user.firstName} ${user.lastName}`}
              className="w-8 h-8 rounded-full object-cover"
              data-testid="img-mobile-user-avatar"
            />
          ) : (
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-primary-foreground font-medium text-xs">
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
