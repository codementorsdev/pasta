import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  User,
  Shield
} from "lucide-react";

const navigationItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard", roles: ["doctor", "patient", "admin"] },
  { href: "/appointments", icon: Calendar, label: "Appointments", roles: ["doctor", "patient"] },
  { href: "/patients", icon: Users, label: "Patients", roles: ["doctor"] },
  { href: "/admin", icon: Shield, label: "Admin", roles: ["admin"] },
  { href: "/profile", icon: User, label: "Profile", roles: ["doctor", "patient", "admin"] },
];

export default function MobileBottomNav() {
  const { user } = useAuth();
  const [location, navigate] = useLocation();

  if (!user) return null;

  const filteredItems = navigationItems.filter(item => 
    item.roles.includes(user.role)
  ).slice(0, 4); // Limit to 4 items for mobile

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border" data-testid="mobile-bottom-nav">
      <div className="flex items-center justify-around py-2">
        {filteredItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          
          return (
            <button
              key={item.href}
              onClick={() => navigate(item.href)}
              className={cn(
                "flex flex-col items-center p-2 transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
              )}
              data-testid={`mobile-nav-${item.label.toLowerCase()}`}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
