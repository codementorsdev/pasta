import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  FileText, 
  CreditCard, 
  User, 
  LogOut,
  Shield
} from "lucide-react";

const navigationItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard", roles: ["doctor", "patient", "admin"] },
  { href: "/appointments", icon: Calendar, label: "Appointments", roles: ["doctor", "patient"] },
  { href: "/patients", icon: Users, label: "Patients", roles: ["doctor"] },
  { href: "/prescriptions", icon: FileText, label: "Prescriptions", roles: ["doctor", "patient"] },
  { href: "/billing", icon: CreditCard, label: "Billing", roles: ["doctor", "patient"] },
  { href: "/admin", icon: Shield, label: "Admin", roles: ["admin"] },
  { href: "/profile", icon: User, label: "Profile", roles: ["doctor", "patient", "admin"] },
];

export default function Sidebar() {
  const { user } = useAuth();
  const [location, navigate] = useLocation();

  if (!user) return null;

  const filteredItems = navigationItems.filter(item => 
    item.roles.includes(user.role)
  );

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar-navigation">
      {/* Logo */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-stethoscope text-primary-foreground text-sm"></i>
          </div>
          <h1 className="text-xl font-bold text-foreground" data-testid="text-app-title">MediBook</h1>
        </div>
      </div>
      
      {/* User Profile */}
      <nav className="flex-1 p-4 space-y-2">
        <div className="mb-6">
          <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
            {user.profileImageUrl ? (
              <img 
                src={user.profileImageUrl} 
                alt={`${user.firstName} ${user.lastName}`}
                className="w-10 h-10 rounded-full object-cover"
                data-testid="img-user-avatar"
              />
            ) : (
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-medium text-sm">
                  {user.firstName?.[0]}{user.lastName?.[0]}
                </span>
              </div>
            )}
            <div>
              <p className="text-sm font-medium text-foreground" data-testid="text-user-name">
                {user.firstName} {user.lastName}
              </p>
              <p className="text-xs text-muted-foreground capitalize" data-testid="text-user-role">
                {user.role}
              </p>
            </div>
          </div>
        </div>
        
        {/* Navigation Items */}
        {filteredItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          
          return (
            <button
              key={item.href}
              onClick={() => navigate(item.href)}
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors w-full text-left",
                isActive 
                  ? "text-foreground bg-primary/10" 
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
              data-testid={`nav-${item.label.toLowerCase()}`}
            >
              <Icon className={cn("w-4 h-4", isActive && "text-primary")} />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>
      
      {/* Logout */}
      <div className="p-4 border-t border-border">
        <button 
          onClick={handleLogout}
          className="flex items-center space-x-3 px-3 py-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors w-full"
          data-testid="button-logout"
        >
          <LogOut className="w-4 h-4" />
          <span className="text-sm font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
}
