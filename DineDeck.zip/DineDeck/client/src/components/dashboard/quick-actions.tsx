import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Calendar, CreditCard, UserPlus, Users, Shield } from "lucide-react";
import { useState } from "react";
import PrescriptionModal from "@/components/modals/prescription-modal";

interface QuickActionsProps {
  userRole: string;
}

export default function QuickActions({ userRole }: QuickActionsProps) {
  const [showPrescriptionModal, setShowPrescriptionModal] = useState(false);

  const doctorActions = [
    {
      icon: FileText,
      title: "Create Prescription",
      description: "Issue new medication",
      onClick: () => setShowPrescriptionModal(true),
      testId: "button-create-prescription"
    },
    {
      icon: Calendar,
      title: "Update Schedule",
      description: "Manage availability",
      onClick: () => {},
      testId: "button-update-schedule"
    },
    {
      icon: CreditCard,
      title: "View Billing",
      description: "Check payments",
      onClick: () => {},
      testId: "button-view-billing"
    }
  ];

  const patientActions = [
    {
      icon: Calendar,
      title: "Book Appointment",
      description: "Schedule with doctor",
      onClick: () => {},
      testId: "button-book-appointment"
    },
    {
      icon: FileText,
      title: "View Prescriptions",
      description: "See your medications",
      onClick: () => {},
      testId: "button-view-prescriptions"
    },
    {
      icon: CreditCard,
      title: "Pay Bills",
      description: "Manage payments",
      onClick: () => {},
      testId: "button-pay-bills"
    }
  ];

  const adminActions = [
    {
      icon: Users,
      title: "Manage Users",
      description: "User administration",
      onClick: () => {},
      testId: "button-manage-users"
    },
    {
      icon: Shield,
      title: "Approve Doctors",
      description: "Review applications",
      onClick: () => {},
      testId: "button-approve-doctors"
    },
    {
      icon: CreditCard,
      title: "System Analytics",
      description: "View metrics",
      onClick: () => {},
      testId: "button-system-analytics"
    }
  ];

  const actions = userRole === 'doctor' ? doctorActions : 
                 userRole === 'admin' ? adminActions : 
                 patientActions;

  return (
    <>
      <Card data-testid="quick-actions-card">
        <CardHeader>
          <CardTitle data-testid="text-quick-actions-title">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {actions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full justify-start h-auto p-4"
                  onClick={action.onClick}
                  data-testid={action.testId}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-medium text-foreground">{action.title}</p>
                      <p className="text-xs text-muted-foreground">{action.description}</p>
                    </div>
                  </div>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {showPrescriptionModal && (
        <PrescriptionModal 
          isOpen={showPrescriptionModal}
          onClose={() => setShowPrescriptionModal(false)}
        />
      )}
    </>
  );
}
