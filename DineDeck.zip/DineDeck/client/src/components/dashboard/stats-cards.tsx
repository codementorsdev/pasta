import { Card, CardContent } from "@/components/ui/card";
import { Calendar, Users, DollarSign, FileText, Shield, UserCheck } from "lucide-react";

interface StatsCardsProps {
  stats?: any;
  isLoading: boolean;
  userRole: string;
}

export default function StatsCards({ stats, isLoading, userRole }: StatsCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} data-testid={`stats-card-skeleton-${i}`}>
            <CardContent className="p-4 md:p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-muted rounded mb-2"></div>
                <div className="h-8 bg-muted rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card data-testid="stats-card-error">
          <CardContent className="p-4 md:p-6 text-center">
            <p className="text-sm text-muted-foreground">No stats available</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Doctor stats
  if (userRole === 'doctor') {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card data-testid="stats-card-today-appointments">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Today's Appointments</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-today-appointments">
                  {stats.todayAppointments}
                </p>
              </div>
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                <Calendar className="h-4 w-4 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="stats-card-total-patients">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Patients</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-total-patients">
                  {stats.totalPatients}
                </p>
              </div>
              <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center">
                <Users className="h-4 w-4 text-secondary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="stats-card-monthly-revenue">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">This Month Revenue</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-monthly-revenue">
                  ${stats.monthlyRevenue?.toLocaleString() || '0'}
                </p>
              </div>
              <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="stats-card-pending-prescriptions">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Prescriptions</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-pending-prescriptions">
                  {stats.pendingPrescriptions}
                </p>
              </div>
              <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
                <FileText className="h-4 w-4 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Admin stats
  if (userRole === 'admin') {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card data-testid="stats-card-total-users">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-total-users">
                  {stats.totalUsers}
                </p>
              </div>
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                <Users className="h-4 w-4 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="stats-card-active-doctors">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Doctors</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-active-doctors">
                  {stats.activeDoctors}
                </p>
              </div>
              <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center">
                <UserCheck className="h-4 w-4 text-secondary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="stats-card-admin-revenue">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Monthly Revenue</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-admin-revenue">
                  ${stats.monthlyRevenue?.toLocaleString() || '0'}
                </p>
              </div>
              <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card data-testid="stats-card-pending-approvals">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Approvals</p>
                <p className="text-2xl font-bold text-foreground" data-testid="text-pending-approvals">
                  {stats.pendingApprovals}
                </p>
              </div>
              <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
                <Shield className="h-4 w-4 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Patient stats - basic placeholder
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <Card data-testid="stats-card-upcoming-appointments">
        <CardContent className="p-4 md:p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Upcoming Appointments</p>
              <p className="text-2xl font-bold text-foreground">3</p>
            </div>
            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
              <Calendar className="h-4 w-4 text-primary" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
