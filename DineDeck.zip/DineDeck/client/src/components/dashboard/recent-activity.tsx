import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";

export default function RecentActivity() {
  const { user } = useAuth();
  
  // Mock activity data for now - in real app this would come from API
  const activities = [
    {
      id: 1,
      type: 'prescription',
      message: 'Prescription issued for Emily Rodriguez',
      timestamp: '2 hours ago',
      color: 'bg-accent'
    },
    {
      id: 2,
      type: 'appointment',
      message: 'Appointment confirmed with Michael Chen',
      timestamp: '4 hours ago',
      color: 'bg-primary'
    },
    {
      id: 3,
      type: 'payment',
      message: 'Payment received from Sarah Williams',
      timestamp: '6 hours ago',
      color: 'bg-secondary'
    },
    {
      id: 4,
      type: 'record',
      message: 'Medical records updated for David Thompson',
      timestamp: '1 day ago',
      color: 'bg-orange-500'
    }
  ];

  return (
    <Card data-testid="recent-activity-card">
      <CardHeader>
        <CardTitle data-testid="text-recent-activity-title">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div 
              key={activity.id} 
              className="flex items-start space-x-3"
              data-testid={`activity-item-${activity.id}`}
            >
              <div className={`w-2 h-2 ${activity.color} rounded-full mt-2 flex-shrink-0`}></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground" data-testid={`text-activity-message-${activity.id}`}>
                  {activity.message}
                </p>
                <p className="text-xs text-muted-foreground" data-testid={`text-activity-timestamp-${activity.id}`}>
                  {activity.timestamp}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
