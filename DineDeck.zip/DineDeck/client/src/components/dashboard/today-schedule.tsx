import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";

export default function TodaySchedule() {
  const { user } = useAuth();
  
  const { data: appointments, isLoading } = useQuery({
    queryKey: ["/api/appointments/doctor", user?.doctorProfile?.id],
    enabled: !!user?.doctorProfile?.id,
  });

  if (isLoading) {
    return (
      <Card data-testid="today-schedule-loading">
        <CardHeader>
          <CardTitle>Today's Schedule</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-muted rounded-full"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-muted rounded mb-2"></div>
                    <div className="h-3 bg-muted rounded w-1/2"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const todayAppointments = appointments?.filter((apt: any) => {
    const today = new Date();
    const aptDate = new Date(apt.appointmentDate);
    return aptDate.toDateString() === today.toDateString();
  }) || [];

  return (
    <Card data-testid="today-schedule-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle data-testid="text-schedule-title">Today's Schedule</CardTitle>
          <Button 
            variant="ghost" 
            size="sm"
            data-testid="button-view-all-appointments"
          >
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {todayAppointments.length === 0 ? (
          <p className="text-center text-muted-foreground py-8" data-testid="text-no-appointments">
            No appointments scheduled for today
          </p>
        ) : (
          <div className="divide-y divide-border">
            {todayAppointments.map((appointment: any) => (
              <div 
                key={appointment.id} 
                className="py-4 hover:bg-muted/50 transition-colors rounded-lg px-2"
                data-testid={`appointment-item-${appointment.id}`}
              >
                <div className="flex items-center space-x-4">
                  {appointment.patient?.profileImageUrl ? (
                    <img 
                      src={appointment.patient.profileImageUrl} 
                      alt={`${appointment.patient.firstName} ${appointment.patient.lastName}`}
                      className="w-12 h-12 rounded-full object-cover"
                      data-testid={`img-patient-${appointment.id}`}
                    />
                  ) : (
                    <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium">
                        {appointment.patient?.firstName?.[0]}{appointment.patient?.lastName?.[0]}
                      </span>
                    </div>
                  )}
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-foreground truncate" data-testid={`text-patient-name-${appointment.id}`}>
                        {appointment.patient?.firstName} {appointment.patient?.lastName}
                      </p>
                      <span className="text-sm text-muted-foreground" data-testid={`text-appointment-time-${appointment.id}`}>
                        {new Date(appointment.appointmentDate).toLocaleTimeString('en-US', { 
                          hour: 'numeric', 
                          minute: '2-digit',
                          hour12: true 
                        })}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground" data-testid={`text-appointment-reason-${appointment.id}`}>
                      {appointment.reason || 'General Consultation'}
                    </p>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant={appointment.status === 'confirmed' ? 'default' : 'secondary'}
                      data-testid={`badge-status-${appointment.id}`}
                    >
                      {appointment.status}
                    </Badge>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      data-testid={`button-appointment-details-${appointment.id}`}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
