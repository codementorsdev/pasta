import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CreditCard, Loader2 } from 'lucide-react';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface CheckoutFormProps {
  onSuccess: () => void;
}

const CheckoutForm = ({ onSuccess }: CheckoutFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsLoading(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/billing`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your payment!",
      });
      onSuccess();
    }

    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6" data-testid="stripe-payment-form">
      <PaymentElement data-testid="stripe-payment-element" />
      
      <Button 
        type="submit" 
        className="w-full" 
        disabled={!stripe || isLoading}
        data-testid="button-submit-payment"
      >
        {isLoading ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <CreditCard className="h-4 w-4 mr-2" />
            Pay Now
          </>
        )}
      </Button>
    </form>
  );
};

interface CheckoutProps {
  amount: number;
  appointmentId?: string;
  onSuccess?: () => void;
  onClose?: () => void;
}

export default function Checkout({ amount, appointmentId, onSuccess, onClose }: CheckoutProps) {
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Create PaymentIntent as soon as the component loads
    const createPaymentIntent = async () => {
      try {
        const response = await apiRequest("POST", "/api/create-payment-intent", { 
          amount,
          appointmentId 
        });
        const data = await response.json();
        setClientSecret(data.clientSecret);
      } catch (error: any) {
        toast({
          title: "Error",
          description: "Failed to initialize payment. Please try again.",
          variant: "destructive",
        });
        console.error("Error creating payment intent:", error);
      } finally {
        setIsLoading(false);
      }
    };

    createPaymentIntent();
  }, [amount, appointmentId, toast]);

  const handleSuccess = () => {
    onSuccess?.();
  };

  if (isLoading) {
    return (
      <Card className="w-full max-w-md mx-auto" data-testid="checkout-loading">
        <CardContent className="p-8">
          <div className="flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2 text-muted-foreground">Initializing payment...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!clientSecret) {
    return (
      <Card className="w-full max-w-md mx-auto" data-testid="checkout-error">
        <CardContent className="p-8 text-center">
          <div className="text-destructive mb-4">
            <CreditCard className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>Unable to initialize payment</p>
          </div>
          <Button onClick={onClose} variant="outline" data-testid="button-close-checkout">
            Close
          </Button>
        </CardContent>
      </Card>
    );
  }

  const options = {
    clientSecret,
    appearance: {
      theme: 'stripe' as const,
      variables: {
        colorPrimary: 'hsl(217.2 91% 59.8%)',
        colorBackground: 'hsl(0 0% 100%)',
        colorText: 'hsl(222.2 84% 4.9%)',
        colorDanger: 'hsl(0 84.2% 60.2%)',
        borderRadius: '8px',
      },
    },
  };

  return (
    <Card className="w-full max-w-md mx-auto" data-testid="checkout-card">
      <CardHeader>
        <CardTitle className="flex items-center justify-center space-x-2">
          <CreditCard className="h-5 w-5" />
          <span>Secure Payment</span>
        </CardTitle>
        <div className="text-center">
          <p className="text-2xl font-bold text-foreground" data-testid="text-payment-amount">
            ${amount.toFixed(2)}
          </p>
          <p className="text-sm text-muted-foreground">
            {appointmentId ? 'Consultation Fee' : 'Payment'}
          </p>
        </div>
      </CardHeader>
      
      <CardContent>
        <Elements stripe={stripePromise} options={options}>
          <CheckoutForm onSuccess={handleSuccess} />
        </Elements>
        
        {onClose && (
          <div className="mt-4 text-center">
            <Button 
              variant="ghost" 
              onClick={onClose}
              data-testid="button-cancel-payment"
            >
              Cancel
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
