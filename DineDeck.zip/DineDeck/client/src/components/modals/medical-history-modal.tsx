import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { FileText, Calendar, User, Upload, Eye } from "lucide-react";

interface MedicalHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: string;
}

export default function MedicalHistoryModal({ isOpen, onClose, patientId }: MedicalHistoryModalProps) {
  const { data: medicalRecords, isLoading: recordsLoading } = useQuery({
    queryKey: ["/api/medical-records/patient", patientId],
    enabled: isOpen && !!patientId,
  });

  const { data: prescriptions, isLoading: prescriptionsLoading } = useQuery({
    queryKey: ["/api/prescriptions/patient", patientId],
    enabled: isOpen && !!patientId,
  });

  const { data: appointments, isLoading: appointmentsLoading } = useQuery({
    queryKey: ["/api/appointments/patient", patientId],
    enabled: isOpen && !!patientId,
  });

  // Combine all medical history items and sort by date
  const allHistoryItems = [
    ...(appointments?.map((apt: any) => ({
      ...apt,
      type: 'appointment',
      date: apt.appointmentDate,
      title: `Appointment - ${apt.reason || 'General Consultation'}`,
      description: apt.notes
    })) || []),
    ...(prescriptions?.map((presc: any) => ({
      ...presc,
      type: 'prescription',
      date: presc.issuedAt,
      title: `Prescription - ${presc.diagnosis}`,
      description: presc.notes
    })) || []),
    ...(medicalRecords?.map((record: any) => ({
      ...record,
      type: 'record',
      date: record.recordDate,
      title: record.title,
      description: record.description
    })) || [])
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="medical-history-modal">
        <DialogHeader>
          <DialogTitle data-testid="text-medical-history-title">Medical History</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Upload Documents Section */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-foreground">Documents</h3>
              <Button variant="outline" size="sm" data-testid="button-upload-document">
                <Upload className="h-4 w-4 mr-2" />
                Upload Document
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {/* Document previews - would be populated from medical records */}
              {medicalRecords?.filter((record: any) => record.fileUrl).map((doc: any) => (
                <div 
                  key={doc.id} 
                  className="p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                  data-testid={`document-${doc.id}`}
                >
                  <div className="w-full h-24 bg-muted rounded flex items-center justify-center mb-2">
                    <FileText className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <p className="text-xs font-medium text-foreground truncate" data-testid={`text-document-name-${doc.id}`}>
                    {doc.title}
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid={`text-document-date-${doc.id}`}>
                    {new Date(doc.recordDate).toLocaleDateString()}
                  </p>
                </div>
              )) || []}
              
              {/* Placeholder if no documents */}
              {(!medicalRecords || medicalRecords.filter((r: any) => r.fileUrl).length === 0) && (
                <div className="col-span-full text-center py-8">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No documents uploaded yet</p>
                </div>
              )}
            </div>
          </div>
          
          {/* Medical Timeline */}
          <div>
            <h3 className="text-lg font-medium text-foreground mb-4">Medical Timeline</h3>
            
            {recordsLoading || prescriptionsLoading || appointmentsLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-start space-x-4">
                      <div className="w-8 h-8 bg-muted rounded-full"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-muted rounded mb-2"></div>
                        <div className="h-16 bg-muted rounded"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : allHistoryItems.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No medical history available</p>
              </div>
            ) : (
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border"></div>
                
                <div className="space-y-6">
                  {allHistoryItems.map((entry: any) => (
                    <div 
                      key={`${entry.type}-${entry.id}`} 
                      className="relative flex items-start space-x-4"
                      data-testid={`history-entry-${entry.type}-${entry.id}`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        entry.type === 'appointment' ? 'bg-primary' :
                        entry.type === 'prescription' ? 'bg-secondary' :
                        'bg-accent'
                      }`}>
                        {entry.type === 'appointment' && <Calendar className="h-4 w-4 text-primary-foreground" />}
                        {entry.type === 'prescription' && <FileText className="h-4 w-4 text-primary-foreground" />}
                        {entry.type === 'record' && <User className="h-4 w-4 text-primary-foreground" />}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="bg-card border border-border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="text-sm font-medium text-foreground" data-testid={`text-entry-title-${entry.id}`}>
                              {entry.title}
                            </h4>
                            <span className="text-xs text-muted-foreground" data-testid={`text-entry-date-${entry.id}`}>
                              {new Date(entry.date).toLocaleDateString()}
                            </span>
                          </div>
                          
                          {entry.doctor && (
                            <p className="text-sm text-muted-foreground mb-2" data-testid={`text-entry-doctor-${entry.id}`}>
                              Dr. {entry.doctor.user?.firstName} {entry.doctor.user?.lastName} - {entry.doctor.specialization}
                            </p>
                          )}
                          
                          {entry.description && (
                            <p className="text-sm text-foreground" data-testid={`text-entry-description-${entry.id}`}>
                              {entry.description}
                            </p>
                          )}
                          
                          {/* Prescription medications */}
                          {entry.type === 'prescription' && entry.medications && (
                            <div className="mt-3 p-3 bg-muted rounded-lg">
                              <h5 className="text-xs font-medium text-foreground mb-2">Prescribed Medications:</h5>
                              <div className="space-y-1">
                                {entry.medications.map((med: any, index: number) => (
                                  <p key={index} className="text-xs text-muted-foreground" data-testid={`text-medication-${entry.id}-${index}`}>
                                    • {med.name} {med.dosage} - {med.duration}
                                  </p>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {/* File attachment */}
                          {entry.type === 'record' && entry.fileUrl && (
                            <div className="mt-3">
                              <Button variant="outline" size="sm" data-testid={`button-view-file-${entry.id}`}>
                                <Eye className="h-3 w-3 mr-1" />
                                View File
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
