import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, User, Save, X } from "lucide-react";
import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment?: any;
  mode: 'create' | 'edit' | 'view';
}

export default function AppointmentModal({ isOpen, onClose, appointment, mode }: AppointmentModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    doctorId: '',
    patientId: '',
    appointmentDate: '',
    appointmentTime: '',
    reason: '',
    notes: '',
    status: 'pending' as const,
    consultationFee: '',
  });

  useEffect(() => {
    if (appointment && mode !== 'create') {
      const appointmentDateTime = new Date(appointment.appointmentDate);
      setFormData({
        doctorId: appointment.doctorId || '',
        patientId: appointment.patientId || '',
        appointmentDate: format(appointmentDateTime, 'yyyy-MM-dd'),
        appointmentTime: format(appointmentDateTime, 'HH:mm'),
        reason: appointment.reason || '',
        notes: appointment.notes || '',
        status: appointment.status || 'pending',
        consultationFee: appointment.consultationFee || '',
      });
    }
  }, [appointment, mode]);

  const updateAppointmentMutation = useMutation({
    mutationFn: async (data: any) => {
      const appointmentDateTime = new Date(`${data.appointmentDate}T${data.appointmentTime}:00`);
      const updateData = {
        ...data,
        appointmentDate: appointmentDateTime.toISOString(),
      };
      delete updateData.appointmentTime;
      
      return await apiRequest("PUT", `/api/appointments/${appointment.id}`, updateData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Appointment updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (mode === 'edit') {
      updateAppointmentMutation.mutate(formData);
    }
  };

  const handleStatusChange = (newStatus: string) => {
    setFormData(prev => ({ ...prev, status: newStatus as any }));
    
    // Auto-save status changes
    if (mode === 'edit') {
      updateAppointmentMutation.mutate({ ...formData, status: newStatus });
    }
  };

  const isReadonly = mode === 'view';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="appointment-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between" data-testid="text-appointment-modal-title">
            <span>
              {mode === 'create' && 'Create Appointment'}
              {mode === 'edit' && 'Edit Appointment'}
              {mode === 'view' && 'Appointment Details'}
            </span>
            {mode === 'view' && (
              <Badge 
                variant={
                  appointment?.status === 'confirmed' ? 'default' :
                  appointment?.status === 'completed' ? 'secondary' :
                  appointment?.status === 'cancelled' ? 'destructive' :
                  'outline'
                }
                data-testid="badge-appointment-status"
              >
                {appointment?.status}
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-appointment">
          {/* Patient/Doctor Info Display */}
          {appointment && (
            <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
              {user?.role === 'doctor' ? (
                // Show patient info for doctors
                <>
                  {appointment.patient?.profileImageUrl ? (
                    <img 
                      src={appointment.patient.profileImageUrl}
                      alt={`${appointment.patient.firstName} ${appointment.patient.lastName}`}
                      className="w-12 h-12 rounded-full object-cover"
                      data-testid="img-appointment-patient"
                    />
                  ) : (
                    <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center">
                      <User className="h-6 w-6 text-muted-foreground" />
                    </div>
                  )}
                  <div>
                    <h3 className="font-medium text-foreground" data-testid="text-appointment-patient-name">
                      {appointment.patient?.firstName} {appointment.patient?.lastName}
                    </h3>
                    <p className="text-sm text-muted-foreground" data-testid="text-appointment-patient-email">
                      {appointment.patient?.email}
                    </p>
                  </div>
                </>
              ) : (
                // Show doctor info for patients
                <>
                  {appointment.doctor?.user?.profileImageUrl ? (
                    <img 
                      src={appointment.doctor.user.profileImageUrl}
                      alt={`${appointment.doctor.user.firstName} ${appointment.doctor.user.lastName}`}
                      className="w-12 h-12 rounded-full object-cover"
                      data-testid="img-appointment-doctor"
                    />
                  ) : (
                    <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center">
                      <User className="h-6 w-6 text-muted-foreground" />
                    </div>
                  )}
                  <div>
                    <h3 className="font-medium text-foreground" data-testid="text-appointment-doctor-name">
                      Dr. {appointment.doctor?.user?.firstName} {appointment.doctor?.user?.lastName}
                    </h3>
                    <p className="text-sm text-muted-foreground" data-testid="text-appointment-doctor-specialization">
                      {appointment.doctor?.specialization}
                    </p>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Date and Time */}
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="appointmentDate" data-testid="label-appointment-date">Date</Label>
              <Input
                id="appointmentDate"
                type="date"
                value={formData.appointmentDate}
                onChange={(e) => setFormData(prev => ({ ...prev, appointmentDate: e.target.value }))}
                disabled={isReadonly}
                data-testid="input-appointment-date"
              />
            </div>
            
            <div>
              <Label htmlFor="appointmentTime" data-testid="label-appointment-time">Time</Label>
              <Input
                id="appointmentTime"
                type="time"
                value={formData.appointmentTime}
                onChange={(e) => setFormData(prev => ({ ...prev, appointmentTime: e.target.value }))}
                disabled={isReadonly}
                data-testid="input-appointment-time"
              />
            </div>
          </div>

          {/* Status - Only for doctors */}
          {user?.role === 'doctor' && mode !== 'create' && (
            <div>
              <Label htmlFor="status" data-testid="label-appointment-status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={handleStatusChange}
                disabled={isReadonly}
              >
                <SelectTrigger data-testid="select-appointment-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Reason */}
          <div>
            <Label htmlFor="reason" data-testid="label-appointment-reason">Reason for Visit</Label>
            <Textarea
              id="reason"
              value={formData.reason}
              onChange={(e) => setFormData(prev => ({ ...prev, reason: e.target.value }))}
              placeholder="Describe the reason for this appointment..."
              rows={3}
              disabled={isReadonly}
              data-testid="textarea-appointment-reason"
            />
          </div>

          {/* Notes - Only for doctors */}
          {user?.role === 'doctor' && (
            <div>
              <Label htmlFor="notes" data-testid="label-appointment-notes">Doctor's Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Add notes about the appointment..."
                rows={3}
                disabled={isReadonly}
                data-testid="textarea-appointment-notes"
              />
            </div>
          )}

          {/* Consultation Fee */}
          {formData.consultationFee && (
            <div>
              <Label data-testid="label-consultation-fee">Consultation Fee</Label>
              <div className="flex items-center space-x-2 text-lg font-medium text-foreground">
                <span data-testid="text-consultation-fee">${formData.consultationFee}</span>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              data-testid="button-appointment-cancel"
            >
              <X className="h-4 w-4 mr-2" />
              {mode === 'view' ? 'Close' : 'Cancel'}
            </Button>
            
            {mode === 'edit' && (
              <Button 
                type="submit"
                disabled={updateAppointmentMutation.isPending}
                data-testid="button-appointment-save"
              >
                <Save className="h-4 w-4 mr-2" />
                {updateAppointmentMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            )}
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
