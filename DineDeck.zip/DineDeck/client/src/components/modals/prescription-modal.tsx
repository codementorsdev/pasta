import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PrescriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointmentId?: string;
}

interface Medication {
  name: string;
  dosage: string;
  duration: string;
}

export default function PrescriptionModal({ isOpen, onClose, appointmentId }: PrescriptionModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [patientId, setPatientId] = useState("");
  const [diagnosis, setDiagnosis] = useState("");
  const [notes, setNotes] = useState("");
  const [medications, setMedications] = useState<Medication[]>([
    { name: "", dosage: "", duration: "" }
  ]);

  const { data: patients } = useQuery({
    queryKey: ["/api/patients"],
    enabled: isOpen && user?.role === 'doctor',
  });

  const createPrescriptionMutation = useMutation({
    mutationFn: async (prescriptionData: any) => {
      return await apiRequest("POST", "/api/prescriptions", prescriptionData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Prescription created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prescriptions"] });
      handleClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setPatientId("");
    setDiagnosis("");
    setNotes("");
    setMedications([{ name: "", dosage: "", duration: "" }]);
    onClose();
  };

  const addMedication = () => {
    setMedications([...medications, { name: "", dosage: "", duration: "" }]);
  };

  const removeMedication = (index: number) => {
    if (medications.length > 1) {
      setMedications(medications.filter((_, i) => i !== index));
    }
  };

  const updateMedication = (index: number, field: keyof Medication, value: string) => {
    const updated = medications.map((med, i) => 
      i === index ? { ...med, [field]: value } : med
    );
    setMedications(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!patientId || !diagnosis || medications.some(med => !med.name)) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    createPrescriptionMutation.mutate({
      patientId,
      diagnosis,
      medications: medications.filter(med => med.name.trim()),
      notes,
      appointmentId,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="prescription-modal">
        <DialogHeader>
          <DialogTitle data-testid="text-prescription-modal-title">Create Prescription</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-prescription">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="patient" data-testid="label-patient">Patient</Label>
              <Select value={patientId} onValueChange={setPatientId}>
                <SelectTrigger data-testid="select-patient">
                  <SelectValue placeholder="Select Patient" />
                </SelectTrigger>
                <SelectContent>
                  {patients?.map((patient: any) => (
                    <SelectItem key={patient.id} value={patient.id} data-testid={`option-patient-${patient.id}`}>
                      {patient.firstName} {patient.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="date" data-testid="label-date">Date</Label>
              <Input 
                type="date" 
                defaultValue={new Date().toISOString().split('T')[0]}
                data-testid="input-date"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="diagnosis" data-testid="label-diagnosis">Diagnosis</Label>
            <Textarea 
              value={diagnosis}
              onChange={(e) => setDiagnosis(e.target.value)}
              placeholder="Enter diagnosis..."
              rows={3}
              data-testid="textarea-diagnosis"
            />
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label data-testid="label-medications">Medications</Label>
              <Button 
                type="button" 
                variant="outline" 
                size="sm"
                onClick={addMedication}
                data-testid="button-add-medication"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Medication
              </Button>
            </div>
            
            <div className="space-y-3">
              {medications.map((medication, index) => (
                <div 
                  key={index} 
                  className="grid md:grid-cols-4 gap-3 p-3 bg-muted rounded-lg"
                  data-testid={`medication-row-${index}`}
                >
                  <div>
                    <Input 
                      placeholder="Medication name"
                      value={medication.name}
                      onChange={(e) => updateMedication(index, 'name', e.target.value)}
                      data-testid={`input-medication-name-${index}`}
                    />
                  </div>
                  <div>
                    <Input 
                      placeholder="Dosage"
                      value={medication.dosage}
                      onChange={(e) => updateMedication(index, 'dosage', e.target.value)}
                      data-testid={`input-medication-dosage-${index}`}
                    />
                  </div>
                  <div>
                    <Input 
                      placeholder="Duration"
                      value={medication.duration}
                      onChange={(e) => updateMedication(index, 'duration', e.target.value)}
                      data-testid={`input-medication-duration-${index}`}
                    />
                  </div>
                  <div className="flex items-center">
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm"
                      onClick={() => removeMedication(index)}
                      disabled={medications.length === 1}
                      data-testid={`button-remove-medication-${index}`}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <Label htmlFor="notes" data-testid="label-notes">Additional Notes</Label>
            <Textarea 
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional instructions..."
              rows={3}
              data-testid="textarea-notes"
            />
          </div>
          
          <div className="flex justify-end space-x-3">
            <Button 
              type="button" 
              variant="outline" 
              onClick={handleClose}
              data-testid="button-cancel-prescription"
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={createPrescriptionMutation.isPending}
              data-testid="button-create-prescription-submit"
            >
              {createPrescriptionMutation.isPending ? "Creating..." : "Create Prescription"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
