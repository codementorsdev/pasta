export const SPECIALIZATIONS = [
  { value: 'cardiology', label: 'Cardiology' },
  { value: 'dermatology', label: 'Dermatology' },
  { value: 'endocrinology', label: 'Endocrinology' },
  { value: 'gastroenterology', label: 'Gastroenterology' },
  { value: 'neurology', label: 'Neurology' },
  { value: 'oncology', label: 'Oncology' },
  { value: 'orthopedics', label: 'Orthopedics' },
  { value: 'pediatrics', label: 'Pediatrics' },
  { value: 'psychiatry', label: 'Psychiatry' },
  { value: 'general_medicine', label: 'General Medicine' },
] as const;

export const APPOINTMENT_STATUSES = [
  { value: 'pending', label: 'Pending', variant: 'outline' },
  { value: 'confirmed', label: 'Confirmed', variant: 'default' },
  { value: 'completed', label: 'Completed', variant: 'secondary' },
  { value: 'cancelled', label: 'Cancelled', variant: 'destructive' },
] as const;

export const PAYMENT_STATUSES = [
  { value: 'pending', label: 'Pending', variant: 'secondary' },
  { value: 'paid', label: 'Paid', variant: 'default' },
  { value: 'failed', label: 'Failed', variant: 'destructive' },
  { value: 'refunded', label: 'Refunded', variant: 'outline' },
] as const;

export const TIME_SLOTS = [
  '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
] as const;

export const USER_ROLES = [
  { value: 'patient', label: 'Patient' },
  { value: 'doctor', label: 'Doctor' },
  { value: 'admin', label: 'Admin' },
] as const;

export const API_ENDPOINTS = {
  AUTH: {
    USER: '/api/auth/user',
    LOGIN: '/api/login',
    LOGOUT: '/api/logout',
  },
  DOCTORS: {
    LIST: '/api/doctors',
    PROFILE: '/api/doctors/profile',
  },
  APPOINTMENTS: {
    LIST: '/api/appointments',
    DOCTOR: '/api/appointments/doctor',
    PATIENT: '/api/appointments/patient',
  },
  PRESCRIPTIONS: {
    LIST: '/api/prescriptions',
    DOCTOR: '/api/prescriptions/doctor',
    PATIENT: '/api/prescriptions/patient',
  },
  MEDICAL_RECORDS: {
    LIST: '/api/medical-records',
    PATIENT: '/api/medical-records/patient',
  },
  INVOICES: {
    DOCTOR: '/api/invoices/doctor',
    PATIENT: '/api/invoices/patient',
  },
  PAYMENTS: {
    CREATE_INTENT: '/api/create-payment-intent',
  },
  STATS: {
    DOCTOR: '/api/stats/doctor',
    ADMIN: '/api/stats/admin',
  },
  ADMIN: {
    APPROVE_DOCTOR: '/api/admin/approve-doctor',
    PENDING_DOCTORS: '/api/admin/pending-doctors',
  },
} as const;

export const PWA_CONFIG = {
  NAME: 'MediBook',
  SHORT_NAME: 'MediBook',
  DESCRIPTION: 'Healthcare Appointment Platform',
  THEME_COLOR: '#3b82f6',
  BACKGROUND_COLOR: '#ffffff',
} as const;

export const DATE_FORMATS = {
  DISPLAY: 'MMM d, yyyy',
  INPUT: 'yyyy-MM-dd',
  TIME: 'HH:mm',
  DATETIME: 'MMM d, yyyy HH:mm',
} as const;
